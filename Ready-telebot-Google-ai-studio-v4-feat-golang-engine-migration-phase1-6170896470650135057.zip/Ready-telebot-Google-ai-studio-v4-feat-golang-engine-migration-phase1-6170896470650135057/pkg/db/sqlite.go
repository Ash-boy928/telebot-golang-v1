package db

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"time"

	"go-telebot/pkg/config"
	_ "modernc.org/sqlite"
)

var DB *sql.DB

func InitDB() error {
	dbPath := config.GetPath("telebot.db")

	var err error
	DB, err = sql.Open("sqlite", dbPath)
	if err != nil {
		return fmt.Errorf("failed to open sqlite database: %w", err)
	}

	// Configure SQLite PRAGMA WAL mode & connection settings
	if _, err := DB.Exec("PRAGMA journal_mode = WAL;"); err != nil {
		log.Printf("[DATABASE WARNING] Could not set WAL mode: %v", err)
	}
	if _, err := DB.Exec("PRAGMA synchronous = NORMAL;"); err != nil {
		log.Printf("[DATABASE WARNING] Could not set synchronous NORMAL: %v", err)
	}

	schema := `
      CREATE TABLE IF NOT EXISTS users (
        username TEXT PRIMARY KEY,
        password TEXT,
        role TEXT,
        active INTEGER,
        expiry_date TEXT,
        data_json TEXT,
        updated_at INTEGER
      );
      CREATE TABLE IF NOT EXISTS accounts (
        phone TEXT PRIMARY KEY,
        owner TEXT,
        label TEXT,
        running INTEGER,
        sent_count INTEGER,
        daily_sent_count INTEGER,
        data_json TEXT,
        updated_at INTEGER
      );
      CREATE TABLE IF NOT EXISTS billing_ledgers (
        username TEXT PRIMARY KEY,
        balance_due REAL,
        total_billed REAL,
        total_paid REAL,
        data_json TEXT,
        updated_at INTEGER
      );
      CREATE TABLE IF NOT EXISTS billing_invoices (
        id TEXT PRIMARY KEY,
        username TEXT,
        date TEXT,
        amount REAL,
        type TEXT,
        status TEXT,
        data_json TEXT,
        created_at INTEGER
      );
      CREATE TABLE IF NOT EXISTS billing_payments (
        id TEXT PRIMARY KEY,
        username TEXT,
        date TEXT,
        amount REAL,
        mode TEXT,
        reference TEXT,
        data_json TEXT,
        created_at INTEGER
      );
      CREATE TABLE IF NOT EXISTS daily_dm_history (
        owner TEXT,
        date TEXT,
        count INTEGER,
        phones_json TEXT,
        total_ids INTEGER,
        PRIMARY KEY (owner, date)
      );
      CREATE TABLE IF NOT EXISTS daily_join_history (
        owner TEXT,
        date TEXT,
        count INTEGER,
        joiners_json TEXT,
        PRIMARY KEY (owner, date)
      );
      CREATE TABLE IF NOT EXISTS sent_recipients (
        owner TEXT,
        uid INTEGER,
        phone TEXT,
        sent_at INTEGER,
        PRIMARY KEY (owner, uid)
      );
      CREATE TABLE IF NOT EXISTS growth_campaigns (
        id TEXT PRIMARY KEY,
        owner TEXT,
        campaign_slug TEXT UNIQUE,
        title TEXT,
        channel_username TEXT,
        channel_id TEXT,
        lock_message TEXT,
        unlock_content TEXT,
        banner_url TEXT,
        video_url TEXT,
        video_caption TEXT,
        audio_url TEXT,
        apk_url TEXT,
        apk_caption TEXT,
        contact_username TEXT,
        contact_button_text TEXT,
        contact_prefill_text TEXT,
        extra_buttons_json TEXT,
        button_text TEXT,
        status TEXT,
        created_at INTEGER,
        updated_at INTEGER
      );
      CREATE TABLE IF NOT EXISTS growth_subscribers (
        id TEXT PRIMARY KEY,
        owner TEXT,
        campaign_id TEXT,
        telegram_id INTEGER,
        username TEXT,
        first_name TEXT,
        last_name TEXT,
        is_joined INTEGER,
        joined_at INTEGER,
        last_active_at INTEGER,
        created_at INTEGER
      );
      CREATE TABLE IF NOT EXISTS growth_broadcasts (
        id TEXT PRIMARY KEY,
        owner TEXT,
        campaign_name TEXT,
        message_text TEXT,
        media_type TEXT,
        media_url TEXT,
        buttons_json TEXT,
        target_filter TEXT,
        total_targets INTEGER,
        sent_count INTEGER,
        failed_count INTEGER,
        status TEXT,
        created_at INTEGER,
        completed_at INTEGER
      );
      CREATE TABLE IF NOT EXISTS kv_store (
        key TEXT PRIMARY KEY,
        value_json TEXT,
        updated_at INTEGER
      );
	`

	if _, err := DB.Exec(schema); err != nil {
		return fmt.Errorf("failed to create database tables: %w", err)
	}

	// Columns migration for growth_campaigns table
	newGrowthCols := [][]string{
		{"video_url", "TEXT"},
		{"video_caption", "TEXT"},
		{"audio_url", "TEXT"},
		{"apk_url", "TEXT"},
		{"apk_caption", "TEXT"},
		{"contact_username", "TEXT"},
		{"contact_button_text", "TEXT"},
		{"contact_prefill_text", "TEXT"},
		{"extra_buttons_json", "TEXT"},
		{"billing_status", "TEXT DEFAULT 'active'"},
		{"customer_tg_id", "TEXT"},
		{"admin_notes", "TEXT"},
		{"bot_token", "TEXT"},
		{"bot_username", "TEXT"},
	}

	for _, col := range newGrowthCols {
		query := fmt.Sprintf("ALTER TABLE growth_campaigns ADD COLUMN %s %s;", col[0], col[1])
		_, _ = DB.Exec(query) // Ignore error if column already exists
	}

	log.Printf("[DATABASE] Pure-Go SQLite WAL Engine activated successfully (%s).", dbPath)
	return nil
}

func GetDbKv(key string) (string, error) {
	if DB == nil {
		return "", fmt.Errorf("database not initialized")
	}
	var val string
	err := DB.QueryRow("SELECT value_json FROM kv_store WHERE key = ?", key).Scan(&val)
	if err != nil {
		return "", err
	}
	return val, nil
}

func SetDbKv(key string, value interface{}) error {
	if DB == nil {
		return fmt.Errorf("database not initialized")
	}

	var jsonStr string
	if str, ok := value.(string); ok {
		jsonStr = str
	} else {
		bytes, err := json.Marshal(value)
		if err != nil {
			return err
		}
		jsonStr = string(bytes)
	}

	_, err := DB.Exec("INSERT OR REPLACE INTO kv_store (key, value_json, updated_at) VALUES (?, ?, ?)", key, jsonStr, time.Now().UnixMilli())
	return err
}

func CloseDB() {
	if DB != nil {
		_ = DB.Close()
	}
}
