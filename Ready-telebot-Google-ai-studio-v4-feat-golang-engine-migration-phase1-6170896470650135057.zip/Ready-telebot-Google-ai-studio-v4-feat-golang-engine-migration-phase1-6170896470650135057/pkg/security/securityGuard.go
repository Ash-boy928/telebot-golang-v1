package security

import (
	"crypto/rand"
	"crypto/subtle"
	"encoding/hex"
	"fmt"
	"os"
	"runtime"
	"strings"
	"sync"
	"time"

	"go-telebot/pkg/config"
	"golang.org/x/crypto/scrypt"
)

// HashVal generates a Scrypt hash string in the format: scrypt:<salt_hex>:<hash_hex>
// Uses exact parameters matching Node.js: N=16384, r=8, p=1, keyLen=64 with UTF-8 salt bytes.
func HashVal(plain string) (string, error) {
	if plain == "" {
		return "", nil
	}
	saltBytes := make([]byte, 16)
	if _, err := rand.Read(saltBytes); err != nil {
		return "", err
	}
	saltHex := hex.EncodeToString(saltBytes)

	// In Node.js crypto.scryptSync(plain, saltHex, 64), the salt argument string is interpreted as UTF-8 bytes!
	derivedKey, err := scrypt.Key([]byte(plain), []byte(saltHex), 16384, 8, 1, 64)
	if err != nil {
		return "", err
	}

	return fmt.Sprintf("scrypt:%s:%s", saltHex, hex.EncodeToString(derivedKey)), nil
}

// VerifyVal checks whether plain string matches stored hash format (scrypt:<salt>:<hash>, sha256:<hash>, or plaintext)
func VerifyVal(stored string, plain string) bool {
	if stored == "" {
		return false
	}

	// 1. Check scrypt format
	if strings.HasPrefix(stored, "scrypt:") {
		parts := strings.Split(stored, ":")
		if len(parts) == 3 {
			saltHex := parts[1]
			originalHashHex := parts[2]

			originalHash, err := hex.DecodeString(originalHashHex)
			if err != nil {
				return false
			}

			derivedKey, err := scrypt.Key([]byte(plain), []byte(saltHex), 16384, 8, 1, 64)
			if err != nil {
				return false
			}

			return subtle.ConstantTimeCompare(originalHash, derivedKey) == 1
		}
		return false
	}

	// 2. Fallback plaintext comparison
	return stored == plain
}

// EnforceSecureFilePermissions enforces chmod 600 on DB and Key files on POSIX
func EnforceSecureFilePermissions() {
	if runtime.GOOS == "windows" {
		return
	}

	targetFiles := []string{
		config.GetPath("secret.key"),
		config.GetPath("telebot.db"),
		config.GetPath("telebot.db-wal"),
		config.GetPath("telebot.db-shm"),
	}

	for _, f := range targetFiles {
		if _, err := os.Stat(f); err == nil {
			_ = os.Chmod(f, 0600)
		}
	}
}

// IP Brute-force rate limiter
type FailedAttempt struct {
	Count          int
	FirstAttemptAt time.Time
	LockedUntil    time.Time
}

var (
	failedLoginStore = make(map[string]*FailedAttempt)
	loginMutex       sync.RWMutex
)

const (
	MaxFailedAttempts = 5
	LockoutWindow     = 5 * time.Minute
	LockoutDuration   = 15 * time.Minute
)

func CheckIpLocked(ip string) (bool, int) {
	loginMutex.RLock()
	defer loginMutex.RUnlock()

	rec, exists := failedLoginStore[ip]
	if !exists {
		return false, 0
	}

	now := time.Now()
	if rec.LockedUntil.After(now) {
		remaining := int(rec.LockedUntil.Sub(now).Minutes()) + 1
		return true, remaining
	}
	return false, 0
}

func RecordFailedLoginAttempt(ip string) (bool, int) {
	loginMutex.Lock()
	defer loginMutex.Unlock()

	now := time.Now()
	rec, exists := failedLoginStore[ip]

	if !exists || (now.Sub(rec.FirstAttemptAt) > LockoutWindow && now.After(rec.LockedUntil)) {
		failedLoginStore[ip] = &FailedAttempt{
			Count:          1,
			FirstAttemptAt: now,
		}
		return false, MaxFailedAttempts - 1
	}

	rec.Count++
	if rec.Count >= MaxFailedAttempts {
		rec.LockedUntil = now.Add(LockoutDuration)
		return true, 0
	}

	return false, MaxFailedAttempts - rec.Count
}

func RecordSuccessfulLogin(ip string) {
	loginMutex.Lock()
	defer loginMutex.Unlock()
	delete(failedLoginStore, ip)
}
