package security_test

import (
	"os"
	"path/filepath"
	"testing"

	"go-telebot/pkg/config"
	"go-telebot/pkg/db"
	"go-telebot/pkg/security"
)

func TestScryptHashingAndVerification(t *testing.T) {
	plainPassword := "admin123"

	// Test Hash Generation
	hashStr, err := security.HashVal(plainPassword)
	if err != nil {
		t.Fatalf("Failed to generate Scrypt hash: %v", err)
	}

	if hashStr == "" {
		t.Fatalf("Expected non-empty hash string")
	}

	// Test Verification
	if !security.VerifyVal(hashStr, plainPassword) {
		t.Errorf("Expected password verification to succeed for correct password")
	}

	if security.VerifyVal(hashStr, "wrong_password") {
		t.Errorf("Expected password verification to fail for wrong password")
	}
}

func TestIpBruteForceRateLimiting(t *testing.T) {
	ip := "192.168.1.100"

	// Should not be locked initially
	locked, _ := security.CheckIpLocked(ip)
	if locked {
		t.Fatalf("IP should not be locked initially")
	}

	// Record 4 failed attempts
	for i := 0; i < 4; i++ {
		isLocked, remaining := security.RecordFailedLoginAttempt(ip)
		if isLocked {
			t.Fatalf("IP should not be locked on attempt %d", i+1)
		}
		if remaining != 4-i {
			t.Errorf("Expected %d remaining attempts, got %d", 4-i, remaining)
		}
	}

	// 5th attempt should lock out the IP
	isLocked, _ := security.RecordFailedLoginAttempt(ip)
	if !isLocked {
		t.Fatalf("IP should be locked on 5th failed attempt")
	}

	// Verify check returns locked
	locked, _ = security.CheckIpLocked(ip)
	if !locked {
		t.Fatalf("CheckIpLocked should return true for locked IP")
	}

	// Record successful login clears lockout
	security.RecordSuccessfulLogin(ip)
	locked, _ = security.CheckIpLocked(ip)
	if locked {
		t.Fatalf("CheckIpLocked should return false after successful login")
	}
}

func TestSQLiteDBAndKVStore(t *testing.T) {
	tempDir, err := os.MkdirTemp("", "telebot_test_*")
	if err != nil {
		t.Fatalf("Failed to create temp dir: %v", err)
	}
	defer os.RemoveAll(tempDir)

	config.SetRootDir(tempDir)

	err = db.InitDB()
	if err != nil {
		t.Fatalf("Failed to init SQLite DB: %v", err)
	}
	defer db.CloseDB()

	// Test KV Store Set & Get
	testKey := "test_master_secret"
	testVal := "supersecretkey12345678901234567890"

	err = db.SetDbKv(testKey, testVal)
	if err != nil {
		t.Fatalf("Failed to set KV in DB: %v", err)
	}

	retrieved, err := db.GetDbKv(testKey)
	if err != nil {
		t.Fatalf("Failed to get KV from DB: %v", err)
	}

	// JSON unmarshal since SetDbKv serializes strings as JSON string or text
	if retrieved != `"`+testVal+`"` && retrieved != testVal {
		t.Errorf("Expected %v, got %v", testVal, retrieved)
	}
}

func TestSecurityFilePermissionsGuard(t *testing.T) {
	tempDir, err := os.MkdirTemp("", "telebot_perm_test_*")
	if err != nil {
		t.Fatalf("Failed to create temp dir: %v", err)
	}
	defer os.RemoveAll(tempDir)

	config.SetRootDir(tempDir)
	dbFile := filepath.Join(tempDir, "telebot.db")
	_ = os.WriteFile(dbFile, []byte("dummy db content"), 0644)

	security.EnforceSecureFilePermissions()

	info, err := os.Stat(dbFile)
	if err != nil {
		t.Fatalf("Failed to stat db file: %v", err)
	}

	// Check permission is 0600 (-rw-------)
	if info.Mode().Perm() != 0600 {
		t.Errorf("Expected mode 0600, got %v", info.Mode().Perm())
	}
}
