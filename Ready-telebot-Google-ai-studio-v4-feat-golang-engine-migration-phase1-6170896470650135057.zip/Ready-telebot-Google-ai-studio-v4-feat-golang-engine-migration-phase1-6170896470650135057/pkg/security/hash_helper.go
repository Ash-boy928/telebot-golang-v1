package security

// HashValQuiet generates a Scrypt hash string strictly matching HashVal
func HashValQuiet(plain string) string {
	if plain == "" {
		return ""
	}
	hash, err := HashVal(plain)
	if err != nil {
		return ""
	}
	return hash
}
