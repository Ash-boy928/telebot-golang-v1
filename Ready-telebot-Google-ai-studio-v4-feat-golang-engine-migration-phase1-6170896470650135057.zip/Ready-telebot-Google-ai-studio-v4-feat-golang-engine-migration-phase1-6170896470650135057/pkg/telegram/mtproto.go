package telegram

import (
	"context"
	"fmt"
	"log"
	"sync"
	"time"

	"github.com/gotd/td/session"
	"github.com/gotd/td/telegram"
	"github.com/gotd/td/tg"
)

type AccountStatus struct {
	Phone               string `json:"phone"`
	Owner               string `json:"owner"`
	Label               string `json:"label"`
	Running             bool   `json:"running"`
	Status              string `json:"status"`
	SentCount           int    `json:"sent_count"`
	DailySentCount      int    `json:"daily_sent_count"`
	DailyExtractedCount int    `json:"daily_extracted_count"`
}

type MTProtoManager struct {
	mu       sync.RWMutex
	clients  map[string]*telegram.Client
	cancels  map[string]context.CancelFunc
	statuses map[string]*AccountStatus
}

var globalManager = &MTProtoManager{
	clients:  make(map[string]*telegram.Client),
	cancels:  make(map[string]context.CancelFunc),
	statuses: make(map[string]*AccountStatus),
}

func GetManager() *MTProtoManager {
	return globalManager
}

func (m *MTProtoManager) RegisterAccount(phone, owner, label string) {
	m.mu.Lock()
	defer m.mu.Unlock()

	if _, exists := m.statuses[phone]; !exists {
		m.statuses[phone] = &AccountStatus{
			Phone:  phone,
			Owner:  owner,
			Label:  label,
			Status: "Ready",
		}
	}
}

func (m *MTProtoManager) GetStatus(phone string) *AccountStatus {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if st, exists := m.statuses[phone]; exists {
		return st
	}
	return &AccountStatus{Phone: phone, Status: "Ready"}
}

func (m *MTProtoManager) GetAllStatuses() []*AccountStatus {
	m.mu.RLock()
	defer m.mu.RUnlock()

	list := make([]*AccountStatus, 0, len(m.statuses))
	for _, st := range m.statuses {
		list = append(list, st)
	}
	return list
}

func (m *MTProtoManager) StartClient(ctx context.Context, phone, sessionStr string, apiID int, apiHash string) error {
	m.mu.Lock()

	if _, running := m.clients[phone]; running {
		m.mu.Unlock()
		return fmt.Errorf("client for %s is already running", phone)
	}

	st, exists := m.statuses[phone]
	if !exists {
		st = &AccountStatus{Phone: phone, Status: "Starting..."}
		m.statuses[phone] = st
	}

	st.Running = true
	st.Status = "Connecting via gotd/td MTProto..."

	clientCtx, cancel := context.WithCancel(ctx)
	m.cancels[phone] = cancel

	opts := telegram.Options{}

	// Parse GramJS string session if provided
	if sessionStr != "" {
		gramSession, err := ParseGramJSStringSession(sessionStr)
		if err == nil && gramSession != nil {
			// Wire session data into gotd/td storage
			loader := session.Loader{
				Storage: new(session.StorageMemory),
			}
			data := session.Data{
				DC:        gramSession.DCID,
				Addr:      fmt.Sprintf("%s:%d", gramSession.IP, gramSession.Port),
				AuthKey:   gramSession.AuthKey,
				AuthKeyID: gramSession.AuthKey[:8],
			}
			_ = loader.Save(clientCtx, &data)
			opts.SessionStorage = loader.Storage
			log.Printf("[MTPROTO GOTD] GramJS Session loaded for %s (DC: %d, Addr: %s:%d)", phone, gramSession.DCID, gramSession.IP, gramSession.Port)
		} else {
			log.Printf("[MTPROTO GOTD WARNING] Could not parse GramJS session string for %s: %v", phone, err)
		}
	}

	client := telegram.NewClient(apiID, apiHash, opts)
	m.clients[phone] = client

	m.mu.Unlock()

	go func() {
		defer func() {
			m.mu.Lock()
			delete(m.clients, phone)
			delete(m.cancels, phone)
			if st, exists := m.statuses[phone]; exists {
				st.Running = false
				st.Status = "Stopped"
			}
			m.mu.Unlock()
		}()

		err := client.Run(clientCtx, func(ctx context.Context) error {
			m.mu.Lock()
			if st, exists := m.statuses[phone]; exists {
				st.Status = "🟢 Running (Connected)"
			}
			m.mu.Unlock()

			api := client.API()
			_ = api

			log.Printf("[MTPROTO GOTD] Account %s client loop active.", phone)
			<-ctx.Done()
			return ctx.Err()
		})

		if err != nil && err != context.Canceled {
			log.Printf("[MTPROTO GOTD ERROR] Account %s exited with error: %v", phone, err)
		}
	}()

	return nil
}

func (m *MTProtoManager) StopClient(phone string) {
	m.mu.Lock()
	defer m.mu.Unlock()

	if cancel, exists := m.cancels[phone]; exists {
		cancel()
	}
	if st, exists := m.statuses[phone]; exists {
		st.Running = false
		st.Status = "Stopped"
	}
}

// SendDirectMessage sends a Telegram message using gotd/td MTProto
func (m *MTProtoManager) SendDirectMessage(ctx context.Context, phone string, peerUsername string, messageText string) error {
	m.mu.RLock()
	client, exists := m.clients[phone]
	m.mu.RUnlock()

	if !exists {
		return fmt.Errorf("account %s client is not running", phone)
	}

	api := client.API()

	// Resolve username peer via gotd/td
	peer, err := api.ContactsResolveUsername(ctx, &tg.ContactsResolveUsernameRequest{
		Username: peerUsername,
	})
	if err != nil {
		return fmt.Errorf("failed to resolve username %s: %w", peerUsername, err)
	}

	if len(peer.Users) == 0 {
		return fmt.Errorf("user %s not found", peerUsername)
	}

	user := peer.Users[0].(*tg.User)
	inputUser := &tg.InputPeerUser{
		UserID:     user.ID,
		AccessHash: user.AccessHash,
	}

	// Send message via MTProto
	_, err = api.MessagesSendMessage(ctx, &tg.MessagesSendMessageRequest{
		Peer:     inputUser,
		Message:  messageText,
		RandomID: time.Now().UnixNano(),
	})

	if err != nil {
		return fmt.Errorf("failed to send MTProto message to %s: %w", peerUsername, err)
	}

	m.mu.Lock()
	if st, ok := m.statuses[phone]; ok {
		st.SentCount++
		st.DailySentCount++
	}
	m.mu.Unlock()

	return nil
}
