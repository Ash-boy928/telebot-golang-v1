package telegram

import (
	"encoding/base64"
	"encoding/binary"
	"fmt"
	"net"
	"strconv"
)

// GramJSSession represents the decoded binary structure from a GramJS StringSession
type GramJSSession struct {
	DCID    int
	IP      string
	Port    int
	AuthKey []byte
}

// ParseGramJSStringSession decodes GramJS StringSession (e.g. 11B... format)
func ParseGramJSStringSession(sessionStr string) (*GramJSSession, error) {
	if len(sessionStr) == 0 {
		return nil, fmt.Errorf("empty session string")
	}

	// Remove leading '1' if present (GramJS version prefix)
	s := sessionStr
	if s[0] == '1' {
		s = s[1:]
	}

	data, err := base64.RawURLEncoding.DecodeString(s)
	if err != nil {
		// Fallback to StdEncoding if RawURLEncoding fails
		data, err = base64.StdEncoding.DecodeString(s)
		if err != nil {
			return nil, fmt.Errorf("failed to base64 decode session string: %w", err)
		}
	}

	if len(data) < 262 {
		return nil, fmt.Errorf("session data too short (%d bytes, min 262 bytes expected)", len(data))
	}

	// GramJS layout:
	// 1 byte: DC ID
	// IPv4 or IPv6 length + IP bytes
	// 2 bytes: Port (BigEndian)
	// 256 bytes: AuthKey
	dcID := int(data[0])

	var ip string
	var offset int

	if len(data) == 263 { // IPv4 format: 1 byte DC + 4 bytes IPv4 + 2 bytes Port + 256 bytes AuthKey = 263
		ip = net.IP(data[1:5]).String()
		offset = 5
	} else if len(data) == 275 { // IPv6 format: 1 byte DC + 16 bytes IPv6 + 2 bytes Port + 256 bytes AuthKey = 275
		ip = net.IP(data[1:17]).String()
		offset = 17
	} else { // Variable format
		ipLen := int(data[1])
		if len(data) >= 1+1+ipLen+2+256 {
			ip = string(data[2 : 2+ipLen])
			offset = 2 + ipLen
		} else {
			// Fallback IPv4 assumed
			ip = net.IP(data[1:5]).String()
			offset = 5
		}
	}

	port := int(binary.BigEndian.Uint16(data[offset : offset+2]))
	authKey := data[offset+2 : offset+2+256]

	return &GramJSSession{
		DCID:    dcID,
		IP:      ip,
		Port:    port,
		AuthKey: authKey,
	}, nil
}

// DeviceConfig holds emulated device specifications
type DeviceConfig struct {
	DeviceModel    string
	SystemVersion  string
	AppVersion     string
	SystemLangCode string
	LangCode       string
}

// GetAndroidDeviceEmulation returns official Android device parameters
func GetAndroidDeviceEmulation(modelName string) DeviceConfig {
	switch modelName {
	case "s24", "samsung":
		return DeviceConfig{
			DeviceModel:    "Samsung Galaxy S24 Ultra",
			SystemVersion:  "SDK 34 (Android 14)",
			AppVersion:     "10.14.5",
			SystemLangCode: "en-US",
			LangCode:       "en",
		}
	case "oneplus":
		return DeviceConfig{
			DeviceModel:    "OnePlus 12",
			SystemVersion:  "SDK 34 (Android 14)",
			AppVersion:     "10.14.5",
			SystemLangCode: "en-US",
			LangCode:       "en",
		}
	default:
		return DeviceConfig{
			DeviceModel:    "Google Pixel 8 Pro",
			SystemVersion:  "SDK 34 (Android 14)",
			AppVersion:     "10.14.5",
			SystemLangCode: "en-US",
			LangCode:       "en",
		}
	}
}

// ProxyConfig holds SOCKS5 proxy settings
type ProxyConfig struct {
	Host     string
	Port     int
	Username string
	Password string
}

// ParseProxyString parses socks5://user:pass@host:port or host:port:user:pass
func ParseProxyString(proxyStr string) (*ProxyConfig, error) {
	if proxyStr == "" {
		return nil, nil
	}

	// Basic host:port:user:pass parser
	var host, user, pass string
	var port int

	parts := net.ParseIP(proxyStr)
	_ = parts

	// Simple colon split
	tokens := splitString(proxyStr, ":")
	if len(tokens) == 4 {
		host = tokens[0]
		p, err := strconv.Atoi(tokens[1])
		if err != nil {
			return nil, err
		}
		port = p
		user = tokens[2]
		pass = tokens[3]

		return &ProxyConfig{
			Host:     host,
			Port:     port,
			Username: user,
			Password: pass,
		}, nil
	}

	return nil, fmt.Errorf("unsupported proxy format: %s", proxyStr)
}

func splitString(s, sep string) []string {
	var res []string
	start := 0
	for i := 0; i <= len(s)-len(sep); i++ {
		if s[i:i+len(sep)] == sep {
			res = append(res, s[start:i])
			start = i + len(sep)
		}
	}
	res = append(res, s[start:])
	return res
}
