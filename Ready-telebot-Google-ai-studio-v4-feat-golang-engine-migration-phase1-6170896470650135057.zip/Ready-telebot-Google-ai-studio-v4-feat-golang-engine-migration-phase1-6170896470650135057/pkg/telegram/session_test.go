package telegram_test

import (
	"encoding/base64"
	"encoding/binary"
	"net"
	"testing"

	"go-telebot/pkg/telegram"
)

func TestParseGramJSStringSession(t *testing.T) {
	// Create dummy GramJS session payload (263 bytes)
	// 1 byte DC (2) + 4 bytes IPv4 (149.154.167.50) + 2 bytes Port (443) + 256 bytes AuthKey
	buf := make([]byte, 263)
	buf[0] = 2 // DC 2
	ip := net.ParseIP("149.154.167.50").To4()
	copy(buf[1:5], ip)
	binary.BigEndian.PutUint16(buf[5:7], 443)

	for i := 7; i < 263; i++ {
		buf[i] = byte(i % 256)
	}

	encoded := "1" + base64.RawURLEncoding.EncodeToString(buf)

	session, err := telegram.ParseGramJSStringSession(encoded)
	if err != nil {
		t.Fatalf("Failed to parse GramJS string session: %v", err)
	}

	if session.DCID != 2 {
		t.Errorf("Expected DC ID 2, got %d", session.DCID)
	}

	if session.IP != "149.154.167.50" {
		t.Errorf("Expected IP 149.154.167.50, got %s", session.IP)
	}

	if session.Port != 443 {
		t.Errorf("Expected Port 443, got %d", session.Port)
	}

	if len(session.AuthKey) != 256 {
		t.Errorf("Expected AuthKey length 256, got %d", len(session.AuthKey))
	}
}

func TestDeviceEmulationAndProxyParsing(t *testing.T) {
	device := telegram.GetAndroidDeviceEmulation("s24")
	if device.DeviceModel != "Samsung Galaxy S24 Ultra" {
		t.Errorf("Expected Samsung Galaxy S24 Ultra, got %s", device.DeviceModel)
	}

	proxy, err := telegram.ParseProxyString("127.0.0.1:1080:admin:pass123")
	if err != nil {
		t.Fatalf("Failed to parse proxy string: %v", err)
	}

	if proxy.Host != "127.0.0.1" || proxy.Port != 1080 || proxy.Username != "admin" || proxy.Password != "pass123" {
		t.Errorf("Unexpected proxy config: %+v", proxy)
	}
}
