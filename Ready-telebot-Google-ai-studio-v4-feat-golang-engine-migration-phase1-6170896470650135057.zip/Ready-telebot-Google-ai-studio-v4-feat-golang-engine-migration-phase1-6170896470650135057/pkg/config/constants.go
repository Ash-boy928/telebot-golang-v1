package config

import (
	"os"
	"path/filepath"
)

var (
	RootDir = "."
)

func SetRootDir(dir string) {
	RootDir = dir
}

func GetPath(filename string) string {
	return filepath.Join(RootDir, filename)
}

func GetPort() string {
	port := os.Getenv("PORT")
	if port == "" {
		return "3000"
	}
	return port
}

func GetAdminPassword() string {
	pass := os.Getenv("ADMIN_PASSWORD")
	if pass == "" {
		return "admin123"
	}
	return pass
}
