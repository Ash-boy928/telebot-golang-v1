package handlers

import (
	"fmt"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"go-telebot/pkg/db"
	"go-telebot/pkg/services/growth"
)

func ListCampaigns(c *gin.Context) {
	if db.DB == nil {
		c.JSON(http.StatusOK, gin.H{"ok": true, "campaigns": []growth.GrowthCampaign{}})
		return
	}

	rows, err := db.DB.Query("SELECT id, owner, campaign_slug, title, channel_username, status FROM growth_campaigns")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"ok": false, "msg": "Database query failed"})
		return
	}
	defer rows.Close()

	campaigns := make([]growth.GrowthCampaign, 0)
	for rows.Next() {
		var camp growth.GrowthCampaign
		if err := rows.Scan(&camp.ID, &camp.Owner, &camp.CampaignSlug, &camp.Title, &camp.ChannelUsername, &camp.Status); err == nil {
			campaigns = append(campaigns, camp)
		}
	}

	c.JSON(http.StatusOK, gin.H{
		"ok":        true,
		"campaigns": campaigns,
	})
}

type CreateCampaignRequest struct {
	Title           string `json:"title" binding:"required"`
	CampaignSlug    string `json:"campaign_slug" binding:"required"`
	ChannelUsername string `json:"channel_username"`
	UnlockContent   string `json:"unlock_content"`
}

func CreateCampaign(c *gin.Context) {
	var req CreateCampaignRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"ok": false, "msg": "Invalid campaign parameters"})
		return
	}

	campID := fmt.Sprintf("camp_%d", time.Now().UnixMilli())
	now := time.Now().UnixMilli()

	camp := growth.GrowthCampaign{
		ID:              campID,
		Owner:           "admin",
		CampaignSlug:    req.CampaignSlug,
		Title:           req.Title,
		ChannelUsername: req.ChannelUsername,
		UnlockContent:   req.UnlockContent,
		Status:          "active",
		CreatedAt:       now,
		UpdatedAt:       now,
	}

	if db.DB != nil {
		_, err := db.DB.Exec("INSERT INTO growth_campaigns (id, owner, campaign_slug, title, channel_username, unlock_content, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, 'active', ?, ?)",
			camp.ID, camp.Owner, camp.CampaignSlug, camp.Title, camp.ChannelUsername, camp.UnlockContent, now, now)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"ok": false, "msg": "Failed to insert campaign into database"})
			return
		}
	}

	c.JSON(http.StatusOK, gin.H{
		"ok":       true,
		"msg":      "Campaign created in SQLite database successfully",
		"campaign": camp,
	})
}
