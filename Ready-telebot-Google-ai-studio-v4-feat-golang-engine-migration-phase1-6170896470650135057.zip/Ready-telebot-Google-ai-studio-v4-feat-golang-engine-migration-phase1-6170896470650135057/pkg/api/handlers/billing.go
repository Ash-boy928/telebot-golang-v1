package handlers

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"go-telebot/pkg/db"
	"go-telebot/pkg/services/billing"
)

func GetBillingLedger(c *gin.Context) {
	username := c.Query("username")
	if username == "" {
		username = "admin"
	}

	invoices := getInvoicesFromDB(username)
	payments := getPaymentsFromDB(username)

	summary := billing.CalculateLedgerSummary(username, invoices, payments)

	c.JSON(http.StatusOK, gin.H{
		"ok":      true,
		"summary": summary,
	})
}

func ListInvoices(c *gin.Context) {
	username := c.Query("username")
	invoices := getInvoicesFromDB(username)

	c.JSON(http.StatusOK, gin.H{
		"ok":       true,
		"invoices": invoices,
	})
}

func ListPayments(c *gin.Context) {
	username := c.Query("username")
	payments := getPaymentsFromDB(username)

	c.JSON(http.StatusOK, gin.H{
		"ok":       true,
		"payments": payments,
	})
}

func getInvoicesFromDB(username string) []billing.BillingInvoice {
	if db.DB == nil {
		return []billing.BillingInvoice{}
	}

	var query string
	var err error
	var rows *sqlRows

	_ = err
	_ = rows

	if username != "" {
		query = "SELECT id, username, date, amount, type, status FROM billing_invoices WHERE username = ?"
		r, e := db.DB.Query(query, username)
		if e != nil {
			return []billing.BillingInvoice{}
		}
		defer r.Close()
		return parseInvoiceRows(r)
	}

	query = "SELECT id, username, date, amount, type, status FROM billing_invoices"
	r, e := db.DB.Query(query)
	if e != nil {
		return []billing.BillingInvoice{}
	}
	defer r.Close()
	return parseInvoiceRows(r)
}

type sqlRows interface {
	Next() bool
	Scan(dest ...interface{}) error
	Close() error
}

func parseInvoiceRows(rows sqlRows) []billing.BillingInvoice {
	invoices := make([]billing.BillingInvoice, 0)
	for rows.Next() {
		var inv billing.BillingInvoice
		if err := rows.Scan(&inv.ID, &inv.Username, &inv.Date, &inv.Amount, &inv.Type, &inv.Status); err == nil {
			invoices = append(invoices, inv)
		}
	}
	return invoices
}

func getPaymentsFromDB(username string) []billing.BillingPayment {
	if db.DB == nil {
		return []billing.BillingPayment{}
	}

	if username != "" {
		r, e := db.DB.Query("SELECT id, username, date, amount, mode, reference FROM billing_payments WHERE username = ?", username)
		if e != nil {
			return []billing.BillingPayment{}
		}
		defer r.Close()
		return parsePaymentRows(r)
	}

	r, e := db.DB.Query("SELECT id, username, date, amount, mode, reference FROM billing_payments")
	if e != nil {
		return []billing.BillingPayment{}
	}
	defer r.Close()
	return parsePaymentRows(r)
}

func parsePaymentRows(rows sqlRows) []billing.BillingPayment {
	payments := make([]billing.BillingPayment, 0)
	for rows.Next() {
		var p billing.BillingPayment
		if err := rows.Scan(&p.ID, &p.Username, &p.Date, &p.Amount, &p.Mode, &p.Reference); err == nil {
			payments = append(payments, p)
		}
	}
	return payments
}
