package handlers

import (
	"encoding/json"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"go-telebot/pkg/db"
	"go-telebot/pkg/security"
)

type UserItem struct {
	Username   string `json:"username"`
	Role       string `json:"role"`
	Active     bool   `json:"active"`
	ExpiryDate string `json:"expiry_date"`
}

func ListUsers(c *gin.Context) {
	if db.DB == nil {
		c.JSON(http.StatusOK, gin.H{"ok": true, "users": []UserItem{}})
		return
	}

	rows, err := db.DB.Query("SELECT username, role, active, expiry_date FROM users")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"ok": false, "msg": "Database query failed"})
		return
	}
	defer rows.Close()

	users := make([]UserItem, 0)
	for rows.Next() {
		var u UserItem
		var activeInt int
		if err := rows.Scan(&u.Username, &u.Role, &activeInt, &u.ExpiryDate); err == nil {
			u.Active = (activeInt == 1)
			users = append(users, u)
		}
	}

	c.JSON(http.StatusOK, gin.H{
		"ok":    true,
		"users": users,
	})
}

type CreateUserRequest struct {
	Username   string `json:"username" binding:"required"`
	Password   string `json:"password" binding:"required"`
	Role       string `json:"role"`
	ExpiryDate string `json:"expiry_date"`
}

func CreateUser(c *gin.Context) {
	var req CreateUserRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"ok": false, "msg": "Invalid user details"})
		return
	}

	role := req.Role
	if role == "" {
		role = "user"
	}

	hashedPassword, err := security.HashVal(req.Password)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"ok": false, "msg": "Password hashing failed"})
		return
	}

	newUser := UserItem{
		Username:   req.Username,
		Role:       role,
		Active:     true,
		ExpiryDate: req.ExpiryDate,
	}

	dataJSON, _ := json.Marshal(newUser)

	if db.DB != nil {
		_, err = db.DB.Exec("INSERT OR REPLACE INTO users (username, password, role, active, expiry_date, data_json, updated_at) VALUES (?, ?, ?, 1, ?, ?, ?)",
			req.Username, hashedPassword, role, req.ExpiryDate, string(dataJSON), time.Now().UnixMilli())
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"ok": false, "msg": "Failed to create user in database"})
			return
		}
	}

	c.JSON(http.StatusOK, gin.H{
		"ok":   true,
		"msg":  "User created in database successfully",
		"user": newUser,
	})
}
