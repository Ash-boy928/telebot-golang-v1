package handlers

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"time"

	"github.com/gin-gonic/gin"
	"go-telebot/pkg/config"
	"go-telebot/pkg/db"
	"go-telebot/pkg/telegram"
)

type AccountItem struct {
	Phone               string `json:"phone"`
	Owner               string `json:"owner"`
	Label               string `json:"label"`
	Running             bool   `json:"running"`
	SentCount           int    `json:"sent_count"`
	DailySentCount      int    `json:"daily_sent_count"`
	DailyExtractedCount int    `json:"daily_extracted_count"`
}

func ListAccounts(c *gin.Context) {
	if db.DB == nil {
		c.JSON(http.StatusOK, gin.H{"ok": true, "accounts": []AccountItem{}})
		return
	}

	rows, err := db.DB.Query("SELECT phone, owner, label, running, sent_count, daily_sent_count FROM accounts")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"ok": false, "msg": "Database query failed"})
		return
	}
	defer rows.Close()

	accounts := make([]AccountItem, 0)
	mgr := telegram.GetManager()

	for rows.Next() {
		var acc AccountItem
		var runningInt int
		if err := rows.Scan(&acc.Phone, &acc.Owner, &acc.Label, &runningInt, &acc.SentCount, &acc.DailySentCount); err == nil {
			acc.Running = (runningInt == 1)
			st := mgr.GetStatus(acc.Phone)
			if st != nil {
				acc.Running = st.Running
				acc.DailyExtractedCount = st.DailyExtractedCount
			}
			accounts = append(accounts, acc)
		}
	}

	c.JSON(http.StatusOK, gin.H{
		"ok":       true,
		"accounts": accounts,
	})
}

type AddAccountRequest struct {
	Phone   string `json:"phone" binding:"required"`
	Owner   string `json:"owner"`
	Label   string `json:"label"`
	ApiID   int    `json:"api_id"`
	ApiHash string `json:"api_hash"`
	Session string `json:"session"`
}

func AddAccount(c *gin.Context) {
	var req AddAccountRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"ok": false, "msg": "Invalid account parameters"})
		return
	}

	owner := req.Owner
	if owner == "" {
		owner = "admin"
	}
	label := req.Label
	if label == "" {
		label = req.Phone
	}

	dataJSON, _ := json.Marshal(req)

	if db.DB != nil {
		_, _ = db.DB.Exec("INSERT OR REPLACE INTO accounts (phone, owner, label, running, sent_count, daily_sent_count, data_json, updated_at) VALUES (?, ?, ?, 0, 0, 0, ?, ?)",
			req.Phone, owner, label, string(dataJSON), time.Now().UnixMilli())
	}

	mgr := telegram.GetManager()
	mgr.RegisterAccount(req.Phone, owner, label)

	c.JSON(http.StatusOK, gin.H{
		"ok":    true,
		"msg":   "Account registered in SQLite database successfully",
		"phone": req.Phone,
	})
}

type AccountActionRequest struct {
	Phone string `json:"phone" binding:"required"`
}

func fetchAccountSessionString(phone string) (string, int, string) {
	apiID := 2040
	apiHash := "b18441a1ff607e10a989891a5462e627"
	sessionStr := ""

	// 1. Try reading from SQLite data_json first
	if db.DB != nil {
		var dataJSON string
		err := db.DB.QueryRow("SELECT data_json FROM accounts WHERE phone = ?", phone).Scan(&dataJSON)
		if err == nil && dataJSON != "" {
			var parsed map[string]interface{}
			if err := json.Unmarshal([]byte(dataJSON), &parsed); err == nil {
				if s, ok := parsed["session"].(string); ok && s != "" {
					sessionStr = s
				}
				if id, ok := parsed["api_id"].(float64); ok && id > 0 {
					apiID = int(id)
				}
				if h, ok := parsed["api_hash"].(string); ok && h != "" {
					apiHash = h
				}
			}
		}
	}

	// 2. Fallback to session file session_+91xxxx.txt if sessionStr is empty
	if sessionStr == "" {
		sessFile := filepath.Join(config.RootDir, fmt.Sprintf("session_%s.txt", phone))
		if bytes, err := os.ReadFile(sessFile); err == nil {
			sessionStr = string(bytes)
		}
	}

	return sessionStr, apiID, apiHash
}

func StartAccount(c *gin.Context) {
	var req AccountActionRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"ok": false, "msg": "Phone is required"})
		return
	}

	sessionStr, apiID, apiHash := fetchAccountSessionString(req.Phone)

	if db.DB != nil {
		_, _ = db.DB.Exec("UPDATE accounts SET running = 1 WHERE phone = ?", req.Phone)
	}

	mgr := telegram.GetManager()
	err := mgr.StartClient(c.Request.Context(), req.Phone, sessionStr, apiID, apiHash)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"ok": false, "msg": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"ok":    true,
		"msg":   "Account started successfully",
		"phone": req.Phone,
	})
}

func StopAccount(c *gin.Context) {
	var req AccountActionRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"ok": false, "msg": "Phone is required"})
		return
	}

	if db.DB != nil {
		_, _ = db.DB.Exec("UPDATE accounts SET running = 0 WHERE phone = ?", req.Phone)
	}

	mgr := telegram.GetManager()
	mgr.StopClient(req.Phone)

	c.JSON(http.StatusOK, gin.H{
		"ok":    true,
		"msg":   "Account stopped successfully",
		"phone": req.Phone,
	})
}
