package api

import (
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
	"go-telebot/pkg/api/handlers"
	"go-telebot/pkg/config"
	"go-telebot/pkg/db"
	"go-telebot/pkg/security"
)

type LoginRequest struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

type UserRecord struct {
	Username string `json:"username"`
	Password string `json:"password"`
	Role     string `json:"role"`
	Active   int    `json:"active"`
}

func SetupRouter() *gin.Engine {
	gin.SetMode(gin.ReleaseMode)
	r := gin.New()
	r.Use(gin.Recovery())

	// Middleware for CORS
	r.Use(func(c *gin.Context) {
		c.Writer.Header().Set("Access-Control-Allow-Origin", "*")
		c.Writer.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		c.Writer.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(http.StatusNoContent)
			return
		}
		c.Next()
	})

	// Static Assets Serving
	rootDir := config.RootDir
	r.StaticFile("/", fmt.Sprintf("%s/index.html", rootDir))
	r.StaticFile("/index.html", fmt.Sprintf("%s/index.html", rootDir))
	r.StaticFile("/login.html", fmt.Sprintf("%s/login.html", rootDir))
	r.StaticFile("/admin.html", fmt.Sprintf("%s/admin.html", rootDir))
	r.StaticFile("/dashboard.html", fmt.Sprintf("%s/dashboard.html", rootDir))
	r.StaticFile("/landing.html", fmt.Sprintf("%s/landing.html", rootDir))

	// API Routes
	api := r.Group("/api")
	{
		api.POST("/login", handleLogin)
		api.GET("/health", handleHealth)
		api.GET("/events", handleSSEEvents)

		// Accounts Management
		api.GET("/accounts", handlers.ListAccounts)
		api.POST("/account/add", handlers.AddAccount)
		api.POST("/account/start", handlers.StartAccount)
		api.POST("/account/stop", handlers.StopAccount)

		// Users Management
		api.GET("/admin/users", handlers.ListUsers)
		api.POST("/admin/user/create", handlers.CreateUser)

		// Billing & Khatabook
		api.GET("/billing/ledger", handlers.GetBillingLedger)
		api.GET("/billing/invoices", handlers.ListInvoices)
		api.GET("/billing/payments", handlers.ListPayments)

		// Growth Campaigns
		api.GET("/campaigns", handlers.ListCampaigns)
		api.POST("/campaign/create", handlers.CreateCampaign)
	}

	return r
}

func handleLogin(c *gin.Context) {
	ip := c.ClientIP()
	if locked, mins := security.CheckIpLocked(ip); locked {
		c.JSON(http.StatusTooManyRequests, gin.H{
			"ok":                false,
			"msg":               fmt.Sprintf("🛡️ Security Lockout: Too many failed login attempts. Temporarily blocked for %d minute(s).", mins),
			"locked":            true,
			"remaining_minutes": mins,
		})
		return
	}

	var req LoginRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		security.RecordFailedLoginAttempt(ip)
		c.JSON(http.StatusBadRequest, gin.H{"ok": false, "msg": "Invalid request payload"})
		return
	}

	// 1. First check default environment admin password
	if req.Username == "admin" && (req.Password == config.GetAdminPassword() || security.VerifyVal(security.HashValQuiet(config.GetAdminPassword()), req.Password)) {
		security.RecordSuccessfulLogin(ip)
		c.JSON(http.StatusOK, gin.H{
			"ok":       true,
			"msg":      "Login successful",
			"token":    "admin_session_token_go_engine",
			"username": "admin",
			"role":     "admin",
		})
		return
	}

	// 2. Query SQLite users table for registered users
	if db.DB != nil {
		var u UserRecord
		var dataJSON string
		err := db.DB.QueryRow("SELECT username, password, role, active, data_json FROM users WHERE username = ?", req.Username).Scan(&u.Username, &u.Password, &u.Role, &u.Active, &dataJSON)
		if err == nil {
			if u.Active == 0 {
				security.RecordFailedLoginAttempt(ip)
				c.JSON(http.StatusForbidden, gin.H{"ok": false, "msg": "User account is disabled"})
				return
			}

			// Verify Scrypt password hash stored in database
			if security.VerifyVal(u.Password, req.Password) || u.Password == req.Password {
				security.RecordSuccessfulLogin(ip)
				role := u.Role
				if role == "" {
					role = "user"
				}
				token := fmt.Sprintf("%s_session_token_go_engine", u.Username)

				var parsed map[string]interface{}
				if err := json.Unmarshal([]byte(dataJSON), &parsed); err == nil {
					c.JSON(http.StatusOK, gin.H{
						"ok":       true,
						"msg":      "Login successful",
						"token":    token,
						"username": u.Username,
						"role":     role,
						"user":     parsed,
					})
					return
				}

				c.JSON(http.StatusOK, gin.H{
					"ok":       true,
					"msg":      "Login successful",
					"token":    token,
					"username": u.Username,
					"role":     role,
				})
				return
			}
		}
	}

	security.RecordFailedLoginAttempt(ip)
	c.JSON(http.StatusUnauthorized, gin.H{"ok": false, "msg": "Invalid username or password"})
}

func handleHealth(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{
		"status":  "ok",
		"engine":  "Golang High-Performance Engine",
		"version": "1.0.0",
	})
}

func handleSSEEvents(c *gin.Context) {
	c.Writer.Header().Set("Content-Type", "text/event-stream")
	c.Writer.Header().Set("Cache-Control", "no-cache")
	c.Writer.Header().Set("Connection", "keep-alive")

	c.SSEvent("message", "Go Engine SSE Connected Successfully")
	c.Writer.Flush()
}
