package api_test

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"go-telebot/pkg/api"
	"go-telebot/pkg/config"
)

func TestHealthEndpoint(t *testing.T) {
	config.SetRootDir(".")
	router := api.SetupRouter()

	req, _ := http.NewRequest("GET", "/api/health", nil)
	w := httptest.NewRecorder()
	router.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("Expected status 200, got %d", w.Code)
	}

	var resp map[string]interface{}
	_ = json.Unmarshal(w.Body.Bytes(), &resp)

	if resp["status"] != "ok" {
		t.Errorf("Expected status ok, got %v", resp["status"])
	}
}

func TestLoginEndpointSuccessAndFailure(t *testing.T) {
	config.SetRootDir(".")
	router := api.SetupRouter()

	// 1. Success test
	body, _ := json.Marshal(map[string]string{
		"username": "admin",
		"password": config.GetAdminPassword(),
	})

	req, _ := http.NewRequest("POST", "/api/login", bytes.NewBuffer(body))
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()
	router.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("Expected login success (200), got %d: %s", w.Code, w.Body.String())
	}

	// 2. Failure test
	failBody, _ := json.Marshal(map[string]string{
		"username": "admin",
		"password": "wrongpassword123",
	})

	failReq, _ := http.NewRequest("POST", "/api/login", bytes.NewBuffer(failBody))
	failReq.Header.Set("Content-Type", "application/json")
	failW := httptest.NewRecorder()
	router.ServeHTTP(failW, failReq)

	if failW.Code != http.StatusUnauthorized {
		t.Fatalf("Expected status 401 on wrong password, got %d", failW.Code)
	}
}
