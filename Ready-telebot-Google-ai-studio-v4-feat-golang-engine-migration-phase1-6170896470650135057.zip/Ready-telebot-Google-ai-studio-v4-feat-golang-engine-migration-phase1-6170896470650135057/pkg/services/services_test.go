package services_test

import (
	"testing"

	"go-telebot/pkg/services/ai"
	"go-telebot/pkg/services/billing"
)

func TestAiEngineRuleFilter(t *testing.T) {
	cfg := ai.GlobalAiConfig{
		FilterEnabled:        true,
		CustomAllowKeywords:  []string{"crypto_vip"},
		CustomRejectKeywords: []string{"scam_channel"},
	}

	users := []ai.BatchUserAnalysisInput{
		{UID: 1, FirstName: "Rabiul", About: "Join my crypto_vip group"},
		{UID: 2, FirstName: "Fake", About: "Join my scam_channel link"},
		{UID: 3, FirstName: "Clean", About: "Normal telegram user"},
	}

	res := ai.AnalyzeTelegramUsersBatch(cfg, users)

	if res[1].Status != "APPROVED" || res[1].Category != "whitelisted" {
		t.Errorf("Expected UID 1 APPROVED (whitelisted), got status: %s, cat: %s", res[1].Status, res[1].Category)
	}

	if res[2].Status != "REJECTED" || res[2].Category != "custom_rule" {
		t.Errorf("Expected UID 2 REJECTED (custom_rule), got status: %s, cat: %s", res[2].Status, res[2].Category)
	}

	if res[3].Status != "APPROVED" || res[3].Category != "clean" {
		t.Errorf("Expected UID 3 APPROVED (clean), got status: %s, cat: %s", res[3].Status, res[3].Category)
	}
}

func TestBillingLedgerSummary(t *testing.T) {
	invs := []billing.BillingInvoice{
		{ID: "inv1", Username: "user1", Amount: 100, Status: "due"},
		{ID: "inv2", Username: "user1", Amount: 50, Status: "due"},
	}

	pays := []billing.BillingPayment{
		{ID: "pay1", Username: "user1", Amount: 70, Mode: "UPI"},
	}

	summary := billing.CalculateLedgerSummary("user1", invs, pays)

	if summary.TotalBilled != 150 {
		t.Errorf("Expected TotalBilled 150, got %f", summary.TotalBilled)
	}

	if summary.TotalPaid != 70 {
		t.Errorf("Expected TotalPaid 70, got %f", summary.TotalPaid)
	}

	if summary.BalanceDue != 80 {
		t.Errorf("Expected BalanceDue 80, got %f", summary.BalanceDue)
	}
}
