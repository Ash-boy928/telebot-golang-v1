package billing

import (
	"math"
	"strings"
	"time"
)

type UserBillingConfig struct {
	IsDemo           bool    `json:"is_demo,omitempty"`
	RatePerDay       float64 `json:"rate_per_day,omitempty"`
	RatePerBot       float64 `json:"rate_per_bot,omitempty"`
	RatePerMonth     float64 `json:"rate_per_month,omitempty"`
	MaxAccounts      int     `json:"max_accounts,omitempty"`
	BillingCycleDays int     `json:"billing_cycle_days,omitempty"`
	PaymentModel     string  `json:"payment_model,omitempty"`
	Notes            string  `json:"notes,omitempty"`
}

type BillingInvoice struct {
	ID          string  `json:"id"`
	Username    string  `json:"username"`
	Date        string  `json:"date"`
	CreatedAt   int64   `json:"created_at"`
	Type        string  `json:"type"`
	Description string  `json:"description"`
	BotsCount   int     `json:"bots_count,omitempty"`
	DaysCount   int     `json:"days_count,omitempty"`
	Amount      float64 `json:"amount"`
	Status      string  `json:"status"` // due, paid, waived
}

type BillingPayment struct {
	ID        string  `json:"id"`
	Username  string  `json:"username"`
	Date      string  `json:"date"`
	CreatedAt int64   `json:"created_at"`
	Amount    float64 `json:"amount"`
	Mode      string  `json:"mode"` // UPI, Cash, USDT, etc.
	Reference string  `json:"reference,omitempty"`
	Note      string  `json:"note,omitempty"`
}

type LedgerSummary struct {
	Username      string  `json:"username"`
	TotalBilled   float64 `json:"total_billed"`
	TotalPaid     float64 `json:"total_paid"`
	TotalDiscount float64 `json:"total_discount"`
	BalanceDue    float64 `json:"balance_due"`
	InvoicesCount int     `json:"invoices_count"`
	PaymentsCount int     `json:"payments_count"`
}

func CalculateLedgerSummary(username string, invoices []BillingInvoice, payments []BillingPayment) LedgerSummary {
	var totalBilled float64
	var totalPaid float64
	var totalDiscount float64
	var invCount, payCount int

	uname := strings.ToLower(username)

	for _, inv := range invoices {
		if strings.ToLower(inv.Username) == uname {
			totalBilled += inv.Amount
			invCount++
		}
	}

	for _, pay := range payments {
		if strings.ToLower(pay.Username) == uname {
			if pay.Mode == "OFFER_DISCOUNT" {
				totalDiscount += pay.Amount
			} else {
				totalPaid += pay.Amount
				payCount++
			}
		}
	}

	balanceDue := math.Max(0, totalBilled-totalPaid-totalDiscount)

	return LedgerSummary{
		Username:      username,
		TotalBilled:   math.Round(totalBilled),
		TotalPaid:     math.Round(totalPaid),
		TotalDiscount: math.Round(totalDiscount),
		BalanceDue:    math.Round(balanceDue),
		InvoicesCount: invCount,
		PaymentsCount: payCount,
	}
}

func GetTodayDateString() string {
	return time.Now().Format("2006-01-02")
}

func FormatDisplayDate(dateStr string) string {
	if dateStr == "" {
		return "Active"
	}
	t, err := time.Parse("2006-01-02", dateStr)
	if err != nil {
		return dateStr
	}
	return t.Format("02/01/2006")
}

func GetDaysUntilExpiry(expiryDateStr string) int {
	if expiryDateStr == "" {
		return 999
	}
	tExp, err := time.Parse("2006-01-02", expiryDateStr)
	if err != nil {
		return 999
	}
	tToday, _ := time.Parse("2006-01-02", GetTodayDateString())

	diff := tExp.Sub(tToday)
	return int(math.Round(diff.Hours() / 24))
}
