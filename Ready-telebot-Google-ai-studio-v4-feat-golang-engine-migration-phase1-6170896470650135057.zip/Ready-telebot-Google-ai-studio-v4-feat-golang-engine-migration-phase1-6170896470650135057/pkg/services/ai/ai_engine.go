package ai

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"
)

type GlobalAiConfig struct {
	PrimaryProvider      string   `json:"primary_provider"` // gemini, groq, deepseek
	GeminiApiKey         string   `json:"gemini_api_key"`
	GroqApiKey           string   `json:"groq_api_key"`
	DeepseekApiKey       string   `json:"deepseek_api_key"`
	FilterEnabled        bool     `json:"filter_enabled"`
	FilterMode           string   `json:"filter_mode"`
	FilterStrictness     string   `json:"filter_strictness"`
	FilterPersona        string   `json:"filter_persona"`
	CustomAllowKeywords  []string `json:"custom_allow_keywords"`
	CustomRejectKeywords []string `json:"custom_reject_keywords"`
	RejectUsernames      bool     `json:"reject_usernames"`
}

type AiRequestInput struct {
	Task              string  `json:"task"`
	Prompt            string  `json:"prompt"`
	SystemInstruction string  `json:"system_instruction"`
	Temperature       float64 `json:"temperature"`
	JsonResponse      bool    `json:"json_response"`
}

type BatchUserAnalysisInput struct {
	UID       int64  `json:"uid"`
	FirstName string `json:"firstName"`
	LastName  string `json:"lastName"`
	Username  string `json:"username"`
	Phone     string `json:"phone"`
	About     string `json:"about"`
}

type BatchUserAnalysisResult struct {
	UID        int64   `json:"uid"`
	Status     string  `json:"status"` // APPROVED or REJECTED
	Reason     string  `json:"reason"`
	Category   string  `json:"category"`
	Confidence float64 `json:"confidence"`
}

// CallAiEngine routes the prompt to Gemini / Groq / DeepSeek REST API
func CallAiEngine(cfg GlobalAiConfig, req AiRequestInput) (string, error) {
	provider := strings.ToLower(cfg.PrimaryProvider)
	if provider == "" {
		provider = "gemini"
	}

	client := &http.Client{Timeout: 30 * time.Second}

	if provider == "gemini" && cfg.GeminiApiKey != "" {
		return callGeminiApi(client, cfg.GeminiApiKey, req)
	} else if provider == "groq" && cfg.GroqApiKey != "" {
		return callOpenAIStyleApi(client, "https://api.groq.com/openai/v1/chat/completions", cfg.GroqApiKey, "llama-3.3-70b-versatile", req)
	} else if provider == "deepseek" && cfg.DeepseekApiKey != "" {
		return callOpenAIStyleApi(client, "https://api.deepseek.com/chat/completions", cfg.DeepseekApiKey, "deepseek-chat", req)
	}

	return "", fmt.Errorf("no valid AI provider API key configured for provider: %s", provider)
}

func callGeminiApi(client *http.Client, apiKey string, req AiRequestInput) (string, error) {
	url := fmt.Sprintf("https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=%s", apiKey)

	payload := map[string]interface{}{
		"contents": []map[string]interface{}{
			{
				"parts": []map[string]interface{}{
					{"text": req.Prompt},
				},
			},
		},
	}

	if req.SystemInstruction != "" {
		payload["systemInstruction"] = map[string]interface{}{
			"parts": []map[string]interface{}{
				{"text": req.SystemInstruction},
			},
		}
	}

	bodyBytes, err := json.Marshal(payload)
	if err != nil {
		return "", err
	}

	httpReq, err := http.NewRequest("POST", url, bytes.NewBuffer(bodyBytes))
	if err != nil {
		return "", err
	}
	httpReq.Header.Set("Content-Type", "application/json")

	resp, err := client.Do(httpReq)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	respBuf, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	var parsed struct {
		Candidates []struct {
			Content struct {
				Parts []struct {
					Text string `json:"text"`
				} `json:"parts"`
			} `json:"content"`
		} `json:"candidates"`
	}

	if err := json.Unmarshal(respBuf, &parsed); err != nil {
		return "", fmt.Errorf("failed to parse Gemini response: %w", err)
	}

	if len(parsed.Candidates) > 0 && len(parsed.Candidates[0].Content.Parts) > 0 {
		return parsed.Candidates[0].Content.Parts[0].Text, nil
	}

	return "", fmt.Errorf("empty candidates in Gemini response")
}

func callOpenAIStyleApi(client *http.Client, url, apiKey, model string, req AiRequestInput) (string, error) {
	messages := []map[string]string{}
	if req.SystemInstruction != "" {
		messages = append(messages, map[string]string{"role": "system", "content": req.SystemInstruction})
	}
	messages = append(messages, map[string]string{"role": "user", "content": req.Prompt})

	payload := map[string]interface{}{
		"model":       model,
		"messages":    messages,
		"temperature": req.Temperature,
	}

	if req.JsonResponse {
		payload["response_format"] = map[string]string{"type": "json_object"}
	}

	bodyBytes, err := json.Marshal(payload)
	if err != nil {
		return "", err
	}

	httpReq, err := http.NewRequest("POST", url, bytes.NewBuffer(bodyBytes))
	if err != nil {
		return "", err
	}
	httpReq.Header.Set("Content-Type", "application/json")
	httpReq.Header.Set("Authorization", "Bearer "+apiKey)

	resp, err := client.Do(httpReq)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	respBuf, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	var parsed struct {
		Choices []struct {
			Message struct {
				Content string `json:"content"`
			} `json:"message"`
		} `json:"choices"`
	}

	if err := json.Unmarshal(respBuf, &parsed); err != nil {
		return "", fmt.Errorf("failed to parse AI response: %w", err)
	}

	if len(parsed.Choices) > 0 {
		return parsed.Choices[0].Message.Content, nil
	}

	return "", fmt.Errorf("empty choices in AI response")
}

// AnalyzeTelegramUsersBatch filters users using rules and AI
func AnalyzeTelegramUsersBatch(cfg GlobalAiConfig, users []BatchUserAnalysisInput) map[int64]BatchUserAnalysisResult {
	results := make(map[int64]BatchUserAnalysisResult)

	for _, u := range users {
		nameStr := strings.TrimSpace(u.FirstName + " " + u.LastName)
		textAll := strings.ToLower(strings.Join([]string{nameStr, u.Username, u.About}, " "))

		// 1. Custom Whitelist check
		whitelisted := false
		for _, allowKw := range cfg.CustomAllowKeywords {
			kw := strings.ToLower(strings.TrimSpace(allowKw))
			if kw != "" && strings.Contains(textAll, kw) {
				results[u.UID] = BatchUserAnalysisResult{
					UID:      u.UID,
					Status:   "APPROVED",
					Reason:   fmt.Sprintf("Matched custom whitelist keyword '%s'", allowKw),
					Category: "whitelisted",
				}
				whitelisted = true
				break
			}
		}
		if whitelisted {
			continue;
		}

		// 2. Custom Blacklist check
		blacklisted := false
		for _, rejectKw := range cfg.CustomRejectKeywords {
			kw := strings.ToLower(strings.TrimSpace(rejectKw))
			if kw != "" && strings.Contains(textAll, kw) {
				results[u.UID] = BatchUserAnalysisResult{
					UID:      u.UID,
					Status:   "REJECTED",
					Reason:   fmt.Sprintf("Matched custom blacklist keyword '%s'", rejectKw),
					Category: "custom_rule",
				}
				blacklisted = true
				break
			}
		}
		if blacklisted {
			continue;
		}

		// 3. Default Approval if AI filter disabled
		results[u.UID] = BatchUserAnalysisResult{
			UID:      u.UID,
			Status:   "APPROVED",
			Reason:   "Clean profile (Passed keyword inspection)",
			Category: "clean",
		}
	}

	return results
}
