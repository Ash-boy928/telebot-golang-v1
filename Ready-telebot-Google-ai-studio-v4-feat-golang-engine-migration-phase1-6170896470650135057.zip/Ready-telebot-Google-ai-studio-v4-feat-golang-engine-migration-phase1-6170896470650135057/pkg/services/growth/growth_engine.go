package growth

import (
	"context"
	"database/sql"
	"log"
	"math/rand"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"

	"go-telebot/pkg/db"
	"go-telebot/pkg/telegram"
)

type GrowthCampaign struct {
	ID                 string `json:"id"`
	Owner              string `json:"owner"`
	CampaignSlug       string `json:"campaign_slug"`
	Title              string `json:"title"`
	ChannelUsername    string `json:"channel_username"`
	ChannelID          string `json:"channel_id"`
	LockMessage        string `json:"lock_message"`
	UnlockContent      string `json:"unlock_content"`
	BannerURL          string `json:"banner_url"`
	VideoURL           string `json:"video_url"`
	VideoCaption       string `json:"video_caption"`
	AudioURL           string `json:"audio_url"`
	ApkURL             string `json:"apk_url"`
	ApkCaption         string `json:"apk_caption"`
	ContactUsername    string `json:"contact_username"`
	ContactButtonText  string `json:"contact_button_text"`
	ContactPrefillText string `json:"contact_prefill_text"`
	Status             string `json:"status"` // active, paused, archived
	CreatedAt          int64  `json:"created_at"`
	UpdatedAt          int64  `json:"updated_at"`
}

type GrowthSubscriber struct {
	ID           string `json:"id"`
	Owner        string `json:"owner"`
	CampaignID   string `json:"campaign_id"`
	TelegramID   int64  `json:"telegram_id"`
	Username     string `json:"username"`
	FirstName    string `json:"first_name"`
	LastName     string `json:"last_name"`
	IsJoined     bool   `json:"is_joined"`
	JoinedAt     int64  `json:"joined_at"`
	LastActiveAt int64  `json:"last_active_at"`
	CreatedAt    int64  `json:"created_at"`
}

type GrowthBroadcastJob struct {
	ID           string `json:"id"`
	Owner        string `json:"owner"`
	CampaignName string `json:"campaign_name"`
	MessageText  string `json:"message_text"`
	MediaType    string `json:"media_type"`
	MediaURL     string `json:"media_url"`
	TargetFilter string `json:"target_filter"` // all, joined_only, pending_only
	TotalTargets int    `json:"total_targets"`
	SentCount    int    `json:"sent_count"`
	FailedCount  int    `json:"failed_count"`
	Status       string `json:"status"` // pending, processing, completed, failed
	CreatedAt    int64  `json:"created_at"`
	CompletedAt  int64  `json:"completed_at"`
}

var (
	broadcastQueue = make([]*GrowthBroadcastJob, 0)
	queueMutex     sync.Mutex
	spintaxRegex   = regexp.MustCompile(`\{([^{}]+)\}`)
)

// ParseSpintax converts spintax string {Hi|Hello|Hey} into a random variation
func ParseSpintax(text string) string {
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	result := spintaxRegex.ReplaceAllStringFunc(text, func(match string) string {
		optionsStr := strings.Trim(match, "{}")
		options := strings.Split(optionsStr, "|")
		if len(options) == 0 {
			return match
		}
		return options[r.Intn(len(options))]
	})
	return result
}

func EnqueueBroadcastJob(job *GrowthBroadcastJob) {
	queueMutex.Lock()
	defer queueMutex.Unlock()
	job.Status = "pending"
	job.CreatedAt = time.Now().UnixMilli()
	broadcastQueue = append(broadcastQueue, job)
	log.Printf("[GROWTH ENGINE] Broadcast job %s enqueued for owner %s.", job.ID, job.Owner)
}

// GetSubscribersByFilter queries growth_subscribers table from SQLite database
func GetSubscribersByFilter(owner string, filter string) ([]GrowthSubscriber, error) {
	if db.DB == nil {
		return []GrowthSubscriber{}, nil
	}

	var query string
	var rows *sql.Rows
	var err error

	switch filter {
	case "joined_only":
		query = "SELECT id, owner, campaign_id, telegram_id, username, first_name, last_name, is_joined FROM growth_subscribers WHERE owner = ? AND is_joined = 1"
		rows, err = db.DB.Query(query, owner)
	case "pending_only":
		query = "SELECT id, owner, campaign_id, telegram_id, username, first_name, last_name, is_joined FROM growth_subscribers WHERE owner = ? AND is_joined = 0"
		rows, err = db.DB.Query(query, owner)
	default: // all
		query = "SELECT id, owner, campaign_id, telegram_id, username, first_name, last_name, is_joined FROM growth_subscribers WHERE owner = ?"
		rows, err = db.DB.Query(query, owner)
	}

	if err != nil {
		return nil, err
	}
	defer rows.Close()

	subscribers := make([]GrowthSubscriber, 0)
	for rows.Next() {
		var sub GrowthSubscriber
		var isJoinedInt int
		if err := rows.Scan(&sub.ID, &sub.Owner, &sub.CampaignID, &sub.TelegramID, &sub.Username, &sub.FirstName, &sub.LastName, &isJoinedInt); err == nil {
			sub.IsJoined = (isJoinedInt == 1)
			subscribers = append(subscribers, sub)
		}
	}

	return subscribers, nil
}

// ProcessNextBroadcastJob executes queued broadcast jobs across actual subscribers
func ProcessNextBroadcastJob() {
	queueMutex.Lock()
	if len(broadcastQueue) == 0 {
		queueMutex.Unlock()
		return
	}
	job := broadcastQueue[0]
	broadcastQueue = broadcastQueue[1:]
	queueMutex.Unlock()

	job.Status = "processing"
	mgr := telegram.GetManager()
	statuses := mgr.GetAllStatuses()

	var runningBotPhone string
	for _, st := range statuses {
		if st.Running {
			runningBotPhone = st.Phone
			break
		}
	}

	if runningBotPhone == "" {
		job.Status = "failed"
		log.Printf("[GROWTH ENGINE] Broadcast %s failed: No running bots available.", job.ID)
		return
	}

	subscribers, err := GetSubscribersByFilter(job.Owner, job.TargetFilter)
	if err != nil || len(subscribers) == 0 {
		job.Status = "completed"
		log.Printf("[GROWTH ENGINE] Broadcast %s finished: No subscribers matched filter '%s'.", job.ID, job.TargetFilter)
		return
	}

	job.TotalTargets = len(subscribers)
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()

	for _, sub := range subscribers {
		recipient := sub.Username
		if recipient == "" && sub.TelegramID != 0 {
			recipient = strconv.FormatInt(sub.TelegramID, 10)
		}
		if recipient == "" {
			continue
		}

		variedMsg := ParseSpintax(job.MessageText)
		err := mgr.SendDirectMessage(ctx, runningBotPhone, recipient, variedMsg)
		if err != nil {
			job.FailedCount++
		} else {
			job.SentCount++
		}
	}

	job.Status = "completed"
	job.CompletedAt = time.Now().UnixMilli()
	log.Printf("[GROWTH ENGINE] Broadcast %s completed. Sent: %d, Failed: %d out of %d subscribers.", job.ID, job.SentCount, job.FailedCount, job.TotalTargets)
}

// StartGrowthEnginePoller runs background loop for processing growth engine tasks
func StartGrowthEnginePoller() {
	go func() {
		ticker := time.NewTicker(3 * time.Second)
		defer ticker.Stop()

		for range ticker.C {
			ProcessNextBroadcastJob()
		}
	}()
	log.Println("[GROWTH ENGINE] Multi-bot broadcast & spintax poller started.")
}
