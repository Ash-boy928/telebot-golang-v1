package growth_test

import (
	"testing"

	"go-telebot/pkg/services/growth"
)

func TestSpintaxParser(t *testing.T) {
	input := "{Hi|Hello|Hey} friend! {Welcome|Greetings}"

	result := growth.ParseSpintax(input)

	if result == "" {
		t.Fatalf("Expected non-empty parsed spintax output")
	}

	if result == input {
		t.Errorf("Expected spintax variation to be resolved, got untouched template: %s", result)
	}
}
