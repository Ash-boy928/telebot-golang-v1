module.exports = {
  apps: [
    {
      name: 'telebot',
      script: 'server.ts',
      interpreter: 'node',
      node_args: '--experimental-strip-types --expose-gc --max-old-space-size=2560',
      max_memory_restart: '3800M',
      restart_delay: 3000,
      env: {
        NODE_ENV: 'production',
        PORT: 3000
      }
    }
  ]
};
