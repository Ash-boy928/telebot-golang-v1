import express from 'express';
import os from 'os';
import net from 'net';
import { execSync } from 'child_process';
import cookieSession from 'cookie-session';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

// Telegram MTProto Client (GramJS)
import { TelegramClient, Api, utils } from 'telegram';
import { StringSession } from 'telegram/sessions/index.js';

import { GoogleGenAI } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Core Configuration & Shared Constants
import {
  PORT,
  ADMIN_PASSWORD,
  USERS_FILE,
  ACCOUNTS_FILE,
  SECRET_KEY_FILE,
  MASTER_PROXY_FILE,
  THEME_CONFIG_FILE,
  SQLITE_DB_FILE,
  BILLING_FILE,
  ACCESS_REQUESTS_FILE,
  GLOBAL_AI_CONFIG_FILE,
  withTimeout
} from './src/config/constants.ts';

// ---------------- SQLITE CORRUPTION-PROOF DATABASE ENGINE (WAL MODE) ----------------
import { sqliteDb, getDbKv, setDbKv } from './src/db/sqlite.ts';

// ---------------- SECURITY HARDENING SUITE ----------------
import {
  enforceSecureFilePermissions,
  checkLoginBruteForce,
  recordFailedLoginAttempt,
  recordSuccessfulLogin,
  getClientIp
} from './src/security/securityGuard.ts';

// Auto-enforce Linux file permissions on startup (chmod 600 on DB & Secret Key)
enforceSecureFilePermissions();

// 🛡️ CRITICAL PROCESS CRASH SHIELDS (Prevents unexpected VPS / PM2 restarts on transient errors)
process.on('uncaughtException', (err: any) => {
  const errMsg = err?.message || String(err || '');
  console.error('🛡️ [CRASH SHIELD] Uncaught Exception caught (prevented process exit):', errMsg);
  if (/ECONNRESET|ETIMEDOUT|EPIPE|ESOCKETTIMEDOUT|Connection closed/i.test(errMsg)) {
    return;
  }
  if (err?.stack) {
    console.error(err.stack.split('\n').slice(0, 3).join('\n'));
  }
});

process.on('unhandledRejection', (reason: any) => {
  const reasonMsg = reason?.message || String(reason || '');
  console.error('🛡️ [CRASH SHIELD] Unhandled Promise Rejection caught (prevented process exit):', reasonMsg);
});

// ---------------- THEME & MASTER PROXY SERVICES ----------------
import {
  getGlobalTheme,
  saveGlobalTheme,
  masterProxyConfig,
  setMasterProxyConfig,
  loadMasterProxyConfig,
  saveMasterProxyConfig,
  getEffectiveProxyForAccount,
  type MasterProxyConfig
} from './src/services/proxyThemeService.ts';

// ---------------- NON-BLOCKING DEBOUNCED ASYNC FILE WRITER ----------------
import {
  asyncSaveJson,
  flushPendingFileWritesSync,
  fileWriteDebounceMap
} from './src/utils/fileWriter.ts';


// ==================== UNIVERSAL AI ENGINE & SWITCHING ARCHITECTURE ====================
import {
  globalAiConfig,
  loadGlobalAiConfigLocal,
  saveGlobalAiConfigLocal,
  loadGlobalAiConfig,
  saveGlobalAiConfig,
  callAiEngine,
  type GlobalAiConfig
} from './src/services/aiEngine.ts';

// ==================== GROWTH & BROADCAST MASTER ENGINE ====================
import {
  getGrowthBotConfig,
  saveGrowthBotConfig,
  testGrowthBotToken,
  getCampaignsByOwner,
  getAllCampaigns,
  getCampaignBySlug,
  getCampaignByCustomerTg,
  setCampaignBillingStatus,
  linkCampaignToCustomerTg,
  saveCampaign,
  deleteCampaign,
  getSubscribersByOwner,
  getGlobalSubscriberStats,
  createBroadcastJob,
  getBroadcastHistory,
  startGrowthBotPoller
} from './src/services/growthEngine.ts';

// BATCH AI PROFILE ANALYZER (Idea 2 & 4)
interface BatchUserAnalysisInput {
  uid: number;
  firstName?: string;
  lastName?: string;
  username?: string;
  phone?: string;
  about?: string;
}

interface BatchUserAnalysisResult {
  uid: number;
  status: "APPROVED" | "REJECTED";
  reason: string;
  category?: string;
  confidence?: number;
}

async function analyzeTelegramUsersBatch(
  users: BatchUserAnalysisInput[]
): Promise<Map<number, BatchUserAnalysisResult>> {
  const results = new Map<number, BatchUserAnalysisResult>();
  if (!users || users.length === 0) return results;

  // 1. Fast local check (custom keywords, deleted account, obvious spam keywords)
  const usersNeedingAi: BatchUserAnalysisInput[] = [];

  for (const u of users) {
    const nameStr = [u.firstName, u.lastName].filter(Boolean).join(" ");
    const textAll = [nameStr, u.username, u.about].filter(Boolean).join(" ").toLowerCase();

    // Check custom allow keywords first
    if (globalAiConfig.custom_allow_keywords?.length > 0) {
      const matchedAllow = globalAiConfig.custom_allow_keywords.find((k) => k && textAll.includes(k.toLowerCase().trim()));
      if (matchedAllow) {
        results.set(u.uid, {
          uid: u.uid,
          status: "APPROVED",
          reason: `Matched custom whitelist keyword "${matchedAllow}"`,
          category: "whitelisted"
        });
        continue;
      }
    }

    // Check custom reject keywords
    if (globalAiConfig.custom_reject_keywords?.length > 0) {
      const matchedReject = globalAiConfig.custom_reject_keywords.find((k) => k && textAll.includes(k.toLowerCase().trim()));
      if (matchedReject) {
        results.set(u.uid, {
          uid: u.uid,
          status: "REJECTED",
          reason: `Matched custom reject keyword "${matchedReject}"`,
          category: "custom_rule"
        });
        continue;
      }
    }

    // Check standard spam keyword rules
    const quickCheck = isTelegramUserSpamOrPromo({ firstName: u.firstName, lastName: u.lastName, username: u.username, about: u.about });
    if (quickCheck.isSpam) {
      results.set(u.uid, {
        uid: u.uid,
        status: "REJECTED",
        reason: quickCheck.reason,
        category: "spam_bio"
      });
      continue;
    }

    if (!globalAiConfig.filter_enabled || globalAiConfig.filter_mode === "smart_keyword") {
      // If AI filter is disabled or in pure keyword mode, approve immediately
      results.set(u.uid, {
        uid: u.uid,
        status: "APPROVED",
        reason: "Clean profile (Passed keyword inspection)",
        category: "clean"
      });
    } else {
      usersNeedingAi.push(u);
    }
  }

  if (usersNeedingAi.length === 0) {
    return results;
  }

  // 2. Process remaining users with Universal Batch AI
  const batchSize = 15;
  for (let i = 0; i < usersNeedingAi.length; i += batchSize) {
    const slice = usersNeedingAi.slice(i, i + batchSize);
    try {
      const profilesPayload = slice.map((u, idx) => ({
        id: u.uid,
        index: idx + 1,
        name: [u.firstName, u.lastName].filter(Boolean).join(" ") || "N/A",
        username: u.username ? `@${u.username.replace(/^@/, "")}` : "None",
        bio_about: u.about || "None"
      }));

      const systemPrompt = `${globalAiConfig.filter_persona || "You are an expert Telegram spam and lead auditor."}
Filter Strictness: ${globalAiConfig.filter_strictness.toUpperCase()}.
Task: Analyze each Telegram profile. Determine if it is a genuine normal user (APPROVED) or a spammer / scammer / promoter / trader / betting channel (REJECTED).
Output MUST be a valid JSON object with the following schema:
{
  "results": [
    {
      "id": <user_id_as_number>,
      "status": "APPROVED" or "REJECTED",
      "reason": "<short 4-8 word reason in English>",
      "category": "clean" or "trading" or "channel_promo" or "betting_casino" or "explicit_18" or "bot_fake" or "other_spam"
    }
  ]
}`;

      const promptText = `Analyze this batch of ${slice.length} Telegram profiles and return approval verdicts:
${JSON.stringify(profilesPayload, null, 2)}`;

      const rawAiResponse = await callAiEngine({
        task: "filtering",
        prompt: promptText,
        systemInstruction: systemPrompt,
        temperature: 0.1,
        jsonResponse: true
      });

      let parsed: any = null;
      try {
        const cleaned = rawAiResponse.replace(/^\s*```json/i, "").replace(/```\s*$/i, "").trim();
        parsed = JSON.parse(cleaned);
      } catch {
        const jsonMatch = rawAiResponse.match(/\{[\s\S]*\}/);
        if (jsonMatch) parsed = JSON.parse(jsonMatch[0]);
      }

      const resList = Array.isArray(parsed?.results) ? parsed.results : (Array.isArray(parsed) ? parsed : []);
      const parsedMap = new Map<number, any>();
      for (const item of resList) {
        const itemId = item?.id ?? item?.uid ?? item?.userId;
        if (itemId !== undefined && itemId !== null) parsedMap.set(Number(itemId), item);
      }

      for (let idx = 0; idx < slice.length; idx++) {
        const u = slice[idx];
        let aiItem = parsedMap.get(u.uid);
        if (!aiItem && slice.length === 1 && resList.length > 0) {
          aiItem = resList[0];
        }
        if (!aiItem && resList.find((r: any) => r?.index === idx + 1)) {
          aiItem = resList.find((r: any) => r?.index === idx + 1);
        }

        if (aiItem) {
          const isApproved = String(aiItem.status).toUpperCase() === "APPROVED";
          results.set(u.uid, {
            uid: u.uid,
            status: isApproved ? "APPROVED" : "REJECTED",
            reason: aiItem.reason || (isApproved ? "AI Approved (Genuine User)" : "AI Rejected (Spam/Promo detected)"),
            category: aiItem.category || (isApproved ? "clean" : "spam_bio")
          });
        } else {
          // Fallback safe approval if single profile was omitted by AI
          results.set(u.uid, {
            uid: u.uid,
            status: "APPROVED",
            reason: "Passed initial check (AI fallback)",
            category: "clean"
          });
        }
      }
    } catch (aiErr: any) {
      const errMsg = aiErr?.message || String(aiErr);
      console.warn("[BATCH AI FILTER ERROR]:", errMsg);
      // For real batch pipeline: don't block pipeline on API error, approve with fallback tag
      // For test bench (uid 999999999): surface the exact error to the tester
      for (const u of slice) {
        if (u.uid === 999999999) {
          results.set(u.uid, {
            uid: u.uid,
            status: "REJECTED",
            reason: `AI Call Error: ${errMsg}`,
            category: "error"
          });
        } else {
          results.set(u.uid, {
            uid: u.uid,
            status: "APPROVED",
            reason: "Approved (AI Provider unreachable / Fallback)",
            category: "clean"
          });
        }
      }
    }
  }

  return results;
}

// ---------------- STATE ----------------

const scanning_channels = new Map<string, string>(); // channel_id -> phone

function getISTDateString() {
  return new Date(Date.now() + 5.5 * 60 * 60 * 1000).toISOString().split('T')[0];
}
let lastResetDateIST = getISTDateString();

setInterval(async () => {
  const currentIST = getISTDateString();
  if (currentIST !== lastResetDateIST) {
    const finishedDate = lastResetDateIST;
    lastResetDateIST = currentIST;

    // Dispatch 12:00 AM midnight daily activity report for the finished day
    try {
      await sendMidnightDailyActivityReportToUsers(finishedDate);
    } catch (err) {
      console.error('[SYSTEM] Error sending midnight activity report:', err);
    }

    for (const [phone, a] of accounts.entries()) {
      a.daily_extracted_count = 0;
      (a as any).daily_extracted_date = currentIST;
      (a as any).daily_sent_count = 0;
      (a as any).daily_sent_date = currentIST;
      (a as any).peer_flood_consecutive = 0;
      (a as any).peer_flood_rest_cycles = 0;
      delete (a as any).dm_rest_until;
      delete (a as any).dm_peer_flood_exhausted;
      a.live_on = true;
      a.dm_on = true;
    }
    scanning_channels.clear();
    saveAccountsJson();
    console.log(`[SYSTEM] Daily quota reset at midnight IST for all accounts.`);
    try {
      const allOwners = new Set<string>(['admin', ...usersList.map((u: any) => u.username)]);
      for (const owner of allOwners) {
        broadcastAccountUpdate(owner);
      }
    } catch (e) {
      console.error('Error broadcasting midnight reset:', e);
    }
  }
}, 30000);

let usersList              = [];
const accounts                              = new Map();
const pendingAuthMap                           = new Map();
const logsMap                        = new Map();
const loginAttempts                                                = new Map();
const MAX_ATTEMPTS = 5;
const LOCK_SECONDS = 300;

// ---------------- TELEGRAM API RATE & HEALTH MONITOR TELEMETRY ----------------
interface ApiCallTimestamp {
  ts: number;
  type: string;
}

const apiCallHistoryMap = new Map<string, ApiCallTimestamp[]>(); // phone -> timestamps
const accountThrottleOverride = new Map<string, { throttled: boolean; reason: string; until: number }>(); // phone -> override

function recordApiCall(phone: string, type: string = 'generic') {
  const now = Date.now();
  let list = apiCallHistoryMap.get(phone);
  if (!list) {
    list = [];
    apiCallHistoryMap.set(phone, list);
  }
  list.push({ ts: now, type });
  // Retain only last 5 minutes of call history
  const fiveMinAgo = now - 5 * 60 * 1000;
  while (list.length > 0 && list[0].ts < fiveMinAgo) {
    list.shift();
  }
}

function getAccountRateStats(phone: string) {
  const now = Date.now();
  const list = apiCallHistoryMap.get(phone) || [];
  const oneMinAgo = now - 60 * 1000;
  const fiveMinAgo = now - 5 * 60 * 1000;
  
  const callsLast1Min = list.filter(c => c.ts >= oneMinAgo).length;
  const callsLast5Min = list.filter(c => c.ts >= fiveMinAgo).length;
  const rpm = callsLast1Min; // Requests Per Minute

  const override = accountThrottleOverride.get(phone);
  const isCustomThrottled = override && override.throttled && override.until > now;

  let healthStatus = 'optimal'; // optimal, warning, cooling, paused
  let healthLabel = '🟢 Optimal (Safe)';
  let safeColor = '#10b981';

  if (isCustomThrottled) {
    healthStatus = 'throttled';
    healthLabel = `🛡️ Throttled by Admin (${Math.ceil((override.until - now)/1000)}s)`;
    safeColor = '#f59e0b';
  } else if (rpm >= 25) {
    healthStatus = 'danger';
    healthLabel = '🔴 High Rate Warning';
    safeColor = '#ef4444';
  } else if (rpm >= 14) {
    healthStatus = 'elevated';
    healthLabel = '🟡 Elevated Activity';
    safeColor = '#f59e0b';
  }

  const dmsLast1Min = list.filter(c => c.ts >= oneMinAgo && c.type === 'dm').length;

  return {
    phone,
    rpm,
    callsLast5Min,
    dmsLast1Min,
    healthStatus,
    healthLabel,
    safeColor,
    isCustomThrottled: Boolean(isCustomThrottled),
    throttleSecondsRemaining: isCustomThrottled ? Math.ceil((override.until - now)/1000) : 0,
    lastCallTs: list.length > 0 ? list[list.length - 1].ts : 0
  };
}

function getSecretKey(): string {
  // 1. Try SQLite kv_store first (bulletproof permanent persistence)
  if (sqliteDb) {
    try {
      const row = sqliteDb.prepare("SELECT value_json FROM kv_store WHERE key = 'master_jwt_secret'").get();
      if (row && row.value_json) {
        const val = JSON.parse(row.value_json);
        if (val && typeof val === 'string' && val.length >= 32) {
          return val;
        }
      }
    } catch {}
  }
  // 2. Try secret.key file
  if (fs.existsSync(SECRET_KEY_FILE)) {
    const k = fs.readFileSync(SECRET_KEY_FILE, 'utf-8').trim();
    if (k.length >= 32) {
      if (sqliteDb) {
        try {
          sqliteDb.prepare("INSERT OR REPLACE INTO kv_store (key, value_json, updated_at) VALUES ('master_jwt_secret', ?, ?)").run(JSON.stringify(k), Date.now());
        } catch {}
      }
      return k;
    }
  }
  // 3. Fallback: generate and save to SQLite and file
  const key = crypto.randomBytes(32).toString('hex');
  try {
    fs.writeFileSync(SECRET_KEY_FILE, key, 'utf-8');
  } catch {}
  if (sqliteDb) {
    try {
      sqliteDb.prepare("INSERT OR REPLACE INTO kv_store (key, value_json, updated_at) VALUES ('master_jwt_secret', ?, ?)").run(JSON.stringify(key), Date.now());
    } catch {}
  }
  return key;
}

let broadcastLogToSse: ((phone: string, line: string, ts: string) => void) | null = null;

function log(phone        , tag        , msg        ) {
  const ts = new Intl.DateTimeFormat('en-IN', {
    timeZone: 'Asia/Kolkata',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  }).format(new Date());
  const line = `[${ts}] [${tag}] ${msg}`;
  let list = logsMap.get(phone);
  if (!list) {
    list = [];
    logsMap.set(phone, list);
  }
  list.push(line);
  if (list.length > 200) {
    list.splice(0, 100);
  }
  // Only write meaningful non-spammy events to stdout (PM2 log) to save SSD
  const isSpammyIdleLog = tag === 'INFO' && (msg.includes('no live audio stream') || msg.includes('Next scan in') || msg.includes('Scanned'));
  if (!isSpammyIdleLog) {
    console.log(`[${phone}] ${line}`);
  }
  if (broadcastLogToSse) {
    try {
      broadcastLogToSse(phone, line, ts);
    } catch {}
  }
}

// ---------------- SECURITY (SCRYPT STRONG PASSWORD HASHING) ----------------
function hashVal(plain: string): string {
  if (!plain) return '';
  const salt = crypto.randomBytes(16).toString('hex');
  const derivedKey = crypto.scryptSync(String(plain), salt, 64);
  return `scrypt:${salt}:${derivedKey.toString('hex')}`;
}

function verifyVal(stored: string, plain: string): boolean {
  if (!stored) return false;
  // 1. Secure scrypt format: scrypt:<salt>:<hash>
  if (stored.startsWith('scrypt:')) {
    try {
      const parts = stored.split(':');
      if (parts.length === 3) {
        const salt = parts[1];
        const originalHash = parts[2];
        const derivedKey = crypto.scryptSync(String(plain || ''), salt, 64);
        return crypto.timingSafeEqual(Buffer.from(originalHash, 'hex'), derivedKey);
      }
    } catch {
      return false;
    }
  }
  // 2. Backward compatibility with legacy unsalted sha256
  if (stored.startsWith('sha256:')) {
    const legacyHash = 'sha256:' + crypto.createHash('sha256').update(String(plain || '')).digest('hex');
    return stored === legacyHash;
  }
  // 3. Fallback plaintext comparison
  return stored === plain;
}

// ---------------- USER SYSTEM ----------------

function saveUsersLocal() {
  if (sqliteDb) {
    try {
      const stmt = sqliteDb.prepare(`INSERT OR REPLACE INTO users (username, password, role, active, expiry_date, data_json, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)`);
      for (const u of usersList) {
        stmt.run(u.username, u.password || '', u.role || 'user', u.active ? 1 : 0, u.expiry_date || '', JSON.stringify(u), Date.now());
      }
    } catch (e) {
      console.error('Error saving users to SQLite:', e);
    }
  }
  // Pure SQLite primary: Non-blocking debounced backup snapshot for users.json
  try {
    asyncSaveJson(USERS_FILE, usersList, 2000);
  } catch (e) {
    console.error('Error scheduling users.json backup:', e);
  }
}

const SLOT_REQUESTS_FILE = path.join(__dirname, 'slot_requests.json');

interface SlotRequest {
  id: string;
  username: string;
  phone: string;
  label: string;
  requested_at: number;
  status: 'pending' | 'approved' | 'rejected';
  resolved_at?: number;
  resolved_by?: string;
}

let slotRequests: SlotRequest[] = [];

function loadSlotRequestsLocal(): boolean {
  try {
    if (fs.existsSync(SLOT_REQUESTS_FILE)) {
      const raw = fs.readFileSync(SLOT_REQUESTS_FILE, 'utf8');
      const data = JSON.parse(raw);
      if (Array.isArray(data)) {
        slotRequests = data;
        return true;
      }
    }
  } catch (e) {}
  return false;
}

function saveSlotRequestsLocal() {
  try {
    fs.writeFileSync(SLOT_REQUESTS_FILE, JSON.stringify(slotRequests, null, 2), 'utf8');
  } catch (e) {}
}

async function loadSlotRequests() {
  loadSlotRequestsLocal();
}

function saveSlotRequests() {
  saveSlotRequestsLocal();
}

// ---------------- USER ACCESS & ONBOARDING REQUESTS ----------------

// ==========================================
// TELEBOT SMART KHATABOOK & BILLING ENGINE
// ==========================================
interface UserBillingConfig {
  is_demo?: boolean;
  rate_per_day?: number;
  rate_per_bot?: number;
  rate_per_month?: number;
  max_accounts?: number;
  billing_cycle_days?: number;
  payment_model?: string;
  demo_expiry?: string;
  currency?: string;
  notes?: string;
  [key: string]: any;
}

interface BillingInvoice {
  id: string;
  username: string;
  date: string;
  created_at: number;
  type: string;
  description: string;
  bots_count?: number;
  days_count?: number;
  amount: number;
  status: 'due' | 'paid' | 'waived';
  settled_at?: number;
  [key: string]: any;
}

interface BillingPayment {
  id: string;
  username: string;
  date: string;
  created_at: number;
  amount: number;
  mode: 'UPI' | 'Cash' | 'Bank Transfer' | 'USDT' | 'Other' | 'OFFER_DISCOUNT' | 'EXTRA_SERVICE' | string;
  reference?: string;
  note?: string;
}

interface DowntimeCompensationLog {
  id: string;
  date: string;
  created_at: number;
  affected_scope: 'global' | 'single_user' | 'single_account';
  target_username?: string;
  target_phone?: string;
  action_type: 'add_days' | 'rupee_credit';
  amount: number;
  reason: string;
}

interface BillingOffer {
  id: string;
  username: string;
  offer_name: string;
  discount_amount: number;
  bonus_days: number;
  note?: string;
  date: string;
  created_at: number;
}

interface BillingDataStore {
  settings: {
    default_rate_per_day: number;
    default_currency: string;
    domain?: string;
  };
  currency?: string;
  user_configs: Record<string, UserBillingConfig>;
  user_ledgers?: Record<string, any>;
  invoices: BillingInvoice[];
  payments: BillingPayment[];
  offers?: BillingOffer[];
  downtimes: DowntimeCompensationLog[];
  [key: string]: any;
}

let billingStore: BillingDataStore = {
  settings: {
    default_rate_per_day: 15,
    default_currency: 'INR'
  },
  user_configs: {},
  invoices: [],
  payments: [],
  offers: [],
  downtimes: []
};

function loadBillingLocal() {
  // 1. Try loading from SQLite first
  if (sqliteDb) {
    try {
      const kvRow = sqliteDb.prepare("SELECT value_json FROM kv_store WHERE key = 'billing_store'").get();
      if (kvRow && kvRow.value_json) {
        billingStore = JSON.parse(kvRow.value_json);
        console.log('[DATABASE] Billing store loaded safely from SQLite (telebot.db).');
        return true;
      }
    } catch (err) {
      console.warn('[DATABASE] SQLite loadBilling error, falling back to JSON:', err);
    }
  }

  // 2. Fallback to billing.json (and auto-migrate into SQLite if empty)
  try {
    if (fs.existsSync(BILLING_FILE)) {
      const raw = fs.readFileSync(BILLING_FILE, 'utf8');
      const data = JSON.parse(raw);
      if (data && typeof data === 'object') {
        billingStore = {
          settings: { default_rate_per_day: 10, default_currency: 'INR', ...(data.settings || {}) },
          user_configs: data.user_configs || {},
          invoices: Array.isArray(data.invoices) ? data.invoices : [],
          payments: Array.isArray(data.payments) ? data.payments : [],
          offers: Array.isArray(data.offers) ? data.offers : [],
          downtimes: Array.isArray(data.downtimes) ? data.downtimes : [],
          user_ledgers: data.user_ledgers || {}
        };
        // Auto-heal any corrupted configs or invoices where rate was divided by 7 (e.g. 1.43 instead of 10)
        let modified = false;
        if (billingStore.user_configs) {
          for (const uname of Object.keys(billingStore.user_configs)) {
            const cfg = billingStore.user_configs[uname];
            if (cfg) {
              const u = getUser(uname);
              const targetRate = Number(cfg.rate_per_bot) >= 5 ? Number(cfg.rate_per_bot) : (Number((u as any)?.rate_per_bot) >= 5 ? Number((u as any)?.rate_per_bot) : 10);
              if (cfg.rate_per_day !== undefined && (cfg.rate_per_day < 5 || cfg.rate_per_day === 1.43)) {
                cfg.rate_per_day = targetRate;
                modified = true;
              }
              if (!cfg.rate_per_bot || cfg.rate_per_bot < 5) {
                cfg.rate_per_bot = targetRate;
                modified = true;
              }
            }
          }
        }
        if (Array.isArray(billingStore.invoices)) {
          for (const inv of billingStore.invoices) {
            if (inv.type === 'daily_usage' || inv.type === 'weekly_plan_daily') {
              if (inv.description && (inv.description.includes('1.43') || inv.amount === 5.72 || (inv.bots_count && inv.amount < (inv.bots_count * 5)))) {
                const bots = inv.bots_count || 4;
                const rpb = getUserDailyRatePerBot(inv.username) || 10;
                inv.amount = bots * rpb;
                inv.description = `Daily Usage: ${bots} Live Bot(s) @ ₹${rpb}/bot/day = ₹${inv.amount}`;
                modified = true;
              }
            }
          }
        }
        if (modified) {
          saveBillingLocal();
        }

        // Auto-migrate to SQLite
        if (sqliteDb) {
          try {
            const kvStmt = sqliteDb.prepare(`INSERT OR REPLACE INTO kv_store (key, value_json, updated_at) VALUES (?, ?, ?)`);
            kvStmt.run('billing_store', JSON.stringify(billingStore), Date.now());
            console.log('[MIGRATION] Successfully auto-migrated billing store into SQLite.');
          } catch {}
        }
        return true;
      }
    }
  } catch (e) {
    console.error('Failed to load billing.json:', e);
  }
  return false;
}

function saveBillingLocal() {
  if (sqliteDb) {
    try {
      // 1. Save full store metadata into kv_store
      const kvStmt = sqliteDb.prepare(`INSERT OR REPLACE INTO kv_store (key, value_json, updated_at) VALUES (?, ?, ?)`);
      kvStmt.run('billing_store', JSON.stringify(billingStore), Date.now());

      // 2. Save individual ledgers
      const ledStmt = sqliteDb.prepare(`INSERT OR REPLACE INTO billing_ledgers (username, balance_due, total_billed, total_paid, data_json, updated_at) VALUES (?, ?, ?, ?, ?, ?)`);
      const ledgers = billingStore.user_ledgers || {};
      for (const [uname, l] of Object.entries(ledgers)) {
        const ledger = l as any;
        ledStmt.run(uname, ledger.balance_due || 0, ledger.total_billed || 0, ledger.total_paid || 0, JSON.stringify(ledger), Date.now());
      }

      // 3. Save recent invoices (last 500)
      const invStmt = sqliteDb.prepare(`INSERT OR REPLACE INTO billing_invoices (id, username, date, amount, type, status, data_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
      for (const inv of (billingStore.invoices || []).slice(-500)) {
        invStmt.run(inv.id || `${inv.username}_${inv.date}_${inv.amount}`, inv.username, inv.date, inv.amount, inv.type || 'weekly_plan', inv.status || 'due', JSON.stringify(inv), Date.now());
      }

      // 4. Save recent payments (last 500)
      const payStmt = sqliteDb.prepare(`INSERT OR REPLACE INTO billing_payments (id, username, date, amount, mode, reference, data_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
      for (const p of (billingStore.payments || []).slice(-500)) {
        payStmt.run(p.id || `${p.username}_${p.date}_${p.amount}`, p.username, p.date, p.amount, p.mode || 'UPI', p.reference || '', JSON.stringify(p), Date.now());
      }
    } catch (err) {
      console.error('Error saving billing to SQLite:', err);
    }
  }

  // Pure SQLite primary: Non-blocking debounced backup snapshot for billing.json
  try {
    asyncSaveJson(BILLING_FILE, billingStore, 2000);
  } catch (e) {
    console.error('Error scheduling billing.json backup:', e);
  }
}

function getUserEffectiveRate(username: string): number {
  if (billingStore.user_configs && billingStore.user_configs[username]) {
    const cfg = billingStore.user_configs[username];
    if (cfg.rate_per_bot && Number(cfg.rate_per_bot) >= 5) {
      return Number(cfg.rate_per_bot);
    }
    if (cfg.rate_per_day && Number(cfg.rate_per_day) >= 5) {
      return Number(cfg.rate_per_day);
    }
  }
  const u = getUser(username);
  if (u && (u as any).rate_per_bot && Number((u as any).rate_per_bot) >= 5) {
    return Number((u as any).rate_per_bot);
  }
  return Number(billingStore.settings.default_rate_per_day) || 10;
}

function addBillingInvoice(inv: any): BillingInvoice {
  const newInv: BillingInvoice = {
    ...inv,
    id: 'inv_' + Date.now() + '_' + Math.floor(100 + Math.random() * 900),
    created_at: Date.now()
  };
  billingStore.invoices.unshift(newInv);
  saveBillingLocal();
  return newInv;
}

function addBillingPayment(pay: any): BillingPayment {
  const newPay: BillingPayment = {
    ...pay,
    id: 'pay_' + Date.now() + '_' + Math.floor(100 + Math.random() * 900),
    created_at: Date.now()
  };
  billingStore.payments.unshift(newPay);
  saveBillingLocal();
  return newPay;
}

function getUserLedgerSummary(username: string) {
  if (!username) {
    return {
      username: '',
      total_billed: 0,
      total_paid: 0,
      total_discount: 0,
      total_bonus_days: 0,
      offers_count: 0,
      balance_due: 0,
      bot_billed: 0,
      bot_paid: 0,
      bot_due: 0,
      extra_billed: 0,
      extra_paid: 0,
      extra_due: 0,
      invoices_count: 0,
      payments_count: 0
    };
  }
  const uname = username.toLowerCase();
  const userInvs = billingStore.invoices.filter(i => (i.username || '').toLowerCase() === uname);
  const userPays = billingStore.payments.filter(p => (p.username || '').toLowerCase() === uname);
  const userOffers = (billingStore.offers || []).filter(o => (o.username || '').toLowerCase() === uname);
  
  const extraInvs = userInvs.filter(i => i.type === 'extra_service');
  const botInvs = userInvs.filter(i => i.type !== 'extra_service');

  // Real cash payments received ONLY (excluding offer discounts)
  const realPays = userPays.filter(p => p.mode !== 'OFFER_DISCOUNT' && !(p as any).is_offer);
  const extraPays = realPays.filter(p => (p as any).is_extra_service === true || p.mode === 'EXTRA_SERVICE' || ((p.reference || '').toLowerCase().includes('extra service')));
  const botPays = realPays.filter(p => !(p as any).is_extra_service && p.mode !== 'EXTRA_SERVICE' && !((p.reference || '').toLowerCase().includes('extra service')));

  const botBilled = botInvs.reduce((acc, i) => acc + Number(i.amount || 0), 0);
  const botPaid = botPays.reduce((acc, p) => acc + Number(p.amount || 0), 0);
  
  // Total discounts given to this user
  const userDiscountAmt = userOffers.reduce((acc, o) => acc + Number(o.discount_amount || 0), 0) +
    userPays.filter(p => p.mode === 'OFFER_DISCOUNT' || (p as any).is_offer).reduce((acc, p) => acc + Number(p.amount || 0), 0);
  const userBonusDays = userOffers.reduce((acc, o) => acc + Number(o.bonus_days || 0), 0);

  // Discount reduces bot due directly
  const botDue = Math.max(0, botBilled - botPaid - userDiscountAmt);

  const extraBilled = extraInvs.reduce((acc, i) => acc + Number(i.amount || 0), 0);
  const extraPaid = extraPays.reduce((acc, p) => acc + Number(p.amount || 0), 0);
  const extraDue = Math.max(0, extraBilled - extraPaid);

  const totalBilled = botBilled + extraBilled;
  const totalPaid = botPaid + extraPaid; // Real cash collected ONLY
  const balanceDue = botDue + extraDue;

  const summary = {
    username,
    total_billed: Math.round(totalBilled),
    total_paid: Math.round(totalPaid),
    total_discount: Math.round(userDiscountAmt),
    total_bonus_days: Math.round(userBonusDays),
    offers_count: userOffers.length,
    balance_due: Math.round(balanceDue),
    bot_billed: Math.round(botBilled),
    bot_paid: Math.round(botPaid),
    bot_due: Math.round(botDue),
    extra_billed: Math.round(extraBilled),
    extra_paid: Math.round(extraPaid),
    extra_due: Math.round(extraDue),
    invoices_count: userInvs.length,
    payments_count: realPays.length
  };
  if (!billingStore.user_ledgers) billingStore.user_ledgers = {};
  billingStore.user_ledgers[username] = summary;
  return summary;
}

// Universal DD/MM/YYYY Date Formatter for Telegram & UI
function formatDisplayDate(dateStr: string | number | Date | null | undefined): string {
  if (!dateStr) return 'Active';
  if (typeof dateStr === 'string') {
    const clean = dateStr.trim();
    if (clean.includes('T')) {
      const p = clean.split('T')[0].split('-');
      if (p.length === 3 && p[0].length === 4) return `${p[2]}/${p[1]}/${p[0]}`;
    }
    const parts = clean.split('-');
    if (parts.length === 3 && parts[0].length === 4) {
      return `${parts[2]}/${parts[1]}/${parts[0]}`;
    }
    return clean;
  }
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return 'Active';
    return new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Asia/Kolkata',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(d);
  } catch {
    return String(dateStr);
  }
}

function getDaysUntilExpiry(expiryDateStr: string): number {
  if (!expiryDateStr) return 999;
  try {
    const todayStr = getTodayDateString();
    const [tY, tM, tD] = todayStr.split('-').map(Number);
    const [eY, eM, eD] = expiryDateStr.split('-').map(Number);
    if (!tY || !tM || !tD || !eY || !eM || !eD) return 999;
    const todayUtc = Date.UTC(tY, tM - 1, tD);
    const expUtc = Date.UTC(eY, eM - 1, eD);
    return Math.round((expUtc - todayUtc) / (86400 * 1000));
  } catch {
    return 999;
  }
}

function getUserCycleDateRange(u: any): { startDate: string; expiryDate: string; formattedRange: string; daysRemaining: number } {
  if (!u) return { startDate: '', expiryDate: '', formattedRange: 'Active', daysRemaining: 999 };
  const expStr = (u.expiry_date || '').toString().trim();
  if (!expStr) return { startDate: '', expiryDate: '', formattedRange: 'Lifetime (No Expiry)', daysRemaining: 999 };

  const expFormatted = formatDisplayDate(expStr);
  const cfg = billingStore?.user_configs?.[u.username] || {};
  const cycleDays = Number(cfg.billing_cycle_days || u.billing_cycle_days || 7) || 7;

  let startStr = u.billing_start_date || (u as any).start_date || '';
  if (!startStr) {
    try {
      const expDate = new Date(expStr + 'T23:59:59Z');
      if (!isNaN(expDate.getTime())) {
        const startDateMs = expDate.getTime() - (cycleDays * 86400 * 1000);
        startStr = new Date(startDateMs).toISOString().split('T')[0];
      }
    } catch {
      startStr = getTodayDateString();
    }
  }
  const startFormatted = formatDisplayDate(startStr);

  const daysRemaining = getDaysUntilExpiry(expStr);

  const formattedRange = `${startFormatted} ➔ ${expFormatted} (${cycleDays} Days)`;
  return { startDate: startStr, expiryDate: expStr, formattedRange, daysRemaining };
}

// ---------------- LIVE BOT & DAILY ACCRUAL BILLING ENGINE ----------------
function getUserLiveBotsCount(username: string): number {
  if (!username) return 0;
  const uname = username.toLowerCase();
  let liveCount = 0;
  for (const a of accounts.values()) {
    if ((a.owner || 'admin').toLowerCase() === uname) {
      liveCount++;
    }
  }
  return liveCount;
}

function getUserDailyRatePerBot(username: string): number {
  const cfg = billingStore.user_configs?.[username];
  const u = getUser(username);
  if (cfg) {
    if (cfg.rate_per_bot && Number(cfg.rate_per_bot) >= 5) {
      return Number(cfg.rate_per_bot);
    }
    if (cfg.rate_per_day && Number(cfg.rate_per_day) >= 5) {
      return Number(cfg.rate_per_day);
    }
  }
  if (u && (u as any).rate_per_bot && Number((u as any).rate_per_bot) >= 5) {
    return Number((u as any).rate_per_bot);
  }
  return Number(billingStore.settings.default_rate_per_day) || 10;
}

function accrueDailyUsageForUser(username: string, dateStr: string = getTodayDateString()): boolean {
  if (!username || username.toLowerCase() === 'admin') return false;
  const u = getUser(username);
  if (!u || u.role === 'admin') return false;

  // Don't accrue if user is payment_paused or completely inactive
  if (!u.active || (u as any).payment_paused) return false;

  // Check if today's daily usage is already logged
  const alreadyBilled = billingStore.invoices.some(
    inv => (inv.username || '').toLowerCase() === username.toLowerCase() &&
           inv.date === dateStr &&
           (inv.type === 'daily_usage' || inv.type === 'weekly_plan_daily')
  );
  if (alreadyBilled) return false;

  const liveBots = getUserLiveBotsCount(username);
  if (liveBots <= 0) return false; // Only charge if user actually has live connected bots!

  const dailyRate = getUserDailyRatePerBot(username);
  const dailyAmount = liveBots * dailyRate;

  addBillingInvoice({
    username: u.username,
    date: dateStr,
    amount: dailyAmount,
    type: 'daily_usage',
    description: `Daily Usage: ${liveBots} Live Bot(s) @ ₹${dailyRate}/bot/day = ₹${dailyAmount}`,
    bots_count: liveBots,
    days_count: 1,
    status: 'due'
  });

  console.log(`[DAILY BILL ACCRUAL] User ${u.username}: +₹${dailyAmount} accrued for ${liveBots} live bots on ${dateStr}`);
  return true;
}

function accrueDailyUsageForAllUsers(dateStr: string = getTodayDateString()): number {
  let count = 0;
  for (const u of usersList) {
    if (u.role === 'admin' || !u.username) continue;
    if (accrueDailyUsageForUser(u.username, dateStr)) {
      count++;
    }
  }
  return count;
}

function applyPaymentAndCheckAutoExtend(
  username: string,
  amount: number,
  mode: string = 'UPI',
  note: string = '',
  reference: string = '',
  forceExtendDays?: number
): { payment: BillingPayment; summary: any; extended: boolean; newExpiry?: string; msg: string } {
  const pay = addBillingPayment({
    username,
    date: getTodayDateString(),
    amount: Math.round(Number(amount)),
    mode: (mode as any) || 'UPI',
    reference: reference || '',
    note: note || ''
  });

  const u = getUser(username);
  const summary = getUserLedgerSummary(username);
  let extended = false;
  let newExpiry = u?.expiry_date;
  let msg = `Payment of ₹${amount} recorded successfully for ${username}.`;

  if (u && u.role !== 'admin') {
    const cfg = billingStore.user_configs?.[username] || {};
    const cycleDays = (forceExtendDays !== undefined && forceExtendDays > 0)
      ? forceExtendDays
      : (Number(cfg.billing_cycle_days || u.billing_cycle_days || 7) || 7);

    // Business Logic: Plan validity extends if:
    // 1. All dues are cleared (balance_due <= 0), OR
    // 2. Admin explicitly requested validity extension on partial payment (e.g. ₹400 paid on ₹550 bill, ₹150 carried forward to next week)
    const shouldExtendValidity = summary.balance_due <= 0 || (forceExtendDays !== undefined && forceExtendDays > 0);

    if (shouldExtendValidity) {
      let curExpMs = Date.now() + 5.5 * 3600 * 1000;
      if (u.expiry_date) {
        const parsed = new Date(u.expiry_date + 'T23:59:59Z').getTime();
        if (!isNaN(parsed) && parsed > curExpMs) {
          curExpMs = parsed;
        }
      }
      const newExpMs = curExpMs + (cycleDays * 86400 * 1000);
      u.expiry_date = new Date(newExpMs).toISOString().split('T')[0];
      newExpiry = u.expiry_date;
      u.active = true;
      (u as any).payment_paused = false;
      (u as any).grace_period_until = null;
      extended = true;
      saveUsers();

      // If user had stopped/paused bots due to payment, unpause them!
      for (const a of accounts.values()) {
        if ((a.owner || 'admin').toLowerCase() === username.toLowerCase() && a.status === 'Paused (Payment Due)') {
          a.status = 'Ready (Payment Cleared)';
        }
      }

      const dateRange = getUserCycleDateRange(u);

      if (summary.balance_due <= 0) {
        msg += ` 🎉 All dues cleared! Validity automatically extended by +${cycleDays} Days to ${formatDisplayDate(u.expiry_date)}!`;
        sendTelegramAlert(username, `🎉 <b>Payment Cleared & Plan Extended!</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\n💵 <b>Amount Paid:</b> ₹${amount.toLocaleString()}\n💳 <b>Current Balance:</b> ₹0 (All Paid)\n📅 <b>Plan Validity:</b> <code>${dateRange.formattedRange}</code>\n⏳ <b>New Expiry Date:</b> <code>${formatDisplayDate(u.expiry_date)}</code> (+${cycleDays} Days Auto-Extended)\n\n⚡ Your bots are active, running, and ready!`).catch(() => null);
      } else {
        msg += ` 💵 Partial payment received. Remaining balance of ₹${summary.balance_due} carried forward to next week's bill. Validity extended by +${cycleDays} Days to ${formatDisplayDate(u.expiry_date)}!`;
        sendTelegramAlert(username, `💵 <b>Partial Payment Received & Days Extended!</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\n💵 <b>Amount Paid:</b> <b>₹${amount.toLocaleString()}</b>\n💳 <b>Remaining Due (Carried Forward):</b> <b>₹${summary.balance_due.toLocaleString()}</b>\n📅 <b>Plan Validity:</b> <code>${dateRange.formattedRange}</code>\n⏳ <b>New Expiry Date:</b> <code>${formatDisplayDate(u.expiry_date)}</code> (+${cycleDays} Days Extended)\n\nℹ️ <i>Remaining balance of ₹${summary.balance_due.toLocaleString()} has been carried forward and will be added to your next week's bill. Your bots are active, running, and ready!</i>`).catch(() => null);
      }
    } else {
      // Partial payment with NO validity extension requested
      msg += ` Partial payment received. Remaining balance due: ₹${summary.balance_due}. (Plan expiry not extended because outstanding balance is pending).`;
      const dateRange = getUserCycleDateRange(u);
      sendTelegramAlert(username, `💵 <b>Partial Payment Received</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\n💵 <b>Amount Paid:</b> <b>₹${amount.toLocaleString()}</b>\n💳 <b>Remaining Due:</b> <b>₹${summary.balance_due.toLocaleString()}</b>\n📅 <b>Current Validity:</b> <code>${dateRange.formattedRange}</code>\n⏳ <b>Expiry Date:</b> <code>${formatDisplayDate(u.expiry_date)}</code>\n\n⚠️ <i>Please clear the remaining balance of ₹${summary.balance_due.toLocaleString()} to extend your plan for the next cycle.</i>`).catch(() => null);
    }
  }

  saveBillingLocal();
  return { payment: pay, summary, extended, newExpiry, msg };
}

loadBillingLocal();

function autoSyncAllUsersIntoBilling(): number {
  const defRate = billingStore?.settings?.default_rate_per_day || 15;
  let added = 0;
  if (!billingStore.user_configs) billingStore.user_configs = {};

  // 1. Scan usersList
  if (Array.isArray(usersList)) {
    for (const u of usersList) {
      if (!u || !u.username) continue;
      const uname = (u.username || '').toString().trim();
      if (!uname || uname.toLowerCase() === 'admin' || u.role === 'admin') continue;
      if (!billingStore.user_configs[uname]) {
        billingStore.user_configs[uname] = { rate_per_day: defRate, notes: 'Auto-detected user' };
        added++;
      }
    }
  }

  // 2. Scan accounts owners
  try {
    for (const acc of Array.from(accounts.values())) {
      const owner = (acc.owner || '').toString().trim();
      if (owner && owner.toLowerCase() !== 'admin' && !billingStore.user_configs[owner]) {
        billingStore.user_configs[owner] = { rate_per_day: defRate, notes: 'Auto-detected bot owner' };
        added++;
      }
    }
  } catch(e) {}

  if (added > 0) {
    saveBillingLocal();
  }
  return added;
}

interface AccessRequest {
  id: string;
  chat_id: string;
  telegram_username?: string;
  full_name: string;
  phone: string;
  bots_count: number;
  validity_days: number;
  note?: string;
  type?: 'new_user' | 'extend_validity' | 'add_bots';
  target_username?: string;
  requested_at: number;
  status: 'pending' | 'approved' | 'rejected';
  resolved_at?: number;
  resolved_by?: string;
  created_username?: string;
  created_password?: string;
  rate_per_bot?: number;
  payment_model?: string;
  [key: string]: any;
}

let accessRequests: AccessRequest[] = [];

interface CustomerOnboardingSession {
  chat_id: string;
  telegram_username?: string;
  step: 'awaiting_name' | 'awaiting_phone' | 'awaiting_bots' | 'awaiting_validity' | 'confirm' | 'awaiting_custom_bots' | 'awaiting_custom_validity' | 'awaiting_ext_days' | 'awaiting_add_bots';
  type?: 'new_user' | 'extend_validity' | 'add_bots';
  target_username?: string;
  full_name?: string;
  phone?: string;
  bots_count?: number;
  validity_days?: number;
  note?: string;
  updated_at: number;
}
const customerOnboardingSessions = new Map<string, CustomerOnboardingSession>();

function loadAccessRequestsLocal(): boolean {
  try {
    if (fs.existsSync(ACCESS_REQUESTS_FILE)) {
      const raw = fs.readFileSync(ACCESS_REQUESTS_FILE, 'utf8');
      const data = JSON.parse(raw);
      if (Array.isArray(data)) {
        accessRequests = data;
        return true;
      }
    }
  } catch (e) {}
  return false;
}

function saveAccessRequestsLocal() {
  try {
    fs.writeFileSync(ACCESS_REQUESTS_FILE, JSON.stringify(accessRequests, null, 2), 'utf8');
  } catch (e) {}
}

async function loadAccessRequests() {
  loadAccessRequestsLocal();
}

function saveAccessRequests() {
  saveAccessRequestsLocal();
}

function syncUserRegisteredPhones() {
  for (const a of accounts.values()) {
    const owner = (a.owner || 'admin').trim();
    if (!owner || owner === 'admin') continue;
    const u = getUser(owner);
    if (u && a.phone) {
      if (!Array.isArray(u.registered_phones)) u.registered_phones = [];
      if (!u.registered_phones.includes(a.phone)) {
        u.registered_phones.push(a.phone);
      }
    }
  }
}

function loadUsersLocal(): boolean {
  // 1. Try loading from SQLite first
  if (sqliteDb) {
    try {
      const rows = sqliteDb.prepare('SELECT * FROM users').all();
      if (Array.isArray(rows) && rows.length > 0) {
        usersList = rows.map((r: any) => {
          try {
            const u = JSON.parse(r.data_json);
            if (!Array.isArray(u.registered_phones)) u.registered_phones = [];
            return u;
          } catch {
            return {
              username: r.username,
              password: r.password,
              role: r.role,
              active: Boolean(r.active),
              expiry_date: r.expiry_date,
              registered_phones: []
            };
          }
        });
        console.log(`[DATABASE] ${usersList.length} panel user(s) loaded safely from SQLite (telebot.db).`);
        return true;
      }
    } catch (e) {
      console.warn('[DATABASE] SQLite loadUsers error, falling back to JSON:', e);
    }
  }

  // 2. Fallback to users.json (and auto-migrate into SQLite if empty)
  try {
    if (fs.existsSync(USERS_FILE)) {
      const raw = fs.readFileSync(USERS_FILE, 'utf8');
      const data = JSON.parse(raw);
      if (Array.isArray(data) && data.length > 0) {
        usersList = data;
        for (const u of usersList) {
          if (!Array.isArray(u.registered_phones)) u.registered_phones = [];
        }
        console.log(`[PRIMARY CACHE] ${usersList.length} panel user(s) loaded from local users.json`);
        // Auto-migrate to SQLite
        if (sqliteDb) {
          try {
            const stmt = sqliteDb.prepare(`INSERT OR REPLACE INTO users (username, password, role, active, expiry_date, data_json, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)`);
            for (const u of usersList) {
              stmt.run(u.username, u.password || '', u.role || 'user', u.active ? 1 : 0, u.expiry_date || '', JSON.stringify(u), Date.now());
            }
            console.log(`[MIGRATION] Successfully auto-migrated ${usersList.length} users into SQLite.`);
          } catch {}
        }
        return true;
      }
    }
  } catch (e) {}
  return false;
}

async function loadUsers() {
  const loadedFromDisk = loadUsersLocal();

  if (!loadedFromDisk && usersList.length === 0) {
    usersList = [
      {
        username: 'admin',
        password: hashVal(ADMIN_PASSWORD),
        role: 'admin',
        active: true,
        max_accounts: 9999,
        max_targets: 9999,
        registered_phones: [],
        ai_enabled: true
      }
    ];
    saveUsersLocal();
    console.log(`[SECURITY] Initial admin account initialized successfully.`);
  }
}

function saveUsers() {
  saveUsersLocal();
}

function ensureAdminUser() {
  let admin = usersList.find((u) => (u.username || '').toLowerCase() === 'admin');
  if (!admin) {
    admin = {
      username: 'admin',
      password: hashVal(ADMIN_PASSWORD),
      role: 'admin',
      active: true,
      max_accounts: 9999,
      max_targets: 9999,
      security_question: '',
      security_answer: ''
    };
    usersList.unshift(admin);
    saveUsersLocal();
  }
  return admin;
}

function getUser(username        )                        {
  if (!username) return undefined;
  const clean = username.toString().trim().replace(/\s+/g, '').toLowerCase();
  if (clean === 'admin') {
    return ensureAdminUser();
  }
  return usersList.find((u) => (u.username || '').toString().trim().replace(/\s+/g, '').toLowerCase() === clean);
}

// Helper to register slash commands in the Telegram message box [☰ Menu]
const botCommandsRegisteredAt = new Map<string, number>();

async function registerTelegramBotCommands(botToken: string, force: boolean = false) {
  try {
    botToken = (botToken || '').trim();
    if (!botToken) return;

    const lastReg = botCommandsRegisteredAt.get(botToken) || 0;
    // Cache for 30 minutes unless forced
    if (!force && Date.now() - lastReg < 30 * 60 * 1000) {
      return;
    }

    const adminCommands = [
      { command: 'dm', description: '📊 User-wise DM Count (Today & 5-Days)' },
      { command: 'user', description: '👥 Total Users & Validity List' },
      { command: 'khatabook', description: '💳 Pending Dues & Balances' },
      { command: 'pay', description: '💰 Record Payment (e.g. /pay user 105)' },
      { command: 'remind', description: '📢 Send Payment Reminder to User' },
      { command: 'remindall', description: '🚨 Send Reminders to All Due Users' },
      { command: 'pause', description: '⏸️ Pause Bots for User (e.g. /pause user)' },
      { command: 'unpause', description: '▶️ Unpause Bots for User' },
      { command: 'menu', description: '👑 Open Master Admin Console' },
      { command: 'vps', description: '🖥️ Live VPS Health & Specs' },
      { command: 'requests', description: '📋 Pending Signup Requests' }
    ];

    const userCommands = [
      { command: 'mydm', description: '📊 My DM Stats (Today & 5-Days)' },
      { command: 'mybots', description: '📱 My Connected Bots & Status' },
      { command: 'bill', description: '💳 My Khatabook Ledger & Balance' },
      { command: 'payinfo', description: '📲 UPI Payment & Renewal Details' },
      { command: 'menu', description: '🎛️ Open My Bot Control Menu' }
    ];

    // 1. DEFAULT SCOPE (What ALL regular users and customers see globally in [☰ Menu]):
    // Strictly USER COMMANDS ONLY. Admin commands NEVER appear here!
    await fetch(`https://api.telegram.org/bot${botToken}/setMyCommands`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        commands: userCommands,
        scope: { type: 'default' }
      })
    }).catch(() => null);

    // 2. Also set all_private_chats scope to userCommands to ensure no residual admin commands show up
    await fetch(`https://api.telegram.org/bot${botToken}/setMyCommands`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        commands: userCommands,
        scope: { type: 'all_private_chats' }
      })
    }).catch(() => null);

    // 3. ADMIN PERSONAL CHAT SCOPE: ONLY the Admin's registered alert_chat_id gets admin commands!
    const adminUser = usersList.find((u) => u.role === 'admin' && (u.alert_bot_token || '').trim() === botToken);
    const adminChatId = String(adminUser?.alert_chat_id || '').trim();
    if (adminChatId) {
      await fetch(`https://api.telegram.org/bot${botToken}/setMyCommands`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          commands: adminCommands,
          scope: { type: 'chat', chat_id: adminChatId }
        })
      }).catch(() => null);
    }

    botCommandsRegisteredAt.set(botToken, Date.now());
  } catch (e) {}
}

// Global Billing Reminder Helper function (6th Day Gentle Reminder & 7th Day Due Reminder in Easy English):
async function sendUserBillingReminder(username: string, reminderType?: 'auto' | 'day6_gentle' | 'day7_due'): Promise<{ ok: boolean; msg: string }> {
  try {
    const u = usersList.find((x: any) => (x.username || '').toLowerCase() === (username || '').toLowerCase());
    if (!u) return { ok: false, msg: `User "${username}" not found.` };
    
    // Find admin user for bot token
    const adminUser = usersList.find((x: any) => x.role === 'admin' && (x.alert_bot_token || '').trim());
    const adminToken = adminUser ? (adminUser.alert_bot_token || '').trim() : '';

    // Target chat ID or Channel ID
    let targetChatId = (u.alert_chat_id || u.telegram_id || '').toString().trim();
    let targetBotToken = (u.alert_bot_token || '').trim() || adminToken;

    if (!targetChatId || !targetBotToken) {
      try {
        const camps = getCampaignsByOwner(u.username);
        const campWithBot = camps.find(c => c.bot_token && c.customer_tg_id);
        if (campWithBot) {
          if (!targetChatId && campWithBot.customer_tg_id) targetChatId = campWithBot.customer_tg_id.trim();
          if (!targetBotToken && campWithBot.bot_token) targetBotToken = campWithBot.bot_token.trim();
        }
      } catch {}
    }

    if (!targetBotToken || !targetChatId) {
      return { ok: false, msg: `⚠️ User ${u.username} does not have a linked Telegram Chat ID or Bot token configured.` };
    }

    // Refresh daily usage & ledger
    accrueDailyUsageForUser(u.username);
    const uLedger = getUserLedgerSummary(u.username);
    const balanceDue = Math.max(0, Number(uLedger.balance_due || 0));
    const curr = (billingStore.currency || 'INR') === 'INR' ? '₹' : '$';

    const diffDays = getDaysUntilExpiry(u.expiry_date);
    let effectiveType = reminderType || 'auto';
    if (effectiveType === 'auto') {
      if (diffDays === 1) {
        effectiveType = 'day6_gentle';
      } else {
        effectiveType = 'day7_due';
      }
    }

    const adminUpi = (adminUser as any)?.upi_id || (adminUser as any)?.gpay_number || '';
    const webLoginUrl = getWebLoginUrl();
    const displayName = u.display_name || u.username;

    let reminderMsg = '';

    if (effectiveType === 'day6_gentle') {
      // 6th Day Gentle Reminder (Strictly NO AMOUNT mentioned per user instruction)
      reminderMsg = `🔔 <b>Gentle Reminder: Bill Date Tomorrow</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `Hello <b>${displayName}</b>,\n\n` +
        `This is a gentle reminder that tomorrow is your official bill date for your TeleBot service.\n\n` +
        `Please clear your bill tomorrow to keep your bot active and avoid your bot being turned off.\n\n` +
        `🌐 <b>Dashboard:</b> ${webLoginUrl}\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━`;
    } else {
      // 7th Day Bill Date Reminder (DUE AMOUNT ONLY - excluding whatever has already been paid)
      if (balanceDue <= 0) {
        return { ok: true, msg: `User "${u.username}" has no pending dues (₹0 due). All clear!` };
      }

      reminderMsg = `⚠️ <b>Action Required: Today is Your Bill Date</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `Hello <b>${displayName}</b>,\n\n` +
        `Today is your official bill date for your TeleBot service. Please clear your remaining due amount to keep your bot active.\n\n` +
        `💰 <b>Pending Due Amount:</b> <b>${curr}${balanceDue.toLocaleString()}</b>\n\n` +
        (adminUpi ? `💳 <b>Payment UPI ID:</b> <code>${adminUpi}</code>\n\n` : '') +
        `Please clear your due amount today so your bot does not get turned off.\n` +
        `If you have already paid, please share the payment screenshot with Admin.\n\n` +
        `🌐 <b>Dashboard:</b> ${webLoginUrl}\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━`;
    }

    const res = await sendTelegramMessage(targetBotToken, targetChatId, reminderMsg);
    if (res && res.ok) {
      const typeLabel = effectiveType === 'day6_gentle' ? '6th-day gentle reminder (no amount)' : `7th-day bill date reminder (Due: ${curr}${balanceDue})`;
      return { ok: true, msg: `✅ ${typeLabel} sent in English to ${u.username} (Chat ID: ${targetChatId})!` };
    }
    return { ok: false, msg: `⚠️ Failed to dispatch Telegram message to ${u.username}.` };
  } catch (err: any) {
    return { ok: false, msg: err?.message || "Failed to dispatch reminder" };
  }
}

async function sendTelegramMessage(botToken, chatId, text, inlineKeyboard = null, messageIdToEdit = null) {
  botToken = (botToken || '').trim();
  chatId = (chatId || '').trim();
  try {
    if (!botToken || !chatId || !text) return null;
    const isEdit = Boolean(messageIdToEdit);
    const endpoint = isEdit ? 'editMessageText' : 'sendMessage';
    const url = `https://api.telegram.org/bot${botToken}/${endpoint}`;
    
    const payload: any = {
      chat_id: chatId,
      text: text,
      parse_mode: 'HTML'
    };
    if (isEdit) {
      payload.message_id = messageIdToEdit;
    }
    if (inlineKeyboard && inlineKeyboard.length > 0) {
      payload.reply_markup = { inline_keyboard: inlineKeyboard };
    }
    
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const json = await res.json().catch(() => null);
    if (!json?.ok) {
      console.error(`[TELEGRAM API ERROR]:`, json?.description || 'Unknown error');
    }
    return json;
  } catch (err) {
    console.error(`[TELEGRAM API EXCEPTION]:`, err?.message || err);
    return null;
  }
}

async function answerTelegramCallback(botToken, callbackQueryId, text = '') {
  try {
    if (!botToken || !callbackQueryId) return;
    const url = `https://api.telegram.org/bot${botToken}/answerCallbackQuery`;
    await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        callback_query_id: callbackQueryId,
        text: text
      })
    });
  } catch (e) {}
}

async function sendTelegramAlert(username: string, text: string) {
  try {
    if (!username) return;
    const u = getUser(username);
    if (!u) return;
    const adminUser = usersList.find((x: any) => x.role === 'admin' && (x.alert_bot_token || '').trim());
    const adminToken = adminUser ? (adminUser.alert_bot_token || '').trim() : '';
    const botToken = (u.alert_bot_token || '').trim() || adminToken;
    const chatId = (u.alert_chat_id || u.telegram_id || '').toString().trim();
    if (!botToken || !chatId) return;

    await sendTelegramMessage(botToken, chatId, text);
  } catch (err: any) {
    console.error(`[TELEGRAM ALERT ERROR for ${username}]:`, err?.message || err);
  }
}

function userLimits(username        )                   {
  const u = getUser(username);
  if (!u || u.role === 'admin') {
    return [9999, 9999];
  }
  return [Number(u.max_accounts || 5), Number(u.max_targets || 9999)];
}

// ---------------- GLOBAL API KEY POOL (UNLIMITED SLOTS) ----------------
interface ApiPoolSlot {
  id: number;
  slot_id: string;
  api_id: number;
  api_hash: string;
  label: string;
  enabled: boolean;
}

const API_POOL_FILE = path.join(__dirname, 'api_pool.json');

function defaultApiPool(): ApiPoolSlot[] {
  return [
    { id: 1, slot_id: 'api_1', api_id: 2040, api_hash: 'b18441a1ff607e10a989891a5462e627', label: 'Telegram Desktop Core', enabled: true },
    { id: 2, slot_id: 'api_2', api_id: 6, api_hash: 'eb06d4abfb49dc3eeb1aeb98ae0f581e', label: 'Telegram Android Official', enabled: true },
    { id: 3, slot_id: 'api_3', api_id: 2496, api_hash: '8da85b0d5b165239a5f4354c0e352885', label: 'Telegram Web Client', enabled: true },
    { id: 4, slot_id: 'api_4', api_id: 17349, api_hash: '344583e45741c457fe1862106095a5eb', label: 'Telegram macOS Client', enabled: true },
    { id: 5, slot_id: 'api_5', api_id: 2834, api_hash: '68875052ad42a40a766ee73f7c8730e6', label: 'Telegram iOS Client', enabled: true },
    { id: 6, slot_id: 'api_6', api_id: 21724, api_hash: '3e0cb5ab27680009c9dd7b439c063f25', label: 'Telegram X Android', enabled: true },
    { id: 7, slot_id: 'api_7', api_id: 0, api_hash: '', label: 'Custom Pool Slot 7', enabled: false },
    { id: 8, slot_id: 'api_8', api_id: 0, api_hash: '', label: 'Custom Pool Slot 8', enabled: false },
    { id: 9, slot_id: 'api_9', api_id: 0, api_hash: '', label: 'Custom Pool Slot 9', enabled: false },
    { id: 10, slot_id: 'api_10', api_id: 0, api_hash: '', label: 'Custom Pool Slot 10', enabled: false },
  ];
}

let apiPool: ApiPoolSlot[] = defaultApiPool();

function saveApiPoolLocal() {
  try {
    fs.writeFileSync(API_POOL_FILE, JSON.stringify(apiPool, null, 2), 'utf8');
  } catch (e) {
    console.error('Error saving api_pool.json locally:', e);
  }
}

function loadApiPoolLocal(): boolean {
  try {
    if (fs.existsSync(API_POOL_FILE)) {
      const raw = fs.readFileSync(API_POOL_FILE, 'utf8');
      const arr = JSON.parse(raw);
      if (Array.isArray(arr) && arr.length > 0) {
        apiPool = arr.map((x: any, idx: number) => ({
          id: Number(x.id) || (idx + 1),
          slot_id: String(x.slot_id || `api_${x.id || (idx + 1)}`).trim(),
          api_id: Number(x.api_id || 0),
          api_hash: String(x.api_hash || '').trim(),
          label: String(x.label || `Pool Slot #${x.id || (idx + 1)}`).trim(),
          enabled: x.enabled !== false
        }));
        console.log(`[PRIMARY CACHE] Global API pool (${apiPool.length} unlimited slots) loaded from api_pool.json`);
        return true;
      }
    }
  } catch (e) {
    console.error('Error loading api_pool.json:', e);
  }
  apiPool = defaultApiPool();
  saveApiPoolLocal();
  return false;
}

async function loadApiPool() {
  loadApiPoolLocal();
}

function saveApiPool() {
  saveApiPoolLocal();
}

function getBestApiCredentials(preferredApiId?: number, preferredApiHash?: string, preferredSlotId?: string | number): { api_id: number; api_hash: string; slot_id?: string; label?: string } {
  // 1. If explicit valid custom credentials passed, use them
  if (preferredApiId && preferredApiId > 0 && preferredApiHash && preferredApiHash.trim().length >= 8) {
    return { api_id: preferredApiId, api_hash: preferredApiHash.trim() };
  }

  // 2. If a specific pool slot ID or slot_id was requested by user
  if (preferredSlotId !== undefined && preferredSlotId !== null && String(preferredSlotId) !== 'auto') {
    const matchedSlot = apiPool.find(s => s.slot_id === String(preferredSlotId) || s.id === Number(preferredSlotId) || s.api_id === Number(preferredSlotId));
    if (matchedSlot && matchedSlot.enabled && matchedSlot.api_id > 0 && matchedSlot.api_hash && matchedSlot.api_hash.trim().length >= 8) {
      return { api_id: matchedSlot.api_id, api_hash: matchedSlot.api_hash.trim(), slot_id: matchedSlot.slot_id, label: matchedSlot.label };
    }
  }

  // 3. Otherwise balance across active enabled slots
  const activeSlots = apiPool.filter(s => s.enabled && s.api_id > 0 && s.api_hash && s.api_hash.trim().length >= 8);
  if (activeSlots.length === 0) {
    return { api_id: 2040, api_hash: 'b18441a1ff607e10a989891a5462e627', slot_id: 'api_1', label: 'Telegram Desktop Core' };
  }

  const slotCountMap = new Map<number, number>();
  for (const s of activeSlots) {
    slotCountMap.set(s.id, 0);
  }

  for (const acc of accounts.values()) {
    if (acc.api_id) {
      const match = activeSlots.find(s => s.api_id === acc.api_id);
      if (match) {
        slotCountMap.set(match.id, (slotCountMap.get(match.id) || 0) + 1);
      }
    }
  }

  let chosenSlot = activeSlots[0];
  let minCount = Infinity;
  for (const s of activeSlots) {
    const count = slotCountMap.get(s.id) || 0;
    if (count < minCount) {
      minCount = count;
      chosenSlot = s;
    }
  }

  return { api_id: chosenSlot.api_id, api_hash: chosenSlot.api_hash.trim(), slot_id: chosenSlot.slot_id, label: chosenSlot.label };
}

// ---------------- ACCOUNT HELPERS ----------------
function defaultConfig()                {
  return {
    use_master_config: true,
    ai_context: '',
    channel_link: '',
    targets: [],
    message_1: 'Join my channel!\n{CHANNEL_LINK}',
    message_2: 'Hello! Please check out my channel:\n{CHANNEL_LINK}',
    message_3: 'Awesome updates available here:\n{CHANNEL_LINK}',
    max_users: 200,
    check_interval: 60,
    delay_min: 60,
    delay_max: 120
  };
}

function getEffectiveConfig(a: any) {
  const base = a.config || defaultConfig();
  const owner = a.owner || 'admin';
  const u = getUser(owner);
  const master = u?.master_config;

  // 🛡️ Global Non-Target Group Links (Master Config) MUST ALWAYS be merged so bots never scan user's own channel!
  const masterTargets = Array.isArray(master?.targets) ? master.targets : [];
  const baseTargets = Array.isArray(base.targets) ? base.targets : [];
  const allTargets = Array.from(new Set([...masterTargets, ...baseTargets]));

  if (base.use_master_config !== false && master) {
    return {
      ...base,
      use_dynamic_templates: master.use_dynamic_templates !== undefined ? master.use_dynamic_templates : (u.ai_enabled === true),
      ai_context: master.ai_context || '',
      channel_link: master.channel_link || base.channel_link || '',
      targets: allTargets,
      message_1: master.message_1 || '',
      message_2: master.message_2 || '',
      message_3: master.message_3 || '',
      delay_min: master.delay_min !== undefined ? Number(master.delay_min) : (base.delay_min || 60),
      delay_max: master.delay_max !== undefined ? Number(master.delay_max) : (base.delay_max || 120),
      check_interval: master.check_interval !== undefined ? Number(master.check_interval) : (base.check_interval || 20),
      filter_bot_token: master.filter_bot_token || ''
    };
  }
  return {
    ...base,
    targets: allTargets,
    filter_bot_token: master?.filter_bot_token || ''
  };
}

function loadAccountsLocal(): boolean {
  const todayStr = getTodayDateString();

  // 1. Try loading accounts from SQLite first
  if (sqliteDb) {
    try {
      const rows = sqliteDb.prepare('SELECT * FROM accounts').all();
      if (Array.isArray(rows) && rows.length > 0) {
        for (const r of rows) {
          try {
            const item = JSON.parse(r.data_json);
            const phone = item.phone || r.phone;
            if (!phone) continue;
            loadPhoneData(phone);
            const cfg = { ...defaultConfig(), ...(item.config || {}) };
            const sentUsers = loadSentUsers(phone);
            const isSameDay = item.daily_sent_date === todayStr;
            const dailySentCount = isSameDay ? (item.daily_sent_count || 0) : 0;
            const sentCount = Math.max(item.sent_count || r.sent_count || 0, dailySentCount);
            const isSameDayExtracted = item.daily_extracted_date === todayStr;
            accounts.set(phone, {
              label: item.label || r.label || phone,
              phone,
              api_id: Number(item.api_id),
              api_hash: item.api_hash,
              username: item.username || '',
              owner: item.owner || r.owner || 'admin',
              config: cfg,
              running: false,
              persisted_running: Boolean(item.persisted_running),
              live_on: true,
              dm_on: true,
              sent_users: sentUsers,
              sent_count: sentCount,
              daily_sent_count: dailySentCount,
              daily_sent_date: todayStr,
              daily_collected_count: isSameDayExtracted ? (item.daily_collected_count || item.daily_extracted_count || 0) : 0,
              daily_extracted_count: isSameDayExtracted ? (item.daily_extracted_count || 0) : 0,
              daily_extracted_date: todayStr,
              status: item.persisted_running ? 'Auto-Resuming on Boot...' : 'Ready'
            });
          } catch {}
        }
        console.log(`[DATABASE] ${accounts.size} telegram account(s) loaded safely from SQLite (telebot.db).`);
        return true;
      }
    } catch (e) {
      console.warn('[DATABASE] SQLite loadAccounts error, falling back to JSON:', e);
    }
  }

  // 2. Fallback to accounts.json (and auto-migrate into SQLite if empty)
  try {
    if (fs.existsSync(ACCOUNTS_FILE)) {
      const raw = fs.readFileSync(ACCOUNTS_FILE, 'utf8');
      const arr = JSON.parse(raw);
      if (Array.isArray(arr) && arr.length > 0) {
        for (const item of arr) {
          const phone = item.phone;
          if (!phone) continue;
          loadPhoneData(phone);
          const cfg = { ...defaultConfig(), ...(item.config || {}) };
          const sentUsers = loadSentUsers(phone);
          const isSameDay = item.daily_sent_date === todayStr;
          const dailySentCount = isSameDay ? (item.daily_sent_count || 0) : 0;
          const sentCount = Math.max(item.sent_count || 0, dailySentCount);
          const isSameDayExtracted = item.daily_extracted_date === todayStr;
          accounts.set(phone, {
            label: item.label,
            phone,
            api_id: Number(item.api_id),
            api_hash: item.api_hash,
            username: item.username || '',
            owner: item.owner || 'admin',
            config: cfg,
            running: false,
            persisted_running: Boolean(item.persisted_running),
            live_on: true,
            dm_on: true,
            sent_users: sentUsers,
            sent_count: sentCount,
            daily_sent_count: dailySentCount,
            daily_sent_date: todayStr,
            daily_collected_count: isSameDayExtracted ? (item.daily_collected_count || item.daily_extracted_count || 0) : 0,
            daily_extracted_count: isSameDayExtracted ? (item.daily_extracted_count || 0) : 0,
            daily_extracted_date: todayStr,
            status: item.persisted_running ? 'Auto-Resuming on Boot...' : 'Ready'
          });
        }
        console.log(`[PRIMARY CACHE] ${accounts.size} telegram account(s) loaded from local accounts.json`);
        // Auto-migrate to SQLite
        if (sqliteDb) {
          try {
            const accStmt = sqliteDb.prepare(`INSERT OR REPLACE INTO accounts (phone, owner, label, running, sent_count, daily_sent_count, data_json, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
            for (const item of arr) {
              if (item.phone) {
                accStmt.run(item.phone, item.owner || 'admin', item.label || item.phone, item.persisted_running ? 1 : 0, item.sent_count || 0, item.daily_sent_count || 0, JSON.stringify(item), Date.now());
              }
            }
            console.log(`[MIGRATION] Successfully auto-migrated ${arr.length} accounts into SQLite.`);
          } catch {}
        }
        return true;
      }
    }
  } catch (e) {}
  return false;
}

async function loadAccounts() {
  loadAccountsLocal();
  for (const phone of accounts.keys()) {
    await loadPhoneData(phone);
  }
}

function saveAccountsLocal(): void {
  const list: any[] = [];
  const todayStr = getTodayDateString();
  for (const a of accounts.values()) {
    if (!a || !a.phone) continue;
    list.push({
      label: a.label || a.phone,
      phone: a.phone,
      api_id: Number(a.api_id),
      api_hash: a.api_hash || '',
      username: a.username || '',
      owner: a.owner || 'admin',
      config: a.config || defaultConfig(),
      persisted_running: Boolean((a as any).persisted_running ?? a.running),
      sent_count: typeof a.sent_count === 'number' ? a.sent_count : 0,
      daily_sent_count: typeof a.daily_sent_count === 'number' ? a.daily_sent_count : 0,
      daily_sent_date: a.daily_sent_date || todayStr,
      daily_collected_count: a.daily_collected_count ?? a.daily_extracted_count ?? 0,
      daily_extracted_count: a.daily_extracted_count ?? 0,
      daily_extracted_date: a.daily_extracted_date || todayStr
    });
  }

  // 1. Sync to SQLite (Primary Storage)
  if (sqliteDb) {
    try {
      const accStmt = sqliteDb.prepare(`INSERT OR REPLACE INTO accounts (phone, owner, label, running, sent_count, daily_sent_count, data_json, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
      for (const item of list) {
        accStmt.run(item.phone, item.owner || 'admin', item.label || item.phone, item.persisted_running ? 1 : 0, item.sent_count || 0, item.daily_sent_count || 0, JSON.stringify(item), Date.now());
      }
    } catch (e) {
      console.error('Error saving accounts to SQLite:', e);
    }
  }

  // 2. Pure SQLite primary: Non-blocking debounced backup snapshot for accounts.json
  try {
    asyncSaveJson(ACCOUNTS_FILE, list, 2000);
  } catch (e) {
    console.error('Error scheduling accounts.json backup:', e);
  }
}

async function saveAccountsJson() {
  saveAccountsLocal();
}

// 🛡️ UNINTERRUPTED AUTO-RESUME ON SERVER RESTART
// When PM2 or VPS restarts, any bot that was running before restart automatically resumes!
async function autoResumeRunningBotsOnStartup(): Promise<void> {
  const toResume = Array.from(accounts.values()).filter(a => (a as any).persisted_running && !a.running);
  if (toResume.length === 0) return;
  console.log(`[AUTO-RESUME ON BOOT] Resuming ${toResume.length} bots that were active before server restart...`);

  for (let i = 0; i < toResume.length; i++) {
    const a = toResume[i];
    if (i > 0) {
      await new Promise(r => setTimeout(r, 2000));
    }
    if ((a as any).persisted_running && !a.running) {
      const sessFile = getSessionFile(a.phone);
      if (!fs.existsSync(sessFile)) continue;
      a.running = true;
      const abortController = new AbortController();
      a.abortController = abortController;
      a.status = 'Starting... (Auto-Resumed)';
      launchBotWorker(a.phone, abortController);
      broadcastAccountUpdate(a.owner);
      console.log(`[AUTO-RESUME #${i + 1}/${toResume.length}] Launched worker for ${a.phone} (${a.owner || 'admin'})`);
    }
  }
}

const queueCache = new Map();
const sentUsersCache = new Map();
const peersCache = new Map();
const activeGroupCalls = new Map();
const ownerActiveGroupCalls = new Map<string, { phone: string; call: any; rawCall: any; entity: any; title: string; lastChecked?: number }>();
const ownerExtractingLock = new Set<string>();
const accountLastDmTimestamp = new Map<string, number>();
const accountLastHeartbeat = new Map<string, number>();

// 🛡️ 24/7 VPS CONTINUOUS EXECUTION: All bots run 24/7 uninterrupted on the VPS server.
// Phone locks, app minimize, or mobile data toggles will NEVER shut down running bots.

// 45-Second Real-Time Exit Watcher & Continuous Cache Sync
interface StreamParticipantCacheEntry {
  uids: Set<number>;
  lastSync: number;
  channelTitle?: string;
  call?: any;
}

const streamParticipantsCache = new Map<string, StreamParticipantCacheEntry>();
const scannerWakeupCallbacks = new Map<string, () => void>();

// 🧠 IN-MEMORY RAM CACHE FOR NON-TARGET CHANNELS (Zero Telegram Calls on Scans)
interface CachedIgnoredChannelData {
  ids: Set<string>;
  usernames: Set<string>;
  hashes: Set<string>;
  titles: Set<string>;
  key: string;
  timestamp: number;
}
const ownerIgnoredChannelsCache = new Map<string, CachedIgnoredChannelData>();

async function getOrResolveOwnerIgnoredChannels(owner: string, client: any, effCfg: any): Promise<CachedIgnoredChannelData> {
  const normOwner = owner || 'admin';
  const allRawNonTargets = [
    effCfg.channel_link,
    ...(Array.isArray(effCfg.targets) ? effCfg.targets : [])
  ].filter(Boolean).map((x: any) => String(x).trim());

  const cacheKey = allRawNonTargets.join('||');
  const existing = ownerIgnoredChannelsCache.get(normOwner);

  // If cache is fresh (< 20 mins) and key matches, return immediately with 0 API calls!
  if (existing && existing.key === cacheKey && (Date.now() - existing.timestamp < 20 * 60 * 1000)) {
    return existing;
  }

  const ids = new Set<string>();
  const usernames = new Set<string>();
  const hashes = new Set<string>();
  const titles = new Set<string>();

  const addIgnoredChat = (c: any) => {
    if (!c) return;
    if (c.id) {
      const sid = String(c.id);
      const bare = sid.replace(/^-100/, '').replace(/^-/, '');
      ids.add(sid);
      ids.add(bare);
      ids.add(`-100${bare}`);
      ids.add(`-${bare}`);
    }
    if (c.title) titles.add(String(c.title).trim().toLowerCase());
    if (c.username) usernames.add(String(c.username).trim().toLowerCase());
  };

  for (const rawItem of allRawNonTargets) {
    const item = (rawItem || '').trim();
    if (!item) continue;

    // 1. Numeric ID
    const numOnly = item.match(/^-?100(\d+)$/) || item.match(/^(\d{8,14})$/);
    if (numOnly) {
      const bare = numOnly[1];
      ids.add(bare);
      ids.add(`-100${bare}`);
      ids.add(`-${bare}`);
      continue;
    }

    // 2. Private message link (t.me/c/12345/...)
    const cLinkMatch = item.match(/t\.me\/c\/(\d+)/);
    if (cLinkMatch && cLinkMatch[1]) {
      const bare = cLinkMatch[1];
      ids.add(bare);
      ids.add(`-100${bare}`);
      continue;
    }

    // 3. Private Invite link (+hash or joinchat/hash)
    const inviteMatch = item.match(/(?:t\.me|telegram\.me)\/(?:\+|joinchat\/)([a-zA-Z0-9_-]+)/) ||
                        item.match(/^\+([a-zA-Z0-9_-]+)$/);
    if (inviteMatch && inviteMatch[1]) {
      const hash = inviteMatch[1].split('?')[0].replace(/[^a-zA-Z0-9_-]/g, '');
      if (hash) {
        hashes.add(hash.toLowerCase());
        try {
          if (client) {
            const inv: any = await client.invoke(new Api.messages.CheckChatInvite({ hash })).catch(() => null);
            if (inv?.chat) addIgnoredChat(inv.chat);
            if (inv?.title) titles.add(String(inv.title).trim().toLowerCase());
          }
        } catch {}
      }
      continue;
    }

    // 4. Public username (@username or t.me/username)
    if (item.includes('t.me/') || item.includes('telegram.me/') || item.startsWith('@')) {
      const clean = item.split('?')[0].split('#')[0].replace(/\/+$/, '');
      const u = clean.split('/').pop()?.replace('@', '').trim().toLowerCase();
      if (u && u.length >= 3 && !u.startsWith('+') && u !== 'joinchat' && u !== 'c') {
        usernames.add(u);
        try {
          if (client) {
            const ent: any = await client.getEntity(u).catch(() => null);
            if (ent) addIgnoredChat(ent);
          }
        } catch {}
      }
      continue;
    }

    // 5. Plain text title
    if (item.length >= 2) {
      titles.add(item.toLowerCase());
    }
  }

  const result: CachedIgnoredChannelData = {
    ids,
    usernames,
    hashes,
    titles,
    key: cacheKey,
    timestamp: Date.now()
  };
  ownerIgnoredChannelsCache.set(normOwner, result);
  return result;
}

// 👑 MULTI-BOT LIVE STREAM LEADER ENGINE (Leader-Worker Model)
// Only ONE bot scans a given live stream; other bots skip it and scan other channels or send DMs!
interface LiveStreamLeaderInfo {
  phone: string;
  owner: string;
  channelId: string;
  channelTitle: string;
  lockedAt: number;
  lastHeartbeat: number;
}
const globalLiveStreamLeaders = new Map<string, LiveStreamLeaderInfo>();

function isChannelScannedByOtherLeader(channelId: string, currentPhone: string): { isOtherLeader: boolean; leaderPhone?: string } {
  const bareId = String(channelId).replace(/^-100/, '').replace(/^-/, '');
  const existing = globalLiveStreamLeaders.get(bareId) || globalLiveStreamLeaders.get(channelId) || globalLiveStreamLeaders.get(`-100${bareId}`);
  if (existing) {
    // If heartbeat expired (> 25 seconds), treat as stale
    if (Date.now() - existing.lastHeartbeat > 25000) {
      globalLiveStreamLeaders.delete(bareId);
      return { isOtherLeader: false };
    }
    if (existing.phone !== currentPhone) {
      return { isOtherLeader: true, leaderPhone: existing.phone };
    }
  }
  return { isOtherLeader: false };
}

function registerLiveStreamLeader(channelId: string, currentPhone: string, owner: string, title: string) {
  const bareId = String(channelId).replace(/^-100/, '').replace(/^-/, '');
  globalLiveStreamLeaders.set(bareId, {
    phone: currentPhone,
    owner: owner || 'admin',
    channelId,
    channelTitle: title || '',
    lockedAt: Date.now(),
    lastHeartbeat: Date.now()
  });
}

function releaseLiveStreamLeader(channelId: string, currentPhone: string) {
  const bareId = String(channelId).replace(/^-100/, '').replace(/^-/, '');
  const existing = globalLiveStreamLeaders.get(bareId);
  if (existing && existing.phone === currentPhone) {
    globalLiveStreamLeaders.delete(bareId);
  }
}

function wakeScanner(phone: string) {
  const cb = scannerWakeupCallbacks.get(phone);
  if (cb) {
    try {
      cb();
    } catch {}
  }
}

function sleepWithWakeup(phone: string, ms: number): Promise<void> {
  return new Promise((resolve) => {
    let timer: NodeJS.Timeout | null = null;
    let resolved = false;
    const cleanup = () => {
      if (resolved) return;
      resolved = true;
      if (timer) clearTimeout(timer);
      scannerWakeupCallbacks.delete(phone);
      resolve();
    };
    timer = setTimeout(cleanup, ms);
    scannerWakeupCallbacks.set(phone, cleanup);
  });
}

function extractParticipantUserId(p: any): number {
  if (!p) return 0;
  let pUserId = 0;
  if (p.peer) {
    if (p.peer.userId !== undefined) pUserId = Number(p.peer.userId);
    else if (p.peer.user_id !== undefined) pUserId = Number(p.peer.user_id);
    else if (p.peer.id !== undefined && p.peer.className !== 'PeerChannel' && p.peer.className !== 'PeerChat') {
      pUserId = Number(p.peer.id);
    }
  }
  if (!pUserId) {
    if (p.userId !== undefined) pUserId = Number(p.userId);
    else if (p.user_id !== undefined) pUserId = Number(p.user_id);
    else if (p.id !== undefined) pUserId = Number(p.id);
  }
  return isNaN(pUserId) ? 0 : pUserId;
}

// Temporary in-memory cooldown for live stream candidates (prevents permanent DB blacklisting of real humans)
const tempLiveStreamCooldown = new Map<number, number>();

async function syncStreamParticipantsCache(phone: string, owner: string, client: any): Promise<void> {
  const normOwner = owner || 'admin';
  const act = activeGroupCalls.get(phone) || ownerActiveGroupCalls.get(normOwner);
  if (!act || !act.call || !client) return;

  // 🤝 MULTI-BOT CACHE SHARING: If cache was updated by another bot for the same call < 8 seconds ago, reuse it!
  const callKey = String(act.call.id || phone);
  const existingCache = streamParticipantsCache.get(phone) || streamParticipantsCache.get(callKey);
  if (existingCache && (Date.now() - existingCache.lastSync < 8000)) {
    return;
  }

  try {
    let callInfo: any = null;
    try {
      callInfo = await client.invoke(
        new Api.phone.GetGroupCall({ call: act.call, limit: 100 })
      );
    } catch (callErr: any) {
      const callErrMsg = String(callErr?.message || callErr);
      if (callErrMsg.includes('GROUPCALL_INVALID') || callErrMsg.includes('GROUPCALL_JOIN_MISSING')) {
        purgeAccountVerifiedQueueOnStreamEnd(phone, 'Live stream concluded or call invalid');
        return;
      }
    }

    if (callInfo) {
      const activeUids = new Set<number>();
      if (Array.isArray(callInfo.users)) {
        recordUserPeers(phone, callInfo.users, client);
      }
      if (Array.isArray(callInfo.participants)) {
        for (const p of callInfo.participants) {
          // Exclude stream host & speakers from active listener pool
          const isSpeaker = p.canSelfUnmute === true || p.can_self_unmute === true || p.self === true;
          if (!p.left && !isSpeaker) {
            const pUid = extractParticipantUserId(p);
            if (pUid) activeUids.add(pUid);
          }
        }
      }

      let nextOffset = callInfo.participantsNextOffset || '';
      let pages = 0;
      while (nextOffset && pages < 8) {
        pages++;
        try {
          const more: any = await client.invoke(
            new Api.phone.GetGroupParticipants({
              call: act.call,
              ids: [],
              sources: [],
              offset: nextOffset,
              limit: 100
            })
          ).catch(() => null);

          if (!more) break;
          if (Array.isArray(more.users)) {
            recordUserPeers(phone, more.users, client);
          }
          if (Array.isArray(more.participants)) {
            for (const p of more.participants) {
              const isSpeaker = p.canSelfUnmute === true || p.can_self_unmute === true || p.self === true;
              if (!p.left && !isSpeaker) {
                const pUid = extractParticipantUserId(p);
                if (pUid) activeUids.add(pUid);
              }
            }
          }
          if (more.nextOffset && more.nextOffset !== nextOffset) {
            nextOffset = more.nextOffset;
          } else {
            break;
          }
        } catch {
          break;
        }
      }

      const cacheEntry: StreamParticipantCacheEntry = {
        uids: activeUids,
        lastSync: Date.now(),
        channelTitle: act.title || '',
        call: act.call
      };
      streamParticipantsCache.set(phone, cacheEntry);
      streamParticipantsCache.set(callKey, cacheEntry);
    }
  } catch {}
}

async function verifyUserStreamPresence(
  phone: string,
  owner: string,
  client: any,
  uid: number,
  pInfo: any
): Promise<boolean> {
  const normOwner = owner || 'admin';
  const act = activeGroupCalls.get(phone) || ownerActiveGroupCalls.get(normOwner);
  if (!act || !act.call) {
    return false;
  }

  // 1. Check live participants cache (updated every 3.5s by Continuous Cache Sync)
  const cache = streamParticipantsCache.get(phone);
  if (cache && cache.uids && cache.uids.size > 0) {
    if (cache.uids.has(Number(uid))) {
      return true;
    }
    // If cache was synced recently (< 6 seconds) and user is missing:
    if (Date.now() - cache.lastSync < 6000) {
      if (client) {
        try {
          const accessHash = pInfo?.accessHash || 0;
          const targetInputPeer = new Api.InputPeerUser({
            userId: BigInt(uid) as any,
            accessHash: BigInt(accessHash) as any
          });
          const res: any = await client.invoke(
            new Api.phone.GetGroupParticipants({
              call: act.call,
              ids: [targetInputPeer],
              sources: [],
              offset: '',
              limit: 5
            })
          ).catch(() => null);

          if (res && Array.isArray(res.participants) && res.participants.length > 0) {
            const p = res.participants.find((item: any) => extractParticipantUserId(item) === Number(uid));
            if (p) {
              if (p.left) return false;
              cache.uids.add(Number(uid));
              return true;
            }
          }
          return false;
        } catch {
          return false;
        }
      }
      return false;
    }
  }

  // Direct check if cache is not yet warmed up
  if (client) {
    try {
      const accessHash = pInfo?.accessHash || 0;
      const targetInputPeer = new Api.InputPeerUser({
        userId: BigInt(uid) as any,
        accessHash: BigInt(accessHash) as any
      });
      const res: any = await client.invoke(
        new Api.phone.GetGroupParticipants({
          call: act.call,
          ids: [targetInputPeer],
          sources: [],
          offset: '',
          limit: 5
        })
      ).catch(() => null);

      if (res && Array.isArray(res.participants) && res.participants.length > 0) {
        const p = res.participants.find((item: any) => extractParticipantUserId(item) === Number(uid));
        if (p) {
          if (p.left) return false;
          if (cache) cache.uids.add(Number(uid));
          return true;
        }
        return false;
      }
      return false;
    } catch {
      return false;
    }
  }

  return false;
}

async function checkIsStreamStillAlive(owner: string, client: any, phone: string): Promise<boolean> {
  const normOwner = owner || 'admin';
  const act = activeGroupCalls.get(phone) || ownerActiveGroupCalls.get(normOwner);
  if (!act || !client) {
    return true; // If no active stream reference or client, never purge prematurely
  }
  try {
    if (act.call) {
      const callInfo = await client.invoke(
        new Api.phone.GetGroupCall({ call: act.call, limit: 1 })
      ).catch(() => null);
      if (!callInfo || !callInfo.call || callInfo.call.className === 'GroupCallDiscarded') {
        activeGroupCalls.delete(phone);
        ownerActiveGroupCalls.delete(normOwner);
        return false;
      }
      const pCount = callInfo.call.participantsCount || (callInfo.participants ? callInfo.participants.length : 0);
      if (pCount === 0) {
        activeGroupCalls.delete(phone);
        ownerActiveGroupCalls.delete(normOwner);
        return false;
      }
      return true;
    }
    if (act.entity) {
      let fullChat: any = null;
      if (act.entity?.className === 'Chat') {
        fullChat = await client.invoke(
          new Api.messages.GetFullChat({ chatId: act.entity.id })
        ).catch(() => null);
      } else {
        fullChat = await client.invoke(
          new Api.channels.GetFullChannel({ channel: act.entity })
        ).catch(() => null);
      }
      if (fullChat && fullChat.fullChat) {
        const call = fullChat.fullChat.call;
        if (!call || call.className === 'GroupCallDiscarded') {
          activeGroupCalls.delete(phone);
          ownerActiveGroupCalls.delete(normOwner);
          return false;
        }
        return true;
      }
    }
    return true;
  } catch (err: any) {
    // Transient error or timeout: DO NOT mark stream as ended!
    return true;
  }
}

// ---------------- TWO-QUEUE DISTRIBUTED PROCESSING ARCHITECTURE ----------------
// 1. Raw / Staging Queue (from stream scanner)
const ownerRawQueueCache = new Map<string, number[]>();
const ownerRawReservedUids = new Map<string, Map<number, string>>();

// 2. Verified / Genuine Queue (filtered & ready for DM dispatch)
const ownerVerifiedQueueCache = new Map<string, number[]>();
const ownerVerifiedReservedUids = new Map<string, Map<number, string>>();

// 3. Sent, Skipped & Peers Cache
interface SkippedUserRecord {
  uid: number;
  name?: string;
  username?: string;
  phone?: string;
  reason: string;
  category: 'privacy' | 'privacy_restricted' | 'premium' | 'no_peer' | 'admin' | 'bot' | 'deleted' | 'spam_bio' | 'spam_keyword' | 'has_username' | 'other' | string;
  timestamp: string;
  dateFormatted: string;
  skippedByPhone?: string;
}

const ownerSkippedDetailsCache = new Map<string, Map<number, SkippedUserRecord>>();

interface PeerInfo {
  isAdmin?: boolean;
  about?: string;
  [key: string]: any;
  userId: string;
  accessHash?: string;
  username?: string;
  firstName?: string;
  lastName?: string;
  phone?: string;
  sourcePhone?: string;
  accessHashes?: Record<string, string>;
  isPremium?: boolean;
  isBot?: boolean;
  isDeleted?: boolean;
  isPrivacyRestricted?: boolean;
  isContactLocked?: boolean;
  contactSaved?: boolean;
}

function isTelegramPrivacyRestricted(u: any): boolean {
  if (!u) return false;
  if (u.contactRequirePremium === true || u.user?.contactRequirePremium === true) return true;
  if (typeof u.flags2 === 'number' && (u.flags2 & 4) !== 0) return true;
  if (u.user && typeof u.user.flags2 === 'number' && (u.user.flags2 & 4) !== 0) return true;
  return false;
}

function isTelegramPremiumUser(u: any): boolean {
  if (!u) return false;
  // 1. Direct boolean property check on User or entity
  if (u.premium === true || u.isPremium === true) return true;
  if (u.user && (u.user.premium === true || u.user.isPremium === true)) return true;
  if (u.fullUser && (u.fullUser.premium === true || u.fullUser.isPremium === true)) return true;

  // 2. MTProto flags bits (flags bit 12: 4096 / flags2 bit 0: 1)
  if (typeof u.flags === 'number' && (u.flags & 4096) !== 0) return true;
  if (typeof u.flags2 === 'number' && (u.flags2 & 1) !== 0) return true;
  if (u.user && typeof u.user.flags === 'number' && (u.user.flags & 4096) !== 0) return true;
  if (u.user && typeof u.user.flags2 === 'number' && (u.user.flags2 & 1) !== 0) return true;

  // 3. Status or emoji status / premium badges
  if (u.emojiStatus && u.emojiStatus.className && u.emojiStatus.className !== 'EmojiStatusEmpty') return true;
  if (u.user?.emojiStatus && u.user.emojiStatus.className && u.user.emojiStatus.className !== 'EmojiStatusEmpty') return true;

  return false;
}

function isTelegramBotUser(u: any): boolean {
  if (!u) return false;
  if (u.bot === true || u.isBot === true) return true;
  if (u.user && (u.user.bot === true || u.user.isBot === true)) return true;
  const uname = String(u.username || u.user?.username || '').toLowerCase();
  if (uname.endsWith('bot')) return true;
  return false;
}

function isTelegramDeletedUser(u: any): boolean {
  if (!u) return false;
  if (u.deleted === true || u.isDeleted === true || u.scam === true || u.fake === true) return true;
  if (u.user && (u.user.deleted === true || u.user.isDeleted === true || u.user.scam === true)) return true;
  const fname = String(u.firstName || u.first_name || u.user?.firstName || '');
  if (/deleted account/i.test(fname)) return true;
  return false;
}

function isTelegramAdminOrOwner(userObj: any, pInfo?: PeerInfo | null): boolean {
  if (!userObj && !pInfo) return false;
  if (pInfo?.isAdmin || (pInfo as any)?.isCreator || (pInfo as any)?.isOwner) return true;
  if (userObj) {
    if (userObj.adminRights || userObj.creator) return true;
    const cls = String(userObj.className || '');
    if (cls.includes('Admin') || cls.includes('Creator')) return true;
    if (userObj.participant) {
      const pCls = String(userObj.participant.className || '');
      if (pCls.includes('Admin') || pCls.includes('Creator')) return true;
      if (userObj.participant.adminRights) return true;
    }
  }
  const nameAll = [userObj?.firstName, userObj?.lastName, pInfo?.firstName, pInfo?.lastName].filter(Boolean).join(' ').toLowerCase();
  if (/\b(admin|owner|creator|founder|moderator|mod|official\s+admin)\b/i.test(nameAll)) return true;
  return false;
}

function isTelegramUserSpamOrPromo(userObj: any, pInfo?: PeerInfo | null): { isSpam: boolean; reason: string } {
  const texts: string[] = [];
  
  if (userObj) {
    if (userObj.firstName) texts.push(String(userObj.firstName));
    if (userObj.lastName) texts.push(String(userObj.lastName));
    if (userObj.username) texts.push(String(userObj.username));
    if (userObj.about) texts.push(String(userObj.about));
    if (userObj.fullUser?.about) texts.push(String(userObj.fullUser.about));
  }
  
  if (pInfo) {
    if (pInfo.firstName) texts.push(String(pInfo.firstName));
    if (pInfo.lastName) texts.push(String(pInfo.lastName));
    if (pInfo.username) texts.push(String(pInfo.username));
  }
  
  const combined = texts.join(' ').toLowerCase();
  if (!combined.trim()) return { isSpam: false, reason: '' };

  // 0. Check custom reject keywords from Global AI Config / Admin Dashboard
  if (globalAiConfig.custom_reject_keywords && globalAiConfig.custom_reject_keywords.length > 0) {
    for (const rawKw of globalAiConfig.custom_reject_keywords) {
      const kw = String(rawKw || '').toLowerCase().trim();
      if (kw && combined.includes(kw)) {
        return { isSpam: true, reason: `Matched Custom Blacklist: "${kw}"` };
      }
    }
  }

  // 1. Trading / Forex / Crypto / Signal Scams & Promos
  const tradingKeywords = [
    'trader', 'trading', 'trade', 'agent', 'sub-agent', 'subagent', 'broker', 'pro trader',
    'copy trade', 'copy trading', 'forex trader', 'crypto trader', 'binance trader',
    'forex', 'crypto', 'binance', 'future trading', 'binary option',
    'trading signal', 'trade signal', 'sure shot', 'sureshot', 'profit share',
    'recover loss', 'loss recover', 'daily profit', 'vip signal', 'crypto signal',
    'banknifty', 'nifty', 'option trading', 'stock market', 'investment plan',
    'earn daily', 'pnl', '100% accurate', 'free call', 'call put', 'share market',
    'cryptocurrency', 'bitcoin', 'usdt trading', 'vip trade', 'quotex'
  ];
  for (const kw of tradingKeywords) {
    if (combined.includes(kw)) {
      return { isSpam: true, reason: `Trading/Crypto Promo detected: "${kw}"` };
    }
  }

  // 2. Channel Join & Promotional Links
  const promoKeywords = [
    'join my channel', 'join channel', 'join group', 'join my group', 'join now',
    'official channel', 'telegram channel', 't.me/', 'subscribe my channel',
    'click link in bio', 'link in bio', 'dm for join', 'paid group', 'free joining',
    'tap to join', 'join telegram', 'channel link', 'wa.me/', 'whatsapp'
  ];
  for (const kw of promoKeywords) {
    if (combined.includes(kw)) {
      return { isSpam: true, reason: `Channel promo detected: "${kw}"` };
    }
  }

  // 3. Gaming / Betting / Casino / Color Prediction / Color Trading
  const gamingKeywords = [
    'color prediction', 'colour prediction', 'color trading', 'colour trading',
    'big small', 'bigsmall', 'big & small', 'big and small', 'prediction bot', 'game prediction',
    'aviator', 'aviator hack', 'aviator signal', 'mines hack', 'daman', 'daman games',
    'bdg win', 'bdg game', 'tiranga', '91 club', '91club', '82 lottery', 'lottery app', 'betting',
    'casino', 'roulette', 'teen patti', 'rummy trick', 'mod apk hack',
    'satta', 'matka', 'kalyan', 'loss cover', 'recover loss', 'sure shot', 'sureshot',
    'earning app', 'deposit', 'withdrawal', 'register link', 'refer code', 'daily income',
    'gaming channel', 'free diamond', 'free uc', 'pubg hack', 'free fire hack'
  ];
  for (const kw of gamingKeywords) {
    if (combined.includes(kw)) {
      return { isSpam: true, reason: `Gaming/Betting promo detected: "${kw}"` };
    }
  }

  return { isSpam: false, reason: '' };
}

const ownerSentCache = new Map<string, Set<number>>();
const ownerSkippedCache = new Map<string, Set<number>>();
const ownerPeersCache = new Map<string, Map<string, PeerInfo>>();

// 4. Global In-Memory Verified Cache (Shared across accounts & owners, 24-hour TTL)
// Maps target Telegram uid -> expiration timestamp (ms). 
// Re-discovered users in this cache instantly promote to Genuine Queue without re-probing Telegram APIs.
const globalVerifiedCache = new Map<number, number>();
const GLOBAL_VERIFIED_TTL_MS = 24 * 60 * 60 * 1000; // 24 Hours

function isGlobalVerified(uid: number): boolean {
  const expiry = globalVerifiedCache.get(uid);
  if (!expiry) return false;
  if (Date.now() > expiry) {
    globalVerifiedCache.delete(uid);
    return false;
  }
  return true;
}

function markGlobalVerified(uid: number): void {
  globalVerifiedCache.set(uid, Date.now() + GLOBAL_VERIFIED_TTL_MS);
}

function categorizeSkipReason(r: string): SkippedUserRecord['category'] {
  const low = (r || '').toLowerCase();
  if (low.includes('spam') || low.includes('promo') || low.includes('trading') || low.includes('channel') || low.includes('gaming') || low.includes('crypto')) return 'spam_bio';
  if (low.includes('premium')) return 'premium';
  if (low.includes('admin') || low.includes('creator') || low.includes('owner')) return 'admin';
  if (low.includes('bot')) return 'bot';
  if (low.includes('deleted') || low.includes('scam') || low.includes('fake')) return 'deleted';
  if (low.includes('privacy') || low.includes('restricted') || low.includes('block') || low.includes('contacts')) return 'privacy';
  if (low.includes('peer') || low.includes('no peer') || low.includes('no username')) return 'no_peer';
  return 'other';
}

function getOwnerSkippedDetails(owner: string): Map<number, SkippedUserRecord> {
  const normOwner = owner || 'admin';
  let m = ownerSkippedDetailsCache.get(normOwner);
  if (!m) {
    m = new Map();
    try {
      const localDbPath = path.join(__dirname, `skipped_db_owner_${normOwner}.json`);
      if (fs.existsSync(localDbPath)) {
        const arr: SkippedUserRecord[] = JSON.parse(fs.readFileSync(localDbPath, 'utf8'));
        if (Array.isArray(arr)) {
          for (const item of arr) {
            if (item && item.uid) m.set(item.uid, item);
          }
        }
      }
    } catch {}
    ownerSkippedDetailsCache.set(normOwner, m);
  }
  return m;
}

function getOwnerSkippedUsers(owner: string): Set<number> {
  const normOwner = owner || 'admin';
  let s = ownerSkippedCache.get(normOwner);
  if (!s) {
    s = new Set();
    try {
      const localOwnerSPath = path.join(__dirname, `skipped_owner_${normOwner}.json`);
      if (fs.existsSync(localOwnerSPath)) {
        const arr = JSON.parse(fs.readFileSync(localOwnerSPath, 'utf8'));
        if (Array.isArray(arr)) arr.forEach((id: number) => s!.add(id));
      }
    } catch {}
    const details = getOwnerSkippedDetails(normOwner);
    for (const id of details.keys()) {
      s.add(id);
    }
    ownerSkippedCache.set(normOwner, s);
  }
  return s;
}

function markOwnerSkippedUser(
  owner: string,
  uid: number,
  reason = 'Skipped',
  details?: Partial<SkippedUserRecord>
): void {
  const normOwner = owner || 'admin';
  globalVerifiedCache.delete(uid);
  const s = getOwnerSkippedUsers(normOwner);
  s.add(uid);
  ownerSkippedCache.set(normOwner, s);

  const m = getOwnerSkippedDetails(normOwner);
  const peers = getOwnerPeers(normOwner);
  const p = peers.get(String(uid));

  const now = new Date();
  const rawReason = reason || details?.reason || 'Skipped';
  const record: SkippedUserRecord = {
    uid,
    name: details?.name || p?.firstName || String(uid),
    username: details?.username || (p?.username ? `@${p.username.replace(/^@/, '')}` : undefined),
    phone: details?.phone || p?.phone,
    reason: rawReason,
    category: details?.category || categorizeSkipReason(rawReason),
    timestamp: now.toISOString(),
    dateFormatted: now.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }),
    skippedByPhone: details?.skippedByPhone
  };

  m.set(uid, record);
  ownerSkippedDetailsCache.set(normOwner, m);

  try {
    const localOwnerSPath = path.join(__dirname, `skipped_owner_${normOwner}.json`);
    asyncSaveJson(localOwnerSPath, Array.from(s), 800);
  } catch {}

  try {
    const localDbPath = path.join(__dirname, `skipped_db_owner_${normOwner}.json`);
    asyncSaveJson(localDbPath, Array.from(m.values()), 1500);
  } catch {}

  // , { uids: Array.from(s) }); // DISABLED TO PREVENT FIRESTORE LIMIT EXHAUSTION
  // try {
  //   const recentRecords = Array.from(m.values()).slice(-500);
  //   , {
  //     records: recentRecords,
  //     totalCount: m.size,
  //     updatedAt: now.toISOString()
  //   });
  // } catch {}

  if (typeof broadcastAccountUpdate === 'function') {
    try {
      broadcastAccountUpdate(normOwner);
    } catch {}
  }
}

function clearOwnerSkippedUsers(owner: string): void {
  const normOwner = owner || 'admin';
  ownerSkippedCache.set(normOwner, new Set());
  ownerSkippedDetailsCache.set(normOwner, new Map());
  try {
    fs.writeFileSync(path.join(__dirname, `skipped_owner_${normOwner}.json`), '[]', 'utf8');
    fs.writeFileSync(path.join(__dirname, `skipped_db_owner_${normOwner}.json`), '[]', 'utf8');
  } catch {}


}

// ---------------- 1. RAW / STAGING QUEUE (From Scanners) ----------------
function getOwnerRawQueue(owner: string): number[] {
  const normOwner = owner || 'admin';
  let q = ownerRawQueueCache.get(normOwner);
  if (!q) {
    q = [];
    try {
      const localOwnerRawPath = path.join(__dirname, `raw_queue_owner_${normOwner}.json`);
      if (fs.existsSync(localOwnerRawPath)) {
        const fileQ = JSON.parse(fs.readFileSync(localOwnerRawPath, 'utf8'));
        if (Array.isArray(fileQ)) q = fileQ;
      } else {
        // Migration fallback: check legacy queue if exists
        const legacyPath = path.join(__dirname, `queue_owner_${normOwner}.json`);
        if (fs.existsSync(legacyPath)) {
          const fileQ = JSON.parse(fs.readFileSync(legacyPath, 'utf8'));
          if (Array.isArray(fileQ)) q = fileQ;
        }
      }
    } catch {}
    ownerRawQueueCache.set(normOwner, q);
  }
  return q;
}

function saveOwnerRawQueue(owner: string, q: number[]): void {
  const normOwner = owner || 'admin';
  ownerRawQueueCache.set(normOwner, q);
  try {
    const localPath = path.join(__dirname, `raw_queue_owner_${normOwner}.json`);
    asyncSaveJson(localPath, q, 800);
  } catch {}
  // , { uids: q }); // DISABLED TO PREVENT FIRESTORE LIMIT EXHAUSTION

  if (typeof broadcastAccountUpdate === 'function') {
    try {
      broadcastAccountUpdate(normOwner);
    } catch {}
  }
}

function addToOwnerRawQueue(owner: string, phone: string, uids: number[]): void {
  const normOwner = owner || 'admin';
  const a = accounts.get(phone);
  if (!a) return;

  const rawQ = getOwnerRawQueue(normOwner);
  const rawSet = new Set(rawQ);
  const verifiedQ = getOwnerVerifiedQueue(normOwner);
  const verifiedSet = new Set(verifiedQ);
  const sentSet = getOwnerSentUsers(normOwner);
  const skippedSet = getOwnerSkippedUsers(normOwner);
  let addedCount = 0;
  const instantVerified: number[] = [];
  const rawPeers = getOwnerPeers(normOwner);

  for (const id of uids) {
    if (!rawSet.has(id) && !verifiedSet.has(id) && !sentSet.has(id) && !skippedSet.has(id)) {
      // Global Verified Cache hit -> Direct promotion to Genuine Queue!
      if (isGlobalVerified(id)) {
        instantVerified.push(id);
        verifiedSet.add(id);
      } else {
        rawQ.push(id);
        rawSet.add(id);
      }
      addedCount++;
    }
  }

  if (instantVerified.length > 0) {
    addToOwnerVerifiedQueue(normOwner, instantVerified);
  }

  if (addedCount > 0) {
    (a as any).daily_extracted_count = ((a as any).daily_extracted_count || 0) + addedCount;
    saveOwnerRawQueue(normOwner, rawQ);
    log(
      phone,
      'DB',
      `📥 Added ${addedCount} listeners (${instantVerified.length > 0 ? instantVerified.length + ' instant-cached -> Genuine | ' : ''}Raw: ${rawQ.length} | Genuine: ${getOwnerVerifiedQueue(normOwner).length})`
    );
  }
}

function claimBatchFromRawQueue(owner: string, phone: string, batchSize: number): number[] {
  const normOwner = owner || 'admin';
  const a = accounts.get(phone);
  // When Live Stream monitoring is active, do NOT feed from raw historical queue!
  // Live stream accounts must exclusively DM fresh participants from the active stream.
  if (a?.live_on) {
    return [];
  }
  const rawQ = getOwnerRawQueue(normOwner);
  const sent = getOwnerSentUsers(normOwner);
  const skipped = getOwnerSkippedUsers(normOwner);
  const verifiedSet = new Set(getOwnerVerifiedQueue(normOwner));
  const peers = getOwnerPeers(normOwner);

  if (!ownerRawReservedUids.has(normOwner)) {
    ownerRawReservedUids.set(normOwner, new Map());
  }
  const reserved = ownerRawReservedUids.get(normOwner)!;

  // Release old reservations for this phone
  for (const [rUid, rPhone] of reserved.entries()) {
    if (rPhone === phone) {
      reserved.delete(rUid);
    }
  }

  const instantPromoted: number[] = [];
  for (const uid of rawQ) {
    if (!sent.has(uid) && !skipped.has(uid) && !verifiedSet.has(uid) && isGlobalVerified(uid)) {
      instantPromoted.push(uid);
      if (instantPromoted.length >= batchSize) break;
    }
  }
  if (instantPromoted.length > 0) {
    addToOwnerVerifiedQueue(normOwner, instantPromoted);
    for (const uid of instantPromoted) {
      removeFromOwnerRawQueue(normOwner, uid);
    }
    // Update verifiedSet with newly promoted users
    for (const uid of instantPromoted) verifiedSet.add(uid);
  }

  // Two-tiered candidate selection:
  // When reject_usernames is enabled, accounts WITHOUT username are prioritized first!
  const withUsername: number[] = [];
  const withoutUsername: number[] = [];

  for (const uid of rawQ) {
    if (!sent.has(uid) && !skipped.has(uid) && !verifiedSet.has(uid) && !reserved.has(uid)) {
      const pInfo = peers.get(String(uid)) || findPeerInfoAnywhere(String(uid), normOwner);
      // Strict individual filtering: Each account only filters its own extracted candidates
      if (pInfo?.sourcePhone && pInfo.sourcePhone !== phone) {
        continue;
      }
      const hasUsername = Boolean(pInfo && pInfo.username && String(pInfo.username).trim().length > 0);
      if (hasUsername) {
        withUsername.push(uid);
      } else {
        withoutUsername.push(uid);
      }
    }
  }

  const prioritizedCandidates = (globalAiConfig.reject_usernames !== false)
    ? [...withoutUsername, ...withUsername]
    : [...withUsername, ...withoutUsername];

  const batch: number[] = [];
  for (const uid of prioritizedCandidates) {
    if (batch.length >= batchSize) break;
    reserved.set(uid, phone);
    batch.push(uid);
  }
  return batch;
}

function releaseOwnerRawReservation(owner: string, uid: number): void {
  const normOwner = owner || 'admin';
  const reserved = ownerRawReservedUids.get(normOwner);
  if (reserved) reserved.delete(uid);
}

function removeFromOwnerRawQueue(owner: string, uid: number): void {
  const normOwner = owner || 'admin';
  const rawQ = getOwnerRawQueue(normOwner);
  const nextQ = rawQ.filter((id) => id !== uid);
  saveOwnerRawQueue(normOwner, nextQ);
  releaseOwnerRawReservation(normOwner, uid);
}

// ---------------- 2. VERIFIED / GENUINE QUEUE (Per-Account / Phone Architecture) ----------------
function getAccountVerifiedQueue(phone: string): number[] {
  let q = queueCache.get(phone);
  if (!q) {
    q = [];
    try {
      const pId = phone.replace(/[^0-9+]/g, '');
      const localPath = path.join(__dirname, `queue_${pId}.json`);
      if (fs.existsSync(localPath)) {
        const fileQ = JSON.parse(fs.readFileSync(localPath, 'utf8'));
        if (Array.isArray(fileQ)) q = fileQ;
      }
    } catch {}
    queueCache.set(phone, q);
  }

  // Real-time automatic sanitization: Filter out any users already sent or skipped
  const a = accounts.get(phone);
  const owner = a?.owner || 'admin';
  const sent = getOwnerSentUsers(owner);
  const skipped = getOwnerSkippedUsers(owner);
  const localSent = a?.sent_users;

  const cleanQ = q.filter(uid => !sent.has(uid) && !skipped.has(uid) && !localSent?.has(uid));
  if (cleanQ.length !== q.length) {
    q = cleanQ;
    queueCache.set(phone, q);
    try {
      const pId = phone.replace(/[^0-9+]/g, '');
      const localPath = path.join(__dirname, `queue_${pId}.json`);
      asyncSaveJson(localPath, q, 800);
    } catch {}
    if (a) {
      a.queue_count = q.length;
      (a as any).verified_queue_count = q.length;
    }
  }

  return q;
}

function saveAccountVerifiedQueue(phone: string, q: number[]): void {
  queueCache.set(phone, q);
  try {
    const pId = phone.replace(/[^0-9+]/g, '');
    const localPath = path.join(__dirname, `queue_${pId}.json`);
    asyncSaveJson(localPath, q, 800);
  } catch {}

  const a = accounts.get(phone);
  if (a) {
    a.queue_count = q.length;
    (a as any).verified_queue_count = q.length;
  }
  if (typeof broadcastAccountUpdate === 'function') {
    try {
      broadcastAccountUpdate(a?.owner || 'admin');
    } catch {}
  }
}

function addToAccountVerifiedQueue(phone: string, uids: number[]): void {
  const verifiedQ = getAccountVerifiedQueue(phone);
  const verifiedSet = new Set(verifiedQ);
  const a = accounts.get(phone);
  const sentSet = a?.sent_users || new Set();
  const owner = a?.owner || 'admin';
  const ownerSentSet = getOwnerSentUsers(owner);
  const ownerSkippedSet = getOwnerSkippedUsers(owner);
  const peers = getOwnerPeers(owner);
  let added = 0;

  // Separate incoming batch into users WITHOUT @username (priority 1) and WITH @username (priority 2)
  const incomingWithoutUname: number[] = [];
  const incomingWithUname: number[] = [];

  for (const id of uids) {
    // Unlimited Genuine Queue capacity (Safety ceiling 100,000)
    if (verifiedQ.length >= 100000) break;
    if (!verifiedSet.has(id) && !sentSet.has(id) && !ownerSentSet.has(id) && !ownerSkippedSet.has(id)) {
      const pInfo = peers.get(String(id)) || findPeerInfoAnywhere(String(id), owner);
      const hasUname = Boolean(pInfo?.username && String(pInfo.username).trim().length > 0);
      if (hasUname) {
        incomingWithUname.push(id);
      } else {
        incomingWithoutUname.push(id);
      }
      verifiedSet.add(id);
      added++;
    }
  }

  // Prepend/insert without-username users first so they are processed before with-username users
  verifiedQ.push(...incomingWithoutUname, ...incomingWithUname);

  if (added > 0) {
    saveAccountVerifiedQueue(phone, verifiedQ);
  }
}

function removeFromAccountVerifiedQueue(phone: string, uid: number): void {
  const currentQ = getAccountVerifiedQueue(phone);
  const nextQ = currentQ.filter((id) => id !== uid);
  saveAccountVerifiedQueue(phone, nextQ);
}

function purgeAccountVerifiedQueueOnStreamEnd(phone: string, reason: string): number {
  activeGroupCalls.delete(phone);
  streamParticipantsCache.delete(phone);
  wakeScanner(phone);
  const a = accounts.get(phone);
  const owner = a?.owner || 'admin';
  ownerActiveGroupCalls.delete(owner);
  ownerExtractingLock.delete(owner);

  const verifiedQ = getAccountVerifiedQueue(phone);
  if (verifiedQ.length === 0) {
    saveAccountVerifiedQueue(phone, []);
    return 0;
  }

  const ownerPeers = getOwnerPeers(owner);
  let purgedCount = 0;
  const retainedQ: number[] = [];

  for (const uid of verifiedQ) {
    const pInfo = ownerPeers.get(String(uid)) || findPeerInfoAnywhere(String(uid), owner);
    const hasUname = Boolean(pInfo?.username && String(pInfo.username).trim().length > 0);
    const isContactLocked = Boolean(pInfo?.isContactLocked || pInfo?.contactSaved);

    // Retain users that CAN actually be messaged after live stream ends:
    // 1. Permanently locked/saved in Telegram Cloud Contacts
    // 2. Users with @username (can be resolved and messaged anytime globally)
    if (isContactLocked) {
      retainedQ.push(uid);
      log(phone, 'OK', `📇 [CONTACT RETAINED] ${pInfo?.firstName || uid} is permanently secured in Telegram Cloud Contacts. Retained in queue despite stream end.`);
      continue;
    }
    if (hasUname) {
      retainedQ.push(uid);
      log(phone, 'OK', `👤 [USERNAME RETAINED] @${String(pInfo?.username).replace(/^@/, '')} retained in queue (can be reached anytime via @username).`);
      continue;
    }

    // Unsaved listeners without username: accessHash expires the moment stream closes
    markOwnerSkippedUser(owner, uid, `Live stream closed by host (${reason}) - Access hash expired`, {
      name: pInfo?.firstName,
      username: pInfo?.username,
      phone: pInfo?.phone,
      category: 'no_peer',
      skippedByPhone: phone
    });
    purgedCount++;
  }

  saveAccountVerifiedQueue(phone, retainedQ);

  if (a) {
    (a as any).in_stream_batch = 0;
    (a as any).batch_sent_in_cycle = 0;
  }

  if (purgedCount > 0) {
    log(
      phone,
      'WARN',
      `⚠️ [STREAM CONCLUDED - AUTO PURGE] Live stream ended by host. Discarded ${purgedCount} stale queue items with expired hashes. Ready for next live stream!`
    );
    if (typeof broadcastAccountUpdate === 'function') {
      try {
        broadcastAccountUpdate(owner);
      } catch {}
    }
  }

  return purgedCount;
}

function claimNextFromAccountVerifiedQueue(phone: string): number | null {
  const q = getAccountVerifiedQueue(phone);
  const a = accounts.get(phone);
  const owner = a?.owner || 'admin';
  const sent = getOwnerSentUsers(owner);
  const skipped = getOwnerSkippedUsers(owner);
  const peers = getOwnerPeers(owner);

  // Prune any already sent or skipped UIDs immediately so queue count reflects reality
  const validUids = q.filter((uid) => !sent.has(uid) && !skipped.has(uid) && !(a?.sent_users?.has(uid)));
  if (validUids.length !== q.length) {
    saveAccountVerifiedQueue(phone, validUids);
  }
  if (validUids.length === 0) return null;

  // Separate into:
  // 1. First priority: Users WITHOUT @username (temporary stream listener hash, DM first)
  // 2. Second priority: Users WITH @username (DM after without-username users, or skip if reject_usernames is true)
  const withoutUsername: number[] = [];
  const withUsername: number[] = [];

  for (const uid of validUids) {
    const pInfo = peers.get(String(uid)) || findPeerInfoAnywhere(String(uid), owner);
    const hasUname = Boolean(pInfo?.username && String(pInfo.username).trim().length > 0);
    if (hasUname) {
      withUsername.push(uid);
    } else {
      withoutUsername.push(uid);
    }
  }

  // FIRST PRIORITY: Always DM users without @username first!
  if (withoutUsername.length > 0) {
    return withoutUsername[0];
  }

  // SECOND PRIORITY: Users with @username (worker handles DMing them or skipping according to config)
  if (withUsername.length > 0) {
    return withUsername[0];
  }

  return null;
}

// Backward-compatible wrappers for owner queue
function getOwnerVerifiedQueue(owner: string): number[] {
  const normOwner = owner || 'admin';
  const combined: number[] = [];
  for (const acc of accounts.values()) {
    if ((acc.owner || 'admin') === normOwner) {
      combined.push(...getAccountVerifiedQueue(acc.phone));
    }
  }
  return Array.from(new Set(combined));
}

function saveOwnerVerifiedQueue(owner: string, q: number[]): void {
  const normOwner = owner || 'admin';
  for (const acc of accounts.values()) {
    if ((acc.owner || 'admin') === normOwner) {
      saveAccountVerifiedQueue(acc.phone, q);
      break;
    }
  }
}

function addToOwnerVerifiedQueue(owner: string, uids: number[]): void {
  const normOwner = owner || 'admin';
  for (const acc of accounts.values()) {
    if ((acc.owner || 'admin') === normOwner && acc.running) {
      addToAccountVerifiedQueue(acc.phone, uids);
      return;
    }
  }
}

function removeFromOwnerVerifiedQueue(owner: string, uid: number): void {
  const normOwner = owner || 'admin';
  for (const acc of accounts.values()) {
    if ((acc.owner || 'admin') === normOwner) {
      removeFromAccountVerifiedQueue(acc.phone, uid);
    }
  }
}

function purgeStaleVerifiedQueueOnStreamEnd(owner: string, phone: string, reason: string): number {
  return purgeAccountVerifiedQueueOnStreamEnd(phone, reason);
}

function broadcastPeerToOwnerClients(owner: string, uidStr: string, p?: PeerInfo): void {
  if (!p) return;
  const hash = p.accessHash ? String(p.accessHash).replace(/[^0-9-]/g, '') : '';
  for (const acc of accounts.values()) {
    if ((acc.owner || 'admin') === owner && acc.client) {
      try {
        if (hash && hash !== '0') {
          const inputPeer = new Api.InputPeerUser({
            userId: BigInt(uidStr) as any,
            accessHash: BigInt(hash) as any
          });
          if ((acc.client as any)._entityCache?.cacheMap) {
            (acc.client as any)._entityCache.cacheMap.set(uidStr, inputPeer);
          }
          const dummyUser = new Api.User({
            id: BigInt(uidStr) as any,
            accessHash: BigInt(hash) as any,
            firstName: p.firstName || 'User',
            username: p.username
          });
          if ((acc.client as any).session && typeof (acc.client as any).session.processEntities === 'function') {
            (acc.client as any).session.processEntities({ users: [dummyUser] });
          }
          if ((acc.client as any)._entityCache && typeof (acc.client as any)._entityCache.add === 'function') {
            (acc.client as any)._entityCache.add([dummyUser]);
          }
        }
      } catch {}
    }
  }
}

function claimNextFromVerifiedQueue(owner: string, phone: string, client?: any): number | null {
  const normOwner = owner || 'admin';
  const q = getOwnerVerifiedQueue(normOwner);
  const sent = getOwnerSentUsers(normOwner);
  const skipped = getOwnerSkippedUsers(normOwner);
  const peers = getOwnerPeers(normOwner);

  if (!ownerVerifiedReservedUids.has(normOwner)) {
    ownerVerifiedReservedUids.set(normOwner, new Map());
  }
  const reserved = ownerVerifiedReservedUids.get(normOwner)!;

  // Release previous reservation of this phone if any
  for (const [rUid, rPhone] of reserved.entries()) {
    if (rPhone === phone) {
      reserved.delete(rUid);
    }
  }

  // Helper: Determine if THIS specific phone can message this user in Telegram
  // MTProto access_hash is cryptographically bound to the account session that discovered the user.
  // 1. Users with @username can be resolved and messaged universally by ANY active account.
  // 2. Users without @username are routed to the specific account that extracted them (or holds their accessHash).
  const canPhoneMessage = (p: PeerInfo | undefined, uid: number): boolean => {
    if (!p) return false;
    // 1. If user has a username, ANY account can resolve and message them universally
    if (p.username && p.username.trim().length > 0) return true;
    // 2. If this specific phone has an account-specific accessHash recorded
    if (p.accessHashes && p.accessHashes[phone] && p.accessHashes[phone] !== '0') return true;
    // 3. If this phone is the source phone that discovered the peer with a valid accessHash
    if (p.sourcePhone === phone && p.accessHash && p.accessHash !== '0') return true;
    // 4. If this client's active GramJS session or entity cache already contains the peer
    if (client) {
      try {
        if ((client as any).session?.getInputEntity?.(uid)) return true;
      } catch {}
    }
    // 5. Fallback if no source phone is specified
    if (!p.sourcePhone) return true;
    return false;
  };

  // Select the next candidate that THIS account has permission / session-access to message
  for (const uid of q) {
    if (!sent.has(uid) && !skipped.has(uid) && !reserved.has(uid)) {
      const p = peers.get(String(uid)) || findPeerInfoAnywhere(String(uid), normOwner);
      if (canPhoneMessage(p, uid)) {
        reserved.set(uid, phone);
        return uid;
      }
    }
  }

  return null;
}

function releaseOwnerVerifiedReservation(owner: string, uid: number): void {
  const normOwner = owner || 'admin';
  const reserved = ownerVerifiedReservedUids.get(normOwner);
  if (reserved) reserved.delete(uid);
}

// Backward-compatible unified wrappers
function getOwnerQueue(owner: string): number[] {
  return getOwnerVerifiedQueue(owner);
}
function saveOwnerQueue(owner: string, q: number[]): void {
  saveOwnerVerifiedQueue(owner, q);
}
function addToOwnerQueue(owner: string, phone: string, uids: number[]): void {
  addToOwnerRawQueue(owner, phone, uids);
}
function claimNextFromOwnerQueue(owner: string, phone: string): number | null {
  return claimNextFromVerifiedQueue(owner, phone);
}
function releaseOwnerReservation(owner: string, uid: number): void {
  releaseOwnerVerifiedReservation(owner, uid);
}
function removeFromOwnerQueue(owner: string, uid: number): void {
  removeFromOwnerVerifiedQueue(owner, uid);
}

function bulkFilterOwnerQueue(owner: string, phone?: string): number {
  const normOwner = owner || 'admin';
  const rawQ = getOwnerRawQueue(normOwner);
  const verifiedQ = getOwnerVerifiedQueue(normOwner);
  const sentSet = getOwnerSentUsers(normOwner);
  const skippedSet = getOwnerSkippedUsers(normOwner);

  const filteredRaw = rawQ.filter((id) => !sentSet.has(id) && !skippedSet.has(id));
  const filteredVerified = verifiedQ.filter((id) => !sentSet.has(id) && !skippedSet.has(id));

  const removedRaw = rawQ.length - filteredRaw.length;
  const removedVerified = verifiedQ.length - filteredVerified.length;

  if (removedRaw > 0) saveOwnerRawQueue(normOwner, filteredRaw);
  if (removedVerified > 0) saveOwnerVerifiedQueue(normOwner, filteredVerified);

  const totalRemoved = removedRaw + removedVerified;
  if (totalRemoved > 0 && phone) {
    log(phone, 'INFO', `⚡ Bulk pruned ${totalRemoved} invalid users (Raw: ${filteredRaw.length} | Genuine: ${filteredVerified.length})`);
  }
  return totalRemoved;
}

function getOwnerSentUsers(owner: string): Set<number> {
  const normOwner = (owner || 'admin').toLowerCase();
  let s = ownerSentCache.get(normOwner);
  if (!s) {
    s = new Set();
    try {
      const localOwnerSPath = path.join(__dirname, `sent_owner_${normOwner}.json`);
      if (fs.existsSync(localOwnerSPath)) {
        const arr = JSON.parse(fs.readFileSync(localOwnerSPath, 'utf8'));
        if (Array.isArray(arr)) arr.forEach((id: number) => s!.add(id));
      } else if (owner && owner !== normOwner) {
        const altPath = path.join(__dirname, `sent_owner_${owner}.json`);
        if (fs.existsSync(altPath)) {
          const arr = JSON.parse(fs.readFileSync(altPath, 'utf8'));
          if (Array.isArray(arr)) arr.forEach((id: number) => s!.add(id));
        }
      }
    } catch {}
    ownerSentCache.set(normOwner, s);
  }
  return s;
}

function markOwnerSentUser(owner: string, uid: number, phone?: string): void {
  const normOwner = (owner || 'admin').toLowerCase();
  const s = getOwnerSentUsers(normOwner);
  s.add(uid);
  ownerSentCache.set(normOwner, s);
  try {
    const localOwnerSPath = path.join(__dirname, `sent_owner_${normOwner}.json`);
    asyncSaveJson(localOwnerSPath, Array.from(s), 1000);
  } catch {}
  // , { uids: Array.from(s) }); // DISABLED TO PREVENT FIRESTORE LIMIT EXHAUSTION

  if (phone) {
    saveSentUser(phone, uid);
  }

  if (typeof broadcastAccountUpdate === 'function') {
    try {
      broadcastAccountUpdate(normOwner);
    } catch {}
  }
}

function getOwnerPeers(owner: string): Map<string, PeerInfo> {
  const normOwner = owner || 'admin';
  let p = ownerPeersCache.get(normOwner);
  if (!p) {
    p = new Map();
    try {
      const localPPath = path.join(__dirname, `peers_owner_${normOwner}.json`);
      if (fs.existsSync(localPPath)) {
        const arr = JSON.parse(fs.readFileSync(localPPath, 'utf8'));
        if (Array.isArray(arr)) {
          for (const [k, v] of arr) {
            p.set(k, v);
          }
        }
      }
    } catch {}
    ownerPeersCache.set(normOwner, p);
  }
  return p;
}

function saveOwnerPeers(owner: string, p: Map<string, PeerInfo>): void {
  const normOwner = owner || 'admin';
  ownerPeersCache.set(normOwner, p);

  // Sync in-memory cache to all accounts of owner instantly (0ms CPU, zero disk thrashing)
  for (const acc of accounts.values()) {
    if ((acc.owner || 'admin') === normOwner) {
      peersCache.set(acc.phone, p);
    }
  }

  // Persist master owner file asynchronously with 10s debounce
  try {
    const localPPath = path.join(__dirname, `peers_owner_${normOwner}.json`);
    asyncSaveJson(localPPath, () => Array.from(p.entries()), 10000);
  } catch {}
}

function findPeerInfoAnywhere(uidStr: string, preferredOwner?: string): PeerInfo | undefined {
  const cleanUid = String(uidStr).replace(/[^0-9-]/g, '');
  if (!cleanUid || cleanUid === '0') return undefined;

  // 1. Check preferred owner
  if (preferredOwner) {
    const p = getOwnerPeers(preferredOwner).get(cleanUid);
    if (p && (p.accessHash || p.username || p.phone)) return p;
  }

  // 2. Check admin
  const adminP = getOwnerPeers('admin').get(cleanUid);
  if (adminP && (adminP.accessHash || adminP.username || adminP.phone)) return adminP;

  // 3. Check all cached owners
  for (const [owner, pMap] of ownerPeersCache.entries()) {
    const p = pMap.get(cleanUid);
    if (p && (p.accessHash || p.username || p.phone)) return p;
  }

  // 4. Check all account peer caches
  for (const [phone, pMap] of peersCache.entries()) {
    const p = pMap.get(cleanUid);
    if (p && (p.accessHash || p.username || p.phone)) return p;
  }

  return undefined;
}

function getTodayDateString(): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Kolkata',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(new Date());
}

function checkAndResetDailyQuota(phone: string): void {
  const a = accounts.get(phone);
  if (!a) return;
  const todayStr = getTodayDateString();
  if ((a as any).daily_extracted_date !== todayStr) {
    (a as any).daily_extracted_date = todayStr;
    (a as any).daily_extracted_count = 0;
    (a as any).daily_alert_sent = false;
    if (a.running && !a.live_on) {
      a.live_on = true;
      log(phone, 'OK', `New day (${todayStr}) started: Daily counters refreshed. Live monitoring activated!`);
    }
  }
}

function checkAndResetDailyDmQuota(phone: string): void {
  const a = accounts.get(phone);
  if (!a) return;
  const todayStr = getTodayDateString();
  if ((a as any).daily_sent_date !== todayStr) {
    (a as any).daily_sent_date = todayStr;
    (a as any).daily_sent_count = 0;
    // a.sent_count is NEVER reset to 0; it is the total lifetime DM count for this ID
    if (a.running && !a.dm_on) {
      a.dm_on = true;
    }
  }
}

// ---------------- DAILY DM HISTORY TRACKING (LAST 5 DAYS PER USER) ----------------
interface DailyDmHistoryRecord {
  count: number;
  phones: string[];
  total_ids?: number;
}
const DAILY_DM_HISTORY_FILE = path.join(__dirname, 'daily_dm_history.json');
let dailyDmHistory: Record<string, Record<string, DailyDmHistoryRecord>> = {};
let saveDailyDmTimeout: NodeJS.Timeout | null = null;

function loadDailyDmHistory(): void {
  // 1. Try loading from SQLite first
  if (sqliteDb) {
    try {
      const rows = sqliteDb.prepare('SELECT * FROM daily_dm_history').all();
      if (Array.isArray(rows) && rows.length > 0) {
        dailyDmHistory = {};
        for (const r of rows) {
          const owner = r.owner;
          const date = r.date;
          if (!dailyDmHistory[owner]) dailyDmHistory[owner] = {};
          let phones: string[] = [];
          try { phones = JSON.parse(r.phones_json); } catch {}
          dailyDmHistory[owner][date] = {
            count: Number(r.count) || 0,
            phones,
            total_ids: r.total_ids ? Number(r.total_ids) : undefined
          };
        }
        console.log(`[DATABASE] Loaded daily DM history from SQLite.`);
        return;
      }
    } catch (err) {
      console.warn('[DATABASE] SQLite loadDailyDmHistory error, falling back to JSON:', err);
    }
  }

  // 2. Fallback to daily_dm_history.json (and auto-migrate into SQLite)
  try {
    if (fs.existsSync(DAILY_DM_HISTORY_FILE)) {
      dailyDmHistory = JSON.parse(fs.readFileSync(DAILY_DM_HISTORY_FILE, 'utf8')) || {};
      // Auto-migrate to SQLite
      if (sqliteDb) {
        try {
          const stmt = sqliteDb.prepare(`INSERT OR REPLACE INTO daily_dm_history (owner, date, count, phones_json, total_ids) VALUES (?, ?, ?, ?, ?)`);
          for (const [owner, days] of Object.entries(dailyDmHistory)) {
            for (const [d, rec] of Object.entries(days || {})) {
              stmt.run(owner, d, rec.count || 0, JSON.stringify(rec.phones || []), rec.total_ids || null);
            }
          }
          console.log('[MIGRATION] Auto-migrated daily DM history into SQLite.');
        } catch {}
      }
    }
  } catch (err) {
    console.error('Error loading daily_dm_history.json:', err);
    dailyDmHistory = {};
  }
}

function saveDailyDmHistory(): void {
  // 1. Sync to SQLite
  if (sqliteDb) {
    try {
      const stmt = sqliteDb.prepare(`INSERT OR REPLACE INTO daily_dm_history (owner, date, count, phones_json, total_ids) VALUES (?, ?, ?, ?, ?)`);
      for (const [owner, days] of Object.entries(dailyDmHistory)) {
        for (const [d, rec] of Object.entries(days || {})) {
          stmt.run(owner, d, rec.count || 0, JSON.stringify(rec.phones || []), rec.total_ids || null);
        }
      }
    } catch (err) {
      console.error('Error saving daily DM history to SQLite:', err);
    }
  }

  // 2. Sync to daily_dm_history.json
  try {
    fs.writeFileSync(DAILY_DM_HISTORY_FILE, JSON.stringify(dailyDmHistory, null, 2), 'utf8');
  } catch (err) {
    console.error('Error saving daily_dm_history.json:', err);
  }
}

function saveDailyDmHistoryDebounced(): void {
  if (saveDailyDmTimeout) return;
  saveDailyDmTimeout = setTimeout(() => {
    saveDailyDmTimeout = null;
    saveDailyDmHistory();
  }, 2000);
}

// Call on startup
loadDailyDmHistory();


// ---------------- DAILY JOIN REQUEST HISTORY & TRACKED INVITE LINKS ----------------
interface TrackedInviteLinkRecord {
  owner: string;
  invite_link: string;
  invite_link_name: string;
  chat_id: string;
  channel_title?: string;
  created_at: number;
}

interface DailyJoinRecord {
  count: number;
  joiners?: { id: number; name: string; username?: string; time: string }[];
}

const USER_TRACKED_LINKS_FILE = path.join(__dirname, 'user_tracked_links.json');
const DAILY_JOIN_HISTORY_FILE = path.join(__dirname, 'daily_join_history.json');

let userTrackedLinks: Record<string, TrackedInviteLinkRecord> = {};
let dailyJoinHistory: Record<string, Record<string, DailyJoinRecord>> = {};
let saveDailyJoinTimeout: NodeJS.Timeout | null = null;

function loadUserTrackedLinks(): void {
  try {
    if (fs.existsSync(USER_TRACKED_LINKS_FILE)) {
      userTrackedLinks = JSON.parse(fs.readFileSync(USER_TRACKED_LINKS_FILE, 'utf8')) || {};
    }
  } catch (err) {
    userTrackedLinks = {};
  }
}

function saveUserTrackedLinks(): void {
  try {
    asyncSaveJson(USER_TRACKED_LINKS_FILE, userTrackedLinks, 1000);
  } catch {}
}

function loadDailyJoinHistory(): void {
  // 1. Try loading from SQLite first
  if (sqliteDb) {
    try {
      const rows = sqliteDb.prepare('SELECT * FROM daily_join_history').all();
      if (Array.isArray(rows) && rows.length > 0) {
        dailyJoinHistory = {};
        for (const r of rows) {
          const owner = r.owner;
          const date = r.date;
          if (!dailyJoinHistory[owner]) dailyJoinHistory[owner] = {};
          let joiners: any[] = [];
          try { joiners = JSON.parse(r.joiners_json); } catch {}
          dailyJoinHistory[owner][date] = {
            count: Number(r.count) || 0,
            joiners
          };
        }
        console.log(`[DATABASE] Loaded daily Join history from SQLite.`);
        return;
      }
    } catch (err) {
      console.warn('[DATABASE] SQLite loadDailyJoinHistory error, falling back to JSON:', err);
    }
  }

  // 2. Fallback to daily_join_history.json (and auto-migrate into SQLite)
  try {
    if (fs.existsSync(DAILY_JOIN_HISTORY_FILE)) {
      dailyJoinHistory = JSON.parse(fs.readFileSync(DAILY_JOIN_HISTORY_FILE, 'utf8')) || {};
      // Auto-migrate to SQLite
      if (sqliteDb) {
        try {
          const stmt = sqliteDb.prepare(`INSERT OR REPLACE INTO daily_join_history (owner, date, count, joiners_json) VALUES (?, ?, ?, ?)`);
          for (const [owner, days] of Object.entries(dailyJoinHistory)) {
            for (const [d, rec] of Object.entries(days || {})) {
              stmt.run(owner, d, rec.count || 0, JSON.stringify(rec.joiners || []));
            }
          }
          console.log('[MIGRATION] Auto-migrated daily Join history into SQLite.');
        } catch {}
      }
    }
  } catch (err) {
    dailyJoinHistory = {};
  }
}

function saveDailyJoinHistoryDebounced(): void {
  // 1. Sync to SQLite
  if (sqliteDb) {
    try {
      const stmt = sqliteDb.prepare(`INSERT OR REPLACE INTO daily_join_history (owner, date, count, joiners_json) VALUES (?, ?, ?, ?)`);
      for (const [owner, days] of Object.entries(dailyJoinHistory)) {
        for (const [d, rec] of Object.entries(days || {})) {
          stmt.run(owner, d, rec.count || 0, JSON.stringify(rec.joiners || []));
        }
      }
    } catch (err) {
      console.error('Error saving daily Join history to SQLite:', err);
    }
  }

  // 2. Sync to daily_join_history.json
  if (saveDailyJoinTimeout) return;
  saveDailyJoinTimeout = setTimeout(() => {
    saveDailyJoinTimeout = null;
    try {
      asyncSaveJson(DAILY_JOIN_HISTORY_FILE, dailyJoinHistory, 1000);
    } catch {}
  }, 2000);
}

loadUserTrackedLinks();
loadDailyJoinHistory();

function recordJoinRequest(owner: string, userDetails?: { id: number; name: string; username?: string }): void {
  const normOwner = (owner || 'admin').toLowerCase();
  const todayStr = getTodayDateString();
  const historyKey = Object.keys(dailyJoinHistory).find(k => k.toLowerCase() === normOwner) || normOwner;
  if (!dailyJoinHistory[historyKey]) {
    dailyJoinHistory[historyKey] = {};
  }
  if (!dailyJoinHistory[historyKey][todayStr]) {
    dailyJoinHistory[historyKey][todayStr] = { count: 0, joiners: [] };
  }
  const rec = dailyJoinHistory[historyKey][todayStr];
  rec.count = (rec.count || 0) + 1;
  if (userDetails) {
    if (!rec.joiners) rec.joiners = [];
    rec.joiners.unshift({
      id: userDetails.id,
      name: userDetails.name || 'Telegram User',
      username: userDetails.username || '',
      time: new Date().toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata' })
    });
    if (rec.joiners.length > 50) rec.joiners = rec.joiners.slice(0, 50);
  }
  saveDailyJoinHistoryDebounced();
}

function getOwnerLifetimeJoins(owner: string): number {
  const normOwner = (owner || 'admin').toLowerCase();
  const historyKey = Object.keys(dailyJoinHistory).find(k => k.toLowerCase() === normOwner) || normOwner;
  const userJoins = dailyJoinHistory[historyKey] || {};
  let total = 0;
  for (const d of Object.keys(userJoins)) {
    total += userJoins[d]?.count || 0;
  }
  return total;
}

function getOwnerDailyJoinStats(owner: string) {
  const normOwner = (owner || 'admin').toLowerCase();
  const todayStr = getTodayDateString();
  const historyKey = Object.keys(dailyJoinHistory).find(k => k.toLowerCase() === normOwner) || normOwner;
  if (!dailyJoinHistory[historyKey]) {
    dailyJoinHistory[historyKey] = {};
  }

  const [currY, currM, currD] = todayStr.split('-').map(Number);
  const result = [];

  for (let i = 0; i < 5; i++) {
    const istDayDate = new Date(Date.UTC(currY, currM - 1, currD - i, 0, 0, 0));
    const dateStr = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Kolkata',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    }).format(istDayDate);

    const parts = new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Asia/Kolkata',
      day: '2-digit',
      month: 'short'
    }).formatToParts(istDayDate);
    const dayVal = parts.find(p => p.type === 'day')?.value || '';
    const monthVal = parts.find(p => p.type === 'month')?.value || '';
    const shortDate = `${dayVal} ${monthVal}`;

    let label = '';
    if (i === 0) label = `Today (${shortDate})`;
    else if (i === 1) label = `Yesterday (${shortDate})`;
    else label = shortDate;

    const count = dailyJoinHistory[historyKey]?.[dateStr]?.count || 0;
    result.push({
      date: dateStr,
      label,
      short_date: shortDate,
      join_count: count
    });
  }

  return result;
}

// Helper to auto-create and cache unique Tracked Join Request invite link per user
async function getOrCreateUserTrackedInviteLink(owner: string, a?: any): Promise<string> {
  const normOwner = owner || 'admin';
  const u = getUser(normOwner);
  const rawTargetLink = (
    u?.master_config?.channel_link || 
    (a ? getEffectiveConfig(a).channel_link : '') || 
    getUser('admin')?.master_config?.channel_link || 
    ''
  ).trim();

  if (!rawTargetLink) return '';

  // 1. Check if already generated for this user
  if (userTrackedLinks[normOwner]?.invite_link) {
    return userTrackedLinks[normOwner].invite_link;
  }

  // 2. Locate filter bot token (prefer user's filter bot, fallback to admin filter/alert bot)
  const botToken = (
    u?.master_config?.filter_bot_token || 
    u?.alert_bot_token || 
    getUser('admin')?.master_config?.filter_bot_token || 
    getUser('admin')?.alert_bot_token || 
    ''
  ).trim();

  if (!botToken) {
    return rawTargetLink;
  }

  // 3. Resolve channel chat_id
  let targetChatId = '';
  try {
    const adminChannels = await getFilterBotAdminChannels(botToken, normOwner);
    for (const [cid] of adminChannels.entries()) {
      targetChatId = cid;
      break;
    }
  } catch {}

  if (!targetChatId) {
    const numMatch = rawTargetLink.match(/-100\d+|\/c\/(\d+)/);
    if (numMatch) {
      targetChatId = numMatch[1] ? `-100${numMatch[1]}` : numMatch[0];
    } else {
      const pubMatch = rawTargetLink.match(/t\.me\/([a-zA-Z0-9_]{4,})(?:\/|\?|$)/);
      if (pubMatch && !pubMatch[1].startsWith('+') && !rawTargetLink.includes('/+')) {
        targetChatId = '@' + pubMatch[1];
      }
    }
  }

  if (!targetChatId) {
    return rawTargetLink;
  }

  // 4. Create chat invite link via Telegram Bot API with creates_join_request: true
  try {
    const linkName = `Track_${normOwner}`;
    const url = `https://api.telegram.org/bot${encodeURIComponent(botToken)}/createChatInviteLink`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: targetChatId,
        name: linkName,
        creates_join_request: true
      })
    });
    const data: any = await res.json().catch(() => null);
    if (data?.ok && data.result?.invite_link) {
      const inviteLink = data.result.invite_link;
      userTrackedLinks[normOwner] = {
        owner: normOwner,
        invite_link: inviteLink,
        invite_link_name: linkName,
        chat_id: String(targetChatId),
        created_at: Date.now()
      };
      saveUserTrackedLinks();
      log(a?.phone || normOwner, 'OK', `🎯 Generated Tracked Join Request Link for ${normOwner}: ${inviteLink}`);
      return inviteLink;
    } else {
      console.warn(`[TRACKED LINK] Could not create link for ${normOwner}:`, data?.description || data);
    }
  } catch (err: any) {
    console.error(`[TRACKED LINK ERROR] ${normOwner}:`, err?.message || err);
  }

  return rawTargetLink;
}

// --- AI DM HISTORY TRACKING ---
const aiDmHistory: Record<string, Record<string, number>> = {};
const aiDmFile = path.join(__dirname, 'ai_dm_history.json');

function loadAiDmHistory() {
  if (fs.existsSync(aiDmFile)) {
    try {
      const parsed = JSON.parse(fs.readFileSync(aiDmFile, 'utf8'));
      for (const k in parsed) { aiDmHistory[k] = parsed[k]; }
    } catch {}
  }
}
loadAiDmHistory();

function saveAiDmHistory() {
  try { fs.writeFileSync(aiDmFile, JSON.stringify(aiDmHistory, null, 2)); } catch {}
}

function recordAiDm(owner: string) {
  const normOwner = owner || 'admin';
  const todayStr = getTodayDateString();
  if (!aiDmHistory[normOwner]) aiDmHistory[normOwner] = {};
  aiDmHistory[normOwner][todayStr] = (aiDmHistory[normOwner][todayStr] || 0) + 1;
  saveAiDmHistory();
}
// -----------------------------

// --- DYNAMIC HINGLISH COMBINATORIAL ENGINE (ULTRA-ATTRACTIVE 2-3 LINE FORMAT) ---
interface HinglishTemplateBank {
  greetings: { id: string; text: string }[];
  offers?: { id: string; text: string }[];
  intros?: { id: string; text: string }[];
  services?: { id: string; text: string }[];
  ctas?: { id: string; text: string }[];
}

let hinglishTemplates: HinglishTemplateBank = {
  greetings: [],
  offers: []
};

function loadHinglishTemplates() {
  try {
    const p = path.join(__dirname, 'templates_hinglish.json');
    if (fs.existsSync(p)) {
      hinglishTemplates = JSON.parse(fs.readFileSync(p, 'utf8'));
    }
  } catch (e) {
    console.error('Error loading templates_hinglish.json:', e);
  }
}
loadHinglishTemplates();

function buildDynamicHinglishMessage(rawName?: string, channelLink?: string): { text: string; code: string; components: any } {
  if (!hinglishTemplates.greetings || !hinglishTemplates.greetings.length) {
    loadHinglishTemplates();
  }
  const cleanLink = (channelLink || '').trim() || 'https://t.me/telegram';
  
  // Sanitize first name: clean symbols/emojis
  let safeName = (rawName || '').trim();
  safeName = safeName.replace(/[^\p{L}\p{N}\s]/gu, '').trim();
  if (!safeName || safeName.length < 2 || safeName.length > 25) {
    safeName = 'bhai';
  } else {
    safeName = safeName.charAt(0).toUpperCase() + safeName.slice(1);
  }

  const gList = hinglishTemplates.greetings || [];
  const oList = hinglishTemplates.offers || [];

  const g = gList[Math.floor(Math.random() * (gList.length || 1))] || { id: 'G01', text: 'Hey {NAME} bhai! Loss recover karna hai? 🔥' };
  const o = oList[Math.floor(Math.random() * (oList.length || 1))] || { id: 'O01', text: 'Mere VIP group me daily prediction aur hacks milte hain jisse aap apna loss khud recover kar sakte ho, join karke mujhe DM karo personally support dunga 👇' };

  const greetingFormatted = g.text.replace(/\{NAME\}/g, safeName);
  const offerFormatted = o.text.replace(/\{CHANNEL_LINK\}/g, cleanLink);

  // Ultra-crisp, high-conversion 2-3 line format (Instant attraction)
  const text = `${greetingFormatted}\n${offerFormatted}\n${cleanLink}`;
  const code = `${g.id}+${o.id}`;

  return { 
    text, 
    code,
    components: {
      greeting: { id: g.id, text: greetingFormatted },
      offer: { id: o.id, text: offerFormatted }
    }
  };
}
// ---------------------------------------------------------------------------------

function recordDailyDm(owner: string, phone: string): void {
  const normOwner = (owner || 'admin').toLowerCase();
  const todayStr = getTodayDateString();
  const historyKey = Object.keys(dailyDmHistory).find(k => k.toLowerCase() === normOwner) || normOwner;
  if (!dailyDmHistory[historyKey]) {
    dailyDmHistory[historyKey] = {};
  }
  if (!dailyDmHistory[historyKey][todayStr]) {
    dailyDmHistory[historyKey][todayStr] = { count: 0, phones: [] };
  }
  const rec = dailyDmHistory[historyKey][todayStr];
  rec.count = (rec.count || 0) + 1;
  if (phone && !rec.phones.includes(phone)) {
    rec.phones.push(phone);
  }
  const userAccs = Array.from(accounts.values()).filter(a => (a.owner || 'admin').toLowerCase() === normOwner);
  rec.total_ids = userAccs.length;

  saveDailyDmHistoryDebounced();
}

function getOwnerDailyDmStats(owner: string, totalAccountsCount: number) {
  const normOwner = (owner || 'admin').toLowerCase();
  const todayStr = getTodayDateString();

  // Sync today's count from live account states (case-insensitive owner match)
  let liveTodayDMs = 0;
  let sumAccSent = 0;
  const activePhonesToday: string[] = [];
  for (const a of accounts.values()) {
    if ((a.owner || 'admin').toLowerCase() === normOwner) {
      checkAndResetDailyDmQuota(a.phone);
      const cnt = Math.max((a as any).daily_sent_count || 0, (a as any).daily_extracted_count || 0);
      if (cnt > 0) {
        liveTodayDMs += cnt;
        activePhonesToday.push(a.phone);
      }
      sumAccSent += (a.sent_count || 0);
    }
  }

  // Find matching dailyDmHistory key (case-insensitive & trimmed)
  const historyKey = Object.keys(dailyDmHistory).find(k => k.trim().toLowerCase() === normOwner) || normOwner;
  if (!dailyDmHistory[historyKey]) {
    dailyDmHistory[historyKey] = {};
  }

  const todayHistCount = dailyDmHistory[historyKey]?.[todayStr]?.count || 0;
  const todayCount = Math.max(liveTodayDMs, todayHistCount);

  if (!dailyDmHistory[historyKey][todayStr]) {
    dailyDmHistory[historyKey][todayStr] = {
      count: todayCount,
      phones: activePhonesToday,
      total_ids: totalAccountsCount
    };
  } else {
    if (todayCount > (dailyDmHistory[historyKey][todayStr].count || 0)) {
      dailyDmHistory[historyKey][todayStr].count = todayCount;
    }
    for (const p of activePhonesToday) {
      if (!dailyDmHistory[historyKey][todayStr].phones.includes(p)) {
        dailyDmHistory[historyKey][todayStr].phones.push(p);
      }
    }
    dailyDmHistory[historyKey][todayStr].total_ids = totalAccountsCount;
  }

  // Calculate lifetime total across accounts, sent set, and history
  const alreadySentSet = getOwnerSentUsers(normOwner);
  let totalHistoryDMs = 0;
  if (dailyDmHistory[historyKey]) {
    for (const d of Object.keys(dailyDmHistory[historyKey])) {
      totalHistoryDMs += (dailyDmHistory[historyKey][d]?.count || 0);
    }
  }
  const lifetimeTotalDMs = Math.max(alreadySentSet.size, sumAccSent, totalHistoryDMs, todayCount);

  // Remaining unaccounted DMs that belong to past days
  let unaccountedPastDMs = Math.max(0, lifetimeTotalDMs - todayCount);

  const [currY, currM, currD] = todayStr.split('-').map(Number);
  const result = [];

  for (let i = 0; i < 5; i++) {
    // Generate dates using exact IST day subtraction
    const istDayDate = new Date(Date.UTC(currY, currM - 1, currD - i, 0, 0, 0));
    const dateStr = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Kolkata',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    }).format(istDayDate);

    const parts = new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Asia/Kolkata',
      day: '2-digit',
      month: 'short'
    }).formatToParts(istDayDate);

    const day = parts.find(p => p.type === 'day')?.value || '';
    const month = parts.find(p => p.type === 'month')?.value || '';
    const shortDate = `${day} ${month}`;

    let label = shortDate;
    if (i === 0) label = `Today (${shortDate})`;
    else if (i === 1) label = `Yesterday (${shortDate})`;

    const histEntry = dailyDmHistory[historyKey]?.[dateStr];
    let dmCount = i === 0 ? todayCount : (histEntry ? (histEntry.count || 0) : 0);

    // If past day has 0 recorded in history but the user has verifiable past DMs sent:
    if (i > 0 && dmCount === 0 && unaccountedPastDMs > 0) {
      const allocated = (i === 1)
        ? Math.min(unaccountedPastDMs, Math.ceil(unaccountedPastDMs / (5 - i)))
        : Math.min(unaccountedPastDMs, Math.floor(unaccountedPastDMs / (5 - i + 1)));
      if (allocated > 0) {
        dmCount = allocated;
        unaccountedPastDMs -= allocated;
        if (!dailyDmHistory[historyKey][dateStr]) {
          dailyDmHistory[historyKey][dateStr] = { count: allocated, phones: [] };
        } else {
          dailyDmHistory[historyKey][dateStr].count = allocated;
        }
      }
    }

    const idsCount = (histEntry && histEntry.total_ids !== undefined) ? histEntry.total_ids : totalAccountsCount;
    const activeIdsCount = i === 0 ? Math.max(activePhonesToday.length, histEntry?.phones?.length || 0) : (histEntry?.phones?.length || 0);

    result.push({
      date: dateStr,
      label,
      short_date: shortDate,
      count: dmCount,
      dm_count: dmCount,
      total_ids: idsCount,
      active_ids: activeIdsCount
    });
  }

  saveDailyDmHistoryDebounced();
  return result;
}

// Universal Comprehensive DM & Join Overview Helper for Admin & User Bots
function getOwnerDmOverview(username: string) {
  const normUser = (username || 'admin').toLowerCase();
  const uAccs = Array.from(accounts.values()).filter((a: any) => (a.owner || 'admin').toLowerCase() === normUser);
  const liveAccounts = uAccs.filter((a: any) => a.running).length;
  const stats5Days = getOwnerDailyDmStats(username, uAccs.length);
  const joins5Days = getOwnerDailyJoinStats(username);

  const todayDms = stats5Days.length > 0 ? (stats5Days[0].count || 0) : 0;
  const todayJoins = joins5Days.length > 0 ? (joins5Days[0].join_count || 0) : 0;
  const sum5DaysDms = stats5Days.reduce((acc: number, item: any) => acc + (item.count || 0), 0);
  const sum5DaysJoins = joins5Days.reduce((acc: number, item: any) => acc + (item.join_count || 0), 0);
  const avgPerDayDms = Math.round(sum5DaysDms / Math.max(1, stats5Days.length));

  const alreadySentSet = getOwnerSentUsers(normUser);
  let sumAccSent = 0;
  for (const a of uAccs) sumAccSent += (a.sent_count || 0);

  const historyKey = Object.keys(dailyDmHistory).find(k => k.trim().toLowerCase() === normUser) || normUser;
  let totalHistoryDMs = 0;
  if (dailyDmHistory[historyKey]) {
    for (const d of Object.keys(dailyDmHistory[historyKey])) {
      totalHistoryDMs += (dailyDmHistory[historyKey][d]?.count || 0);
    }
  }
  const lifetimeDms = Math.max(alreadySentSet.size, sumAccSent, totalHistoryDMs, sum5DaysDms, todayDms);
  const lifetimeJoins = getOwnerLifetimeJoins(username);
  const convRate = todayDms > 0 ? ((todayJoins / todayDms) * 100).toFixed(1) + '%' : (todayJoins > 0 ? '100%' : '0.0%');

  return {
    username,
    uAccs,
    liveAccounts,
    totalAccounts: uAccs.length,
    todayDms,
    todayJoins,
    sum5DaysDms,
    sum5DaysJoins,
    avgPerDayDms,
    lifetimeDms,
    lifetimeJoins,
    convRate,
    stats5Days,
    joins5Days
  };
}

// ---------------- MIDNIGHT 12:00 AM & EXPIRY AUTOMATIONS ----------------
const LAST_SWEEP_FILE = path.join(__dirname, 'last_midnight_sweep.json');
let lastMidnightTransferDate = '';
try {
  if (fs.existsSync(LAST_SWEEP_FILE)) {
    const raw = fs.readFileSync(LAST_SWEEP_FILE, 'utf8');
    lastMidnightTransferDate = JSON.parse(raw).lastDate || getTodayDateString();
  } else {
    // CRITICAL: On first startup during the day, lock to today's date so it NEVER wipes daytime data prematurely!
    lastMidnightTransferDate = getTodayDateString();
    fs.writeFileSync(LAST_SWEEP_FILE, JSON.stringify({ lastDate: lastMidnightTransferDate, lastRun: new Date().toISOString() }), 'utf8');
  }
} catch {
  lastMidnightTransferDate = getTodayDateString();
}

const LAST_MIDNIGHT_REPORT_FILE = path.join(__dirname, 'last_midnight_report.json');
let lastMidnightReportDate = '';
try {
  if (fs.existsSync(LAST_MIDNIGHT_REPORT_FILE)) {
    const raw = fs.readFileSync(LAST_MIDNIGHT_REPORT_FILE, 'utf8');
    lastMidnightReportDate = JSON.parse(raw).lastDate || '';
  }
} catch {}

// 12:00 AM Midnight Automatic Activity Summary Report
async function sendMidnightDailyActivityReportToUsers(targetDateStr?: string): Promise<void> {
  const todayStr = getTodayDateString();
  let reportDate = targetDateStr;

  if (!reportDate) {
    // Default to the day that just concluded (yesterday in IST)
    const [tY, tM, tD] = todayStr.split('-').map(Number);
    const yesterdayDate = new Date(Date.UTC(tY, tM - 1, tD - 1, 0, 0, 0));
    reportDate = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Kolkata',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    }).format(yesterdayDate);
  }

  if (lastMidnightReportDate === reportDate) {
    return; // Already sent report for this date
  }
  lastMidnightReportDate = reportDate;
  try {
    fs.writeFileSync(LAST_MIDNIGHT_REPORT_FILE, JSON.stringify({ lastDate: reportDate, sentAt: new Date().toISOString() }), 'utf8');
  } catch {}

  console.log(`[MIDNIGHT REPORT] Dispatching 12:00 AM Daily Activity Reports for date: ${reportDate}...`);

  const adminUser = usersList.find((x: any) => x.role === 'admin' && (x.alert_bot_token || '').trim());
  const globalToken = adminUser ? (adminUser.alert_bot_token || '').trim() : '';

  for (const u of usersList) {
    if (u.role === 'admin' || u.username === 'admin') continue;

    const normUser = u.username.toLowerCase();

    // 1. Calculate Sent DMs for reportDate
    const uAccs = Array.from(accounts.values()).filter((a: any) => (a.owner || 'admin').toLowerCase() === normUser);
    const dmStats = getOwnerDailyDmStats(u.username, uAccs.length);
    const dayDmStat = dmStats.find((s: any) => s.date === reportDate);
    const dmHistKey = Object.keys(dailyDmHistory).find(k => k.trim().toLowerCase() === normUser) || normUser;
    const histDmCount = dailyDmHistory[dmHistKey]?.[reportDate]?.count || 0;
    const totalDms = Math.max(dayDmStat?.count || 0, histDmCount);

    // 2. Calculate Channel Join Requests for reportDate
    const joinKey = Object.keys(dailyJoinHistory).find(k => k.trim().toLowerCase() === normUser) || normUser;
    const histJoins = dailyJoinHistory[joinKey]?.[reportDate]?.count || 0;
    let growthJoins = 0;
    try {
      if (sqliteDb) {
        const [y, m, d] = reportDate.split('-').map(Number);
        const startOfDay = new Date(Date.UTC(y, m - 1, d, 0, 0, 0)).getTime() - (5.5 * 3600 * 1000);
        const endOfDay = startOfDay + (24 * 3600 * 1000);
        const row = sqliteDb.prepare("SELECT COUNT(*) as cnt FROM growth_subscribers WHERE LOWER(owner) = ? AND created_at >= ? AND created_at < ?").get(normUser, startOfDay, endOfDay) as any;
        growthJoins = row?.cnt || 0;
      }
    } catch {}
    const totalJoins = Math.max(histJoins, growthJoins);

    // Find destination chat ID and Bot token
    let targetChatId = (u.alert_chat_id || u.telegram_id || '').toString().trim();
    let targetBotToken = (u.alert_bot_token || '').trim() || globalToken;

    if (!targetChatId || !targetBotToken) {
      try {
        const camps = getCampaignsByOwner(u.username);
        const campWithBot = camps.find(c => c.bot_token && c.customer_tg_id);
        if (campWithBot) {
          if (!targetChatId && campWithBot.customer_tg_id) targetChatId = campWithBot.customer_tg_id.trim();
          if (!targetBotToken && campWithBot.bot_token) targetBotToken = campWithBot.bot_token.trim();
        }
      } catch {}
    }

    if (!targetBotToken || !targetChatId) {
      continue;
    }

    const displayName = u.display_name || u.username;
    const dateFormatted = formatDisplayDate(reportDate);

    // Easy English daily message with user's required closing phrase
    const reportMsg = `📊 <b>Daily Activity Summary (${dateFormatted})</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `Hello <b>${displayName}</b>,\n\n` +
      `Here is your daily activity summary for today:\n\n` +
      `🚀 <b>Total Sent DMs:</b> <b>${totalDms}</b>\n` +
      `🎯 <b>Total Join Requests:</b> <b>${totalJoins}</b>\n\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `Please join More live Audio stream Channel for mor Message.`;

    try {
      await sendTelegramMessage(targetBotToken, targetChatId, reportMsg);
      console.log(`[MIDNIGHT REPORT] ✅ 12:00 AM summary sent to ${u.username} (${totalDms} DMs, ${totalJoins} Joins).`);
    } catch (e: any) {
      console.error(`[MIDNIGHT REPORT] Failed to send report to ${u.username}:`, e?.message || e);
    }
  }
}

const lastUserReminderSentDate: Record<string, string> = {};

// 7-Day Billing Cycle Reminders:
// - 6th Day: Gentle reminder ONLY that tomorrow is bill date (NO AMOUNT mentioned)
// - 7th Day: Reminder that today is bill date, clear pending due amount only
async function checkAndSendAuto2DayReminders(): Promise<void> {
  const todayStr = getTodayDateString();

  for (const u of usersList) {
    if (u.role === 'admin' || !u.expiry_date || !u.active) continue;

    const diffDays = getDaysUntilExpiry(u.expiry_date);
    const uLedger = (billingStore.user_ledgers || {})[u.username] || {};
    const balanceDue = Number(uLedger.balance_due || 0);

    // 6th Day: Tomorrow is bill date (diffDays === 1)
    // Send gentle reminder ONLY. Strictly NO AMOUNT mentioned!
    if (diffDays === 1) {
      const reminderKey = `${u.username}_day6_${todayStr}`;
      if (lastUserReminderSentDate[reminderKey]) continue;
      lastUserReminderSentDate[reminderKey] = todayStr;
      console.log(`[AUTO REMINDER: DAY 6] Sending gentle reminder (no amount) to ${u.username} (Tomorrow is bill date: ${u.expiry_date})`);
      sendUserBillingReminder(u.username, 'day6_gentle').catch(() => null);
      continue;
    }

    // 7th Day (or overdue): Today is bill date (diffDays <= 0)
    // Only send if customer has remaining balance_due > 0 (excluding whatever has already been paid)
    if (diffDays <= 0 && balanceDue > 0) {
      const reminderKey = `${u.username}_day7_${todayStr}`;
      if (lastUserReminderSentDate[reminderKey]) continue;
      lastUserReminderSentDate[reminderKey] = todayStr;
      console.log(`[AUTO REMINDER: DAY 7] Sending bill date reminder with remaining due ₹${balanceDue} to ${u.username}`);
      sendUserBillingReminder(u.username, 'day7_due').catch(() => null);
      continue;
    }
  }
}

async function checkExpiredUsersAndTerminate(): Promise<void> {
  const todayStr = getTodayDateString();
  let changed = false;

  for (const u of usersList) {
    if (u.role === 'admin' || !u.expiry_date) continue;

    const isDemoUser = Boolean((u as any).is_demo || (billingStore.user_configs[u.username]?.is_demo));

    // Demo user termination logic
    if (isDemoUser) {
      if (todayStr > u.expiry_date && u.active) {
        u.active = false;
        changed = true;
        console.log(`[USER EXPIRED & TERMINATED]: DEMO USER "${u.username}" expired on ${u.expiry_date}. Disabling account and stopping bots.`);
        for (const a of accounts.values()) {
          if ((a.owner || 'admin') === u.username && a.running) {
            a.running = false;
            if (a.abortController) a.abortController.abort();
            a.status = 'Stopped (Demo Expired)';
            log(a.phone, 'FAIL', `Demo period expired on ${u.expiry_date}. Bot stopped.`);
          }
        }
        if (u.alert_enabled) {
          sendTelegramAlert(u.username, `⚠️ <b>Demo Period Expired</b>:\nYour free demo period ended on <b>${u.expiry_date}</b>. Please upgrade to a paid plan.`);
        }
      }
      continue;
    }

    // Regular / Weekly Paid Users:
    if (todayStr > u.expiry_date) {
      const summary = getUserLedgerSummary(u.username);

      // Case 1: All dues cleared (balance_due <= 0) -> AUTOMATIC 7-DAY EXTENSION!
      if (summary.balance_due <= 0) {
        const parsed = new Date(u.expiry_date + 'T23:59:59Z').getTime();
        const curMs = Date.now() + 5.5 * 3600 * 1000;
        const baseMs = (!isNaN(parsed) && parsed > curMs) ? parsed : curMs;
        const newExpMs = baseMs + (7 * 86400 * 1000);
        u.expiry_date = new Date(newExpMs).toISOString().split('T')[0];
        u.active = true;
        (u as any).payment_paused = false;
        (u as any).grace_period_until = null;
        changed = true;

        console.log(`[CYCLE AUTO-EXTEND]: User ${u.username} has ₹0 due. Auto-extended by 7 days until ${u.expiry_date}`);
        sendTelegramAlert(u.username, `🎉 <b>Plan Auto-Extended!</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\nYour previous 7-day cycle has completed with 0 pending dues.\nYour validity has been <b>automatically extended for 7 Days</b> until <b>${u.expiry_date}</b>!\nYour bots are active and running.`).catch(() => null);
        continue;
      }

      // Case 2: Dues are pending (balance_due > 0, e.g. ₹180) -> 2-Day Grace Period Reminder!
      let graceUntil = (u as any).grace_period_until;
      if (!graceUntil) {
        const expDateObj = new Date(u.expiry_date + 'T23:59:59Z');
        const graceMs = expDateObj.getTime() + (2 * 86400 * 1000);
        graceUntil = new Date(graceMs).toISOString().split('T')[0];
        (u as any).grace_period_until = graceUntil;
        changed = true;

        console.log(`[GRACE PERIOD START]: User ${u.username}: 7-day cycle ended on ${u.expiry_date} with ₹${summary.balance_due} due. 2-Day grace period until ${graceUntil}`);
        sendTelegramAlert(u.username, `⚠️ <b>Payment Due & 2-Day Grace Reminder</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\nYour 7-day plan cycle ended on <b>${u.expiry_date}</b>.\n💳 <b>Pending Balance Due:</b> <b>₹${summary.balance_due}</b>\n⏳ <b>Grace Period:</b> You have <b>2 days until ${graceUntil}</b> to clear this payment.\n\nℹ️ Your bots will continue running during this 2-day grace period. If payment is not cleared by ${graceUntil}, bots will be automatically paused.`).catch(() => null);
      }

      // Case 3: 2-day grace period expired and payment is STILL NOT CLEARED -> PAUSE BOTS!
      if (graceUntil && todayStr > graceUntil) {
        if (!(u as any).payment_paused) {
          (u as any).payment_paused = true;
          changed = true;
          console.log(`[GRACE PERIOD EXPIRED]: User ${u.username} did not clear ₹${summary.balance_due} due. Pausing all bots.`);

          for (const a of accounts.values()) {
            if ((a.owner || 'admin') === u.username && a.running) {
              a.running = false;
              if (a.abortController) a.abortController.abort();
              a.status = 'Paused (Payment Due)';
              log(a.phone, 'FAIL', `2-day grace period expired with ₹${summary.balance_due} pending. Bot paused.`);
            }
          }

          sendTelegramAlert(u.username, `🚨 <b>Bots Paused (Payment Overdue)</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\nYour 2-day grace period ended on <b>${graceUntil}</b>.\n💳 <b>Outstanding Due:</b> <b>₹${summary.balance_due}</b>\n\n⏸️ All your bots have been paused. Once you clear the payment, your bots will automatically resume and your plan will extend by 7 days!`).catch(() => null);
        }
      }
    }
  }

  if (changed) {
    await saveUsers();
    if (typeof broadcastAccountUpdate === 'function') {
      broadcastAccountUpdate('admin');
    }
  }
}

async function runMidnightQueueTransferSweep(force: boolean = false): Promise<number> {
  const todayStr = getTodayDateString();
  if (!force && lastMidnightTransferDate === todayStr) return 0;
  lastMidnightTransferDate = todayStr;
  try {
    fs.writeFileSync(LAST_SWEEP_FILE, JSON.stringify({ lastDate: todayStr, lastRun: new Date().toISOString() }), 'utf8');
  } catch {}

  console.log(`[MIDNIGHT QUEUE SWEEP] Running 12:00 AM Sent DM transfer sweep for date: ${todayStr} (force=${force})...`);
  let totalMovedSent = 0;
  const adminPeers = getOwnerPeers('admin');
  const adminSent = getOwnerSentUsers('admin');

  for (const u of usersList) {
    if (u.role === 'admin' || u.username === 'admin') continue;

    // 1. Gather ALL sent UIDs from both user owner cache AND all accounts owned by this user
    const sentSet = new Set<number>(getOwnerSentUsers(u.username));
    for (const acc of accounts.values()) {
      if ((acc.owner || 'admin') === u.username && acc.sent_users && acc.sent_users.size > 0) {
        for (const uid of acc.sent_users) {
          sentSet.add(Number(uid));
        }
      }
    }

    if (sentSet.size > 0) {
      const sentCount = sentSet.size;
      totalMovedSent += sentCount;

      const userPeers = getOwnerPeers(u.username);
      for (const uid of sentSet) {
        adminSent.add(uid);
        const uidStr = String(uid);
        let p = userPeers.get(uidStr) || findPeerInfoAnywhere(uidStr, u.username);
        // Fallback check in account-level peers
        if (!p) {
          for (const acc of accounts.values()) {
            if ((acc.owner || 'admin') === u.username) {
              const accPeers = loadPeers(acc.phone);
              if (accPeers && accPeers.has(uidStr)) {
                p = accPeers.get(uidStr);
                break;
              }
            }
          }
        }
        if (p) {
          adminPeers.set(uidStr, {
            userId: uidStr,
            accessHash: p.accessHash,
            username: p.username,
            firstName: p.firstName,
            lastName: p.lastName,
            phone: p.phone,
            sourcePhone: p.sourcePhone || u.username
          });
        }
      }

      // Reset user sent cache for new day so they can fresh operate, while admin holds master record
      ownerSentCache.set(u.username, new Set());
      try {
        const localOwnerSPath = path.join(__dirname, `sent_owner_${u.username}.json`);
        fs.writeFileSync(localOwnerSPath, JSON.stringify([]), 'utf8');
      } catch {}

      // Clear account-level sent caches for all accounts belonging to this user
      for (const acc of accounts.values()) {
        if ((acc.owner || 'admin') === u.username) {
          acc.sent_users?.clear();
          sentUsersCache.set(acc.phone, new Set());
          const pId = acc.phone.replace(/[^0-9+]/g, '');
          try {
            const accSentFile = path.join(__dirname, `sent_${pId}.json`);
            if (fs.existsSync(accSentFile)) {
              fs.writeFileSync(accSentFile, JSON.stringify([]), 'utf8');
            }
          } catch {}
        }
      }

      console.log(`[MIDNIGHT SWEEP]: Successfully archived and transferred ${sentCount} sent DM contacts from "${u.username}" to Admin master database with complete peer credentials.`);
    }

    broadcastAccountUpdate(u.username);

    if (u.alert_enabled && sentSet.size > 0) {
      sendTelegramAlert(u.username, `🌙 <b>Midnight Sweep (${todayStr})</b>:\n✅ Sent DM records (${sentSet.size}) transferred to Admin master pool for fresh new day.\nℹ️ Your Genuine Queue was preserved.`);
    }
  }

  if (totalMovedSent > 0) {
    saveOwnerPeers('admin', adminPeers);
    ownerSentCache.set('admin', adminSent);
    try {
      const localOwnerSPath = path.join(__dirname, `sent_owner_admin.json`);
      fs.writeFileSync(localOwnerSPath, JSON.stringify(Array.from(adminSent)), 'utf8');
    } catch {}

    broadcastAccountUpdate('admin');
    console.log(`[MIDNIGHT SWEEP COMPLETED]: Transferred & archived ${totalMovedSent} sent DM records into Admin master pool.`);

    // Send summary alert to Admin bot
    const adminUser = usersList.find(x => x.username === 'admin' || x.role === 'admin');
    if (adminUser && adminUser.alert_enabled) {
      sendTelegramAlert('admin', `🌙 <b>Midnight Sweep Report (${todayStr})</b>:\n✅ Transferred & archived <b>${totalMovedSent}</b> sent DM records into Admin master pool with all peer details.\nℹ️ User leftover queues were left untouched.`);
    }
  }

  return totalMovedSent;
}

// 🛡️ CONTINUOUS ULTRA RAM & CACHE OPTIMIZATION WATCHDOG (Caps RAM under 1.5GB)
function runMemoryAndCacheOptimizationSweep(): void {
  try {
    const mem = process.memoryUsage();
    const heapUsedMb = Math.round(mem.heapUsed / 1024 / 1024);
    const heapTotalMb = Math.round(mem.heapTotal / 1024 / 1024);
    const rssMb = Math.round(mem.rss / 1024 / 1024);

    // 1. Prune logsMap to max 80 lines per phone
    for (const [phone, list] of logsMap.entries()) {
      if (Array.isArray(list) && list.length > 80) {
        list.splice(0, list.length - 80);
      }
    }

    // 2. Prune ownerSkippedDetailsCache to max 250 records per owner
    for (const [owner, detailsMap] of ownerSkippedDetailsCache.entries()) {
      if (detailsMap && detailsMap.size > 250) {
        const toDeleteCount = detailsMap.size - 100;
        const it = detailsMap.keys();
        for (let i = 0; i < toDeleteCount; i++) {
          const k = it.next().value;
          if (k !== undefined) detailsMap.delete(k);
          else break;
        }
      }
    }

    // 3. Prune streamParticipantsCache older than 8 minutes
    const now = Date.now();
    for (const [phone, entry] of streamParticipantsCache.entries()) {
      if (entry && now - entry.lastSync > 8 * 60 * 1000) {
        streamParticipantsCache.delete(phone);
      }
    }

    // 4. Prune tempLiveStreamCooldown
    for (const [uid, exp] of tempLiveStreamCooldown.entries()) {
      if (now > exp) {
        tempLiveStreamCooldown.delete(uid);
      }
    }

    // 5. Aggressively prune GramJS internal entity caches across connected clients (cap at max 50 items)
    for (const a of accounts.values()) {
      if (a.client) {
        // Prune entity cache
        const entCache = (a.client as any)._entityCache;
        if (entCache && entCache.cacheMap instanceof Map) {
          if (entCache.cacheMap.size > 50) {
            const deleteCount = entCache.cacheMap.size - 25;
            const it = entCache.cacheMap.keys();
            for (let i = 0; i < deleteCount; i++) {
              const k = it.next().value;
              if (k !== undefined) entCache.cacheMap.delete(k);
              else break;
            }
          }
        }
        // Prune unneeded message/channel buffers if attached
        if ((a.client as any)._messageCache instanceof Map) {
          (a.client as any)._messageCache.clear();
        }
      }
    }

    // 6. Trigger V8 Garbage Collector if exposed
    if (typeof (global as any).gc === 'function') {
      try {
        (global as any).gc();
      } catch {}
    }

    if (heapUsedMb > 900) {
      console.log(`[RAM WATCHDOG] Optimized Memory: Heap ${heapUsedMb}MB / ${heapTotalMb}MB (RSS: ${rssMb}MB) | Cleaned client entity caches`);
    }
  } catch (err) {
    console.error('[RAM WATCHDOG ERROR]:', err);
  }
}

// 🛡️ AUTO 4-HOUR COMPREHENSIVE GARBAGE & LOG PURGE WATCHDOG
let lastFourHourPurge = Date.now();
function runFourHourGarbageSweep(): void {
  const now = Date.now();
  if (now - lastFourHourPurge < 4 * 3600 * 1000) return;
  lastFourHourPurge = now;
  console.log('[AUTO-PURGE 4H] Running scheduled 4-hour garbage, queue, and memory sweep...');

  // 1. Clear in-memory logs to max 50 lines per phone
  for (const [phone, list] of logsMap.entries()) {
    if (Array.isArray(list) && list.length > 50) {
      list.splice(0, list.length - 50);
    }
  }

  // 2. Clear stale stream listener participants cache
  streamParticipantsCache.clear();
  tempLiveStreamCooldown.clear();

  // 3. Clear GramJS entity caches across all accounts
  for (const a of accounts.values()) {
    if (a.client) {
      try {
        const entCache = (a.client as any)._entityCache;
        if (entCache && entCache.cacheMap instanceof Map) {
          entCache.cacheMap.clear();
        }
      } catch {}
    }
  }

  // 4. Force V8 Garbage Collection if exposed
  if (typeof (global as any).gc === 'function') {
    try { (global as any).gc(); } catch {}
  }

  // 5. Auto-truncate PM2 log files if over 30MB
  try {
    const homeDir = process.env.HOME || '/home/leotelebot_000';
    const pm2LogPath = path.join(homeDir, '.pm2', 'logs', 'telebot-out.log');
    if (fs.existsSync(pm2LogPath)) {
      const stats = fs.statSync(pm2LogPath);
      if (stats.size > 30 * 1024 * 1024) {
        fs.writeFileSync(pm2LogPath, `[AUTO-TRUNCATED 4H AT ${new Date().toISOString()}]\n`, 'utf8');
        console.log(`[AUTO-PURGE 4H] Successfully truncated PM2 log file (${Math.round(stats.size / 1024 / 1024)}MB -> 0MB).`);
      }
    }
  } catch {}
}

// Background scheduler loop (checks every 25 seconds)
let midnightSchedulerActive = false;
let memSweepCounter = 0;
async function startMidnightAndExpirySchedulerLoop() {
  if (midnightSchedulerActive) return;
  midnightSchedulerActive = true;

  while (true) {
    try {
      memSweepCounter++;
      if (memSweepCounter % 2 === 0) {
        // Runs every ~50 seconds for real-time memory cleanup
        runMemoryAndCacheOptimizationSweep();
      }
      runFourHourGarbageSweep();
      await checkExpiredUsersAndTerminate();
      await checkAndSendAuto2DayReminders();
      await sendMidnightDailyActivityReportToUsers();
      accrueDailyUsageForAllUsers();
      const moved = await runMidnightQueueTransferSweep();
      if (moved > 0) {
        console.log(`[MIDNIGHT PURGE] Daily quota reset completed. Running 1-day personal chat sweep for all accounts...`);
        runAutoCleanOldChatsSweep(1).catch(() => {});
      }
    } catch (e) {
      console.error('[MIDNIGHT/EXPIRY SCHEDULER ERROR]:', e);
    }
    await new Promise((r) => setTimeout(r, 25000));
  }
}

// ---------------- AUTO-DELETE PERSONAL CHATS OLDER THAN 1 DAY (24 HOURS) ----------------
async function cleanOldPersonalChatsForAccount(phone: string, daysThreshold: number = 1): Promise<{ cleaned: number; errors: number }> {
  const a = accounts.get(phone);
  if (!a || !a.client || !a.client.connected) {
    return { cleaned: 0, errors: 0 };
  }
  const client = a.client;
  const thresholdSeconds = Math.floor(Date.now() / 1000) - (daysThreshold * 24 * 3600);
  let cleaned = 0;
  let errors = 0;

  try {
    const myId = (client as any)._self?.id || (client.session as any)?.userId;
    const dialogs = await client.getDialogs({ limit: 250 });
    for (const d of dialogs) {
      // Strictly personal 1-on-1 human chats (NOT channels, NOT groups, NOT official bots, NOT self/saved messages)
      const peerId = d.entity?.id;
      if (d.isUser && !d.entity?.bot && peerId !== 777000 && peerId !== myId) {
        const lastMsgDate = d.date || (d.message && d.message.date) || 0;
        // If the entire chat had its last activity more than 24 hours ago (yesterday/older):
        if (lastMsgDate > 0 && lastMsgDate < thresholdSeconds) {
          try {
            await client.invoke(
              new Api.messages.DeleteHistory({
                peer: d.inputEntity || d.entity,
                maxId: 0,
                revoke: true
              })
            );
            cleaned++;
            await new Promise((r) => setTimeout(r, 350)); // anti-flood safe pause
          } catch (e: any) {
            errors++;
          }
        } else if (lastMsgDate >= thresholdSeconds) {
          // Chat is active recently, but delete older messages inside it (> 24 hours old)
          try {
            await client.invoke(
              new Api.messages.DeleteHistory({
                peer: d.inputEntity || d.entity,
                maxId: 0,
                maxDate: thresholdSeconds,
                revoke: true
              })
            );
          } catch {}
        }
      }
    }
    if (cleaned > 0) {
      log(phone, 'CLEAN', `🧹 [AUTO-CLEANUP] Deleted ${cleaned} personal chat(s) older than 24 hours (1 day).`);
    }
  } catch (err: any) {
    log(phone, 'ERROR', `Error during chat cleanup: ${err?.message || err}`);
  }

  return { cleaned, errors };
}

async function runAutoCleanOldChatsSweep(daysThreshold: number = 1): Promise<{ totalCleaned: number }> {
  let totalCleaned = 0;
  for (const [phone, acc] of accounts.entries()) {
    if (acc.client && acc.client.connected) {
      try {
        const res = await cleanOldPersonalChatsForAccount(phone, daysThreshold);
        totalCleaned += res.cleaned;
      } catch {}
    }
  }
  if (totalCleaned > 0) {
    console.log(`🧹 [AUTO-CLEAN CRON] Successfully cleaned ${totalCleaned} personal 1-on-1 chats (> 24h old) across active accounts.`);
  }
  return { totalCleaned };
}

// 🚀 REAL-TIME RAM & TELEGRAM CLIENT MEMORY OPTIMIZER
function optimizeProcessMemory(): { freedAccounts: number; rssBeforeMb: number; rssAfterMb: number } {
  const memBefore = process.memoryUsage();
  const rssBeforeMb = Math.round(memBefore.rss / 1024 / 1024);
  let freedAccounts = 0;

  try {
    // 1. Trim GramJS Entity Cache & Update queues for all running clients
    for (const [phone, acc] of accounts.entries()) {
      if (acc.client) {
        freedAccounts++;
        try {
          const clientAny = acc.client as any;
          if (clientAny._entityCache) {
            // Keep at most 150 essential recent entity items to prevent runaway memory
            if (clientAny._entityCache.cacheMap && clientAny._entityCache.cacheMap instanceof Map) {
              if (clientAny._entityCache.cacheMap.size > 200) {
                const entries = (Array.from(clientAny._entityCache.cacheMap.entries()) as [any, any][]).slice(-150);
                clientAny._entityCache.cacheMap.clear();
                for (const [k, v] of entries) {
                  clientAny._entityCache.cacheMap.set(k, v);
                }
              }
            }
          }
          // Clear discarded pending update buffers
          if (Array.isArray(clientAny._pendingUpdates)) {
            clientAny._pendingUpdates.length = 0;
          }
        } catch {}
      }

      // 2. Trim in-memory logsMap per account to max 120 lines
      const logs = logsMap.get(phone);
      if (logs && logs.length > 120) {
        logs.splice(0, logs.length - 120);
      }
    }

    // 3. Compact owner peer stores in RAM (keep essential recent peers)
    for (const [owner, peerMap] of ownerPeersCache.entries()) {
      if (peerMap && peerMap.size > 2000) {
        const recentEntries = Array.from(peerMap.entries()).slice(-1000);
        peerMap.clear();
        for (const [k, v] of recentEntries) {
          peerMap.set(k, v);
        }
      }
    }

    // 4. Prune stale audio stream participants cache (> 3 min)
    const nowSync = Date.now();
    for (const [k, entry] of streamParticipantsCache.entries()) {
      if (entry && nowSync - entry.lastSync > 3 * 60 * 1000) {
        streamParticipantsCache.delete(k);
      }
    }

    // 5. Truncate SQLite WAL file to free OS disk and memory-mapped cache
    if (sqliteDb) {
      try {
        sqliteDb.exec('PRAGMA wal_checkpoint(TRUNCATE);');
      } catch {}
    }

    // 6. Trigger garbage collector if available
    if (typeof (global as any).gc === 'function') {
      try {
        (global as any).gc();
      } catch {}
    }
  } catch (err) {
    console.error('Error during RAM optimization:', err);
  }

  const memAfter = process.memoryUsage();
  const rssAfterMb = Math.round(memAfter.rss / 1024 / 1024);
  return { freedAccounts, rssBeforeMb, rssAfterMb };
}

// 🕒 3-MINUTE AUTO RAM COMPACTION & GARBAGE SWEEPER
setInterval(() => {
  try {
    const res = optimizeProcessMemory();
    if (res.rssBeforeMb - res.rssAfterMb > 15 || res.rssBeforeMb > 600) {
      console.log(`🧹 [RAM OPTIMIZER] Compaction: ${res.rssBeforeMb}MB -> ${res.rssAfterMb}MB (${res.freedAccounts} active bots optimized).`);
    }
  } catch {}
}, 3 * 60 * 1000);

// 🛡️ PROACTIVE OOM WATCHDOG (Checks memory every 30s to prevent Linux kernel OOM Killer from terminating process)
setInterval(() => {
  try {
    const freeMb = Math.round(os.freemem() / 1024 / 1024);
    const procMem = process.memoryUsage();
    const rssMb = Math.round(procMem.rss / 1024 / 1024);

    // If host system free RAM is critical (< 140MB) or Node process uses > 500MB on low-memory VPS
    if (freeMb < 140 || rssMb > 500) {
      console.warn(`⚠️ [OOM GUARD] Critical memory threshold: Host Free: ${freeMb}MB, Node RSS: ${rssMb}MB. Executing emergency compaction...`);
      const res = optimizeProcessMemory();
      console.log(`🛡️ [OOM GUARD] Emergency compaction freed memory: RSS ${res.rssBeforeMb}MB -> ${res.rssAfterMb}MB.`);
    }
  } catch {}
}, 30 * 1000);

// 🧹 30-MINUTE BACKGROUND CRON: Periodically auto-cleans personal chats older than 24 hours (1 day)
setInterval(async () => {
  try {
    await runAutoCleanOldChatsSweep(1);
  } catch (e) {
    console.error('[CRON AUTO-CLEAN ERROR]:', e);
  }
}, 30 * 60 * 1000);

async function loadPhoneData(phone: string) {
  const pId = phone.replace(/[^0-9+]/g, '');
  const a = accounts.get(phone);
  const owner = a?.owner || 'admin';
  try {
    const s = new Set<number>();
    const localSentPath = path.join(__dirname, `sent_${pId}.json`);
    if (fs.existsSync(localSentPath)) {
      try {
        const fileContent = fs.readFileSync(localSentPath, 'utf8');
        const parsed = JSON.parse(fileContent);
        if (Array.isArray(parsed)) {
          parsed.forEach((id: any) => s.add(Number(id)));
        }
      } catch {}
    }
    sentUsersCache.set(phone, s);
    const ownerS = getOwnerSentUsers(owner);
    s.forEach((id: any) => ownerS.add(Number(id)));
    
    // Load Two-Queue state: Raw & Verified from local files
    getOwnerVerifiedQueue(owner);
    getOwnerRawQueue(owner);
    
    // Load peers from local file
    const peersMap = new Map<number, PeerInfo>();
    const localPeersPath = path.join(__dirname, `peers_${pId}.json`);
    if (fs.existsSync(localPeersPath)) {
      try {
        const fileContent = fs.readFileSync(localPeersPath, 'utf8');
        if (fileContent && fileContent.trim().length > 0) {
          const parsed = JSON.parse(fileContent);
          if (Array.isArray(parsed)) {
            for (const [k, v] of parsed) {
              peersMap.set(Number(k), v as PeerInfo);
            }
          } else if (typeof parsed === 'object' && parsed !== null) {
            for (const [k, v] of Object.entries(parsed)) {
              peersMap.set(Number(k), v as PeerInfo);
            }
          }
        }
      } catch (err: any) {
        console.warn(`[RECOVERY] Local peers file corrupted for ${phone} (${err?.message || err}). Safe fallback initialized.`);
        try {
          fs.renameSync(localPeersPath, `${localPeersPath}.corrupt.${Date.now()}`);
        } catch {}
      }
    }
    peersCache.set(phone, peersMap);

    // Merge peers into owner peer map
    const ownerPeers = getOwnerPeers(owner);
    for (const [k, v] of peersMap.entries()) {
      const kStr = String(k);
      if (!ownerPeers.has(kStr) || (!ownerPeers.get(kStr)?.accessHash && v.accessHash)) {
        ownerPeers.set(kStr, v);
      }
    }
    saveOwnerPeers(owner, ownerPeers);
  } catch (err) {
    console.error(`Error loading local data for ${phone}:`, err);
    if (!sentUsersCache.has(phone)) sentUsersCache.set(phone, new Set());
    if (!queueCache.has(phone)) queueCache.set(phone, []);
    if (!peersCache.has(phone)) peersCache.set(phone, new Map());
  }
}

function loadSentUsers(phone        )              {
  const a = accounts.get(phone);
  const owner = a?.owner || 'admin';
  return getOwnerSentUsers(owner);
}

function saveSentUser(phone        , uid        )       {
  const s = sentUsersCache.get(phone) || new Set        ();
  s.add(uid);
  sentUsersCache.set(phone, s);
  const pId = phone.replace(/[^0-9+]/g, '');

}

function getOwnerQueueLength(owner: string): number {
  return getOwnerQueue(owner).length;
}

function loadDmQueue(phone        )           {
  const a = accounts.get(phone);
  const owner = a?.owner || 'admin';
  return getOwnerQueue(owner);
}

function addToQueue(phone: string, uids: number[]): void {
  const a = accounts.get(phone);
  if (!a) return;
  const owner = a.owner || 'admin';
  addToOwnerQueue(owner, phone, uids);
}

function removeFromQueue(phone: string, uid: number): void {
  const a = accounts.get(phone);
  const owner = a?.owner || 'admin';
  removeFromOwnerQueue(owner, uid);
}

function loadPeers(phone        )                        {
  const a = accounts.get(phone);
  const owner = a?.owner || 'admin';
  return getOwnerPeers(owner);
}

function savePeers(phone: string, map: Map<number, PeerInfo>): void {
  peersCache.set(phone, map);
  const pId = phone.replace(/[^0-9+]/g, '');

  try {
    const filePath = path.join(__dirname, `peers_${pId}.json`);
    asyncSaveJson(filePath, () => Array.from(map.entries()), 15000);
  } catch (err) {
    console.error('Local peers save error:', err);
  }
}

function savePeer(phone: string, uidStr: string, pInfo: PeerInfo): void {
  const a = accounts.get(phone);
  const owner = a?.owner || 'admin';
  const peers = getOwnerPeers(owner);
  peers.set(uidStr, pInfo);
  saveOwnerPeers(owner, peers);
}

function recordUserPeers(phone: string, users: any[], client?: any): void {
  if (!Array.isArray(users) || users.length === 0) return;
  const a = accounts.get(phone);
  const owner = a?.owner || 'admin';
  const peers = getOwnerPeers(owner);
  let updated = false;

  for (const u of users) {
    if (!u) continue;
    const uid = u.id || u.userId || u.user_id;
    if (!uid) continue;
    const uidStr = String(uid.toString ? uid.toString() : uid).replace(/[^0-9-]/g, '');
    if (!uidStr || uidStr === '0') continue;

    const rawHash = u.accessHash !== undefined ? u.accessHash : (u.access_hash !== undefined ? u.access_hash : u.peer?.accessHash);
    let accessHashStr: string | undefined = undefined;
    if (rawHash !== undefined && rawHash !== null) {
      const s = String(rawHash.toString ? rawHash.toString() : rawHash).replace(/[^0-9-]/g, '');
      if (s && s !== '0') accessHashStr = s;
    }
    const username = u.username ? String(u.username) : undefined;
    const firstName = (u.firstName || u.first_name) ? String(u.firstName || u.first_name) : undefined;
    const lastName = (u.lastName || u.last_name) ? String(u.lastName || u.last_name) : undefined;
    const phoneNum = u.phone ? String(u.phone) : undefined;

    const existing = peers.get(uidStr);
    const pInfo: PeerInfo = existing ? { ...existing } : { userId: uidStr };
    if (!pInfo.accessHashes) {
      pInfo.accessHashes = {};
      if (existing?.accessHash && existing?.sourcePhone) {
        pInfo.accessHashes[existing.sourcePhone] = existing.accessHash;
      }
    }

    if (accessHashStr && accessHashStr !== '0') {
      pInfo.accessHashes[phone] = accessHashStr;
      pInfo.accessHash = accessHashStr;
      pInfo.sourcePhone = phone;
    } else if (!pInfo.sourcePhone) {
      pInfo.sourcePhone = phone;
    }

    if (username) pInfo.username = username;
    if (firstName) pInfo.firstName = firstName;
    if (lastName) pInfo.lastName = lastName;
    if (phoneNum) pInfo.phone = phoneNum;
    if (isTelegramPremiumUser(u)) pInfo.isPremium = true;
    if (isTelegramBotUser(u)) pInfo.isBot = true;
    if (isTelegramDeletedUser(u)) pInfo.isDeleted = true;
    if (isTelegramPrivacyRestricted(u)) pInfo.isPrivacyRestricted = true;

    peers.set(uidStr, pInfo);
    updated = true;

    // Broadcast newly recorded peer and accessHash to all active client entity caches of this owner
    broadcastPeerToOwnerClients(owner, uidStr, pInfo);

    if (client) {
      try {
        if (accessHashStr && accessHashStr !== '0') {
          const inputPeer = new Api.InputPeerUser({
            userId: BigInt(uidStr) as any,
            accessHash: BigInt(accessHashStr) as any
          });
          if ((client as any)._entityCache?.cacheMap) {
            (client as any)._entityCache.cacheMap.set(uidStr, inputPeer);
          }
        }
        if ((client as any).session && typeof (client as any).session.processEntities === 'function') {
          (client as any).session.processEntities({ users: [u] });
        }
        if ((client as any)._entityCache && typeof (client as any)._entityCache.add === 'function') {
          (client as any)._entityCache.add([u]);
        }
      } catch {}
    }
  }

  if (updated) {
    saveOwnerPeers(owner, peers);
  }
}

function getSessionFile(phone: string): string {
  return path.join(__dirname, `session_${phone.replace(/[^0-9+]/g, '')}.txt`);
}

async function loadSessionString(phone: string): Promise<string> {
  const localPath = getSessionFile(phone);
  try {
    if (fs.existsSync(localPath)) {
      const localSess = fs.readFileSync(localPath, 'utf8').trim();
      if (localSess) return localSess;
    }
  } catch {}
  return '';
}

async function saveSessionString(phone: string, sess: string): Promise<void> {
  const localPath = getSessionFile(phone);
  try {
    fs.writeFileSync(localPath, sess, 'utf8');
  } catch (err) {
    console.error('Error saving session string locally:', err);
  }
}

function statusState(a: any): string {
  const s = a.status;
  if (s === 'awaiting_otp' || s === 'awaiting_2fa') return 'waiting';
  if (s === 'Stopping...' || s.startsWith('Finishing')) return 'stopping';
  if (s.startsWith('Failed') || s.startsWith('Error')) return 'failed';
  if (a.running) return 'running';
  return 'idle';
}

// ---------------- SERVER-SENT EVENTS (SSE) ENGINE ----------------
interface SseClient {
  id: string;
  res: any;
  owner: string;
}

const sseClients = new Map<string, SseClient>();

function broadcastSse(owner: string, eventName: string, data: any): void {
  const normOwner = owner || 'admin';
  const payload = `event: ${eventName}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const [id, client] of sseClients.entries()) {
    if (client.owner === normOwner || client.owner === 'admin') {
      try {
        client.res.write(payload);
      } catch {
        sseClients.delete(id);
      }
    }
  }
}

broadcastLogToSse = (phone: string, line: string, server_time: string): void => {
  const a = accounts.get(phone);
  const owner = a?.owner || 'admin';
  broadcastSse(owner, 'log', { phone, line, server_time });
};

function broadcastAccountUpdate(owner?: string): void {
  const targetOwners = owner ? [owner || 'admin'] : Array.from(new Set(Array.from(accounts.values()).map(a => a.owner || 'admin')));
  if (targetOwners.length === 0) targetOwners.push('admin');

  for (const eff of targetOwners) {
    const data: any[] = [];
    let total_sent = 0;
    let total_today_dms = 0;
    const rawQ = getOwnerRawQueue(eff);
    const verifiedQ = getOwnerVerifiedQueue(eff);
    const rawQCount = rawQ.length;
    const verifiedQCount = verifiedQ.length;
    const ownerPeers = getOwnerPeers(eff);

    for (const a of accounts.values()) {
      const aOwner = a.owner || 'admin';
      if (aOwner !== eff) continue;
      checkAndResetDailyQuota(a.phone);
      checkAndResetDailyDmQuota(a.phone);
      const accDailyDms = (a as any).daily_sent_count || 0;
      const accTotalSent = Math.max(a.sent_count || 0, accDailyDms, (a.sent_users ? a.sent_users.size : 0));
      total_sent += accTotalSent;
      total_today_dms += accDailyDms;

      const accRawCount = rawQ.filter(uid => {
        const p = ownerPeers.get(String(uid));
        return !p || !p.sourcePhone || p.sourcePhone === a.phone;
      }).length;
      const accVerifiedCount = getAccountVerifiedQueue(a.phone).length;

      data.push({
        label: a.label,
        phone: a.phone,
        username: a.username || '',
        status: a.status,
        state: statusState(a),
        queue_count: accVerifiedCount,
        shared_queue_count: accVerifiedCount,
        raw_queue_count: accRawCount,
        verified_queue_count: accVerifiedCount,
        daily_extracted_count: (a as any).daily_extracted_count || 0,
        daily_extracted_max: 0,
        daily_sent_count: accDailyDms,
        live_on: a.live_on,
        dm_on: a.dm_on,
        dm_rest_until: (a as any).dm_rest_until || 0,
        peer_flood_consecutive: (a as any).peer_flood_consecutive || 0,
        sent_count: accTotalSent,
        owner: aOwner
      });
    }

    const histTodayCount = dailyDmHistory[eff]?.[getTodayDateString()]?.count || 0;
    total_today_dms = Math.max(total_today_dms, histTodayCount);

    const uObj = getUser(eff);
    const maxAcc = uObj ? (uObj.max_accounts ?? 5) : 5;
    const regPhones = uObj && Array.isArray(uObj.registered_phones) ? uObj.registered_phones : [];

    broadcastSse(eff, 'accounts', {
      accounts: data,
      total_sent,
      total_today_dms,
      effective_user: eff,
      ai_enabled: uObj?.ai_enabled === true,
      raw_queue_total: rawQCount,
      verified_queue_total: verifiedQCount,
      registered_phones: regPhones,
      max_accounts: maxAcc,
      registered_count: regPhones.length
    });
  }
}

// ---------------- CONTACT LOCK HELPER ----------------
async function lockContactPermanently(
  client: any,
  phone: string,
  uid: number | string,
  pInfo: any
): Promise<{ success: boolean; inputPeer?: any; error?: string }> {
  if (!client || !pInfo) return { success: false };
  const uidStr = String(uid).replace(/[^0-9-]/g, '');

  // Method 1: If phone number is present (7+ digits), import contact
  if (pInfo.phone && String(pInfo.phone).trim().length >= 7) {
    try {
      const cleanPhone = String(pInfo.phone).replace(/[^0-9+]/g, '');
      const res: any = await client.invoke(
        new Api.contacts.ImportContacts({
          contacts: [
            new Api.InputPhoneContact({
              clientId: BigInt(uidStr) as any,
              phone: cleanPhone,
              firstName: (pInfo.firstName || 'Member').slice(0, 30),
              lastName: (pInfo.lastName || '')
            })
          ]
        })
      ).catch(() => null);

      if (res && Array.isArray(res.users) && res.users.length > 0) {
        recordUserPeers(phone, res.users, client);
        const match = res.users.find((u: any) => String(u.id) === uidStr) || res.users[0];
        if (match && match.accessHash) {
          const permHash = String(match.accessHash);
          pInfo.accessHash = permHash;
          if (!pInfo.accessHashes) pInfo.accessHashes = {};
          pInfo.accessHashes[phone] = permHash;
          pInfo.isContactLocked = true;
          pInfo.contactSaved = true;
          savePeer(phone, uidStr, pInfo);
          const owner = accounts.get(phone)?.owner || 'admin';
          broadcastPeerToOwnerClients(owner, uidStr, pInfo);
          const inputPeer = new Api.InputPeerUser({
            userId: BigInt(uidStr) as any,
            accessHash: BigInt(permHash) as any
          });
          if ((client as any)._entityCache?.cacheMap) {
            (client as any)._entityCache.cacheMap.set(uidStr, inputPeer);
          }
          log(phone, 'OK', `📇 [PHONE CONTACT SAVED & LOCKED] ${pInfo.firstName || uidStr} saved to Telegram Contacts!`);
          return { success: true, inputPeer };
        }
        return { success: true };
      }
    } catch {}
  }

  // Method 2: Telegram Cloud Contact Save via contacts.AddContact (Works for live stream listeners without phone number or @username)
  const targetHash = (pInfo?.accessHashes && pInfo.accessHashes[phone]) || pInfo?.accessHash;
  if (targetHash && String(targetHash) !== '0') {
    try {
      const inputUser = new Api.InputUser({
        userId: BigInt(uidStr) as any,
        accessHash: BigInt(String(targetHash).replace(/[^0-9-]/g, '')) as any
      });
      const res: any = await client.invoke(
        new Api.contacts.AddContact({
          id: inputUser,
          firstName: (pInfo.firstName || 'User').slice(0, 30),
          lastName: (pInfo.lastName || '').slice(0, 30),
          phone: pInfo.phone || '',
          addPhonePrivacyException: false
        })
      ).catch(() => null);

      if (res) {
        let permHash = String(targetHash);
        if (res.users && Array.isArray(res.users) && res.users.length > 0) {
          const match = res.users.find((u: any) => String(u.id) === uidStr) || res.users[0];
          if (match && match.accessHash) {
            permHash = String(match.accessHash);
          }
          recordUserPeers(phone, res.users, client);
          try {
            if (client.session && typeof client.session.processEntities === 'function') {
              client.session.processEntities(res.users);
            }
            if ((client as any)._entityCache) {
              (client as any)._entityCache.add(res.users);
            }
          } catch {}
        }
        pInfo.accessHash = permHash;
        if (!pInfo.accessHashes) pInfo.accessHashes = {};
        pInfo.accessHashes[phone] = permHash;
        pInfo.isContactLocked = true;
        pInfo.contactSaved = true;
        savePeer(phone, uidStr, pInfo);
        const owner = accounts.get(phone)?.owner || 'admin';
        broadcastPeerToOwnerClients(owner, uidStr, pInfo);

        const inputPeer = new Api.InputPeerUser({
          userId: BigInt(uidStr) as any,
          accessHash: BigInt(permHash) as any
        });
        if ((client as any)._entityCache?.cacheMap) {
          (client as any)._entityCache.cacheMap.set(uidStr, inputPeer);
        }
        log(phone, 'OK', `📇 [CLOUD CONTACT SAVED & PERMANENT HASH LOCKED] ${pInfo.firstName || uidStr} secured in Telegram Contacts! (AccessHash: ${permHash})`);
        return { success: true, inputPeer };
      }
    } catch (err: any) {
      return { success: false, error: String(err?.message || err) };
    }
  }

  return { success: false };
}

// ---------------- EXPIRED HASH AUTO-RECOVERY HELPER ----------------
async function recoverOrHealPeer(
  client: any,
  phone: string,
  owner: string,
  uid: number | string,
  pInfo?: any
): Promise<any> {
  const uidStr = String(uid).replace(/[^0-9-]/g, '');

  // 1. If pInfo is already contact-locked and has accessHash, construct InputPeerUser directly!
  if (pInfo?.isContactLocked && pInfo?.accessHash && String(pInfo.accessHash) !== '0') {
    const inputPeer = new Api.InputPeerUser({
      userId: BigInt(uidStr) as any,
      accessHash: BigInt(String(pInfo.accessHash).replace(/[^0-9-]/g, '')) as any
    });
    if ((client as any)._entityCache?.cacheMap) {
      (client as any)._entityCache.cacheMap.set(uidStr, inputPeer);
    }
    return inputPeer;
  }

  // 2. Query Telegram Cloud Contacts list directly (contacts.GetContacts) to recover permanent access hash
  try {
    const contactsRes: any = await client.invoke(
      new Api.contacts.GetContacts({ hash: BigInt(0) as any })
    ).catch(() => null);

    if (contactsRes?.users && Array.isArray(contactsRes.users)) {
      recordUserPeers(phone, contactsRes.users, client);
      const match = contactsRes.users.find((u: any) => String(u.id) === uidStr);
      if (match && match.accessHash && String(match.accessHash) !== '0') {
        const permHash = String(match.accessHash);
        if (pInfo) {
          pInfo.accessHash = permHash;
          if (!pInfo.accessHashes) pInfo.accessHashes = {};
          pInfo.accessHashes[phone] = permHash;
          pInfo.isContactLocked = true;
          pInfo.contactSaved = true;
          savePeer(phone, uidStr, pInfo);
          broadcastPeerToOwnerClients(owner, uidStr, pInfo);
        }
        const inputPeer = new Api.InputPeerUser({
          userId: BigInt(uidStr) as any,
          accessHash: BigInt(permHash) as any
        });
        if ((client as any)._entityCache?.cacheMap) {
          (client as any)._entityCache.cacheMap.set(uidStr, inputPeer);
        }
        log(phone, 'OK', `🔄 [AUTO-RECOVERY SUCCESS] Recovered active contact access hash for ${pInfo?.firstName || uidStr} from Telegram Contacts!`);
        return inputPeer;
      }
    }
  } catch {}

  // 3. Heal from active live stream if stream is still ongoing
  try {
    const healed = await healPeerFromActiveLiveStream(client, phone, owner, Number(uidStr), pInfo);
    if (healed) {
      log(phone, 'OK', `🔄 [AUTO-RECOVERY SUCCESS] Healed access hash for ${pInfo?.firstName || uidStr} from live stream!`);
      // Lock into contacts immediately now that we have fresh hash
      lockContactPermanently(client, phone, uidStr, pInfo).catch(() => null);
      return healed;
    }
  } catch {}

  // 4. Cross-account lookup among all accounts of this owner
  const found = findPeerInfoAnywhere(uidStr, owner);
  if (found?.accessHash && String(found.accessHash) !== '0') {
    const crossPeer = new Api.InputPeerUser({
      userId: BigInt(uidStr) as any,
      accessHash: BigInt(String(found.accessHash).replace(/[^0-9-]/g, '')) as any
    });
    return crossPeer;
  }

  // 5. Try direct AddContact with any stored accessHash
  const anyHash = pInfo?.accessHash || (pInfo?.accessHashes && Object.values(pInfo.accessHashes)[0]);
  if (anyHash && String(anyHash) !== '0') {
    try {
      const lockRes = await lockContactPermanently(client, phone, uidStr, pInfo);
      if (lockRes.success && lockRes.inputPeer) {
        return lockRes.inputPeer;
      }
    } catch {}
  }

  return null;
}

// ---------------- PEER RESOLUTION & FORCING HELPER ----------------
async function resolveTargetPeer(client: any, uid: number, pInfo: PeerInfo | undefined, phone: string): Promise<any> {
  const uidCleanStr = String(uid).replace(/[^0-9-]/g, '');

  // Level 0: Contact-locked Permanent AccessHash (Direct, never expires even if user left stream)
  if (pInfo?.isContactLocked && pInfo?.accessHash && String(pInfo.accessHash) !== '0') {
    const inputPeer = new Api.InputPeerUser({
      userId: BigInt(uidCleanStr) as any,
      accessHash: BigInt(String(pInfo.accessHash).replace(/[^0-9-]/g, '')) as any
    });
    if ((client as any)._entityCache?.cacheMap) {
      (client as any)._entityCache.cacheMap.set(uidCleanStr, inputPeer);
    }
    return inputPeer;
  }

  // Level 0.5: Cloud Contact InputEntity resolution (Directly resolvable if saved in Telegram cloud contacts)
  try {
    const contactEntity = await client.getInputEntity(BigInt(uidCleanStr)).catch(() => null);
    if (contactEntity) {
      const safe = utils.getInputPeer(contactEntity);
      if (safe) return safe;
    }
  } catch {}

  // Fallback: If pInfo is missing or has neither username nor accessHash nor phone, search anywhere in system
  if (!pInfo || (!pInfo.accessHash && !pInfo.username && !pInfo.phone)) {
    const found = findPeerInfoAnywhere(uidCleanStr, accounts.get(phone)?.owner);
    if (found) {
      pInfo = { ...(pInfo || { userId: uidCleanStr }), ...found };
    }
  }

  const hashCleanStr = pInfo?.accessHash ? String(pInfo.accessHash).replace(/[^0-9-]/g, '') : '';

  // Level 1: Prioritize Username resolution (Telegram MTProto globally resolves fresh, session-valid InputPeer)
  if (pInfo?.username && pInfo.username.trim().length > 0) {
    const cleanUser = pInfo.username.trim().replace(/^@/, '');
    try {
      const inputEntity = await client.getInputEntity(`@${cleanUser}`).catch(() => null);
      if (inputEntity) {
        try {
          const safe = utils.getInputPeer(inputEntity);
          if (safe) {
            if ((safe as any).accessHash && pInfo) {
              pInfo.accessHash = String((safe as any).accessHash);
            }
            if ((client as any)._entityCache?.cacheMap) {
              (client as any)._entityCache.cacheMap.set(uidCleanStr, safe);
            }
            return safe;
          }
        } catch {}
      }
    } catch {}
    return `@${cleanUser}`;
  }

  // Level 2: GramJS client session lookup (User might already be cached in this client's session)
  try {
    const sessionPeer = (client as any).session?.getInputEntity(uid);
    if (sessionPeer) {
      try {
        const safe = utils.getInputPeer(sessionPeer);
        if (safe) return safe;
      } catch {}
    }
  } catch {}

  try {
    const cached = (client as any)._entityCache?.get?.(uidCleanStr);
    if (cached) {
      try {
        const safe = utils.getInputPeer(cached);
        if (safe) return safe;
      } catch {}
    }
  } catch {}

  // Level 3: Known accessHash (exact Telegram InputPeerUser)
  // Use account-specific hash if available, or fall back to global/extracted accessHash
  const effectiveHash = (pInfo?.accessHashes && pInfo.accessHashes[phone])
    ? String(pInfo.accessHashes[phone]).replace(/[^0-9-]/g, '')
    : (hashCleanStr || (pInfo?.accessHash ? String(pInfo.accessHash).replace(/[^0-9-]/g, '') : ''));

  if (effectiveHash && effectiveHash !== '0') {
    const inputPeer = new Api.InputPeerUser({
      userId: BigInt(uidCleanStr) as any,
      accessHash: BigInt(effectiveHash) as any
    });
    if ((client as any)._entityCache?.cacheMap) {
      (client as any)._entityCache.cacheMap.set(uidCleanStr, inputPeer);
    }
    // Background safety lock in contacts if not already secured
    lockContactPermanently(client, phone, uidCleanStr, pInfo).catch(() => null);
    return inputPeer;
  }

  // Level 3.5: Phone number contact import resolution (if user has phone number)
  if (pInfo?.phone && pInfo.phone.trim().length > 0) {
    try {
      const cleanPhone = pInfo.phone.replace(/[^0-9+]/g, '');
      if (cleanPhone.length >= 7) {
        const res: any = await client.invoke(new Api.contacts.ImportContacts({
          contacts: [new Api.InputPhoneContact({
            clientId: BigInt(uidCleanStr) as any,
            phone: cleanPhone,
            firstName: pInfo.firstName || 'User',
            lastName: pInfo.lastName || ''
          })]
        })).catch(() => null);
        if (res?.users && res.users.length > 0) {
          const safe = utils.getInputPeer(res.users[0]);
          if (safe) {
            if ((safe as any).accessHash && pInfo) {
              pInfo.accessHash = String((safe as any).accessHash);
            }
            if ((client as any)._entityCache?.cacheMap) {
              (client as any)._entityCache.cacheMap.set(uidCleanStr, safe);
            }
            return safe;
          }
        }
      }
    } catch {}
  }

  // Level 4: Active live voice call stream participants lookup
  for (const [_, act] of activeGroupCalls.entries()) {
    if (act?.call) {
      try {
        const partRes: any = await client.invoke(
          new Api.phone.GetGroupParticipants({
            call: act.call,
            ids: [],
            sources: [],
            offset: '',
            limit: 100
          })
        ).catch(() => null);

        if (partRes?.users && Array.isArray(partRes.users)) {
          recordUserPeers(phone, partRes.users, client);
          const found = partRes.users.find((u: any) => String(u.id) === uidCleanStr);
          if (found?.username) {
            return `@${found.username.replace(/^@/, '')}`;
          } else if (found?.accessHash && String(found.accessHash) !== '0') {
            return new Api.InputPeerUser({
              userId: BigInt(uidCleanStr) as any,
              accessHash: BigInt(found.accessHash.toString()) as any
            });
          }
        }
      } catch {}
    }

    if (act?.entity) {
      try {
        const partRes: any = await client.invoke(
          new Api.channels.GetParticipants({
            channel: act.entity,
            filter: new Api.ChannelParticipantsRecent(),
            offset: 0,
            limit: 200,
            hash: BigInt(0) as any
          })
        ).catch(() => null);

        if (partRes?.users && Array.isArray(partRes.users)) {
          recordUserPeers(phone, partRes.users, client);
          const found = partRes.users.find((u: any) => String(u.id) === uidCleanStr);
          if (found?.username) {
            return `@${found.username.replace(/^@/, '')}`;
          } else if (found?.accessHash && String(found.accessHash) !== '0') {
            return new Api.InputPeerUser({
              userId: BigInt(uidCleanStr) as any,
              accessHash: BigInt(found.accessHash.toString()) as any
            });
          }
        }
      } catch {}
    }
  }

  // Level 5: Try direct client.getInputEntity (strictly converting to InputPeer)
  try {
    const direct = await client.getInputEntity(uid).catch(() => null);
    if (direct) {
      try {
        const safe = utils.getInputPeer(direct);
        if (safe) return safe;
      } catch {}
    }
  } catch {}

  // Level 6: Expired Hash Auto-Recovery attempt
  const recovered = await recoverOrHealPeer(client, phone, accounts.get(phone)?.owner || 'admin', uid, pInfo);
  if (recovered) return recovered;

  // Fallback: If not resolvable to a valid InputPeer or username, return null so it can be skipped immediately with 0 delay
  return null;
}

// ---------------- LIVE STREAM PEER HEALING & REFRESH HELPER ----------------
async function healPeerFromActiveLiveStream(client: any, phone: string, owner: string, uid: number, pInfo?: any): Promise<any> {
  const uidCleanStr = String(uid).replace(/[^0-9-]/g, '');
  const act = activeGroupCalls.get(phone) || ownerActiveGroupCalls.get(owner);
  if (!act?.call) return null;

  try {
    const callRes: any = await client.invoke(
      new Api.phone.GetGroupCall({ call: act.call, limit: 100 })
    ).catch(() => null);

    if (callRes && Array.isArray(callRes.users)) {
      recordUserPeers(phone, callRes.users, client);
      const match = callRes.users.find((u: any) => String(u.id) === uidCleanStr);
      if (match && match.accessHash && String(match.accessHash) !== '0') {
        const inputPeer = new Api.InputPeerUser({
          userId: BigInt(uidCleanStr) as any,
          accessHash: BigInt(String(match.accessHash)) as any
        });
        if ((client as any)._entityCache?.cacheMap) {
          (client as any)._entityCache.cacheMap.set(uidCleanStr, inputPeer);
        }
        if ((client as any).session && typeof (client as any).session.processEntities === 'function') {
          (client as any).session.processEntities({ users: [match] });
        }
        return inputPeer;
      }
    }

    const partRes: any = await client.invoke(
      new Api.phone.GetGroupParticipants({
        call: act.call,
        ids: [],
        sources: [],
        offset: '',
        limit: 100
      })
    ).catch(() => null);

    if (partRes && Array.isArray(partRes.users)) {
      recordUserPeers(phone, partRes.users, client);
      const match = partRes.users.find((u: any) => String(u.id) === uidCleanStr);
      if (match && match.accessHash && String(match.accessHash) !== '0') {
        const inputPeer = new Api.InputPeerUser({
          userId: BigInt(uidCleanStr) as any,
          accessHash: BigInt(String(match.accessHash)) as any
        });
        if ((client as any)._entityCache?.cacheMap) {
          (client as any)._entityCache.cacheMap.set(uidCleanStr, inputPeer);
        }
        if ((client as any).session && typeof (client as any).session.processEntities === 'function') {
          (client as any).session.processEntities({ users: [match] });
        }
        return inputPeer;
      }
    }
  } catch {}

  return null;
}

/**
 * Interacts with @SpamBot 4-5 times with human-like delays to refresh and lift temporary limit
 * Returns true if SpamBot indicates no limits, false otherwise
 */
async function checkAndResolveSpamBot(client: any, phone: string, isAutoAfterLimit = false): Promise<boolean> {
  if (!client) return false;
  try {
    log(phone, 'INFO', `Contacting @SpamBot (5-cycle verification & appeal system)...`);
    const spamBotPeer = await client.getInputEntity('@SpamBot').catch(() => '@SpamBot');

    const maxAttempts = 5;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      log(phone, 'INFO', `@SpamBot step (${attempt}/${maxAttempts}): Sending /start`);
      
      // Send /start command
      await client.sendMessage(spamBotPeer, { message: '/start' }).catch(() => null);

      // Wait 3.5 to 5 seconds for SpamBot response
      await new Promise((r) => setTimeout(r, 4000));

      // Get latest message from @SpamBot
      let msgs: any = await client.getMessages(spamBotPeer, { limit: 2 }).catch(() => []);
      let latest = msgs?.[0];
      let text = String(latest?.message || '').toLowerCase();

      // Check if limit is cleared
      if (
        text.includes('good news') ||
        text.includes('no limits') ||
        text.includes('free as a bird') ||
        text.includes('your account is free') ||
        text.includes('no limits are currently applied')
      ) {
        log(phone, 'OK', `🎉 @SpamBot SUCCESS: Account has NO limits! Restriction cleared on attempt ${attempt}/${maxAttempts}.`);
        return true;
      }

      // Check if button click / appeal can be submitted
      if (latest?.replyMarkup?.rows && Array.isArray(latest.replyMarkup.rows)) {
        for (const row of latest.replyMarkup.rows) {
          for (const btn of row.buttons || []) {
            const btnText = String(btn.text || '').toLowerCase();
            if (
              btnText.includes('mistake') ||
              btnText.includes('wrong') ||
              btnText.includes("didn't") ||
              btnText.includes('never') ||
              btnText.includes('yes') ||
              btnText.includes('complaint')
            ) {
              try {
                log(phone, 'INFO', `@SpamBot: Clicking '${btn.text}' button...`);
                await latest.click(btn);
                await new Promise((r) => setTimeout(r, 3500));

                msgs = await client.getMessages(spamBotPeer, { limit: 2 }).catch(() => []);
                latest = msgs?.[0];
                text = String(latest?.message || '').toLowerCase();

                if (
                  text.includes('good news') ||
                  text.includes('no limits') ||
                  text.includes('free as a bird') ||
                  text.includes('your account is free')
                ) {
                  log(phone, 'OK', `🎉 @SpamBot SUCCESS: Restriction lifted after appeal on attempt ${attempt}!`);
                  return true;
                }
              } catch {}
            }
          }
        }
      }

      if (attempt < maxAttempts) {
        log(phone, 'WAIT', `@SpamBot reported limit. Retrying /start cycle in 4-5s (attempt ${attempt + 1}/${maxAttempts})...`);
        await new Promise((r) => setTimeout(r, 4500));
      } else {
        const snippet = latest?.message ? latest.message.slice(0, 100).replace(/\n/g, ' ') : 'Account still restricted';
        log(phone, 'WARN', `@SpamBot: ${snippet}...`);
      }
    }
  } catch (err: any) {
    log(phone, 'WARN', `@SpamBot check exception: ${err?.message || err}`);
  }
  return false;
}

const DEVICE_PROFILES = [
  { deviceModel: 'realme realme P2 Pro 5G', systemVersion: 'Android 14 (SDK 34)', appVersion: 'Telegram Android 12.10.1' },
  { deviceModel: 'OnePlus 12', systemVersion: 'Android 14 (CPH2581_14.0.0.404)', appVersion: 'Telegram Android 12.10.1' },
  { deviceModel: 'Samsung Galaxy S24 Ultra', systemVersion: 'Android 14 (UP1A.231005.007)', appVersion: 'Telegram Android 12.10.1' },
  { deviceModel: 'Samsung Galaxy S23+', systemVersion: 'Android 14 (TP1A.220624.014)', appVersion: 'Telegram Android 12.10.1' },
  { deviceModel: 'Google Pixel 8 Pro', systemVersion: 'Android 14 (UD1A.230803.041)', appVersion: 'Telegram Android 12.10.1' },
  { deviceModel: 'Google Pixel 7a', systemVersion: 'Android 13 (TQ2A.230505.002)', appVersion: 'Telegram Android 12.10.1' },
  { deviceModel: 'Xiaomi 14 Pro', systemVersion: 'Android 14 (OS1.0.24.0.UNBCNXM)', appVersion: 'Telegram Android 12.10.1' },
  { deviceModel: 'Vivo X100 Pro', systemVersion: 'Android 14 (SDK 34)', appVersion: 'Telegram Android 12.10.1' }
];

function getDeviceProfileForPhone(phone: string) {
  let hash = 0;
  for (let i = 0; i < phone.length; i++) {
    hash = (hash * 31 + phone.charCodeAt(i)) & 0xffffffff;
  }
  const index = Math.abs(hash) % DEVICE_PROFILES.length;
  return DEVICE_PROFILES[index];
}

// 🤖 TELEGRAM BOT FAST FILTER & EARLY CHANNEL LOCK
// Cache of channel IDs for each user's filter bot: token -> { timestamp, channels: Map<string, string> }
const filterBotAdminChannelsCache = new Map<string, { timestamp: number; channels: Map<string, string> }>();
const knownJoinedMembersCache = new Set<string>();

async function getFilterBotAdminChannels(botToken: string, owner: string, providedLink?: string): Promise<Map<string, string>> {
  const cached = filterBotAdminChannelsCache.get(botToken);
  if (cached && Date.now() - cached.timestamp < 300000 && cached.channels.size > 0 && !providedLink) {
    return cached.channels;
  }

  const channels = (cached && cached.channels) ? new Map(cached.channels) : new Map<string, string>(); // chatId -> title

  try {
    const updRes = await fetch(`https://api.telegram.org/bot${encodeURIComponent(botToken)}/getUpdates?limit=100`);
    const updData: any = await updRes.json().catch(() => null);
    if (updData && updData.ok && Array.isArray(updData.result)) {
      for (const u of updData.result) {
        const chat = u.my_chat_member?.chat || u.chat_member?.chat || u.channel_post?.chat || u.message?.chat;
        if (chat && (chat.type === 'channel' || chat.type === 'supergroup')) {
          const cid = String(chat.id);
          channels.set(cid, chat.title || `Channel ${cid}`);
          if (chat.username) {
            channels.set('@' + chat.username.toLowerCase(), chat.title || `@${chat.username}`);
          }
        }
      }
    }
  } catch {}

  // Also resolve from providedLink or user's master_config.channel_link
  const uObj = getUser(owner);
  const chLink = (providedLink || uObj?.master_config?.channel_link || '').trim();
  if (chLink) {
    // 1. If numeric channel ID in link (e.g. -1002345678901 or /c/2345678901)
    const numMatch = chLink.match(/-100\d+|\/c\/(\d+)/);
    if (numMatch) {
      const nid = numMatch[1] ? `-100${numMatch[1]}` : numMatch[0];
      try {
        const gcRes = await fetch(`https://api.telegram.org/bot${encodeURIComponent(botToken)}/getChat?chat_id=${encodeURIComponent(nid)}`);
        const gcD: any = await gcRes.json().catch(() => null);
        if (gcD?.ok && gcD.result) {
          channels.set(nid, gcD.result.title || `Target Channel (${nid})`);
          if (gcD.result.username) channels.set('@' + gcD.result.username.toLowerCase(), gcD.result.title);
        } else {
          channels.set(nid, `Target Channel (${nid})`);
        }
      } catch {
        channels.set(nid, `Target Channel (${nid})`);
      }
    }

    // 2. If public username
    const pubMatch = chLink.match(/t\.me\/([a-zA-Z0-9_]{4,})(?:\/|\?|$)/);
    if (pubMatch && !pubMatch[1].startsWith('+') && !chLink.includes('/+')) {
      const pubUser = '@' + pubMatch[1].toLowerCase();
      try {
        const getChatRes = await fetch(`https://api.telegram.org/bot${encodeURIComponent(botToken)}/getChat?chat_id=${encodeURIComponent(pubUser)}`);
        const gcData: any = await getChatRes.json().catch(() => null);
        if (gcData?.ok && gcData.result?.id) {
          channels.set(String(gcData.result.id), gcData.result.title || pubUser);
          channels.set(pubUser, gcData.result.title || pubUser);
        }
      } catch {}
    }
  }

  // 3. Also check active accounts of this owner to match private invite link in dialogs
  if (channels.size === 0 && chLink) {
    for (const acc of accounts.values()) {
      if ((acc.owner || 'admin') === owner && acc.client && acc.running) {
        try {
          const dlgs = await acc.client.getDialogs({ limit: 40 }).catch(() => []);
          for (const d of dlgs) {
            if (d.isChannel || d.isGroup) {
              const did = String(d.id);
              const didFull = did.startsWith('-100') ? did : `-100${did.replace(/^-/, '')}`;
              try {
                const gcRes = await fetch(`https://api.telegram.org/bot${encodeURIComponent(botToken)}/getChat?chat_id=${encodeURIComponent(didFull)}`);
                const gcD: any = await gcRes.json().catch(() => null);
                if (gcD?.ok && gcD.result) {
                  channels.set(didFull, gcD.result.title || d.title || didFull);
                }
              } catch {}
            }
          }
        } catch {}
      }
    }
  }

  filterBotAdminChannelsCache.set(botToken, { timestamp: Date.now(), channels });
  return channels;
}

async function isUserAlreadyInChannel(
  owner: string,
  uid: number,
  phone?: string,
  client?: any
): Promise<{ inChannel: boolean; channelName?: string }> {
  if (!uid || isNaN(uid) || uid <= 0) return { inChannel: false };

  const cacheKey = `${owner}:${uid}`;
  if (knownJoinedMembersCache.has(cacheKey)) {
    return { inChannel: true, channelName: 'Target Channel (Joined Member)' };
  }

  const uObj = getUser(owner);
  const botToken = uObj?.master_config?.filter_bot_token?.trim();

  // 1. FAST BOT API CHECK (Zero Flood Wait, 100% Reliable for Public & Private Channels)
  if (botToken) {
    try {
      const adminChannels = await getFilterBotAdminChannels(botToken, owner);
      const targets = Array.from(adminChannels.keys());

      // If no admin channels were auto-discovered from getUpdates, also fallback to channel_link if available
      const rawChLink = (uObj?.master_config?.channel_link || '').trim();
      if (rawChLink) {
        const pubMatch = rawChLink.match(/t\.me\/([a-zA-Z0-9_]{4,})(?:\/|\?|$)/);
        if (pubMatch && !pubMatch[1].startsWith('+') && !rawChLink.includes('/+')) {
          const pubTarget = '@' + pubMatch[1].toLowerCase();
          if (!targets.includes(pubTarget)) targets.push(pubTarget);
        }
      }

      for (const targetChat of targets) {
        try {
          const url = `https://api.telegram.org/bot${encodeURIComponent(botToken)}/getChatMember?chat_id=${encodeURIComponent(targetChat)}&user_id=${uid}`;
          const res = await fetch(url);
          const data: any = await res.json().catch(() => null);
          if (data && data.ok && data.result) {
            const st = data.result.status;
            const isMember = data.result.is_member;
            if (st === 'member' || st === 'administrator' || st === 'creator' || (st === 'restricted' && isMember !== false)) {
              knownJoinedMembersCache.add(cacheKey);
              const title = adminChannels.get(targetChat) || targetChat;
              return { inChannel: true, channelName: title };
            }
          }
        } catch (_) {}
      }
    } catch (_) {}
  }

  // 2. MTPROTO CLIENT FALLBACK (If Bot API not configured or not resolved)
  if (client) {
    try {
      const rawChLink = (uObj?.master_config?.channel_link || '').trim();
      if (rawChLink) {
        let chEntity: any = null;
        try {
          chEntity = await client.getEntity(rawChLink).catch(() => null);
        } catch {}

        if (chEntity) {
          const participant = await Promise.race([
            client.invoke(new Api.channels.GetParticipant({
              channel: chEntity,
              participant: uid
            })),
            new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 1500))
          ]).catch(() => null);

          if (participant) {
            knownJoinedMembersCache.add(cacheKey);
            return { inChannel: true, channelName: chEntity.title || 'Target Channel' };
          }
        }
      }
    } catch {}
  }

  return { inChannel: false };
}

async function runTelegramBot(phone: string, signal: AbortSignal) {
  const a = accounts.get(phone);
  if (!a) return;
  if (signal.aborted) return;
  a.running = true;

  a.sent_users = loadSentUsers(phone);
  log(phone, 'OK', `Starting up... ${a.sent_users.size} previously-DMed users loaded`);

  const savedSession = await loadSessionString(phone);
  const stringSession = new StringSession(savedSession);

  const deviceProf = getDeviceProfileForPhone(phone);

  let deviceModel = deviceProf.deviceModel;
  let systemVersion = deviceProf.systemVersion;
  let appVersion = 'Telegram Android 12.10.1';

  const isMobile = (a as any).engine_mode === 'mobile_app' || 
    (a as any).device_mode === 'mobile' || 
    (a as any).is_mobile ||
    getUser(a.owner || '')?.access_type === 'app_only' ||
    Boolean(a.phone && a.phone.length > 5); // Default all user phone bots to realistic Android mobile device

  if (isMobile) {
    // 📱 Force authentic Mobile Android Signature so Telegram -> Settings -> Devices shows Android Phone!
    deviceModel = (a as any).device_model || deviceProf.deviceModel || 'Samsung Galaxy S24 Ultra';
    systemVersion = (a as any).system_version || deviceProf.systemVersion || 'Android 14 (UP1A.231005.007)';
    appVersion = 'Telegram Android 12.10.1';
  } else if (a.api_id === 2040) {
    deviceModel = 'PC 64bit';
    systemVersion = 'Windows 11 (23H2)';
    appVersion = '5.1.0 x64';
  } else if (a.api_id === 2834) {
    deviceModel = 'iPhone 15 Pro';
    systemVersion = 'iOS 17.5.1';
    appVersion = '10.14.0';
  } else if (a.api_id === 17349) {
    deviceModel = 'MacBook Pro 16';
    systemVersion = 'macOS 14.5';
    appVersion = '10.9.1';
  } else if (a.api_id === 2496) {
    deviceModel = 'Chrome / Linux x86_64';
    systemVersion = 'Linux';
    appVersion = 'WebK 2.1.0';
  }

  log(phone, 'INFO', `Device Emulation: ${deviceModel} [${systemVersion}] (API ID: ${a.api_id})`);

  const clientParams: any = {
    connectionRetries: 5,
    useWSS: false,
    autoReconnect: true,
    catchUp: false,
    timeout: 15,
    deviceModel,
    systemVersion,
    appVersion,
    langCode: 'en',
    systemLangCode: 'en-US'
  };

  const effectiveProxy = getEffectiveProxyForAccount(phone, a);
  if (effectiveProxy) {
    clientParams.proxy = effectiveProxy;
    log(phone, 'OK', `🛡️ Connected via Proxy: ${effectiveProxy.ip}:${effectiveProxy.port}${effectiveProxy.username ? ' (Authenticated/Sticky)' : ''}`);
  }

  const client = new TelegramClient(stringSession, a.api_id, a.api_hash, clientParams);
  try {
    (client as any).setLogLevel('none');
    if ((client as any)._entityCache) {
      (client as any)._entityCache.maxEntities = 40;
    }
  } catch {}
  client.onError = async (err       ) => {
    const msg = err?.message || String(err);
    if (msg.includes('TIMEOUT')) return;
    if (msg.includes('AUTH_KEY_UNREGISTERED') || msg.includes('SESSION_REVOKED') || msg.includes('401')) {
      log(phone, 'FAIL', `Session terminated/expired remotely (401: AUTH_KEY_UNREGISTERED). Auto-clearing dead session.`);
      a.status = 'Logged Out (Session Revoked)';
      a.running = false;
      const sessFile = getSessionFile(phone);
      if (fs.existsSync(sessFile)) {
        try { fs.unlinkSync(sessFile); } catch {}
      }
      broadcastAccountUpdate(a.owner);
      await client.disconnect().catch(() => {});
      return;
    }
    log(phone, 'WARN', `Telegram client: ${msg.slice(0, 80)}`);
  };
  a.client = client;

  let connected = false;
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      await client.connect();
      connected = true;
      break;
    } catch (err: any) {
      log(phone, 'WARN', `Connect attempt ${attempt}/3 failed: ${String(err?.message || err).slice(0, 80)}`);
      if (attempt < 3) await new Promise((r) => setTimeout(r, 2500));
    }
  }
  if (!connected) {
    log(phone, 'FAIL', `Connect failed after 3 attempts. Auto-reconnecting...`);
    if (signal.aborted) {
      a.running = false;
      a.status = 'Failed - network error';
      return;
    }
    a.status = 'Reconnecting...';
    throw new Error('Telegram connection failed (will auto-retry)');
  }

  // Pre-seed GramJS entityCache and session with known saved peers from Master Owner Store & phone store
  try {
    const owner = a.owner || 'admin';
    const ownerPeers = getOwnerPeers(owner);
    const savedPeers = loadPeers(phone);
    const mockUsers: any[] = [];

    // Combine Master Owner Peers with local account peers
    const allPeers = new Map<string, PeerInfo>();
    for (const [uidStr, pInfo] of ownerPeers.entries()) {
      allPeers.set(uidStr, pInfo);
    }
    for (const [uidNum, pInfo] of savedPeers.entries()) {
      const uStr = String(uidNum);
      if (!allPeers.has(uStr)) {
        allPeers.set(uStr, pInfo);
      }
    }

    // Pre-seed only recent 40 peers in memory to avoid multi-gigabyte heap bloat with 20+ accounts
    const recentPeerEntries = Array.from(allPeers.entries()).slice(-40);
    for (const [uidStr, pInfo] of recentPeerEntries) {
      const hash = pInfo.accessHash || (pInfo.accessHashes && pInfo.accessHashes[phone]);
      if (hash && String(hash) !== '0') {
        const inputPeer = new Api.InputPeerUser({
          userId: BigInt(uidStr) as any,
          accessHash: BigInt(hash) as any
        });
        if ((client as any)._entityCache) {
          (client as any)._entityCache.set?.(uidStr, inputPeer);
          if ((client as any)._entityCache.cacheMap) {
            (client as any)._entityCache.cacheMap.set(uidStr, inputPeer);
          }
        }
        mockUsers.push(new Api.User({
          id: BigInt(uidStr) as any,
          accessHash: BigInt(hash) as any,
          username: pInfo.username || undefined
        }));
      }
    }
    if (mockUsers.length > 0 && (client as any).session && typeof (client as any).session.processEntities === 'function') {
      (client as any).session.processEntities(mockUsers);
    }
  } catch {}

  let myId                = null;

  // Check login
  const isAuthorized = await client.isUserAuthorized().catch(() => false);
  if (isAuthorized) {
    try {
      const me      = await client.getMe();
      if (me?.id) myId = Number(me.id);
      log(phone, 'OK', `Session valid, auto-login: ${me?.firstName || me?.username || 'User'}`);
      a.status = 'online';
      if (me?.username) {
        a.username = me.username;
        saveAccountsJson();
      }
    } catch {
      // ignore
    }
  } else {
    // Start / Login flow using GramJS client.start
    log(phone, 'INFO', `Starting authentication for ${phone}...`);
    try {
      await client.start({
        phoneNumber: async () => phone,
        phoneCode: async (isCodeViaApp?: boolean) => {
          a.status = 'awaiting_otp';
          broadcastAccountUpdate(a.owner);
          const via = isCodeViaApp ? 'Telegram App' : 'Telegram/SMS';
          log(phone, 'OTP', `📱 OTP code sent via ${via} to ${phone} - ENTER IT IN DASHBOARD`);

          const pending: any = pendingAuthMap.get(phone) || {};
          pending.waiting = 'otp';
          pending.phone = phone;
          pendingAuthMap.set(phone, pending);

          return new Promise<string>((resolve, reject) => {
            pending.otpResolve = resolve;
            pending.otpReject = reject;
            setTimeout(() => {
              if (pending.waiting === 'otp') {
                reject(new Error('OTP timeout (10 min). Press START again.'));
              }
            }, 600000);
          });
        },
        password: async () => {
          a.status = 'awaiting_2fa';
          broadcastAccountUpdate(a.owner);
          log(phone, 'OTP', '🔒 2FA Cloud Password required - ENTER IT IN DASHBOARD');

          const pending: any = pendingAuthMap.get(phone) || {};
          pending.waiting = 'twofa';
          pending.phone = phone;
          pendingAuthMap.set(phone, pending);

          if (typeof pending.notifyResult === 'function') {
            pending.notifyResult({
              success: true,
              status: 'awaiting_2fa',
              msg: '🔒 2FA Cloud Password required. Please enter your password.'
            });
            pending.notifyResult = null;
          }

          return new Promise<string>((resolve, reject) => {
            pending.twoFaResolve = resolve;
            pending.twoFaReject = reject;
            setTimeout(() => {
              if (pending.waiting === 'twofa') {
                reject(new Error('2FA timeout. Press START again.'));
              }
            }, 600000);
          });
        },
        onError: async (err: any): Promise<boolean> => {
          const errMsg = String(err?.message || err?.errorMessage || err);
          if (errMsg.includes('SESSION_PASSWORD_NEEDED')) {
            // GramJS will transition to password() callback next - do not crash
            return false;
          }

          const pending = pendingAuthMap.get(phone);
          let userMsg = errMsg;
          if (errMsg.includes('PHONE_CODE_INVALID')) {
            userMsg = '❌ Incorrect OTP code entered. Please enter the latest code received on Telegram.';
          } else if (errMsg.includes('PHONE_CODE_EXPIRED')) {
            userMsg = '❌ OTP code expired. Click "START BOT" to request a new code.';
          } else if (errMsg.includes('PASSWORD_HASH_INVALID')) {
            userMsg = '❌ Incorrect 2FA Password.';
          } else if (errMsg.includes('API_ID_INVALID')) {
            userMsg = '❌ Invalid API ID/Hash. Please check my.telegram.org.';
          } else if (errMsg.includes('PHONE_NUMBER_BANNED')) {
            userMsg = '❌ Telegram phone number is banned.';
          }

          if (pending && typeof pending.notifyResult === 'function') {
            pending.notifyResult({ success: false, status: 'failed', msg: userMsg });
            pending.notifyResult = null;
          }

          log(phone, 'FAIL', userMsg);
          throw new Error(errMsg);
        }
      });
    } catch (err: any) {
      const errMsg = String(err?.message || err?.errorMessage || err);
      log(phone, 'FAIL', `Login stopped: ${errMsg}`);
      
      const pending = pendingAuthMap.get(phone);
      if (pending && typeof pending.notifyResult === 'function') {
        pending.notifyResult({ success: false, status: 'failed', msg: `Login failed: ${errMsg}` });
      }
      pendingAuthMap.delete(phone);

      if (errMsg.includes('PHONE_CODE_INVALID')) {
        a.status = 'Invalid OTP - Click START to retry';
      } else if (errMsg.includes('PHONE_CODE_EXPIRED')) {
        a.status = 'Expired OTP - Click START to retry';
      } else if (errMsg.includes('PASSWORD_HASH_INVALID')) {
        a.status = 'Invalid 2FA Password';
      } else if (errMsg.includes('API_ID_INVALID')) {
        a.status = 'Failed - Invalid API ID/Hash';
      } else {
        a.status = `Failed - ${errMsg.slice(0, 30)}`;
      }
      a.running = false;
      broadcastAccountUpdate(a.owner);
      await client.disconnect().catch(() => {});
      return;
    }

    // Save session string immediately upon successful authentication to disk and Local Storage
    const pending = pendingAuthMap.get(phone);
    const newSession = client.session.save() as unknown as string;
    if (newSession) {
      await saveSessionString(phone, newSession);
    }
    a.status = 'online';
    a.running = true;
    broadcastAccountUpdate(a.owner);
    await saveAccountsJson();
    log(phone, 'OK', `✅ Authentication successful for ${phone}! Session stored.`);

    // Instantly notify any awaiting HTTP verification request so the UI transitions with zero delay
    if (pending && typeof pending.notifyResult === 'function') {
      pending.notifyResult({
        success: true,
        status: 'online',
        msg: `✅ Logged in successfully! Telegram account is now online.`
      });
      pending.notifyResult = null;
    }
    pendingAuthMap.delete(phone);

    // Asynchronously resolve user profile details without blocking authentication return
    (async () => {
      try {
        const me = await client.getMe().catch(() => null);
        if (me?.id) myId = Number(me.id);
        let updated = false;
        if (me?.username && a.username !== me.username) {
          a.username = me.username;
          updated = true;
        }
        if (me?.firstName && (!a.label || a.label.startsWith('+') || /^Account\s*\d+$/i.test(a.label))) {
          const fullTgName = [me.firstName, me.lastName].filter(Boolean).join(' ').trim();
          a.label = fullTgName || me.firstName;
          updated = true;
        }
        if (updated) {
          await saveAccountsJson();
          broadcastAccountUpdate(a.owner);
        }
      } catch {}
    })();

    // Pre-seed entity cache with only recent 40 peers to avoid RAM bloat
    const knownPeers = loadPeers(phone);
    const recentKnownEntries = Array.from(knownPeers.entries()).slice(-40);
    const seedUsers: any[] = [];
    for (const [uidStr, pInfo] of recentKnownEntries) {
      if (pInfo.accessHash && String(pInfo.accessHash) !== '0') {
        try {
          seedUsers.push(
            new Api.User({
              id: BigInt(uidStr) as any,
              accessHash: BigInt(pInfo.accessHash) as any,
              username: pInfo.username
            })
          );
        } catch {}
      }
    }
    if (seedUsers.length > 0) {
      try {
        if ((client       ).session && typeof (client       ).session.processEntities === 'function') {
          (client       ).session.processEntities(seedUsers);
        }
        if ((client       )._entityCache) {
          (client       )._entityCache.add(seedUsers);
        }
      } catch {}
    }
  }

  a.status = 'Monitoring...';

  // 🧹 Auto-clean personal chats older than 24 hours (1 day) upon bot boot
  setTimeout(() => {
    cleanOldPersonalChatsForAccount(phone, 1).catch((err) => {
      log(phone, 'WARN', `Boot chat cleanup notice: ${err?.message || err}`);
    });
  }, 3500);

  // 1. Multi-Account Distributed Filter Worker (Raw Queue -> Verified Queue)
  const filterLoopPromise = (async () => {
    const BATCH_SIZE = 50; // High-throughput batch for instant Node.js processing
    let cachedChEntity: any = null;
    let cachedChLink = '';
    let lastChFetch = 0;

    while (a.running) {
      if (signal.aborted) break;

      try {
        const owner = a.owner || "admin";
        if (getOwnerVerifiedQueue(owner).length >= 100000) {
          await new Promise((r) => setTimeout(r, 2000));
          continue;
        }
        const batch = claimBatchFromRawQueue(owner, phone, BATCH_SIZE);

        if (batch.length === 0) {
          await new Promise((r) => setTimeout(r, 2000));
          continue;
        }

        log(
          phone,
          'DB',
          `🔍 Claimed batch of ${batch.length} candidate(s) from Raw Queue. Applying Node.js filters...`
        );

        let validCount = 0;
        let skippedCount = 0;
        const verifiedBatch: number[] = [];

        // Pre-resolve channel entity once if Early Channel Lock is enabled
        const effChLink = getEffectiveConfig(a).channel_link;
        if (globalAiConfig.channel_lock_early !== false && effChLink) {
          if (effChLink !== cachedChLink || Date.now() - lastChFetch > 60000 || !cachedChEntity) {
            try {
              cachedChEntity = await Promise.race([
                client.getEntity(effChLink),
                new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 2500))
              ]).catch(() => null);
              cachedChLink = effChLink;
              lastChFetch = Date.now();
            } catch {}
          }
        }

        for (const uid of batch) {
          if (signal.aborted || !a.running) {
            releaseOwnerRawReservation(owner, uid);
            break;
          }

          try {
            const sent = getOwnerSentUsers(owner);
            const skipped = getOwnerSkippedUsers(owner);
            const verified = getOwnerVerifiedQueue(owner);
            const verifiedSet = new Set(verified);

            if (sent.has(uid) || skipped.has(uid) || verifiedSet.has(uid)) {
              removeFromOwnerRawQueue(owner, uid);
              continue;
            }

            const ownerPeers = getOwnerPeers(owner);
            const pInfo = ownerPeers.get(String(uid));
            let userObj: any = null;
            let targetPeer: any = null;

            // 1. Check Non-Indian Phone (if phone available, Indian numbers start with 91 or +91)
            const rawPhone = String(pInfo?.phone || '').trim();
            const cleanPhone = rawPhone.replace(/^\+/, '');
            if (cleanPhone && !cleanPhone.startsWith('91')) {
              skippedCount++;
              markOwnerSkippedUser(owner, uid, `Non-Indian Phone (${rawPhone})`, {
                name: pInfo?.firstName,
                username: pInfo?.username,
                phone: rawPhone,
                category: 'other',
                skippedByPhone: phone
              });
              removeFromOwnerRawQueue(owner, uid);
              log(phone, 'SKIP', `🌍 [NON-INDIAN FILTER] Skipped ${pInfo?.firstName || uid}: Non-Indian phone (+${cleanPhone}).`);
              continue;
            }

            // 2. Strict Check: Telegram Premium accounts
            if (pInfo?.isPremium || (globalAiConfig.reject_premium !== false && pInfo?.isPremium)) {
              skippedCount++;
              markOwnerSkippedUser(owner, uid, 'Telegram Premium Account', {
                name: pInfo?.firstName,
                username: pInfo?.username,
                phone: pInfo?.phone,
                category: 'premium',
                skippedByPhone: phone
              });
              removeFromOwnerRawQueue(owner, uid);
              log(phone, 'SKIP', `⭐ [PREMIUM FILTER] Skipped ${pInfo?.firstName || pInfo?.username || uid}: Telegram Premium account.`);
              continue;
            }

            // 3. Strict Check: Bots
            if (pInfo?.isBot || (globalAiConfig.reject_bots !== false && pInfo?.isBot)) {
              skippedCount++;
              markOwnerSkippedUser(owner, uid, 'Telegram Bot Account', {
                name: pInfo?.firstName,
                username: pInfo?.username,
                phone: pInfo?.phone,
                category: 'bot',
                skippedByPhone: phone
              });
              removeFromOwnerRawQueue(owner, uid);
              continue;
            }

            // 4. Strict Check: Deleted / Scam Accounts
            if (pInfo?.isDeleted || (globalAiConfig.reject_deleted !== false && pInfo?.isDeleted)) {
              skippedCount++;
              markOwnerSkippedUser(owner, uid, 'Deleted / Scam Account', {
                name: pInfo?.firstName,
                username: pInfo?.username,
                phone: pInfo?.phone,
                category: 'deleted',
                skippedByPhone: phone
              });
              removeFromOwnerRawQueue(owner, uid);
              continue;
            }

            // 4b. Strict Check: Privacy Restricted (Only My Contacts)
            if (pInfo?.isPrivacyRestricted) {
              skippedCount++;
              markOwnerSkippedUser(owner, uid, 'User privacy restricted (Only Contacts)', {
                name: pInfo?.firstName,
                username: pInfo?.username,
                phone: pInfo?.phone,
                category: 'privacy',
                skippedByPhone: phone
              });
              removeFromOwnerRawQueue(owner, uid);
              log(phone, 'SKIP', `🔒 [PRIVACY PRE-FILTER] Skipped ${pInfo?.firstName || uid}: User restricts messages to contacts only.`);
              continue;
            }

            const hasUsername = Boolean(pInfo?.username && String(pInfo.username).trim().length > 0);

            // 5. Strict Rule: @username are NOT ALLOWED (Users with @username are skipped)
            if (globalAiConfig.reject_usernames !== false && hasUsername) {
              skippedCount++;
              const uname = pInfo?.username || 'user';
              markOwnerSkippedUser(owner, uid, 'Has @username (Filtered by Node.js rule)', {
                name: pInfo?.firstName,
                username: uname,
                phone: pInfo?.phone,
                category: 'has_username',
                skippedByPhone: phone
              });
              removeFromOwnerRawQueue(owner, uid);
              log(phone, 'SKIP', `🚫 [USERNAME FILTER] Skipped @${uname.replace(/^@/, '')}: Account has @username.`);
              continue;
            }

            // 6. Strict Check: Exclude Admins & Channel/Group Owners
            if ((globalAiConfig.reject_admins !== false) && isTelegramAdminOrOwner(null, pInfo)) {
              skippedCount++;
              markOwnerSkippedUser(owner, uid, 'Admin or Channel/Group Owner', {
                name: pInfo?.firstName,
                username: pInfo?.username,
                phone: pInfo?.phone,
                category: 'admin',
                skippedByPhone: phone
              });
              removeFromOwnerRawQueue(owner, uid);
              log(phone, 'SKIP', `👑 [ADMIN FILTER] Skipped ${pInfo?.firstName || uid}: Group/Channel Admin or Owner.`);
              continue;
            }

            // 7. Strict Check: Node.js Fast Pattern & Scam/Gambling/Betting/Color Prediction Filter
            if (globalAiConfig.reject_scam_keywords !== false) {
              const spamCheck = isTelegramUserSpamOrPromo(null, pInfo);
              if (spamCheck.isSpam) {
                skippedCount++;
                markOwnerSkippedUser(owner, uid, spamCheck.reason, {
                  name: pInfo?.firstName,
                  username: pInfo?.username,
                  phone: pInfo?.phone,
                  category: 'spam_bio',
                  skippedByPhone: phone
                });
                removeFromOwnerRawQueue(owner, uid);
                log(phone, 'SKIP', `🚫 [NODE.JS SPAM FILTER] Skipped ${pInfo?.firstName || uid}: ${spamCheck.reason}`);
                continue;
              }
            }

            // 8. Optional AI Filter (Only if explicitly enabled by admin in AI tab)
            if (globalAiConfig.filter_enabled && globalAiConfig.filter_mode !== 'smart_keyword') {
              try {
                const batchResults = await analyzeTelegramUsersBatch([{
                  uid,
                  firstName: pInfo?.firstName,
                  lastName: pInfo?.lastName,
                  username: pInfo?.username,
                  phone: pInfo?.phone,
                  about: pInfo?.about
                }]);
                const aiVerdict = batchResults.get(uid);
                if (aiVerdict && aiVerdict.status === "REJECTED") {
                  skippedCount++;
                  markOwnerSkippedUser(owner, uid, aiVerdict.reason, {
                    name: pInfo?.firstName,
                    username: pInfo?.username,
                    phone: pInfo?.phone,
                    category: aiVerdict.category || "spam_bio",
                    skippedByPhone: phone
                  });
                  removeFromOwnerRawQueue(owner, uid);
                  log(phone, 'SKIP', `🚫 [AI FILTER] Skipped ${pInfo?.firstName || uid}: ${aiVerdict.reason}`);
                  continue;
                }
              } catch {}
            }

            // 9. Telegram Bot Fast Filter & Early Channel Lock (skip users already in the target channel)
            if (globalAiConfig.channel_lock_early !== false) {
              const chCheck = await isUserAlreadyInChannel(owner, uid, phone, client);
              if (chCheck.inChannel) {
                skippedCount++;
                markOwnerSkippedUser(owner, uid, `Already joined ${chCheck.channelName || 'target channel'} (Fast Bot Filter)`, {
                  name: pInfo?.firstName,
                  category: 'other',
                  skippedByPhone: phone
                });
                removeFromOwnerRawQueue(owner, uid);
                log(phone, 'SKIP', `🔒 [FAST BOT FILTER] Skipped ${pInfo?.firstName || uid}: ALREADY JOINED in ${chCheck.channelName || 'channel'}.`);
                continue;
              }
            }

            // 10. Peer Resolution & Pre-Flight Validation in Raw Queue
            const evalClient = (pInfo?.sourcePhone && accounts.get(pInfo.sourcePhone)?.client) || client;
            const evalPhone = pInfo?.sourcePhone || phone;
            try {
              if (!targetPeer) {
                targetPeer = await resolveTargetPeer(evalClient, uid, pInfo, evalPhone).catch(() => null);
              }
            } catch {}

            if (!targetPeer && !pInfo?.username) {
              skippedCount++;
              markOwnerSkippedUser(owner, uid, 'Cannot resolve Telegram Peer entity / access hash', {
                name: pInfo?.firstName,
                category: 'no_peer',
                skippedByPhone: evalPhone
              });
              removeFromOwnerRawQueue(owner, uid);
              log(phone, 'SKIP', `🔒 [RAW PEER FILTER] Skipped ${pInfo?.firstName || uid}: Peer unresolvable.`);
              continue;
            }

            // 11. Multi-Account Entity Cache Injection: Inject peer into ALL accounts of this owner
            broadcastPeerToOwnerClients(owner, String(uid), pInfo);

            // Cloud Contact Save during Live Stream (Instant permanent lock into Telegram Cloud Contacts)
            await lockContactPermanently(evalClient, evalPhone, uid, pInfo).catch(() => null);

            // Pre-check Privacy & Peer Settings at Raw Stage (Skip contact-only users right here!)
            try {
              if (targetPeer) {
                const settingsRes: any = await Promise.race([
                  evalClient.invoke(new Api.messages.GetPeerSettings({ peer: targetPeer })),
                  new Promise((_, reject) => setTimeout(() => reject(new Error('TIMEOUT')), 2500))
                ]).catch(() => null);
                const st = settingsRes?.settings;
                if (st?.needContactsException || st?.blockContact) {
                  skippedCount++;
                  markOwnerSkippedUser(owner, uid, 'User privacy restricted (Only Contacts can message)', {
                    name: pInfo?.firstName,
                    username: pInfo?.username,
                    phone: pInfo?.phone,
                    category: 'privacy',
                    skippedByPhone: evalPhone
                  });
                  removeFromOwnerRawQueue(owner, uid);
                  log(phone, 'SKIP', `🔒 [RAW ONLY-CONTACT FILTER] Skipped ${pInfo?.firstName || uid}: Only Contacts can message (Filtered out at Raw stage).`);
                  continue;
                }
                await evalClient.invoke(new Api.messages.GetHistory({ peer: targetPeer, limit: 1 })).catch(() => null);
              }
            } catch {}

            // 12. PROMOTION TO GENUINE QUEUE (100% Verified Clean Lead Ready for DM)
            validCount++;
            markGlobalVerified(uid);
            verifiedBatch.push(uid);
            addToOwnerVerifiedQueue(owner, [uid]);
            removeFromOwnerRawQueue(owner, uid);
            log(phone, 'OK', `⚡ [GENUINE - NODE.JS] ${pInfo?.firstName || uid} promoted to Genuine Queue (100% DM Ready & Cloud Contact Saved).`);
          } catch (uErr: any) {
            log(phone, 'WARN', `Filter error on user ${uid}: ${uErr?.message || uErr}`);
            releaseOwnerRawReservation(owner, uid);
          }
        }

        if (validCount > 0 || skippedCount > 0) {
          log(
            phone,
            "OK",
            `✅ Batch of ${batch.length} completed: +${validCount} Genuine Users ready (Pruned ${skippedCount}). Verified Queue: ${getOwnerVerifiedQueue(owner).length} | Raw Left: ${getOwnerRawQueue(owner).length}`
          );
        }

        // Adaptive rest: If raw queue still has users, process next batch with minimal 200ms delay
        const rawRemaining = getOwnerRawQueue(owner).length;
        const restMs = (batch.length > 0 && rawRemaining > 0) ? 200 : 2000;
        await new Promise((r) => setTimeout(r, restMs));
      } catch (loopErr: any) {
        log(phone, 'WARN', `Filter worker loop error: ${loopErr?.message || loopErr}`);
        await new Promise((r) => setTimeout(r, 2000));
      }
    }
  })();

  // 2. DM Worker runner in background (Processes 100% Genuine Verified Queue in 10-User Batches)
  const dmLoopPromise = (async () => {
    while (a.running) {
      if (signal.aborted) break;

      const owner = a.owner || 'admin';

      if (!a.dm_on) {
        // Auto-check if account is in 10-Min Rest Mode due to PEER_FLOOD
        if ((a as any).dm_rest_until) {
          const now = Date.now();
          if (now >= (a as any).dm_rest_until) {
            delete (a as any).dm_rest_until;
            a.dm_on = true;
            (a as any).peer_flood_consecutive = 0;
            log(phone, 'OK', `🟢 10-Minute Rest Mode completed (Cycle ${(a as any).peer_flood_rest_cycles || 1}/2). DM automatically re-enabled!`);
            saveAccountsJson();
            broadcastAccountUpdate(owner);
          }
        }
        await new Promise((r) => setTimeout(r, 4000));
        continue;
      }

      // Check if live stream is running if live_on is true
      if (a.live_on) {
        const currentVerifiedQ = getAccountVerifiedQueue(phone);
        if (currentVerifiedQ.length > 0) {
          const nextUid = currentVerifiedQ[0];
          const nextPInfo = getOwnerPeers(owner).get(String(nextUid));
          // If the next target is already contact-locked, do NOT check or purge stream! Send the DM!
          if (!nextPInfo?.isContactLocked && !nextPInfo?.contactSaved) {
            const streamAlive = await checkIsStreamStillAlive(owner, client, phone);
            if (!streamAlive) {
              const stalePurged = purgeAccountVerifiedQueueOnStreamEnd(phone, 'No active live stream');
              if (stalePurged > 0) {
                await new Promise((r) => setTimeout(r, 2000));
                continue;
              }
            }
          }
        }
      }

      const uid = claimNextFromAccountVerifiedQueue(phone);

      if (uid === null) {
        await new Promise((r) => setTimeout(r, 3000));
        continue;
      }

      const verifiedQ = getAccountVerifiedQueue(phone);

      if (getOwnerSentUsers(owner).has(uid) || getOwnerSkippedUsers(owner).has(uid) || a.sent_users.has(uid)) {
        removeFromAccountVerifiedQueue(phone, uid);
        continue;
      }

      // 1. Check & Forcefully Resolve peer BEFORE taking any wait delay
      const ownerPeers = getOwnerPeers(owner);
      const pInfo = ownerPeers.get(String(uid));

      // Check reject_usernames setting: Skip accounts with @username ONLY if user explicitly enabled this option
      if (globalAiConfig.reject_usernames === true && pInfo?.username && String(pInfo.username).trim().length > 0) {
        log(phone, 'SKIP', `🚫 [STRICT RULE] Skipped @${String(pInfo.username).replace(/^@/, '')} (${uid}): Has @username (reject_usernames active).`);
        markOwnerSkippedUser(owner, uid, 'Has @username (Filtered by reject_usernames option)', {
          name: pInfo.firstName,
          username: pInfo.username,
          phone: pInfo.phone,
          category: 'has_username',
          skippedByPhone: phone
        });
        removeFromAccountVerifiedQueue(phone, uid);
        removeFromOwnerVerifiedQueue(owner, uid);
        releaseOwnerVerifiedReservation(owner, uid);
        broadcastAccountUpdate(owner);
        continue;
      }

      let targetPeer = await resolveTargetPeer(client, uid, pInfo, phone);
      if (!targetPeer) {
        // Attempt Expired Hash Auto-Recovery before giving up!
        targetPeer = await recoverOrHealPeer(client, phone, owner, uid, pInfo);
      }

      // If user entity cannot be resolved at all, advance queue cleanly with instant log
      if (!targetPeer) {
        log(phone, 'SKIP', `⚠️ [UNRESOLVABLE PEER] Skipped ${pInfo?.firstName || uid}: Cannot resolve user entity without active stream or valid access hash.`);
        markOwnerSkippedUser(owner, uid, 'Unresolvable peer (Access hash expired or stream ended)', {
          name: pInfo?.firstName,
          username: pInfo?.username,
          phone: pInfo?.phone,
          category: 'no_peer',
          skippedByPhone: phone
        });
        removeFromAccountVerifiedQueue(phone, uid);
        removeFromOwnerVerifiedQueue(owner, uid);
        releaseOwnerVerifiedReservation(owner, uid);
        broadcastAccountUpdate(owner);
        continue;
      }

      // PRE-DM SAFETY CHECK: Check cached profile in memory (0 network API calls to avoid spam score)
      if (globalAiConfig.reject_usernames === true && pInfo?.username && String(pInfo.username).trim().length > 0) {
        log(phone, 'SKIP', `🚫 [STRICT RULE] Skipped @${String(pInfo.username).replace(/^@/, '')} (${uid}): Has @username.`);
        markOwnerSkippedUser(owner, uid, 'Has @username (Filtered by reject_usernames option)', {
          name: pInfo.firstName,
          username: pInfo.username,
          phone: pInfo.phone,
          category: 'has_username',
          skippedByPhone: phone
        });
        removeFromAccountVerifiedQueue(phone, uid);
        removeFromOwnerVerifiedQueue(owner, uid);
        releaseOwnerVerifiedReservation(owner, uid);
        broadcastAccountUpdate(owner);
        continue;
      }

      if (pInfo?.isPremium) {
        log(phone, 'SKIP', `⭐ [PREMIUM GATE] Skipped ${pInfo?.firstName || uid}: Telegram Premium account.`);
        markOwnerSkippedUser(owner, uid, 'Telegram Premium Account', {
          name: pInfo?.firstName,
          username: pInfo?.username,
          phone: pInfo?.phone,
          category: 'premium',
          skippedByPhone: phone
        });
        removeFromAccountVerifiedQueue(phone, uid);
        continue;
      }

      if (pInfo?.isBot) {
        log(phone, 'SKIP', `🤖 [BOT GATE] Skipped ${pInfo?.firstName || uid}: Telegram Bot.`);
        markOwnerSkippedUser(owner, uid, 'Telegram Bot Account', {
          name: pInfo?.firstName,
          username: pInfo?.username,
          category: 'bot',
          skippedByPhone: phone
        });
        removeFromAccountVerifiedQueue(phone, uid);
        continue;
      }

      if (pInfo?.isDeleted) {
        log(phone, 'SKIP', `🗑️ [DELETED GATE] Skipped ${uid}: Deleted / Scam Account.`);
        markOwnerSkippedUser(owner, uid, 'Deleted / Scam Account', {
          name: pInfo?.firstName,
          category: 'deleted',
          skippedByPhone: phone
        });
        removeFromAccountVerifiedQueue(phone, uid);
        continue;
      }

      // PRE-DM BLACKLIST SAFETY CHECK: Final drop for Trader, Agent, or custom reject keywords before DM
      if (globalAiConfig.reject_scam_keywords !== false) {
        const spamCheck = isTelegramUserSpamOrPromo(null, pInfo);
        if (spamCheck.isSpam) {
          log(phone, 'SKIP', `🚫 [BLACKLIST FILTER] Skipped ${pInfo?.firstName || uid}: ${spamCheck.reason}`);
          markOwnerSkippedUser(owner, uid, spamCheck.reason, {
            name: pInfo?.firstName,
            username: pInfo?.username,
            phone: pInfo?.phone,
            category: 'spam_bio',
            skippedByPhone: phone
          });
          removeFromAccountVerifiedQueue(phone, uid);
          removeFromOwnerVerifiedQueue(owner, uid);
          releaseOwnerVerifiedReservation(owner, uid);
          broadcastAccountUpdate(owner);
          continue;
        }
      }

      // Physical DM Mobile Emulation: Permanent Telegram Cloud Contact Save FIRST
      let verifiedTargetPeer: any = targetPeer;
      try {
        const lockRes = await lockContactPermanently(client, phone, uid, pInfo).catch(() => null);
        if (lockRes?.inputPeer) {
          verifiedTargetPeer = lockRes.inputPeer;
        }
      } catch {}

      // PRE-DELAY INSTANT PEER VERIFICATION & PRIVACY CHECK (0-Second Abort)
      let profileRestrictedReason: string | null = null;
      let peerSettingsRes: any = null;

      try {
        const settingsPromise = client.invoke(new Api.messages.GetPeerSettings({ peer: verifiedTargetPeer || targetPeer }));
        peerSettingsRes = await Promise.race([
          settingsPromise,
          new Promise((_, reject) => setTimeout(() => reject(new Error('SETTINGS_TIMEOUT')), 3500))
        ]);
      } catch (sErr: any) {
        const sMsg = String(sErr?.message || sErr);
        if (sMsg.includes('PEER_ID_INVALID') || sMsg.includes('USER_ID_INVALID')) {
          // Stale / unlinked access hash: Attempt auto-recovery
          const healed = await recoverOrHealPeer(client, phone, owner, uid, pInfo);
          if (healed) {
            verifiedTargetPeer = healed;
          } else {
            profileRestrictedReason = 'Telegram access hash invalid or expired';
          }
        } else if (sMsg.includes('SETTINGS_TIMEOUT')) {
          if (!pInfo?.isContactLocked) {
            profileRestrictedReason = 'Profile loading hang / spinning timeout (Telegram restricted)';
          }
        } else if (sMsg.includes('PRIVACY') || sMsg.includes('RESTRICTED')) {
          if (!pInfo?.isContactLocked) {
            profileRestrictedReason = 'Privacy settings block non-contact messaging';
          }
        }
      }

      if (!profileRestrictedReason && peerSettingsRes?.settings) {
        const st = peerSettingsRes.settings;
        if (st.blockContact) {
          profileRestrictedReason = 'User has blocked this contact';
        } else if (st.needContactsException && !pInfo?.isContactLocked) {
          profileRestrictedReason = 'Only Contact Privacy Blocked (User requires mutual contact exception for DMs)';
        }
      }

      // If restricted in ANY way, DROP IMMEDIATELY BEFORE TAKING DELAY (0s Wasted!)
      if (profileRestrictedReason) {
        log(phone, 'SKIP', `⚡ [PRE-DELAY RESTRICTION ABORT] Skipped ${pInfo?.firstName || uid}: ${profileRestrictedReason} (0s delay wasted).`);
        markOwnerSkippedUser(owner, uid, profileRestrictedReason, {
          name: pInfo?.firstName,
          category: 'privacy_restricted',
          skippedByPhone: phone
        });
        removeFromAccountVerifiedQueue(phone, uid);
        removeFromOwnerVerifiedQueue(owner, uid);
        releaseOwnerVerifiedReservation(owner, uid);
        wakeScanner(phone); // Instantly wake scanner to target next live stream listener
        broadcastAccountUpdate(owner);
        continue; // BREAK IMMEDIATELY! NO 60-90s DELAY WAITED!
      }

      // Physical DM Mobile Emulation: Permanent Telegram Cloud Contact Save
      await lockContactPermanently(client, phone, uid, pInfo).catch(() => null);

      // Pre-warm chat history (Simulate physical mobile app opening chat box)
      try {
        await client.invoke(new Api.messages.GetHistory({ peer: verifiedTargetPeer || targetPeer, limit: 1 })).catch(() => null);
      } catch {}

      // Smart Delay Calculation:
      // 1. Pehla target user milte hi turant 2 second me DM shoot hoga.
      // 2. Uske baad agar last DM se ab tak scanning me 1.5 - 2 min (ya configured delay) beet chuka hai,
      //    to target milte hi usko bhi turant 2 second me DM jayega.
      // 3. Agar next target jaldi mila hai to Telegram safe gap ke liye bacha hua interval wait hoga.
      const effCfg = getEffectiveConfig(a);
      const dmin = Math.max(1, effCfg.delay_min !== undefined ? effCfg.delay_min : 90);
      const dmax = Math.max(dmin, effCfg.delay_max !== undefined ? effCfg.delay_max : 120);
      const targetGapSec = Math.floor(Math.random() * (dmax - dmin + 1)) + dmin;

      const lastDmTime = accountLastDmTimestamp.get(phone) || 0;
      const now = Date.now();
      const elapsedSinceLastDmSec = lastDmTime > 0 ? Math.floor((now - lastDmTime) / 1000) : 999999;

      let delay = 2; // Default 2 second
      if (lastDmTime === 0 || elapsedSinceLastDmSec >= targetGapSec) {
        delay = 2;
        log(
          phone,
          'WAIT',
          `⚡ [TURANT 2s DM SHOOT] ${lastDmTime === 0 ? 'Pehla stream target user' : `Pichle DM se ab tak ${elapsedSinceLastDmSec}s ho chuke hain (Target gap: ${targetGapSec}s)`} -> ${pInfo?.firstName || uid} ko turant 2 second me DM shoot hoga!`
        );
      } else {
        const remaining = targetGapSec - elapsedSinceLastDmSec;
        delay = Math.max(2, remaining);
        log(
          phone,
          'WAIT',
          `⏳ [SAFE GAP DELAY] Last DM was ${elapsedSinceLastDmSec}s ago. Waiting remaining ${delay}s (target gap: ${targetGapSec}s) before sending DM to ${pInfo?.firstName || uid}...`
        );
      }

      // Interruptible wait without 3-second stream exit abort
      // (User Telegram Cloud Contact me permanently lock ho chuka hai, to DM 100% deliver hoga chahe user stream chhod kar nikal jaye)
      let interrupted = false;
      for (let i = 0; i < delay; i++) {
        if (signal.aborted || !a.running) {
          interrupted = true;
          break;
        }
        await new Promise((r) => setTimeout(r, 1000));
      }

      if (interrupted) {
        if (signal.aborted || !a.running) {
          log(phone, 'WARN', 'Force stop! Bot stopping immediately.');
          releaseOwnerVerifiedReservation(owner, uid);
          break;
        }
        continue;
      }

      // Optional Channel Lock Check (Cached entity, only if channel_lock_early is enabled)
      const effChannelLink = getEffectiveConfig(a).channel_link;
      if (effChannelLink && globalAiConfig.channel_lock_early !== false) {
        let shouldSkip = false;
        try {
          // Check cached channel entity in client session
          const chEntity = await client.getInputEntity(effChannelLink).catch(() => null);
          if (chEntity) {
            let partInputPeer: any = null;
            try {
              partInputPeer = utils.getInputPeer(targetPeer);
            } catch {
              try {
                partInputPeer = await client.getInputEntity(targetPeer).catch(() => null);
              } catch {}
            }
            if (partInputPeer) {
              const participant = await client.invoke(
                new Api.channels.GetParticipant({
                  channel: chEntity,
                  participant: partInputPeer
                })
              ).catch(() => null);
              if (participant) shouldSkip = true;
            }
          }
        } catch {}

        if (shouldSkip) {
          log(phone, 'SKIP', `User ${uid} is already in the channel (Channel Lock).`);
          markOwnerSkippedUser(owner, uid, 'Already in target channel (Channel Lock)', {
            category: 'other',
            skippedByPhone: phone
          });
          removeFromOwnerVerifiedQueue(owner, uid);
          continue;
        }
      }

      // Message templates (current update preserved)
      const availableMessages: string[] = [
        getEffectiveConfig(a).message_1,
        getEffectiveConfig(a).message_2,
        getEffectiveConfig(a).message_3,
        getEffectiveConfig(a).message || ''
      ].filter((m): m is string => Boolean(m && m.trim().length > 0));

      const aiContext = getEffectiveConfig(a).ai_context;
      const uObj = getUser(owner);
      const aiEnabled = uObj?.ai_enabled === true;
      const useDynamic = aiEnabled || getEffectiveConfig(a).use_dynamic_templates === true || availableMessages.length === 0;

      let msgText = '';
      let wasAiDm = false;

      // Check whether AI DM is configured with a valid key for the selected provider
      const selectedDmProv = globalAiConfig.dm_provider || 'groq';
      const hasDmKey = Boolean(
        globalAiConfig.dm_api_key?.trim() ||
        globalAiConfig.filter_api_key?.trim() ||
        (selectedDmProv === 'groq' && process.env.GROQ_API_KEY) ||
        (selectedDmProv === 'deepseek' && (process.env.DEEPSEEK_API_KEY || process.env.OPENAI_API_KEY)) ||
        (selectedDmProv === 'gemini' && (process.env.GEMINI_API_KEY || globalAiConfig.filter_api_key?.trim())) ||
        (selectedDmProv === 'openai' && process.env.OPENAI_API_KEY)
      );

      if (aiEnabled && aiContext && aiContext.trim().length > 0 && hasDmKey) {
        try {
          const userNameStr = pInfo?.firstName || "user";
          const sysInstruction = globalAiConfig.dm_system_prompt || "You are a casual human user reaching out on Telegram.";
          const prompt = `Context/Goal: ${aiContext.trim()}
My target channel link (if needed): ${getEffectiveConfig(a).channel_link || "N/A"}
Recipient's first name: ${userNameStr}

Task: Write a very short, natural-sounding direct message (DM) in Hinglish (or English if the context implies it). 
Do NOT sound like a bot. Sound like a real human. Keep it under 2-3 sentences.
Make sure to include the channel link if the context is about promoting a channel.
Output ONLY the message text, nothing else. No quotation marks.`;

          msgText = await callAiEngine({
            task: "dm",
            prompt,
            systemInstruction: sysInstruction,
            temperature: 0.65
          });
          if (msgText) wasAiDm = true;
        } catch (e: any) {
          log(phone, 'INFO', `ℹ️ [AI DM] LLM call skipped, using 37.5L Dynamic Hinglish Engine.`);
        }
      }

      // Resolve effective channel link (growth bot campaign link or tracked per-user join link or master link)
      let effectiveTargetLink = (getEffectiveConfig(a).channel_link || '').trim();
      try {
        const ownerCampaigns = getCampaignsByOwner(owner);
        const activeCamp = ownerCampaigns.find(c => c.billing_status !== 'suspended' && c.billing_status !== 'unpaid' && c.status === 'active');
        if (activeCamp) {
          const config = getGrowthBotConfig();
          const targetBotUser = activeCamp.bot_username || (config && config.bot_username && config.enabled ? config.bot_username : '');
          if (targetBotUser) {
            effectiveTargetLink = `https://t.me/${targetBotUser}?start=${activeCamp.campaign_slug}`;
          }
        }
      } catch (e) {}

      if (!effectiveTargetLink) {
        try {
          const trackedL = await getOrCreateUserTrackedInviteLink(owner, a);
          if (trackedL) effectiveTargetLink = trackedL;
        } catch {}
      }

      // Fast, zero-cost 37.5L Dynamic Hinglish Engine (Greetings + Intros + Services + CTAs)
      if (!msgText && (useDynamic || availableMessages.length === 0)) {
        const dynResult = buildDynamicHinglishMessage(pInfo?.firstName, effectiveTargetLink);
        if (dynResult && dynResult.text) {
          msgText = dynResult.text;
          wasAiDm = true;
          log(
            phone,
            'OK',
            `⚡ [DYNAMIC DM: ${dynResult.code}] Generated natural 4-line Hinglish message for ${pInfo?.firstName || uid}${availableMessages.length === 0 ? ' (Dynamic DM active: 3 DM boxes empty)' : ''}`
          );
        }
      }

      if (!msgText) {
        if (availableMessages.length > 0) {
          const randomMsgTemplate: string =
            availableMessages[Math.floor(Math.random() * availableMessages.length)] || 'Join my channel: {CHANNEL_LINK}';
          msgText = randomMsgTemplate.replace(/\{CHANNEL_LINK\}/g, effectiveTargetLink || "");
          const originalL = (getEffectiveConfig(a).channel_link || '').trim();
          if (originalL && originalL !== effectiveTargetLink) {
            msgText = msgText.split(originalL).join(effectiveTargetLink);
          }
        } else {
          const dynResult = buildDynamicHinglishMessage(pInfo?.firstName, effectiveTargetLink);
          msgText = dynResult?.text || `Hey ${pInfo?.firstName || 'bhai'}! Check out my channel: ${effectiveTargetLink || ''}`;
          wasAiDm = true;
        }
      }

      // Direct, safe DM dispatch with natural typing indicator
      try {
        if (signal.aborted || !a.running) {
          releaseOwnerVerifiedReservation(owner, uid);
          break;
        }

        // Clean human preparation pause before send (fast 200ms if delay <= 2s, else 1.5-2.5s)
        const prepDelay = delay <= 2 ? 200 : (Math.floor(Math.random() * 1000) + 1500);
        await new Promise((r) => setTimeout(r, prepDelay));

        if (signal.aborted || !a.running) {
          releaseOwnerVerifiedReservation(owner, uid);
          break;
        }

        // 🔒 FINAL FAST BOT FILTER CHECK: Guarantee user hasn't joined while waiting in queue
        const chFinalCheck = await isUserAlreadyInChannel(owner, uid, phone, client);
        if (chFinalCheck.inChannel) {
          log(phone, 'SKIP', `🔒 [FAST BOT FILTER] Skipped DM to ${uid}: Already joined ${chFinalCheck.channelName || 'target channel'}!`);
          markOwnerSkippedUser(owner, uid, `Already joined ${chFinalCheck.channelName || 'target channel'} (Fast Bot Filter)`, {
            name: pInfo?.firstName,
            category: 'other',
            skippedByPhone: phone
          });
          a.sent_users.add(uid);
          saveSentUser(phone, uid);
          releaseOwnerVerifiedReservation(owner, uid);
          continue;
        }

        const sendResult = await withTimeout(
          client.sendMessage(verifiedTargetPeer || targetPeer, { message: msgText }),
          20000,
          'MTPROTO_SEND_TIMEOUT'
        );
        recordApiCall(phone, "dm");
        if (sendResult) {
          accountLastDmTimestamp.set(phone, Date.now());
          (a as any).peer_flood_consecutive = 0;
          delete (a as any).dm_rest_until;
          a.sent_users.add(uid);
          saveSentUser(phone, uid);
          a.sent_count = (a.sent_count || 0) + 1;
          checkAndResetDailyDmQuota(phone);
          (a as any).daily_sent_count = ((a as any).daily_sent_count || 0) + 1;
          (a as any).peer_flood_consecutive = 0; // Reset consecutive flood counter on clean message
          saveAccountsLocal();
          markOwnerSentUser(owner, uid, phone);
          recordDailyDm(owner, phone);
          if (wasAiDm) recordAiDm(owner);
          const userTag = pInfo?.username ? ` @${pInfo.username}` : "";
          const namePart = pInfo?.firstName ? `${pInfo.firstName}${userTag} (${uid})` : (userTag ? `${userTag} (${uid})` : String(uid));
          
          removeFromAccountVerifiedQueue(phone, uid);
          broadcastAccountUpdate(owner);

          log(phone, "SENT", `🚀 [INSTANT DM DELIVERED] Live message delivered to ${namePart}! Daily: ${(a as any).daily_sent_count} | Total: ${a.sent_count}. Scanner ready to hook next live listener...`);

          // 🧹 Instant RAM Pruning: Drop bulky peer entity from memory cache after delivery
          try {
            const ent = (client as any)._entityCache;
            if (ent && ent.cacheMap instanceof Map) {
              ent.cacheMap.delete(uid);
              if (ent.cacheMap.size > 25) {
                const it = ent.cacheMap.keys();
                for (let i = 0; i < 15; i++) {
                  const k = it.next().value;
                  if (k !== undefined) ent.cacheMap.delete(k);
                  else break;
                }
              }
            }
          } catch {}

          // Gentle human buffer pause between live stream checks (4 to 8s)
          const bufferDelay = Math.floor(Math.random() * 4000) + 4000;
          await new Promise((r) => setTimeout(r, bufferDelay));
        }
      } catch (err: any) {
        const errMsg = String(err?.message || err);
        const isFloodWait = errMsg.includes("FLOOD_WAIT") || errMsg.includes("FloodWaitError") || err?.seconds;
        const isPeerFlood = errMsg.includes("PEER_FLOOD") || errMsg.includes("PeerFloodError");
        const isPeerIdInvalid = errMsg.includes("PEER_ID_INVALID");
        const isTimeout = errMsg.includes("MTPROTO_SEND_TIMEOUT") || errMsg.includes("Operation timed out") || errMsg.includes("TIMEOUT") || errMsg.includes("timed out") || errMsg.includes("ETIMEDOUT");
        const isPrivacyOrBlocked =
          errMsg.includes("PRIVACY") ||
          errMsg.includes("UserPrivacyRestrictedError") ||
          errMsg.includes("USER_IS_BLOCKED") ||
          errMsg.includes("UserIsBlockedError") ||
          errMsg.includes("YOU_BLOCKED_USER") ||
          errMsg.includes("USER_DEACTIVATED") ||
          errMsg.includes("InputUserDeactivatedError") ||
          errMsg.includes("INPUT_USER_DEACTIVATED");

        if (isTimeout) {
          const userTag = pInfo?.username ? ` @${pInfo.username}` : "";
          const namePart = pInfo?.firstName ? `${pInfo.firstName}${userTag} (${uid})` : (userTag ? `${userTag} (${uid})` : String(uid));
          log(phone, "WARN", `⏱️ [SOCKET TIMEOUT RECOVERY] Message delivery to ${namePart} timed out (>20s). Advancing queue to avoid bot freeze!`);
          releaseOwnerVerifiedReservation(owner, uid);
          removeFromAccountVerifiedQueue(phone, uid);
          try {
            if (client && !client.connected) {
              client.connect().catch(() => {});
            }
          } catch {}
          continue;
        }

        if (isFloodWait) {
          // Precise extraction of Telegram wait seconds (DO NOT match HTTP status 420!)
          const floodMatch = errMsg.match(/FLOOD_WAIT_(\d+)/i) || errMsg.match(/wait of (\d+)/i) || errMsg.match(/(\d+)\s*seconds/i);
          const seconds = err?.seconds ? Number(err.seconds) : (floodMatch ? parseInt(floodMatch[1], 10) : 30);
          const safeSeconds = Math.min(Math.max(seconds, 5), 3600);
          const cool = safeSeconds + 5;
          log(phone, "WARN", `⏳ Telegram rate limit (FLOOD_WAIT: ${safeSeconds}s). Pausing DM worker for ${cool}s... (User remains in queue)`);
          releaseOwnerVerifiedReservation(owner, uid);
          await new Promise((r) => setTimeout(r, cool * 1000));
          continue;
        } else if (isPeerFlood) {
          (a as any).peer_flood_consecutive = ((a as any).peer_flood_consecutive || 0) + 1;
          const attempt = (a as any).peer_flood_consecutive;
          releaseOwnerVerifiedReservation(owner, uid);

          if (attempt >= 5) {
            // 5 consecutive PEER_FLOOD attempts reached without resolving -> Check rest cycle count
            (a as any).peer_flood_rest_cycles = ((a as any).peer_flood_rest_cycles || 0) + 1;
            const cycle = (a as any).peer_flood_rest_cycles;
            (a as any).peer_flood_consecutive = 0;
            a.dm_on = false;

            if (cycle < 2) {
              // Cycle 1: 10 minutes Rest Mode
              const restSeconds = 600; // 10 minutes
              (a as any).dm_rest_until = Date.now() + restSeconds * 1000;
              saveAccountsJson();
              broadcastAccountUpdate(owner);

              log(
                phone,
                "WARN",
                `🛑 [10-MIN REST MODE ACTIVATED] 5 consecutive @SpamBot runs failed to clear PEER_FLOOD (Cycle ${cycle}/2). DM OFF & entering Rest Mode for 10 minutes (600s). Live Stream Monitoring remains ACTIVE.`
              );
              await new Promise((r) => setTimeout(r, 5000));
              continue;
            } else {
              // Cycle 2 failed: Limit exhausted until midnight/daily quota reset
              (a as any).dm_peer_flood_exhausted = true;
              delete (a as any).dm_rest_until;
              saveAccountsJson();
              broadcastAccountUpdate(owner);

              log(
                phone,
                "WARN",
                `⛔ [DM REST MODE - LIMIT EXHAUSTED] PEER_FLOOD persisted after 2 consecutive 10-minute rest cycles (10 @SpamBot runs). DM option placed in Rest Mode until daily limit reset at midnight. Live Stream Monitoring remains ACTIVE.`
              );
              await new Promise((r) => setTimeout(r, 5000));
              continue;
            }
          }

          log(
            phone,
            "WARN",
            `⚠️ [PEER_FLOOD ${attempt}/5] Telegram rate limit encountered. Running @SpamBot verification cycle (${attempt}/5)...`
          );

          let isCleared = false;
          try {
            isCleared = await checkAndResolveSpamBot(client, phone, true);
          } catch {}

          if (isCleared) {
            log(phone, "OK", `🎉 @SpamBot reported clean status on attempt ${attempt}/5! Retrying DM in 5s...`);
            await new Promise((r) => setTimeout(r, 5000));
            continue;
          } else {
            log(phone, "WARN", `⚠️ @SpamBot restriction reported (attempt ${attempt}/5). Retrying next cycle in 6s...`);
            await new Promise((r) => setTimeout(r, 6000));
            continue;
          }
        } else if (isPeerIdInvalid) {
          const displayName = pInfo?.firstName ? `${pInfo.firstName} (${uid})` : (pInfo?.username ? `@${pInfo.username} (${uid})` : String(uid));
          let reResolvedPeer: any = null;

          // Auto-Recovery: If user has a username, re-resolve via username
          if (pInfo?.username) {
            const cleanUser = pInfo.username.trim().replace(/^@/, "");
            try {
              const freshEnt = await client.getInputEntity(`@${cleanUser}`).catch(() => null);
              if (freshEnt) {
                reResolvedPeer = utils.getInputPeer(freshEnt);
                if (reResolvedPeer && (reResolvedPeer as any).accessHash && pInfo) {
                  pInfo.accessHash = String((reResolvedPeer as any).accessHash);
                }
              }
            } catch {}
          }

          if (reResolvedPeer) {
            try {
              const retryResult = await client.sendMessage(reResolvedPeer, { message: msgText });
              if (retryResult) {
                (a as any).peer_flood_consecutive = 0;
                delete (a as any).dm_rest_until;
                a.sent_users.add(uid);
                saveSentUser(phone, uid);
                a.sent_count = (a.sent_count || 0) + 1;
                checkAndResetDailyDmQuota(phone);
                (a as any).daily_sent_count = ((a as any).daily_sent_count || 0) + 1;
                markOwnerSentUser(owner, uid, phone);
                recordDailyDm(owner, phone);
                if (wasAiDm) recordAiDm(owner);
                const userTag = pInfo?.username ? ` @${pInfo.username}` : "";
                const namePart = pInfo?.firstName ? `${pInfo.firstName}${userTag} (${uid})` : (userTag ? `${userTag} (${uid})` : String(uid));
                log(phone, "SENT", `🚀 [DM DELIVERED] Successfully sent DM to ${namePart} ➔ Daily: ${(a as any).daily_sent_count} | Total: ${a.sent_count}`);
                removeFromOwnerVerifiedQueue(owner, uid);
                broadcastAccountUpdate(owner);
                continue;
              }
            } catch {}
          }

          // Universal peer fallback across accounts of this owner & Contact Auto-Recovery
          let recoveredPeer: any = null;
          try {
            recoveredPeer = await recoverOrHealPeer(client, phone, owner, uid, pInfo).catch(() => null);
            if (!recoveredPeer) {
              recoveredPeer = await resolveTargetPeer(client, uid, pInfo, phone).catch(() => null);
            }
            if (recoveredPeer) {
              const resend = await client.sendMessage(recoveredPeer, { message: msgText }).catch(() => null);
              if (resend) {
                accountLastDmTimestamp.set(phone, Date.now());
                (a as any).peer_flood_consecutive = 0;
                delete (a as any).dm_rest_until;
                a.sent_users.add(uid);
                saveSentUser(phone, uid);
                a.sent_count = (a.sent_count || 0) + 1;
                checkAndResetDailyDmQuota(phone);
                (a as any).daily_sent_count = ((a as any).daily_sent_count || 0) + 1;
                markOwnerSentUser(owner, uid, phone);
                recordDailyDm(owner, phone);
                if (wasAiDm) recordAiDm(owner);
                const userTag = pInfo?.username ? ` @${pInfo.username}` : "";
                const namePart = pInfo?.firstName ? `${pInfo.firstName}${userTag} (${uid})` : (userTag ? `${userTag} (${uid})` : String(uid));
                log(phone, "SENT", `🚀 [DM DELIVERED VIA RECOVERY] Successfully sent DM to ${namePart} ➔ Daily: ${(a as any).daily_sent_count} | Total: ${a.sent_count}`);
                removeFromOwnerVerifiedQueue(owner, uid);
                broadcastAccountUpdate(owner);
                continue;
              }
            }
          } catch {}

          // User cannot be messaged (access hash expired or invalid for this account)
          log(phone, "SKIP", `🔒 Skipped ${displayName}: User privacy restricted (Only Contacts) or access hash expired.`);
          markOwnerSkippedUser(owner, uid, 'User privacy restricted (Only Contacts) or access hash expired', {
            category: 'privacy_restricted',
            skippedByPhone: phone
          });
          removeFromAccountVerifiedQueue(phone, uid);

          if (a.live_on) {
            const streamAlive = await checkIsStreamStillAlive(owner, client, phone);
            if (!streamAlive) {
              purgeAccountVerifiedQueueOnStreamEnd(phone, 'Telegram access hash expired due to concluded stream');
            }
          }
          broadcastAccountUpdate(owner);
        } else if (isPrivacyOrBlocked) {
          const displayName = pInfo?.firstName ? `${pInfo.firstName} (${uid})` : (pInfo?.username ? `@${pInfo.username} (${uid})` : String(uid));
          const shortErr = errMsg.split("\n")[0].replace(/Error: /g, "").slice(0, 35);
          log(phone, "SKIP", `🔒 Skipped ${displayName}: ${shortErr}.`);
          markOwnerSkippedUser(owner, uid, `Privacy/Blocked: ${shortErr}`, {
            category: 'privacy',
            skippedByPhone: phone
          });
          removeFromAccountVerifiedQueue(phone, uid);
          broadcastAccountUpdate(owner);
        } else {
          log(phone, "FAIL", `DM error: ${errMsg.slice(0, 60)}`);
          await new Promise((r) => setTimeout(r, 5000));
          markOwnerSkippedUser(owner, uid, `DM error: ${errMsg.slice(0, 40)}`, {
            category: 'other',
            skippedByPhone: phone
          });
          removeFromAccountVerifiedQueue(phone, uid);
          broadcastAccountUpdate(owner);
        }
      }
    }
  })();

  // Midnight reset
  let lastResetDate = new Date().getDate();

  // Channel & Live Monitor loop
  const checkIntervalSec = Math.max(5, a.config.check_interval || 12);
  log(phone, 'GO', `Live Audio Stream Detection active (fast scan interval: ${checkIntervalSec}s)`);

  while (a.running && !signal.aborted) {
    const now = new Date();
    const today = now.getDate();
    if (today !== lastResetDate) {
      a.daily_collected_count = 0;
      lastResetDate = today;
    }
    if (a.daily_collected_count === undefined) a.daily_collected_count = 0;

    const owner = a.owner || 'admin';

    if (a.live_on) {
      try {
        const currentVerifiedQ = getAccountVerifiedQueue(phone);
        if (currentVerifiedQ.length > 0) {
          // 🔒 SCANNER STREAM LOCK:
          // When users are in Genuine Queue, stay locked to this stream until current batch finishes.
          // Zero getDialogs() calls made during stream lock!
          const streamAlive = await checkIsStreamStillAlive(owner, client, phone);
          if (!streamAlive) {
            const purged = purgeAccountVerifiedQueueOnStreamEnd(phone, 'Live stream concluded by host');
            if (purged > 0) {
              log(phone, 'WARN', `🛑 Live stream ended by host! Purged ${purged} expired leads from Genuine Queue.`);
              broadcastAccountUpdate(owner);
            }
            const lockedAct = activeGroupCalls.get(phone);
            if (lockedAct?.entity?.id) releaseLiveStreamLeader(String(lockedAct.entity.id), phone);
            continue;
          }

          // Refresh leader heartbeat
          const lockedAct = activeGroupCalls.get(phone);
          if (lockedAct?.entity?.id) {
            registerLiveStreamLeader(String(lockedAct.entity.id), phone, owner, lockedAct.title);
          }

          // Continuous Cache Sync: Stream lock ke dauran scanner har 3.5 second me call participants list refresh karta rehta hai
          await syncStreamParticipantsCache(phone, owner, client);
          await sleepWithWakeup(phone, 3500);
          continue;
        }

        // 🧠 MEMORY-CACHED NON-TARGET RESOLUTION (0 Telegram API Calls on repeat scans)
        const effCfg = getEffectiveConfig(a);
        const ignoredData = await getOrResolveOwnerIgnoredChannels(owner, client, effCfg);
        const ignoredIds = ignoredData.ids;
        const ignoredUsernames = ignoredData.usernames;
        const ignoredTitles = ignoredData.titles;

        const candidates: Array<{ id: string; title: string; entity: any; inputEntity: any }> = [];
        const seenIds = new Set<string>();

        // Auto-detect joined channels & groups from dialogs (Lightweight scan: 35 active channels instead of 120)
        try {
          const dialogs = await client.getDialogs({ limit: 35 }).catch(() => []);
          for (const d of dialogs) {
            if (d.isChannel || d.isGroup) {
              const did = String(d.id || '');
              const didBare = did.replace(/^-100/, '').replace(/^-/, '');
              const dUsername = (d.entity as any)?.username ? String((d.entity as any).username).toLowerCase() : '';
              const dTitle = (d.title || '').trim().toLowerCase();

              // 🚫 RIGOROUS RAM NON-TARGET CHECK (Zero Telegram API Call):
              let isNonTarget = false;
              if (ignoredIds.has(did) || ignoredIds.has(didBare) || ignoredIds.has(`-100${didBare}`)) {
                isNonTarget = true;
              } else if (dUsername && ignoredUsernames.has(dUsername)) {
                isNonTarget = true;
              } else if (dTitle && (ignoredTitles.has(dTitle) || Array.from(ignoredTitles).some(t => t.length >= 3 && (dTitle === t || dTitle.includes(t) || t.includes(dTitle))))) {
                isNonTarget = true;
              }

              if (isNonTarget) {
                continue; // 🚫 STRICTLY SKIP THIS NON-TARGET CHANNEL - NEVER SCAN!
              }

              if (!seenIds.has(did)) {
                seenIds.add(did);
                candidates.push({
                  id: did,
                  title: d.title || `Chat ${did}`,
                  entity: d.entity,
                  inputEntity: d.inputEntity
                });
              }
            }
          }
        } catch (dialogErr: any) {
          log(phone, 'WARN', `Dialogs fetch: ${dialogErr?.message || dialogErr}`);
        }

        let liveFoundCount = 0;

        // Prioritize active locked stream in candidates
        const lockedAct = activeGroupCalls.get(phone) || ownerActiveGroupCalls.get(owner);
        if (lockedAct && lockedAct.title) {
          const lockedIdx = candidates.findIndex(
            (c) => c.title === lockedAct.title || String(c.id) === String((lockedAct.entity as any)?.id)
          );
          if (lockedIdx > 0) {
            const [lockedCand] = candidates.splice(lockedIdx, 1);
            candidates.unshift(lockedCand);
          }
        }

        // Check each candidate for active live audio stream
        for (const cand of candidates) {
          if (!a.running || signal.aborted || !a.live_on) break;

          const cid = String(cand.id || '');
          const cidBare = cid.replace(/^-100/, '').replace(/^-/, '');
          const cTitle = (cand.title || '').trim().toLowerCase();
          if (ignoredIds.has(cid) || ignoredIds.has(cidBare) || ignoredIds.has(`-100${cidBare}`) || ignoredTitles.has(cTitle)) {
            continue; // Skip non-target candidate
          }

          // 👑 MULTI-BOT STREAM LEADER CHECK:
          // If another bot belonging to this user is already the designated leader scanning this stream,
          // skip this channel so we don't duplicate calls, and let this bot scan other channels!
          const leaderCheck = isChannelScannedByOtherLeader(cid, phone);
          if (leaderCheck.isOtherLeader) {
            continue;
          }

          try {
            let fullChat: any = null;
            if (cand.entity?.className === 'Chat') {
              // Basic group
              fullChat = await client.invoke(
                new Api.messages.GetFullChat({ chatId: cand.entity.id })
              ).catch(() => null);
            } else {
              // Supergroup / Channel
              fullChat = await client.invoke(
                new Api.channels.GetFullChannel({ channel: cand.inputEntity || cand.entity })
              ).catch(() => null);
            }

            const groupCall = fullChat?.fullChat?.call;
            if (groupCall && groupCall.className !== 'GroupCallDiscarded') {
              // Construct properly typed InputGroupCall with safe string/BigInt conversion
              const callIdStr = (groupCall.id?.toString ? groupCall.id.toString() : String(groupCall.id || '')).replace(/[^0-9-]/g, '');
              const rawHash = groupCall.accessHash !== undefined ? groupCall.accessHash : groupCall.access_hash;
              const callHashStr = (rawHash?.toString ? rawHash.toString() : String(rawHash || '0')).replace(/[^0-9-]/g, '');

              const inputCall = new Api.InputGroupCall({
                id: BigInt(callIdStr || '0') as any,
                accessHash: BigInt(callHashStr || '0') as any
              });

              // Pre-validate that this call is TRULY live: not discarded, not scheduled for the future, and has real listeners (> 0)
              let callInfo: any = null;
              try {
                callInfo = await client.invoke(
                  new Api.phone.GetGroupCall({ call: inputCall, limit: 100 })
                );
              } catch (callErr: any) {
                const callErrMsg = String(callErr?.message || callErr);
                if (callErrMsg.includes('GROUPCALL_INVALID') || callErrMsg.includes('GROUPCALL_JOIN_MISSING')) {
                  activeGroupCalls.delete(phone);
                  releaseLiveStreamLeader(cid, phone);
                }
                continue; // Not an active call, ignore and check next channel
              }

              if (!callInfo || !callInfo.call || callInfo.call.className === 'GroupCallDiscarded') {
                continue;
              }

              // Reject if scheduled in the future (stream not started yet)
              if (callInfo.call.scheduleDate && callInfo.call.scheduleDate > Math.floor(Date.now() / 1000)) {
                continue;
              }

              // Reject if 0 listeners/participants (empty/abandoned room)
              const participantCount = callInfo.call.participantsCount || (callInfo.participants ? callInfo.participants.length : 0);
              if (!participantCount || participantCount <= 0) {
                continue;
              }

              // Genuinely ACTIVE live stream confirmed! Register leader lock!
              liveFoundCount++;
              registerLiveStreamLeader(cid, phone, owner, cand.title);
              log(phone, 'LIVE', `Live audio stream DETECTED in "${cand.title}" (${participantCount} participants)! Extracting listeners...`);
              a.status = `LIVE: ${cand.title}`;
              broadcastAccountUpdate(a.owner);

              activeGroupCalls.set(phone, { call: inputCall, rawCall: groupCall, entity: cand.inputEntity || cand.entity, title: cand.title });
              ownerActiveGroupCalls.set(owner, { phone, call: inputCall, rawCall: groupCall, entity: cand.inputEntity || cand.entity, title: cand.title, lastChecked: Date.now() });

              // 1. Fetch channel admins and creator/owner so we can strictly exclude them
              const channelAdmins = new Set<number>();
              try {
                if (cand.entity?.className !== 'Chat') {
                  const adminRes: any = await client.invoke(
                    new Api.channels.GetParticipants({
                      channel: cand.inputEntity || cand.entity,
                      filter: new Api.ChannelParticipantsAdmins(),
                      offset: 0,
                      limit: 100,
                      hash: BigInt(0) as any
                    })
                  ).catch(() => null);
                  recordApiCall(phone, 'get_participants');
                  if (adminRes && Array.isArray(adminRes.users)) {
                    recordUserPeers(phone, adminRes.users, client);
                    for (const au of adminRes.users) {
                      const auId = Number(au.id);
                      if (auId) channelAdmins.add(auId);
                    }
                  }
                }
              } catch {}

              // 2. Fetch call participants (muted, unmuted, listeners, speakers) and channel members
              const allUsersMap = new Map<number, any>();

              const safeNum = (val: any): number => {
                if (val === undefined || val === null) return 0;
                if (typeof val === 'number') return isNaN(val) ? 0 : val;
                if (typeof val === 'bigint') return Number(val);
                try {
                  const s = String(val.toString ? val.toString() : val).replace(/[^0-9-]/g, '');
                  const n = Number(s);
                  return isNaN(n) ? 0 : n;
                } catch {
                  return 0;
                }
              };

              let listenerSeqCounter = 0;
              const ingestGroupParticipants = (participantsList: any[]) => {
                if (!Array.isArray(participantsList)) return;
                for (const p of participantsList) {
                  let pUserId: number = 0;
                  if (p.peer) {
                    if (p.peer.userId !== undefined) pUserId = safeNum(p.peer.userId);
                    else if (p.peer.user_id !== undefined) pUserId = safeNum(p.peer.user_id);
                    else if (p.peer.id !== undefined && p.peer.className !== 'PeerChannel' && p.peer.className !== 'PeerChat') {
                      pUserId = safeNum(p.peer.id);
                    }
                  }
                  if (!pUserId) {
                    if (p.userId !== undefined) pUserId = safeNum(p.userId);
                    else if (p.user_id !== undefined) pUserId = safeNum(p.user_id);
                    else if (p.id !== undefined) pUserId = safeNum(p.id);
                  }

                  if (pUserId && pUserId !== 0) {
                    const existing = allUsersMap.get(pUserId);
                    const accHash = p.accessHash || p.access_hash || p.peer?.accessHash || p.peer?.access_hash || existing?.accessHash;
                    
                    // 🛡️ STREAM HOST & SPEAKER DETECTION:
                    // In Telegram Group Calls, ONLY host, co-hosts and speakers have canSelfUnmute: true!
                    // Regular listeners are audience and cannot unmute themselves.
                    const canSelfUnmute = Boolean(p.canSelfUnmute || p.can_self_unmute);
                    const isUnmutedSpeaker = (p.muted === false) && (p.volumeByAdmin === false || p.volume_by_admin === false);
                    const isSelf = Boolean(p.self || p.isSelf);
                    const isSpeakerOrHost = canSelfUnmute || isUnmutedSpeaker || isSelf || channelAdmins.has(pUserId);

                    allUsersMap.set(pUserId, {
                      ...(existing || {}),
                      id: pUserId,
                      accessHash: accHash,
                      muted: p.muted,
                      left: p.left,
                      volume: p.volume,
                      about: p.about,
                      isParticipant: true,
                      canSelfUnmute,
                      isSpeakerOrHost,
                      joinIndex: existing?.joinIndex || (++listenerSeqCounter)
                    });
                  }
                }
              };

              if (callInfo) {
                if (Array.isArray(callInfo.users)) {
                  recordUserPeers(phone, callInfo.users, client);
                  for (const u of callInfo.users) {
                    const uId = safeNum(u.id);
                    if (uId) {
                      const existing = allUsersMap.get(uId);
                      allUsersMap.set(uId, { ...(existing || {}), ...u, accessHash: u.accessHash || existing?.accessHash });
                    }
                  }
                }
                if (Array.isArray(callInfo.participants)) {
                  ingestGroupParticipants(callInfo.participants);
                }

                // Paginate to collect all call participants (mute, unmute, listeners)
                let nextOffset = callInfo.participantsNextOffset || '';
                let pageCount = 1;
                while (allUsersMap.size < 2000 && pageCount < 20) {
                  pageCount++;
                  try {
                    const more: any = await client.invoke(
                      new Api.phone.GetGroupParticipants({
                        call: inputCall,
                        ids: [],
                        sources: [],
                        offset: nextOffset,
                        limit: 100
                      })
                    ).catch(() => null);

                    if (!more) break;

                    if (Array.isArray(more.users)) {
                      recordUserPeers(phone, more.users, client);
                      for (const u of more.users) {
                        const uId = safeNum(u.id);
                        if (uId) {
                          const existing = allUsersMap.get(uId);
                          allUsersMap.set(uId, { ...(existing || {}), ...u, accessHash: u.accessHash || existing?.accessHash });
                        }
                      }
                    }

                    if (Array.isArray(more.participants)) {
                      ingestGroupParticipants(more.participants);
                    }

                    if (more.nextOffset && more.nextOffset !== nextOffset) {
                      nextOffset = more.nextOffset;
                    } else {
                      break;
                    }
                  } catch {
                    break;
                  }
                }
              }

              // Forcefully resolve any active call participants that lack accessHash or username
              if (inputCall) {
                const missingIds = Array.from(allUsersMap.keys()).filter((uid) => {
                  const uObj = allUsersMap.get(uid);
                  return !uObj?.accessHash && !uObj?.username;
                });
                if (missingIds.length > 0) {
                  for (let i = 0; i < missingIds.length && i < 60; i += 20) {
                    const batch = missingIds.slice(i, i + 20);
                    try {
                      const bRes: any = await client.invoke(
                        new Api.phone.GetGroupParticipants({
                          call: inputCall,
                          ids: batch.map((bid) => new Api.InputPeerUser({ userId: BigInt(bid) as any, accessHash: BigInt(0) as any })),
                          sources: [],
                          offset: '',
                          limit: 20
                        })
                      ).catch(() => null);
                      if (bRes?.users && Array.isArray(bRes.users)) {
                        recordUserPeers(phone, bRes.users, client);
                        for (const ru of bRes.users) {
                          const ruId = safeNum(ru.id);
                          if (ruId) {
                            const existing = allUsersMap.get(ruId);
                            allUsersMap.set(ruId, { ...(existing || {}), ...ru, accessHash: ru.accessHash || existing?.accessHash });
                          }
                        }
                      }
                    } catch {}
                  }
                }
              }

              // Record discovered peers in memory cache
              recordUserPeers(phone, Array.from(allUsersMap.values()), client);

              // 3. Filter out: admin, owner/creator, bot, deleted account, premium, @username, already sent
              const stats = { admin: 0, bot: 0, deleted: 0, already_sent: 0, uncontactable: 0 };
              const eligibleUids: number[] = [];

              for (const [rawUid, u] of allUsersMap.entries()) {
                const uid = safeNum(rawUid);
                if (!uid || uid === myId || u.self || u.isSelf) continue;

                // 1. Exclude Admins & Owner/Creator, Stream Host, and Invited Speakers
                if (channelAdmins.has(uid) || u.isSpeakerOrHost || u.canSelfUnmute) {
                  stats.admin++;
                  markOwnerSkippedUser(owner, uid, 'Stream Host / Speaker / Admin Shield', {
                    name: u.firstName,
                    username: u.username,
                    phone: u.phone,
                    category: 'admin',
                    skippedByPhone: phone
                  });
                  continue;
                }

                // 2. Exclude Bots
                if (isTelegramBotUser(u)) {
                  stats.bot++;
                  markOwnerSkippedUser(owner, uid, 'Telegram Bot Account', {
                    name: u.firstName,
                    username: u.username,
                    phone: u.phone,
                    category: 'bot',
                    skippedByPhone: phone
                  });
                  continue;
                }

                // 3. Exclude Deleted Accounts / scam
                if (isTelegramDeletedUser(u)) {
                  stats.deleted++;
                  markOwnerSkippedUser(owner, uid, 'Deleted / Scam Account', {
                    name: u.firstName,
                    username: u.username,
                    phone: u.phone,
                    category: 'deleted',
                    skippedByPhone: phone
                  });
                  continue;
                }

                // 3b. Exclude Privacy Restricted (Messages limited to Contacts)
                if (isTelegramPrivacyRestricted(u)) {
                  markOwnerSkippedUser(owner, uid, 'User privacy restricted (Only Contacts)', {
                    name: u.firstName,
                    username: u.username,
                    phone: u.phone,
                    category: 'privacy',
                    skippedByPhone: phone
                  });
                  continue;
                }

                // 4. Exclude Non-Indian (Indian phone numbers start with 91 or +91)
                if (u.phone) {
                  const cleanPhone = String(u.phone).replace(/^\+/, '').trim();
                  if (cleanPhone && !cleanPhone.startsWith('91')) {
                    markOwnerSkippedUser(owner, uid, `Non-Indian Phone (${u.phone})`, {
                      name: u.firstName,
                      username: u.username,
                      phone: u.phone,
                      category: 'other',
                      skippedByPhone: phone
                    });
                    continue;
                  }
                }

                // 5. Exclude Already Sent
                if (a.sent_users.has(uid) || getOwnerSentUsers(owner).has(uid)) {
                  stats.already_sent++;
                  continue;
                }

                // 6. Exclude Telegram Premium (comprehensive check)
                if (isTelegramPremiumUser(u)) {
                  markOwnerSkippedUser(owner, uid, 'Telegram Premium Account', {
                    name: u.firstName,
                    username: u.username,
                    phone: u.phone,
                    category: 'premium',
                    skippedByPhone: phone
                  });
                  continue;
                }

                // 7. Check reject_usernames setting: Skip accounts with @username ONLY if enabled by user
                if (globalAiConfig.reject_usernames !== false && u.username && String(u.username).trim().length > 0) {
                  markOwnerSkippedUser(owner, uid, 'Has @username (Filtered by reject_usernames option)', {
                    name: u.firstName,
                    username: u.username,
                    phone: u.phone,
                    category: 'has_username',
                    skippedByPhone: phone
                  });
                  continue;
                }

                // 8. PHYSICAL DM REQUIREMENT: Must have an authentic Telegram accessHash or public @username!
                const candidateHash = u.accessHash || (u.access_hash !== undefined ? u.access_hash : undefined);
                const hasUname = Boolean(u.username && String(u.username).trim().length > 0);
                if (!hasUname && (!candidateHash || String(candidateHash) === '0')) {
                  continue; // Skip participants without username that do not have an authentic accessHash
                }

                eligibleUids.push(uid);
              }

              const rawQ = getOwnerRawQueue(owner);
              const verifiedQ = getAccountVerifiedQueue(phone);
              const rawSet = new Set(rawQ);
              const verifiedSet = new Set(verifiedQ);
              const sentUsersSet = getOwnerSentUsers(owner);
              const skippedUsersSet = getOwnerSkippedUsers(owner);

              const nowTime = Date.now();
              const freshUids = eligibleUids.filter(
                (uid) =>
                  !rawSet.has(uid) &&
                  !verifiedSet.has(uid) &&
                  !sentUsersSet.has(uid) &&
                  !skippedUsersSet.has(uid) &&
                  (!tempLiveStreamCooldown.has(uid) || (tempLiveStreamCooldown.get(uid)! < nowTime))
              );

              // UNLIMITED Genuine Queue capacity (Safety ceiling 5000 per live stream)
              const MAX_STREAM_TARGETS = 5000;
              const currentVQueue = getAccountVerifiedQueue(phone);
              if (currentVQueue.length >= MAX_STREAM_TARGETS) {
                break;
              }
              const neededSlots = MAX_STREAM_TARGETS - currentVQueue.length;

              try {
                // INSTANT TARGET HOOK: High-Speed Micro-Parallel Candidate Verification
                // Priority: 1. Without @username FIRST, 2. Bottom-to-Top (Recent listeners FIRST), 3. Online status
                const prioritizedUids = [...freshUids].sort((a, b) => {
                  const userA = allUsersMap.get(a);
                  const userB = allUsersMap.get(b);
                  const hasUnameA = Boolean(userA?.username && String(userA.username).trim().length > 0) ? 1 : 0;
                  const hasUnameB = Boolean(userB?.username && String(userB.username).trim().length > 0) ? 1 : 0;
                  
                  // 1. NON-@USERNAME FIRST: Crucial because their session hash expires when stream ends!
                  if (hasUnameA !== hasUnameB) {
                    return hasUnameA - hasUnameB; // 0 (without @username) comes FIRST!
                  }

                  // 2. BOTTOM-TO-TOP PRIORITY: Listeners who joined towards the bottom/recent of the room come first!
                  const joinA = userA?.joinIndex || 0;
                  const joinB = userB?.joinIndex || 0;
                  if (joinA !== joinB) {
                    return joinB - joinA; // Higher joinIndex (bottom/newer listeners) comes FIRST!
                  }

                  // 3. Online status tie-breaker
                  const isOnlineA = userA?.status?.className === 'UserStatusOnline' ? 2 : (userA?.status?.className === 'UserStatusRecently' ? 1 : 0);
                  const isOnlineB = userB?.status?.className === 'UserStatusOnline' ? 2 : (userB?.status?.className === 'UserStatusRecently' ? 1 : 0);
                  return isOnlineB - isOnlineA;
                });

                const candidateBatch = prioritizedUids.slice(0, Math.min(prioritizedUids.length, neededSlots * 3));
                const newlyQueued: any[] = [];

                for (const candUid of candidateBatch) {
                  if (newlyQueued.length >= neededSlots) break;

                  const u = allUsersMap.get(candUid);
                  if (!u) continue;
                  const uId = safeNum(u.id);
                  if (!uId) continue;

                  const spamCheck = isTelegramUserSpamOrPromo(null, u);
                  if (spamCheck.isSpam) {
                    markOwnerSkippedUser(owner, uId, spamCheck.reason, {
                      name: u.firstName,
                      username: u.username,
                      phone: u.phone,
                      category: 'spam_keyword',
                      skippedByPhone: phone
                    });
                    continue;
                  }

                  const candidateHash = u.accessHash || u.access_hash;
                  const hasCandUname = Boolean(u.username && String(u.username).trim().length > 0);
                  if (!hasCandUname && (!candidateHash || String(candidateHash) === '0')) continue;

                  try {
                    // Lock into Telegram Cloud Contacts immediately while live stream is active!
                    // This captures their permanent contact access hash so they NEVER expire even if they leave stream!
                    await lockContactPermanently(client, phone, uId, u).catch(() => null);

                    recordUserPeers(phone, [u], client);
                    markGlobalVerified(uId);
                    addToAccountVerifiedQueue(phone, [uId]);
                    a.daily_collected_count = (a.daily_collected_count || 0) + 1;
                    newlyQueued.push(u);

                    log(phone, 'TARGET', `🎯 [GENUINE STREAM TARGET LOCKED] ${u.firstName || uId} permanently secured in Telegram Cloud Contacts & queued for DM delivery!`);
                  } catch (lockErr: any) {
                    tempLiveStreamCooldown.set(uId, Date.now() + 60000);
                  }
                }

                if (newlyQueued.length > 0) {
                  streamParticipantsCache.set(phone, {
                    uids: new Set(allUsersMap.keys()),
                    lastSync: Date.now(),
                    channelTitle: cand.title,
                    call: inputCall
                  });
                  log(phone, 'OK', `⚡ [BATCH LOCKED] Queued +${newlyQueued.length} genuine listeners into Verified Queue (Total in Queue: ${getAccountVerifiedQueue(phone).length}).`);
                  break; // Channel successfully harvested, proceed to dispatch
                } else {
                  log(
                    phone,
                    'LIVE',
                    `Scanned "${cand.title}" - no new eligible listeners (All listeners either contacted, in queue, or filtered).`
                  );
                }
              } catch (batchErr: any) {
                // Batch error handled
              }
            }
          } catch (candErr: any) {
            // Ignored single candidate error
          }
        }

        if (liveFoundCount === 0) {
          const hadActiveCall = activeGroupCalls.has(phone) || getAccountVerifiedQueue(phone).length > 0;
          activeGroupCalls.delete(phone);
          ownerActiveGroupCalls.delete(owner);
          if (hadActiveCall) {
            purgeAccountVerifiedQueueOnStreamEnd(phone, 'Live stream concluded by host');
          }
          log(
            phone,
            'INFO',
            `Scanned ${candidates.length} channels - no live audio stream active currently. Next scan in ${checkIntervalSec}s.`
          );
          if (a.status.startsWith('LIVE:')) {
            a.status = 'Monitoring...';
            broadcastAccountUpdate(a.owner);
          }
        }
      } catch (e: any) {
        log(phone, 'WARN', `Monitor scan error: ${String(e?.message || e).slice(0, 60)}`);
      }
      await new Promise((r) => setTimeout(r, checkIntervalSec * 1000));
    } else {
      // Live monitoring is OFF (queue full or paused) - wait 4s before rechecking
      await new Promise((r) => setTimeout(r, 4000));
    }
  }

  // Await DM task if queue has items and we are stopping gracefully
  const qLeft = loadDmQueue(phone).length;
  if (qLeft > 0) {
    a.status = `Finishing queue: ${qLeft} left`;
    log(phone, 'DB', `Draining queue of ${qLeft} users before disconnecting...`);
    await Promise.race([
      dmLoopPromise,
      new Promise((r) => setTimeout(r, 10000)) // graceful timeout 10s max
    ]);
  }

  await client.disconnect().catch(() => {});
  if (signal.aborted) {
    a.running = false;
    a.status = 'Stopped';
    log(phone, 'BYE', 'Client disconnected cleanly on user stop.');
  } else {
    log(phone, 'WARN', 'Client connection ended. Preserving running state for auto-recovery...');
    a.status = 'Reconnecting...';
  }
}

// 🛡️ UNINTERRUPTED AUTO-RECOVERY BOT SUPERVISOR (Module-Level)
// User requirement: Bots must NEVER shut down unless explicitly stopped by user!
function launchBotWorker(phone: string, abortController: AbortController) {
  const a = accounts.get(phone);
  if (a) {
    if (a.abortController && a.abortController !== abortController) {
      try { a.abortController.abort(); } catch {}
    }
    a.abortController = abortController;
    a.running = true;
    (a as any).persisted_running = true;
    saveAccountsLocal();
  }

  const runWithAutoRecovery = async () => {
    while (!abortController.signal.aborted) {
      const cur = accounts.get(phone);
      if (!cur) break;
      if (cur.abortController && cur.abortController !== abortController) {
        // Newer worker supervisor took over this account
        return;
      }
      cur.running = true;
      (cur as any).persisted_running = true;
      try {
        await runTelegramBot(phone, abortController.signal);
      } catch (err: any) {
        if (abortController.signal.aborted) break;
        log(phone, 'WARN', `⚠️ [AUTO-RECOVERY] Bot loop interrupted (${err?.message || err}). Auto-recovering in 4s...`);
      }

      if (abortController.signal.aborted) break;

      // 🛡️ Ensure bot remains RUNNING in UI and memory unless explicitly aborted by user stop
      const curAfter = accounts.get(phone);
      if (curAfter && curAfter.abortController === abortController && !abortController.signal.aborted) {
        curAfter.running = true;
        (curAfter as any).persisted_running = true;
        curAfter.status = 'Reconnecting...';
        broadcastAccountUpdate(curAfter.owner);
      }
      await new Promise((r) => setTimeout(r, 3000));
    }

    // Only set stopped when abortController.signal.aborted is TRUE (user clicked stop)
    const curEnd = accounts.get(phone);
    if (curEnd && curEnd.abortController === abortController && abortController.signal.aborted) {
      curEnd.running = false;
      (curEnd as any).persisted_running = false;
      curEnd.status = 'Stopped';
      saveAccountsLocal();
      broadcastAccountUpdate(curEnd.owner);
    }
  };

  runWithAutoRecovery().catch((err) => {
    log(phone, 'FAIL', `Bot supervisor unexpected loop exit: ${err?.message || err}`);
    const cur = accounts.get(phone);
    if (cur && cur.abortController === abortController && abortController.signal.aborted) {
      cur.running = false;
      (cur as any).persisted_running = false;
      cur.status = 'Stopped';
      saveAccountsLocal();
      broadcastAccountUpdate(cur.owner);
    }
  });
}

// ---------------- APP SETUP ----------------
const app = express();
const secretKey = getSecretKey();

// Trust reverse proxy (nginx / cloud run) so secure cookies & protocol headers work
app.set('trust proxy', 1);

app.use(cors());
app.use(express.json({ limit: '60mb' }));
app.use(express.urlencoded({ limit: '60mb', extended: true }));
app.use(
  cookieSession({
    name: 'telebot_sess',
    keys: [secretKey],
    maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days session
    sameSite: 'lax', // 'lax' prevents cookie dropping on mobile browsers on HTTP & HTTPS
    secure: false, // allows mobile browsers to store cookie over plain VPS HTTP IP without silent drops
    httpOnly: true
  })
);

// Prevent mobile browser and proxy aggressive caching of HTML and auth pages
app.use((req, res, next) => {
  const p = req.path;
  if (
    p === '/' ||
    p === '/login' ||
    p === '/login.html' ||
    p === '/dashboard' ||
    p === '/dashboard.html' ||
    p === '/admin' ||
    p === '/admin.html' ||
    p === '/index.html' ||
    p === '/whoami' ||
    p.startsWith('/api/')
  ) {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    res.setHeader('Surrogate-Control', 'no-store');
  }
  next();
});

const SYSTEM_DOMAIN_FILE = path.join(__dirname, 'system_domain.json');
let systemConfiguredDomain = '';
try {
  if (fs.existsSync(SYSTEM_DOMAIN_FILE)) {
    const raw = fs.readFileSync(SYSTEM_DOMAIN_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    systemConfiguredDomain = (parsed.domain || parsed.custom_web_url || '').trim();
  }
} catch (e) {}

let globalDetectedWebUrl = '';

function setSystemConfiguredDomain(domainUrl: string) {
  if (!domainUrl) return;
  let clean = domainUrl.trim();
  if (!clean.startsWith('http://') && !clean.startsWith('https://')) {
    clean = 'https://' + clean;
  }
  clean = clean.replace(/\/$/, '');
  systemConfiguredDomain = clean;
  try {
    fs.writeFileSync(SYSTEM_DOMAIN_FILE, JSON.stringify({ domain: clean, updatedAt: new Date().toISOString() }), 'utf8');
  } catch (e) {}
}

function updateDetectedWebUrl(req: any) {
  if (!req) return;
  try {
    const rawHost = (req.get('x-forwarded-host') || req.get('host') || '').trim();
    const proto = (req.get('x-forwarded-proto') || req.protocol || 'https').trim();
    if (rawHost && !rawHost.includes('localhost') && !rawHost.includes('127.0.0.1')) {
      const isRawIp = /^(\d{1,3}\.){3}\d{1,3}(:\d+)?$/.test(rawHost);
      const hostUrl = `${proto}://${rawHost}`;
      if (!isRawIp) {
        // High-priority real domain detected from active web traffic
        globalDetectedWebUrl = hostUrl;
        if (!systemConfiguredDomain) {
          setSystemConfiguredDomain(hostUrl);
        }
      } else if (!globalDetectedWebUrl && !systemConfiguredDomain) {
        globalDetectedWebUrl = hostUrl;
      }
    }
  } catch (e) {}
}

app.use((req, res, next) => {
  updateDetectedWebUrl(req);
  next();
});

// Serve HTML & PWA files
const UPLOADS_DIR = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) {
  try { fs.mkdirSync(UPLOADS_DIR, { recursive: true }); } catch (e) {}
}
app.use('/uploads', express.static(UPLOADS_DIR));
app.use('/icons', express.static(path.join(__dirname, 'icons')));
app.get('/manifest.json', (req: any, res: any) => {
  res.sendFile(path.join(__dirname, 'manifest.json'));
});
app.get('/sw.js', (req: any, res: any) => {
  res.setHeader('Service-Worker-Allowed', '/');
  res.setHeader('Content-Type', 'application/javascript');
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.sendFile(path.join(__dirname, 'sw.js'));
});
app.get('/favicon.ico', (req: any, res: any) => {
  res.sendFile(path.join(__dirname, 'icons', 'favicon.png'));
});
app.get('/api/download/flutter-app', (req: any, res: any) => {
  const zipPath = path.join(__dirname, 'telebot_flutter.tar.gz');
  if (fs.existsSync(zipPath)) {
    res.setHeader('Content-Type', 'application/gzip');
    res.setHeader('Content-Disposition', 'attachment; filename="telebot_flutter.tar.gz"');
    return res.sendFile(zipPath);
  }
  res.status(404).send('Flutter project archive not found');
});

app.get('/api/v1/mobile/tele-config', (req: any, res: any) => {
  const creds = getBestApiCredentials();
  res.json({
    api_id: creds.api_id,
    api_hash: creds.api_hash,
  });
});

function getAdminTelegramBotUrl(): string {
  const adminUser = usersList.find((u: any) => u.role === 'admin' || u.username === 'admin');
  const botUsername = (adminUser as any)?.alert_bot_username || cachedAdminBotUsername || '';
  if (botUsername) {
    return `https://t.me/${botUsername}?start=request_id`;
  }
  return 'https://t.me/';
}

function sendInjectedHtml(filePath: string, res: any) {
  try {
    let content = fs.readFileSync(filePath, 'utf8');
    const botUrl = getAdminTelegramBotUrl();
    if (botUrl && botUrl !== 'https://t.me/') {
      content = content.replace(/https:\/\/t\.me\/(?![\w_]+)/g, botUrl);
    }
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    res.setHeader('Surrogate-Control', 'no-store');
    res.send(content);
  } catch (err) {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0');
    res.sendFile(filePath);
  }
}

app.use('/admin.html', (req: any, res: any) => {
  res.sendFile(path.join(__dirname, 'admin.html'));
});
app.use('/dashboard.html', (req: any, res: any) => {
  sendInjectedHtml(path.join(__dirname, 'dashboard.html'), res);
});
app.use('/login.html', (req: any, res: any) => {
  sendInjectedHtml(path.join(__dirname, 'login.html'), res);
});

// ---------------- TOKEN & SESSION UTILS ----------------
function createToken(username        , role        )         {
  const payload = JSON.stringify({
    username,
    role,
    exp: Date.now() + 7 * 24 * 3600 * 1000
  });
  const b64 = Buffer.from(payload).toString('base64url');
  const sig = crypto.createHmac('sha256', secretKey).update(b64).digest('base64url');
  return `${b64}.${sig}`;
}

function verifyToken(token        )                                            {
  if (!token || typeof token !== 'string' || !token.includes('.')) return null;
  const [b64, sig] = token.split('.');
  if (!b64 || !sig) return null;
  const expectedSig = crypto.createHmac('sha256', secretKey).update(b64).digest('base64url');
  if (sig !== expectedSig) return null;
  try {
    const payload = JSON.parse(Buffer.from(b64, 'base64url').toString('utf-8'));
    if (payload.exp && payload.exp < Date.now()) return null;
    return { username: payload.username, role: payload.role };
  } catch {
    return null;
  }
}

function getSessionUser(req         )                                            {
  let found                                            = null;
  // 1. Check Authorization header: Bearer <token>
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.slice(7).trim();
    found = verifyToken(token);
  }
  // 2. Check query parameter ?token=
  if (!found && typeof req.query.token === 'string' && req.query.token) {
    found = verifyToken(req.query.token);
  }
  // 3. Check custom header x-telebot-token
  if (!found) {
    const xToken = req.headers['x-telebot-token']          ;
    if (xToken) found = verifyToken(xToken);
  }
  // 4. Check cookie session
  if (!found && req.session?.username) {
    found = {
      username: req.session.username          ,
      role: (req.session.role          ) || 'user'
    };
  }

  if (found) {
    const u = getUser(found.username);
    if (!u || !u.active) return null;
    if (found.role !== 'admin' && u.expiry_date) {
      const today = new Date().toISOString().split('T')[0];
      if (today > u.expiry_date) return null;
    }
  }

  return found;
}

// Helper for session
function getEffectiveUser(req         )         {
  const user = getSessionUser(req);
  const va = (req.headers['x-view-as']          ) || (req.query.view_as          ) || (req.session?.view_as          );
  if (va && user?.role === 'admin') {
    return va;
  }
  return user?.username || '';
}

function isAdminSession(req         )          {
  const user = getSessionUser(req);
  if (!user) return false;
  const u = getUser(user.username);
  return Boolean(u && u.role === 'admin');
}

function canTouch(req         , owner        )          {
  if (isAdminSession(req)) return true;
  return owner === getEffectiveUser(req);
}

// Auth guard middleware
app.use((req         , res          , next              ) => {
  if (
    req.path === '/' ||
    req.path === '/login' ||
    req.path === '/api/login' ||
    req.path === '/api/health' ||
    req.path === '/health' ||
    req.path === '/api/system/theme' ||
    req.path === '/whoami' ||
    req.path === '/api/tma/auth' ||
    req.path === '/api/tma/status' ||
    req.path === '/logout' ||
    req.path === '/prd' ||
    req.path === '/prd.html' ||
    req.path === '/PRD.md' ||
    req.path === '/mobile-demo' ||
    req.path === '/mobile-demo.html' ||
    req.path === '/manifest.json' ||
    req.path === '/sw.js' ||
    req.path === '/favicon.ico' ||
    req.path.startsWith('/icons/') ||
    req.path.startsWith('/api/download/prd') ||
    req.path.startsWith('/api/download/flutter-app') ||
    req.path === '/telebot_flutter.tar.gz' ||
    req.path.startsWith('/api/forgot') ||
    req.path.startsWith('/api/public/') ||
    req.path === '/api/system/theme' ||
    req.path.startsWith('/api/system/theme') ||
    req.path.startsWith('/api/telegram-webhook') ||
    req.path === '/login.html' ||
    req.path === '/landing' ||
    req.path === '/landing.html' ||
    req.path === '/index.html'
  ) {
    return next();
  }

  const sessionUser = getSessionUser(req);
  if (!sessionUser) {
    if (req.path.startsWith('/api/')) {
      return res.status(401).json({ msg: 'Unauthorized. Please login.' });
    }
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0');
    return res.redirect('/login?expired=1');
  }

  const u = getUser(sessionUser.username);
  if (!u || !u.active) {
    if (req.session) {
      req.session.username = null;
      req.session.role = null;
      req.session.view_as = null;
    }
    if (req.path.startsWith('/api/')) {
      return res.status(401).json({ msg: 'Unauthorized. Account is disabled or does not exist.' });
    }
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0');
    return res.redirect('/login?expired=1');
  }

  if (u.role !== 'admin' && u.expiry_date) {
    const todayStr = getTodayDateString();
    if (todayStr > u.expiry_date) {
      u.active = false;
      saveUsers();
      if (req.session) {
        req.session.username = null;
        req.session.role = null;
        req.session.view_as = null;
      }
      if (req.path.startsWith('/api/')) {
        return res.status(401).json({ msg: `Your account expired on ${u.expiry_date} and has been terminated/disabled. Please contact administrator to renew.` });
      }
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0');
      return res.redirect('/login?expired=1');
    }
  }

  if (req.session) {
    req.session.username = u.username;
    req.session.role = u.role;
  }

  const va = (req.headers['x-view-as']          ) || (req.query.view_as          ) || (req.session?.view_as          );
  if (va && u.role === 'admin') {
    const vu = getUser(va);
    if (vu && vu.active) {
      if (req.session) req.session.view_as = va;
    } else if (req.session) {
      req.session.view_as = null;
    }
  }

  if (req.path === '/admin' || req.path.startsWith('/api/admin')) {
    if (u.role !== 'admin') {
      if (req.path.startsWith('/api/')) {
        return res.status(403).json({ msg: 'Admin access required' });
      }
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0');
      return res.redirect('/login?expired=1');
    }
  }

  next();
});

// ---------------- ROUTES ----------------
app.get(['/api/health', '/health'], (req, res) => {
  res.json({ ok: true, status: 'healthy', uptime: Math.round(process.uptime()), timestamp: Date.now() });
});

app.get('/', (req, res) => {
  sendInjectedHtml(path.join(__dirname, 'index.html'), res);
});

app.get('/index.html', (req, res) => {
  sendInjectedHtml(path.join(__dirname, 'index.html'), res);
});

app.get('/login', (req         , res          ) => {
  sendInjectedHtml(path.join(__dirname, 'login.html'), res);
});

app.get('/landing', (req         , res          ) => {
  res.sendFile(path.join(__dirname, 'landing.html'));
});

app.get('/landing.html', (req         , res          ) => {
  res.sendFile(path.join(__dirname, 'landing.html'));
});

app.get('/dashboard', (req         , res          ) => {
  sendInjectedHtml(path.join(__dirname, 'dashboard.html'), res);
});

app.get('/mobile-demo', (req: any, res: any) => {
  res.sendFile(path.join(__dirname, 'mobile-demo.html'));
});

app.get('/mobile-demo.html', (req: any, res: any) => {
  res.sendFile(path.join(__dirname, 'mobile-demo.html'));
});

app.get('/prd', (req         , res          ) => {
  res.sendFile(path.join(__dirname, 'prd.html'));
});

app.get('/prd.html', (req         , res          ) => {
  res.sendFile(path.join(__dirname, 'prd.html'));
});

app.get('/PRD.md', (req         , res          ) => {
  res.setHeader('Content-Type', 'text/markdown; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="Leo_TeleGm_Bot_PRD.md"');
  res.sendFile(path.join(__dirname, 'PRD.md'));
});

app.get('/api/download/prd-doc', (req         , res          ) => {
  const prdPath = path.join(__dirname, 'prd.html');
  if (fs.existsSync(prdPath)) {
    res.setHeader('Content-Type', 'application/msword');
    res.setHeader('Content-Disposition', 'attachment; filename="Leo_TeleGm_Bot_PRD.doc"');
    return res.sendFile(prdPath);
  }
  res.status(404).send('PRD not found');
});

app.get('/index.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/admin', (req         , res          ) => {
  res.sendFile(path.join(__dirname, 'admin.html'));
});

app.get('/logout', (req         , res          ) => {
  if (req.session) {
    req.session.username = null;
    req.session.role = null;
    req.session.view_as = null;
  }
  res.redirect('/login');
});

app.get('/whoami', (req         , res          ) => {
  const sessionUser = getSessionUser(req);
  const va = (req.headers['x-view-as']          ) || (req.query.view_as          ) || (req.session?.view_as          ) || '';
  res.json({
    username: sessionUser?.username || '',
    view_as: va,
    role: sessionUser?.role || 'user'
  });
});

app.get('/back-to-admin', (req         , res          ) => {
  if (req.session) {
    req.session.view_as = null;
  }
  res.redirect('/admin');
});

// POST /login & /api/login
const handleAuthLogin = (req         , res          ) => {
  try {
    const { username, password } = req.body || {};
    const uname = (username || '').trim();
    const pwd = (password || '').trim();
    const now = Date.now();

    if (!uname || !pwd) {
      return res.status(400).json({ ok: false, msg: 'Please provide both username and password' });
    }

    const isExplicitAdmin = uname.toLowerCase() === 'admin';

    if (!isExplicitAdmin) {
      const att = loginAttempts.get(uname) || { count: 0, until: 0 };
      if (att.until > now) {
        const wait = Math.ceil((att.until - now) / 1000);
        return res.status(429).json({ ok: false, msg: `Too many failed attempts! Try again in ${wait} seconds.` });
      }
    } else {
      // Clear any lockout for admin
      loginAttempts.delete(uname);
    }

    const u = getUser(uname);
    let isValid = false;

    if (u) {
      if (verifyVal(u.password, pwd)) {
        isValid = true;
        // Lazy-migrate legacy hash to salted scrypt
        if (u.password && !u.password.startsWith('scrypt:')) {
          u.password = hashVal(pwd);
          saveUsers();
        }
      }
    }

    if (!u || !isValid) {
      const clientIp = getClientIp(req);
      const lock = recordFailedLoginAttempt(clientIp);
      if (lock.locked) {
        return res.status(429).json({ ok: false, msg: `🛡️ Security Lockout: Too many failed login attempts. Temporarily blocked for ${lock.lockoutMins} minutes.` });
      }
      if (!isExplicitAdmin) {
        const att = loginAttempts.get(uname) || { count: 0, until: 0 };
        att.count = (att.count || 0) + 1;
        if (att.count >= MAX_ATTEMPTS) {
          att.count = 0;
          att.until = now + LOCK_SECONDS * 1000;
        }
        loginAttempts.set(uname, att);
      }
      return res.status(401).json({ ok: false, msg: `Wrong username or password! (${lock.remainingAttempts} attempts remaining)` });
    }

    loginAttempts.delete(uname);
    recordSuccessfulLogin(getClientIp(req));

    // Platform Authorization Check (Mobile App vs Web Browser)
    const rawPlat = (
      req.headers['x-client-platform'] ||
      req.body?.platform ||
      (/LeoTeleBot|okhttp|dart:io/i.test(req.headers['user-agent'] || '') ? 'android' : 'web')
    ).toString().toLowerCase();
    const isAppClient = rawPlat === 'android' || rawPlat === 'app' || rawPlat === 'mobile';
    const userAccessType = (u.access_type || 'both').toLowerCase();

    if (u.role !== 'admin') {
      if (isAppClient && userAccessType === 'web_only') {
        return res.status(403).json({
          ok: false,
          msg: '🚫 Access Denied: Yeh user account sirf Web Dashboard ke liye authorized hai (Mobile App not allowed). Please login from Web Browser or contact Admin.'
        });
      }
      if (!isAppClient && userAccessType === 'app_only') {
        return res.status(403).json({
          ok: false,
          msg: '🚫 Access Denied: Yeh user account sirf Mobile App ke liye authorized hai (Web Browser login not allowed). Please use LeoTeleBot Android App or contact Admin.'
        });
      }
    }

    // Record login platform telemetry
    (u as any).last_platform = isAppClient ? 'Mobile App' : 'Web Browser';
    (u as any).last_login = Date.now();
    saveUsers();

    if (u.role !== 'admin' && u.expiry_date) {
      const todayStr = getTodayDateString();
      if (todayStr > u.expiry_date) {
        u.active = false;
        saveUsers();
        return res.status(401).json({ ok: false, msg: `Your account expired on ${u.expiry_date} and has been disabled/terminated. Please contact administrator to renew.` });
      }
    }

    if (!u.active) {
      return res.status(401).json({ ok: false, msg: 'This account has been disabled/terminated by admin!' });
    }

    const token = createToken(u.username, u.role);

    if (req.session) {
      req.session.username = u.username;
      req.session.role = u.role;
    }

    return res.json({
      ok: true,
      msg: 'ok',
      role: u.role,
      username: u.username,
      token,
      redirect: u.role === 'admin' ? '/admin' : '/dashboard'
    });
  } catch (err: any) {
    console.error('Login route error:', err);
    return res.status(500).json({ ok: false, msg: 'Server error during authentication. Please retry.' });
  }
};

app.post('/login', checkLoginBruteForce, handleAuthLogin);
app.post('/api/login', checkLoginBruteForce, handleAuthLogin);

// ---------------- TELEGRAM MINI APP (TMA) HMAC-SHA256 VERIFICATION ----------------
function verifyTelegramWebAppData(initData: string, botToken: string): { isValid: boolean; user?: any; authDate?: number } {
  if (!initData || !botToken) return { isValid: false };
  try {
    const params = new URLSearchParams(initData);
    const hash = params.get('hash');
    if (!hash) return { isValid: false };

    // Remove hash parameter before calculating data_check_string
    params.delete('hash');

    // Sort parameters alphabetically: key=value\nkey2=value2...
    const keys = Array.from(params.keys()).sort();
    const dataCheckArr: string[] = [];
    for (const key of keys) {
      dataCheckArr.push(`${key}=${params.get(key)}`);
    }
    const dataCheckString = dataCheckArr.join('\n');

    // Secret key = HMAC_SHA256("WebAppData", botToken)
    const secretKey = crypto.createHmac('sha256', 'WebAppData').update(botToken.trim()).digest();

    // Signature = HMAC_SHA256(secretKey, dataCheckString).hex()
    const calculatedHash = crypto.createHmac('sha256', secretKey).update(dataCheckString).digest('hex');

    const calculatedBuffer = Buffer.from(calculatedHash, 'utf8');
    const hashBuffer = Buffer.from(hash, 'utf8');

    if (calculatedBuffer.length !== hashBuffer.length) {
      return { isValid: false };
    }

    if (!crypto.timingSafeEqual(calculatedBuffer, hashBuffer)) {
      return { isValid: false };
    }

    const userStr = params.get('user');
    const authDateStr = params.get('auth_date');
    const authDate = authDateStr ? parseInt(authDateStr, 10) : undefined;
    let userObj: any = null;
    if (userStr) {
      try {
        userObj = JSON.parse(userStr);
      } catch {}
    }

    return { isValid: true, user: userObj, authDate };
  } catch (err) {
    return { isValid: false };
  }
}

// ---------------- TELEGRAM MINI APP (TMA) AUTO-AUTHENTICATION ----------------
app.post('/api/tma/auth', (req: any, res: any) => {
  try {
    const { initData } = req.body || {};

    if (!initData || typeof initData !== 'string' || !initData.trim()) {
      return res.status(400).json({ ok: false, msg: 'Missing Telegram Mini App initData signature.' });
    }

    // Collect all valid bot tokens configured in system to verify HMAC signature
    const adminUser = usersList.find((u: any) => u.role === 'admin');
    const candidateTokens: string[] = [];
    if (adminUser?.alert_bot_token) candidateTokens.push(adminUser.alert_bot_token.trim());
    for (const u of usersList) {
      if (u.alert_bot_token && !candidateTokens.includes(u.alert_bot_token.trim())) {
        candidateTokens.push(u.alert_bot_token.trim());
      }
    }
    if (process.env.BOT_TOKEN && !candidateTokens.includes(process.env.BOT_TOKEN.trim())) {
      candidateTokens.push(process.env.BOT_TOKEN.trim());
    }
    if (process.env.TELEGRAM_BOT_TOKEN && !candidateTokens.includes(process.env.TELEGRAM_BOT_TOKEN.trim())) {
      candidateTokens.push(process.env.TELEGRAM_BOT_TOKEN.trim());
    }

    let verifiedPayload: { isValid: boolean; user?: any; authDate?: number } = { isValid: false };

    for (const token of candidateTokens) {
      const v = verifyTelegramWebAppData(initData, token);
      if (v.isValid) {
        verifiedPayload = v;
        break;
      }
    }

    // If bot tokens are configured in system, enforce strict cryptographic HMAC verification
    if (candidateTokens.length > 0 && !verifiedPayload.isValid) {
      console.warn('[SECURITY] TMA HMAC verification failed: Untrusted or forged initData signature rejected.');
      return res.status(401).json({
        ok: false,
        msg: 'Security verification failed: Invalid or forged Telegram HMAC signature. Access denied.'
      });
    }

    // Extract user profile from verified cryptographic payload (or parse if no token configured yet)
    let tgUser: any = verifiedPayload.user;
    if (!tgUser) {
      try {
        const parsed = new URLSearchParams(initData);
        const userStr = parsed.get('user');
        if (userStr) tgUser = JSON.parse(userStr);
      } catch (e) {
        const match = initData.match(/user=({[^&]+})/);
        if (match) {
          try {
            tgUser = JSON.parse(decodeURIComponent(match[1]));
          } catch {}
        }
      }
    }

    if (!tgUser || !tgUser.id) {
      return res.status(400).json({ ok: false, msg: 'No Telegram user profile detected in TMA initData' });
    }

    const tgId = String(tgUser.id);
    const tgUsername = (tgUser.username || '').toLowerCase().trim();
    const tgName = [tgUser.first_name, tgUser.last_name].filter(Boolean).join(' ') || tgUsername || `User_${tgId}`;

    // 1. Check if user already exists with matching telegram_id or matching username
    let matchedUser = usersList.find((u: any) => 
      (u.telegram_id && String(u.telegram_id) === tgId) ||
      (tgUsername && u.username && u.username.toLowerCase() === tgUsername)
    );

    if (matchedUser) {
      if (!matchedUser.telegram_id) {
        matchedUser.telegram_id = tgId;
        saveUsers();
      }
    } else {
      // Auto-provision a starter account for new Telegram user
      const baseUsername = tgUsername || `tg_${tgId}`;
      let finalUsername = baseUsername;
      let counter = 1;
      while (usersList.some((u: any) => u.username === finalUsername)) {
        finalUsername = `${baseUsername}_${counter++}`;
      }

      matchedUser = {
        username: finalUsername,
        password: hashVal(crypto.randomBytes(16).toString('hex')),
        role: 'user',
        active: true,
        telegram_id: tgId,
        telegram_name: tgName,
        max_accounts: 3,
        max_targets: 10,
        registered_phones: [],
        master_config: {
          delay_min: 45,
          delay_max: 90,
          check_interval: 20
        },
        ai_enabled: false,
        dynamic_templates_enabled: true
      };
      usersList.push(matchedUser);
      saveUsers();
      console.log(`[TMA AUTH] Created new user "${finalUsername}" for Telegram ID: ${tgId} (${tgName})`);

      try {
        const adminUser = usersList.find((u: any) => u.role === 'admin');
        if (adminUser?.alert_bot_token && adminUser?.alert_chat_id) {
          const newTmaAlert = `👤 <b>NEW USER ACCOUNT REGISTERED VIA TMA!</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `👤 <b>Username:</b> <code>${finalUsername}</code>\n` +
            `📱 <b>Telegram ID:</b> <code>${tgId}</code> (${tgName || tgUsername || 'Telegram User'})\n` +
            `🤖 <b>Bot Slots:</b> <b>3 Bots</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `🕒 <i>Registered at ${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })} IST</i>`;
          sendTelegramMessage(adminUser.alert_bot_token, adminUser.alert_chat_id, newTmaAlert).catch(() => null);
        }
      } catch {}
    }

    if (!matchedUser.active) {
      return res.status(401).json({ ok: false, msg: 'Account disabled. Contact administrator.' });
    }

    const token = createToken(matchedUser.username, matchedUser.role);
    if (req.session) {
      req.session.username = matchedUser.username;
      req.session.role = matchedUser.role;
    }

    return res.json({
      ok: true,
      role: matchedUser.role,
      username: matchedUser.username,
      token,
      redirect: matchedUser.role === 'admin' ? '/admin' : '/dashboard',
      user: {
        username: matchedUser.username,
        role: matchedUser.role,
        telegram_id: tgId,
        telegram_name: tgName
      }
    });
  } catch (err: any) {
    console.error('[TMA AUTH ERROR]:', err);
    return res.status(500).json({ ok: false, msg: 'Internal error processing TMA authentication' });
  }
});

// ---------------- DASHBOARD APIS ----------------

app.get('/api/accounts', (req, res) => {
  const eff = getEffectiveUser(req);
  const uObj = getUser(eff);

  const data = [];
  let total_sent = 0;
  let total_today_dms = 0;
  const rawQ = getOwnerRawQueue(eff);
  const verifiedQ = getOwnerVerifiedQueue(eff);
  const rawQCount = rawQ.length;
  const verifiedQCount = verifiedQ.length;
  const ownerPeers = getOwnerPeers(eff);

  for (const a of accounts.values()) {
    const owner = a.owner || 'admin';
    if (owner !== eff) {
      continue;
    }
    checkAndResetDailyQuota(a.phone);
    checkAndResetDailyDmQuota(a.phone);
    const dailyDms = (a as any).daily_sent_count || 0;
    const accTotalSent = Math.max(a.sent_count || 0, dailyDms, (a.sent_users ? a.sent_users.size : 0));
    total_sent += accTotalSent;
    total_today_dms += dailyDms;

    const accRawCount = rawQ.filter(uid => {
      const p = ownerPeers.get(String(uid));
      return !p || !p.sourcePhone || p.sourcePhone === a.phone;
    }).length;
    const accVerifiedCount = verifiedQ.filter(uid => {
      const p = ownerPeers.get(String(uid));
      if (!p) return false;
      if (p.username && p.username.trim().length > 0) return true;
      if (p.accessHashes && p.accessHashes[a.phone] && p.accessHashes[a.phone] !== '0') return true;
      if (p.sourcePhone === a.phone && p.accessHash && p.accessHash !== '0') return true;
      return false;
    }).length;

    const hasSessFile = fs.existsSync(getSessionFile(a.phone));
    let healthState = 'healthy';
    let healthLabel = '🟢 Healthy & Validated';
    let skippingRisk = '0%';
    let needsReauth = false;

    if (a.status?.includes('Revoked') || a.status?.includes('Logged Out') || a.status?.includes('AUTH_KEY') || a.status?.includes('401')) {
      healthState = 'critical';
      healthLabel = '🔴 Re-Auth Required (Key Revoked)';
      skippingRisk = '100% (All Users Skipped)';
      needsReauth = true;
    } else if (!hasSessFile && a.status !== 'awaiting_otp' && a.status !== 'awaiting_2fa') {
      healthState = 'critical';
      healthLabel = '🔴 Re-Auth Required (No Session)';
      skippingRisk = '100% (Not Logged In)';
      needsReauth = true;
    } else if (a.dm_rest_until && a.dm_rest_until > Date.now()) {
      healthState = 'warning';
      healthLabel = '🟡 Rest Mode / Cooling';
      skippingRisk = 'Temporarily Paused';
    } else if (verifiedQCount > 0 && accVerifiedCount === 0) {
      healthState = 'warning';
      healthLabel = '🟡 Queue Lacks Hashes';
      skippingRisk = 'High (Queue users lack hash for this phone)';
    } else if (!a.running && hasSessFile) {
      healthState = 'ready';
      healthLabel = '🟢 Session Ready';
      skippingRisk = '0%';
    } else if (a.running) {
      healthState = 'healthy';
      healthLabel = '🟢 Active & Validated';
      skippingRisk = '0%';
    }

    data.push({
      label: a.label,
      phone: a.phone,
      username: a.username || '',
      status: a.status,
      state: statusState(a),
      queue_count: accVerifiedCount,
      shared_queue_count: verifiedQCount,
      raw_queue_count: accRawCount,
      verified_queue_count: accVerifiedCount,
      daily_extracted_count: (a as any).daily_extracted_count || 0,
      daily_extracted_max: 0,
      daily_sent_count: dailyDms,
      live_on: a.live_on,
      dm_on: a.dm_on,
      dm_rest_until: (a as any).dm_rest_until || 0,
      peer_flood_consecutive: (a as any).peer_flood_consecutive || 0,
      sent_count: accTotalSent,
      running: Boolean(a.running),
      engine_mode: (a as any).engine_mode || (uObj?.access_type === 'app_only' ? 'mobile_app' : 'vps_server'),
      is_logged_in: Boolean(hasSessFile && a.status !== 'awaiting_otp' && a.status !== 'awaiting_2fa' && a.state !== 'waiting' && !needsReauth),
      health_indicator: {
        state: healthState,
        label: healthLabel,
        skipping_risk: skippingRisk,
        needs_reauth: needsReauth,
        has_session: hasSessFile
      },
      owner
    });
  }

  const maxAcc = uObj ? (uObj.max_accounts ?? 5) : 5;
  const regPhones = uObj && Array.isArray(uObj.registered_phones) ? uObj.registered_phones : [];

  // If any phone in user's registered_phones failed to setup or is missing from active accounts map,
  // surface it as an unlinked/failed item so the user can easily click Delete to release the slot!
  const presentPhones = new Set(data.map((d: any) => d.phone));
  for (const regP of regPhones) {
    const regDigits = String(regP).replace(/[^0-9]/g, '');
    const alreadyPresent = Array.from(presentPhones).some(p => p === regP || String(p).replace(/[^0-9]/g, '') === regDigits);
    if (!alreadyPresent) {
      data.push({
        label: regP,
        phone: regP,
        username: '',
        status: 'Setup Incomplete / Failed',
        state: 'failed',
        queue_count: 0,
        shared_queue_count: verifiedQCount,
        raw_queue_count: 0,
        verified_queue_count: 0,
        daily_extracted_count: 0,
        daily_extracted_max: 0,
        daily_sent_count: 0,
        live_on: false,
        dm_on: false,
        dm_rest_until: 0,
        peer_flood_consecutive: 0,
        sent_count: 0,
        is_logged_in: false,
        health_indicator: {
          state: 'critical',
          label: '🔴 Failed to Connect / Unlinked',
          skipping_risk: '100% (Not Added)',
          needs_reauth: true,
          has_session: false
        },
        owner: eff
      });
    }
  }

  const histTodayCount = dailyDmHistory[eff]?.[getTodayDateString()]?.count || 0;
  total_today_dms = Math.max(total_today_dms, histTodayCount);

  let userHistoricalTotalDMs = 0;
  const userHistory = dailyDmHistory[eff] || {};
  for (const d of Object.keys(userHistory)) {
    userHistoricalTotalDMs += userHistory[d]?.count || 0;
  }
  const effectiveTotalSent = Math.max(total_sent, total_today_dms, userHistoricalTotalDMs, getOwnerSentUsers(eff).size);

  res.json({
    accounts: data,
    total_sent: effectiveTotalSent,
    total_today_dms,
    last_5_days_dms: getOwnerDailyDmStats(eff, data.length),
    total_lifetime_joins: getOwnerLifetimeJoins(eff),
    today_joins: dailyJoinHistory[eff]?.[getTodayDateString()]?.count || 0,
    last_5_days_joins: getOwnerDailyJoinStats(eff),
    tracked_invite_link: userTrackedLinks[eff]?.invite_link || '',
    effective_user: eff,
    ai_enabled: uObj?.ai_enabled === true,
    dynamic_templates_enabled: uObj?.dynamic_templates_enabled !== false,
    user_dynamic_enabled: uObj?.dynamic_templates_enabled !== false,
    user_ai_enabled: uObj?.ai_enabled === true,
    user_has_any_premium: (uObj?.ai_enabled === true || uObj?.dynamic_templates_enabled !== false),
    raw_queue_total: rawQCount,
    verified_queue_total: verifiedQCount,
    registered_phones: regPhones,
    max_accounts: maxAcc,
    registered_count: regPhones.length
  });
});

app.get('/api/logs', (req         , res          ) => {
  const phone = (req.query.phone          ) || '';
  const a = accounts.get(phone);
  if (a && !canTouch(req, a.owner || 'admin')) {
    return res.json({ logs: [], server_time: '' });
  }
  const l = logsMap.get(phone) || [];
  const server_time = new Intl.DateTimeFormat('en-IN', {
    timeZone: 'Asia/Kolkata',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  }).format(new Date());
  res.json({ logs: l.slice(-100), server_time });
});

app.get('/api/events', (req, res) => {
  const eff = getEffectiveUser(req);
  if (!eff) {
    return res.status(401).send('Unauthorized');
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  if (typeof (res as any).flushHeaders === 'function') {
    (res as any).flushHeaders();
  }

  const clientId = `${eff}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const client: SseClient = {
    id: clientId,
    res,
    owner: eff
  };
  sseClients.set(clientId, client);

  // Send connected event
  try {
    res.write(`event: connected\ndata: ${JSON.stringify({ msg: 'connected', time: Date.now() })}\n\n`);
  } catch {}

  // Send initial account snapshot right after connection
  setTimeout(() => {
    try {
      broadcastAccountUpdate(eff);
    } catch {}
  }, 50);

  const keepAliveTimer = setInterval(() => {
    try {
      res.write(': keep-alive\n\n');
    } catch {
      clearInterval(keepAliveTimer);
      sseClients.delete(clientId);
    }
  }, 20000);

  req.on('close', () => {
    clearInterval(keepAliveTimer);
    sseClients.delete(clientId);
  });
});

app.get('/api/account/config', (req         , res          ) => {
  const phone = req.query.phone          ;
  const a = accounts.get(phone);
  if (!a) return res.json({});
  if (!canTouch(req, a.owner || 'admin')) return res.json({});
  const u = getUser(a.owner || 'admin');
  res.json({
    ...getEffectiveConfig(a),
    user_ai_enabled: u?.ai_enabled === true
  });
});

app.post('/api/account/config', (req         , res          ) => {
  const data = req.body || {};
  const phone = data.phone;
  const a = accounts.get(phone);
  if (!a) return res.json({ msg: 'Account not found!' });
  if (!canTouch(req, a.owner || 'admin')) return res.json({ msg: 'This account is not yours!' });

  const owner = a.owner || 'admin';
  const [, maxTargets] = userLimits(owner);
  const targets = Array.isArray(data.targets) ? data.targets : [];

  if (targets.length > maxTargets) {
    return res.json({
      msg: `LIMIT REACHED! This user is allowed maximum ${maxTargets} target groups (you entered ${targets.length})`
    });
  }

  a.config = {
    use_master_config: data.use_master_config === true,
    ai_context: data.ai_context || '',
    channel_link: data.channel_link || '',
    targets,
    message_1: data.message_1 || '',
    message_2: data.message_2 || '',
    message_3: data.message_3 || '',
    max_users: Math.min(200, Number(data.max_users || 200)),
    check_interval: Number(data.check_interval || 20),
    delay_min: Number(data.delay_min || 60),
    delay_max: Number(data.delay_max || 120)
  };
  saveAccountsJson();
  res.json({ msg: `${a.label} config saved successfully!` });
});

app.get('/api/account/proxy', (req         , res          ) => {
  const phone = req.query.phone          ;
  const a = accounts.get(phone);
  if (!a) return res.json({});
  if (!canTouch(req, a.owner || 'admin')) return res.json({});
  res.json(a.proxy || { protocol: 'none' });
});

app.post('/api/account/proxy', (req         , res          ) => {
  const data = req.body || {};
  const phone = data.phone;
  const a = accounts.get(phone);
  if (!a) return res.json({ msg: 'Account not found!' });
  if (!canTouch(req, a.owner || 'admin')) return res.json({ msg: 'This account is not yours!' });
  if (a.running) return res.json({ msg: 'STOP the account first before updating proxy!' });

  const protocol = data.protocol || 'none';
  if (protocol === 'none') {
    a.proxy = { protocol: 'none', ip: '', port: 0 };
  } else {
    a.proxy = {
      protocol: protocol,
      ip: data.ip || '',
      port: Number(data.port) || 0,
      username: data.username || '',
      password: data.password || '',
      secret: data.secret || ''
    };
  }
  
  saveAccountsJson();
  res.json({ msg: `Proxy settings for ${a.label} saved successfully!` });
});

// Auto-delete 1-on-1 personal chats older than N days (default: 1 day / 24 hours)
app.post('/api/accounts/clean-old-chats', async (req: any, res: any) => {
  const eff = getEffectiveUser(req);
  if (!eff) return res.status(401).json({ error: 'Login first!' });

  const me = getUser(eff);
  const isUserAdmin = eff === 'admin' || Boolean(me && me.role === 'admin');
  const targetPhone = req.body?.phone;
  const days = Math.max(1, Number(req.body?.days) || 1);

  try {
    let totalCleaned = 0;
    for (const [phone, acc] of accounts.entries()) {
      if ((isUserAdmin || acc.owner === eff) && (!targetPhone || targetPhone === 'all' || targetPhone === phone)) {
        if (acc.client && acc.client.connected) {
          const r = await cleanOldPersonalChatsForAccount(phone, days);
          totalCleaned += r.cleaned;
        }
      }
    }
    res.json({
      success: true,
      cleaned: totalCleaned,
      message: `Cleaned ${totalCleaned} personal chat(s) older than ${days} days.`
    });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Chat cleanup failed' });
  }
});

app.post('/api/account/add', (req         , res          ) => {
  const data = req.body || {};
  const phone = (data.phone || '').trim();
  if (!phone.startsWith('+')) {
    return res.json({ msg: 'Enter phone in +91XXXXXXXXXX format!' });
  }
  const eff = getEffectiveUser(req);
  if (!eff) return res.json({ msg: 'Login first!' });

  const u = getUser(eff);
  const isUserAdmin = eff === 'admin' || Boolean(u && u.role === 'admin');
  const [maxAcc] = userLimits(eff);

  if (accounts.has(phone)) {
    return res.json({ msg: 'This account is already added and present in your dashboard!' });
  }

  let owned = 0;
  for (const acc of accounts.values()) {
    if ((acc.owner || 'admin') === eff) owned++;
  }

  // Lifetime Slot Check for regular users
  if (!isUserAdmin && u) {
    if (!Array.isArray(u.registered_phones)) u.registered_phones = [];
    const isAlreadyRegistered = u.registered_phones.includes(phone);

    if (!isAlreadyRegistered) {
      if (u.registered_phones.length >= maxAcc) {
        return res.json({
          ok: false,
          limit_exhausted: true,
          registered_count: u.registered_phones.length,
          max_accounts: maxAcc,
          msg: `SLOT LIMIT EXHAUSTED! You have registered ${u.registered_phones.length}/${maxAcc} lifetime phone slots. Logging out or deleting accounts does not free up slots. Request Admin Approval to add or replace this Telegram ID.`
        });
      }

      if (owned >= maxAcc) {
        return res.json({
          ok: false,
          limit_exhausted: true,
          registered_count: u.registered_phones.length,
          max_accounts: maxAcc,
          msg: `ACCOUNT LIMIT REACHED! You currently have ${owned}/${maxAcc} active accounts. Request Admin Approval to increase your allowed slots.`
        });
      }

      // Register new phone slot
      u.registered_phones.push(phone);
      saveUsers();
      broadcastAccountUpdate(eff);
    } else {
      // Re-connecting an already registered phone
      if (owned >= maxAcc) {
        return res.json({
          ok: false,
          limit_exhausted: true,
          registered_count: u.registered_phones.length,
          max_accounts: maxAcc,
          msg: `ACCOUNT LIMIT REACHED! You currently have ${owned}/${maxAcc} active accounts in your dashboard.`
        });
      }
    }
  }

  // Determine API credentials: Custom provided vs selected Global Pool Slot vs Auto Best Key
  let apiIdNum = parseInt(data.api_id, 10);
  let apiHash = (data.api_hash || '').trim();

  // If user selected a pool slot or didn't supply manual credentials:
  const creds = getBestApiCredentials(apiIdNum, apiHash, data.slot_id || data.pool_id);
  apiIdNum = creds.api_id;
  apiHash = creds.api_hash;

  accounts.set(phone, {
    label: data.label || phone,
    phone,
    api_id: apiIdNum,
    api_hash: apiHash,
    username: data.username || '',
    owner: eff,
    running: false,
    live_on: true,
    dm_on: true,
    sent_users: new Set(),
    sent_count: 0,
    daily_extracted_count: 0,
    daily_collected_count: 0,
    status: 'Ready',
    config: defaultConfig()
  });
  saveAccountsJson();
  broadcastAccountUpdate(eff);
  res.json({ ok: true, msg: `${phone} added! Now open its tab and fill the config.` });
});

// Endpoint for users to inspect and select available API slots from Global Pool
app.get('/api/account/available-apis', (req: any, res: any) => {
  const activeSlots = apiPool.filter(s => s.enabled && s.api_id > 0 && s.api_hash);

  const slotStats = activeSlots.map(slot => {
    let linkedCount = 0;
    for (const acc of accounts.values()) {
      if (acc.api_id === slot.api_id) linkedCount++;
    }
    let statusText = '🟢 100% Free / Unused';
    if (linkedCount === 1) statusText = '🟢 1 account linked (Optimal)';
    else if (linkedCount === 2) statusText = '🟡 2 accounts linked (Good)';
    else if (linkedCount >= 3) statusText = `🟠 ${linkedCount} accounts linked`;

    return {
      id: slot.id,
      slot_id: slot.slot_id,
      label: slot.label,
      api_id: slot.api_id,
      linkedCount,
      statusText
    };
  });

  res.json({
    success: true,
    totalPoolSize: apiPool.length,
    activePoolCount: activeSlots.length,
    apis: slotStats
  });
});

app.post('/api/account/request-slot', async (req: any, res: any) => {
  const eff = getEffectiveUser(req);
  if (!eff) return res.status(401).json({ ok: false, msg: 'Login first!' });

  const data = req.body || {};
  const phone = (data.phone || '').trim();
  const label = (data.label || phone).trim();

  if (!phone.startsWith('+')) {
    return res.json({ ok: false, msg: 'Valid phone number in +91XXXXXXXXXX format is required!' });
  }

  const u = getUser(eff);
  if (!u) return res.status(404).json({ ok: false, msg: 'User account not found!' });

  const [maxAcc] = userLimits(eff);
  const regCount = (u.registered_phones || []).length;

  const existingPending = slotRequests.find((r) => r.username === eff && r.phone === phone && r.status === 'pending');
  if (existingPending) {
    return res.json({
      ok: true,
      already_pending: true,
      msg: `An approval request for ${phone} is already pending with Super Admin. Please wait for approval!`,
      request_id: existingPending.id
    });
  }

  const reqId = 'slot_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
  const newReq: SlotRequest = {
    id: reqId,
    username: eff,
    phone,
    label,
    requested_at: Date.now(),
    status: 'pending'
  };

  slotRequests.unshift(newReq);
  saveSlotRequests();

  const escHtml = (s: string) => String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  // Instant Real-Time Alert to Super Admin Master Bot
  const adminUser = usersList.find((x: any) => x.username === 'admin' || x.role === 'admin');
  if (adminUser && adminUser.alert_enabled && adminUser.alert_bot_token && adminUser.alert_chat_id) {
    const adminMsg = `🚨 <b>Account Slot Approval Request!</b>\n\n` +
      `👤 <b>User:</b> <code>${escHtml(eff)}</code>\n` +
      `📱 <b>Requested Phone:</b> <code>Leo Bot Super Admin</code>\n` +
      `🏷️ <b>Label:</b> ${escHtml(label)}\n` +
      `📊 <b>Quota Used:</b> ${regCount} / ${maxAcc} Registered Slots\n\n` +
      `⚠️ <i>User reached their ID limit and requests permission to add this new Telegram number.</i>`;

    const inlineKeyboard = [
      [
        { text: '✅ Approve Slot (+1 Slot)', callback_data: `slot_appr:${reqId}` },
        { text: '❌ Reject Request', callback_data: `slot_rej:${reqId}` }
      ]
    ];

    sendTelegramMessage(adminUser.alert_bot_token, adminUser.alert_chat_id, adminMsg, inlineKeyboard).catch((err) => {
      console.error('[SLOT REQUEST TELEGRAM ALERT ERROR]:', err);
    });
  }

  broadcastAccountUpdate('admin');

  return res.json({
    ok: true,
    msg: `✅ Approval request for ${phone} sent to Super Admin in real-time! Admin has been alerted on Telegram.`,
    request_id: reqId
  });
});

app.post('/api/account/update-credentials', (req: any, res: any) => {
  const phone = req.body?.phone;
  const a = accounts.get(phone);
  if (!a) return res.json({ msg: 'Account not found!' });
  if (!canTouch(req, a.owner || 'admin')) return res.json({ msg: 'This account is not yours!' });
  if (a.running) return res.json({ msg: 'Please STOP the account before updating API credentials!' });

  const apiIdNum = parseInt(req.body?.api_id, 10);
  const apiHash = (req.body?.api_hash || '').trim();

  if (isNaN(apiIdNum) || apiIdNum <= 0) {
    return res.json({ msg: 'Valid numerical API ID is required!' });
  }
  if (!apiHash) {
    return res.json({ msg: 'API Hash is required!' });
  }

  a.api_id = apiIdNum;
  a.api_hash = apiHash;
  if (req.body?.label) a.label = req.body.label.trim();
  saveAccountsJson();
  res.json({ msg: `API credentials updated for ${a.label || phone}! You can now click START.` });
});

app.post('/api/account/rename', (req: any, res: any) => {
  const phone = (req.body?.phone || '').trim();
  const newLabel = (req.body?.label || '').trim();
  if (!phone || !newLabel) {
    return res.status(400).json({ success: false, msg: 'Phone number and new name are required!' });
  }
  const a = accounts.get(phone);
  if (!a || !canTouch(req, a.owner || 'admin')) {
    return res.status(403).json({ success: false, msg: 'Account not found or access denied!' });
  }
  a.label = newLabel;
  saveAccountsJson();
  broadcastAccountUpdate(a.owner || 'admin');
  return res.json({ success: true, msg: `Account successfully renamed to "${newLabel}"`, label: newLabel });
});

app.post('/api/account/reset-daily-count', (req: any, res: any) => {
  const eff = getEffectiveUser(req);
  const phone = (req.body?.phone || '').trim();
  const resetAll = req.body?.all === true || !phone;
  const todayStr = getTodayDateString();
  let count = 0;

  for (const [p, a] of accounts.entries()) {
    if (!canTouch(req, a.owner || 'admin')) continue;
    if (resetAll || p === phone) {
      (a as any).daily_sent_count = 0;
      (a as any).daily_sent_date = todayStr;
      (a as any).daily_extracted_count = 0;
      (a as any).daily_extracted_date = todayStr;
      (a as any).peer_flood_consecutive = 0;
      (a as any).peer_flood_rest_cycles = 0;
      delete (a as any).dm_rest_until;
      delete (a as any).dm_peer_flood_exhausted;
      count++;
    }
  }

  if (dailyDmHistory[eff] && dailyDmHistory[eff][todayStr]) {
    if (resetAll) {
      dailyDmHistory[eff][todayStr].count = 0;
      dailyDmHistory[eff][todayStr].phones = [];
    } else if (phone && Array.isArray(dailyDmHistory[eff][todayStr].phones)) {
      dailyDmHistory[eff][todayStr].phones = dailyDmHistory[eff][todayStr].phones.filter((ph: string) => ph !== phone);
    }
    saveDailyDmHistory();
  }

  saveAccountsJson();
  broadcastAccountUpdate(eff);
  return res.json({ success: true, msg: `Today's DM count reset to 0 for ${count} account(s)!`, resetCount: count });
});

app.post('/api/admin/reset-daily-dms', (req: any, res: any) => {
  if (req.session?.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  const todayStr = getTodayDateString();
  let count = 0;
  for (const a of accounts.values()) {
    (a as any).daily_sent_count = 0;
    (a as any).daily_sent_date = todayStr;
    (a as any).daily_extracted_count = 0;
    (a as any).daily_extracted_date = todayStr;
    (a as any).peer_flood_consecutive = 0;
    (a as any).peer_flood_rest_cycles = 0;
    delete (a as any).dm_rest_until;
    delete (a as any).dm_peer_flood_exhausted;
    count++;
  }

  for (const u of Object.keys(dailyDmHistory)) {
    if (dailyDmHistory[u] && dailyDmHistory[u][todayStr]) {
      dailyDmHistory[u][todayStr].count = 0;
      dailyDmHistory[u][todayStr].phones = [];
    }
  }
  saveDailyDmHistory();

  saveAccountsJson();
  broadcastAccountUpdate('admin');
  return res.json({ success: true, msg: `Daily DM counts reset to 0 for all ${count} accounts!`, resetCount: count });
});

app.all('/api/account/diagnose', async (req: any, res: any) => {
  const phone = (req.body?.phone || req.query?.phone || '').trim();
  if (!phone) {
    return res.status(400).json({ success: false, msg: 'Phone number is required for diagnostic health check!' });
  }
  const a = accounts.get(phone);
  if (!a || !canTouch(req, a.owner || 'admin')) {
    return res.status(403).json({ success: false, msg: 'Account not found or access denied!' });
  }

  const startTs = Date.now();
  const owner = a.owner || 'admin';
  const ownerPeers = getOwnerPeers(owner);
  const verifiedQ = getOwnerVerifiedQueue(owner);
  const totalVerifiedQ = verifiedQ.length;

  const sessFile = getSessionFile(phone);
  const sessionExists = fs.existsSync(sessFile) && fs.statSync(sessFile).size > 10;

  let authValid = false;
  let authErrorMsg = '';
  let pingLatencyMs = 0;
  let telegramProfile: any = null;

  // 1. Check MTProto session validity
  if (a.client && a.running) {
    try {
      const pingStart = Date.now();
      const mePromise = a.client.getMe();
      const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('PING_TIMEOUT')), 5000));
      const me: any = await Promise.race([mePromise, timeoutPromise]);
      pingLatencyMs = Date.now() - pingStart;
      if (me && me.id) {
        authValid = true;
        telegramProfile = {
          id: String(me.id),
          username: me.username || '',
          firstName: me.firstName || '',
          lastName: me.lastName || ''
        };
      }
    } catch (e: any) {
      const emsg = e?.message || String(e);
      authErrorMsg = emsg;
      if (/AUTH_KEY_UNREGISTERED|SESSION_REVOKED|USER_DEACTIVATED|401/i.test(emsg)) {
        authValid = false;
        a.status = 'Logged Out (Session Revoked)';
        a.running = false;
        broadcastAccountUpdate(a.owner);
      }
    }
  } else if (sessionExists) {
    // Client is stopped/offline: check saved session auth with lightweight verification
    const sessStr = await loadSessionString(phone);
    if (sessStr) {
      const devProf = getDeviceProfileForPhone(phone);
      const testClient = new TelegramClient(new StringSession(sessStr), a.api_id, a.api_hash, {
        connectionRetries: 2,
        timeout: 6,
        useWSS: false,
        deviceModel: devProf.deviceModel,
        systemVersion: devProf.systemVersion
      });
      try {
        const pingStart = Date.now();
        await testClient.connect();
        const isAuth = await testClient.isUserAuthorized().catch(() => false);
        if (isAuth) {
          const me = await testClient.getMe().catch(() => null);
          pingLatencyMs = Date.now() - pingStart;
          authValid = true;
          if (me) {
            telegramProfile = {
              id: String(me.id),
              username: me.username || '',
              firstName: me.firstName || '',
              lastName: me.lastName || ''
            };
          }
        } else {
          authErrorMsg = 'Session not authorized in Telegram datacenter';
        }
      } catch (e: any) {
        authErrorMsg = e?.message || String(e);
      } finally {
        await testClient.disconnect().catch(() => {});
      }
    }
  }

  // 2. MTProto Access Hash & Queue Reachability Analysis
  let reachableCount = 0;
  let viaUsernameCount = 0;
  let viaAccessHashCount = 0;
  let unreachableCount = 0;
  let accessHashSerializationOk = true;

  for (const uid of verifiedQ) {
    const p = ownerPeers.get(String(uid));
    if (!p) {
      unreachableCount++;
      continue;
    }
    const hasUsername = Boolean(p.username && p.username.trim().length > 0);
    const hasAccHash = Boolean(
      (p.accessHashes && p.accessHashes[phone] && p.accessHashes[phone] !== '0') ||
      (p.sourcePhone === phone && p.accessHash && p.accessHash !== '0')
    );

    if (hasUsername) {
      reachableCount++;
      viaUsernameCount++;
    } else if (hasAccHash) {
      reachableCount++;
      viaAccessHashCount++;
      // Test BigInt serialization
      try {
        const testHash = p.accessHashes?.[phone] || p.accessHash;
        BigInt(String(testHash).replace(/[^0-9-]/g, ''));
      } catch {
        accessHashSerializationOk = false;
      }
    } else {
      unreachableCount++;
    }
  }

  // 3. Flood & Restriction State
  const isCooling = Boolean(a.dm_rest_until && a.dm_rest_until > Date.now());
  const coolingSecs = isCooling ? Math.max(1, Math.ceil((a.dm_rest_until - Date.now()) / 1000)) : 0;
  const floodCount = (a as any).peer_flood_consecutive || 0;

  // 4. Overall Health & Skipping Risk Determination
  let healthState: 'healthy' | 'warning' | 'critical' = 'healthy';
  let skippingRisk = '0%';
  let needsReauth = false;
  let healthLabel = '🟢 Healthy & Validated';
  let summary = 'Account MTProto session and access hashes are 100% operational.';
  let recommendation = 'Account is in peak health and ready to deliver direct messages without skipping users.';

  if (!sessionExists || !authValid) {
    healthState = 'critical';
    needsReauth = true;
    skippingRisk = '100% (High Alert: Bot will skip all targets)';
    healthLabel = '🔴 Re-Authentication Required';
    summary = `MTProto session is invalid, expired, or revoked by Telegram (${authErrorMsg || 'No valid session token'}).`;
    recommendation = 'Click "Re-Authenticate" now to enter a fresh OTP code. This prevents the bot from skipping queued leads.';
  } else if (isCooling) {
    healthState = 'warning';
    skippingRisk = 'Paused (Rate Limit Protection)';
    healthLabel = '🟡 Rest Mode / Cooling';
    summary = `Account is resting for ${coolingSecs}s due to Telegram rate protection (${floodCount} consecutive PEER_FLOOD detections).`;
    recommendation = 'Wait for cooling timer to finish or click "Resume Now". Do not reduce DM delay below 40s.';
  } else if (totalVerifiedQ > 0 && reachableCount === 0) {
    healthState = 'warning';
    skippingRisk = `High (${unreachableCount}/${totalVerifiedQ} targets lack access hash for this phone)`;
    healthLabel = '🟡 Access Hash Missing for Queue';
    summary = `All ${totalVerifiedQ} verified users in queue were extracted without universal @usernames by another account. Telegram MTProto restricts messaging them from this phone.`;
    recommendation = 'Start the account that extracted these users, or scan a channel using this account to capture session-bound access hashes.';
  } else if (!accessHashSerializationOk) {
    healthState = 'warning';
    skippingRisk = 'Elevated (Malformed Hash Detected)';
    healthLabel = '🟡 Access Hash Serialization Issue';
    summary = 'One or more access hashes in the peer store contain malformed characters.';
    recommendation = 'Run channel scanner to refresh access hashes.';
  }

  const durationMs = Date.now() - startTs;

  res.json({
    success: true,
    phone,
    label: a.label || phone,
    timestamp: new Date().toISOString(),
    duration_ms: durationMs,
    latency_ms: pingLatencyMs,
    health: {
      state: healthState,
      label: healthLabel,
      skipping_risk: skippingRisk,
      needs_reauth: needsReauth,
      summary,
      recommendation
    },
    checks: {
      session_exists: sessionExists,
      auth_valid: authValid,
      telegram_connected: a.running && Boolean(a.client),
      access_hash_ok: accessHashSerializationOk,
      cooling_mode: isCooling,
      cooling_seconds: coolingSecs,
      peer_flood_count: floodCount
    },
    queue_reachability: {
      total_queue: totalVerifiedQ,
      reachable: reachableCount,
      via_username: viaUsernameCount,
      via_access_hash: viaAccessHashCount,
      unreachable: unreachableCount,
      reachability_percentage: totalVerifiedQ > 0 ? Math.round((reachableCount / totalVerifiedQ) * 100) : 100
    },
    profile: telegramProfile
  });
});

app.post('/api/account/reauth', async (req: any, res: any) => {
  const phone = (req.body?.phone || '').trim();
  const a = accounts.get(phone);
  if (!a) return res.status(404).json({ success: false, msg: 'Account not found!' });
  if (!canTouch(req, a.owner || 'admin')) return res.status(403).json({ success: false, msg: 'Access denied!' });

  log(phone, 'INFO', `🔄 Re-authentication triggered for ${phone}. Resetting stale session and requesting fresh OTP...`);

  // Stop client if running
  if (a.running && a.abortController) {
    try { a.abortController.abort(); } catch {}
  }
  if (a.client) {
    try { await a.client.disconnect(); } catch {}
    a.client = null;
  }
  a.running = false;

  // Clear dead session file so GramJS requests a new phone code from Telegram
  const sessFile = getSessionFile(phone);
  if (fs.existsSync(sessFile)) {
    try { fs.unlinkSync(sessFile); } catch {}
  }

  a.status = 'Starting... sending OTP';
  broadcastAccountUpdate(a.owner);

  // Trigger background login run
  a.running = true;
  const abortController = new AbortController();
  a.abortController = abortController;
  runTelegramBot(phone, abortController.signal).catch((err) => {
    log(phone, 'FAIL', `Re-auth bot run failed: ${err?.message || err}`);
  });

  return res.json({
    success: true,
    phone,
    msg: `Re-authentication initiated for ${a.label || phone}! Fresh Telegram OTP code has been dispatched.`
  });
});

async function permanentlyDeleteAccount(phone: string): Promise<{
  success: boolean;
  owner: string;
  sentTransferred: number;
  queueTransferred: number;
  peersTransferred: number;
}> {
  const normPhone = (phone || '').trim();
  const cleanPId = normPhone.replace(/[^0-9+]/g, '');
  const numOnly = normPhone.replace(/[^0-9]/g, '');

  let a = accounts.get(normPhone);
  if (!a && cleanPId) a = accounts.get(cleanPId);
  let foundKey = '';
  if (a) {
    foundKey = normPhone;
  } else {
    for (const [k, v] of accounts.entries()) {
      const kDigits = k.replace(/[^0-9]/g, '');
      const vDigits = (v?.phone || '').replace(/[^0-9]/g, '');
      if (
        k === normPhone ||
        k === cleanPId ||
        (numOnly && (kDigits === numOnly || vDigits === numOnly))
      ) {
        a = v;
        foundKey = k;
        break;
      }
    }
  }

  const owner = a?.owner || 'admin';
  console.log(`[PERMANENT DELETE] Deleting Telegram ID "${normPhone}" (owner: ${owner}) from VPS backend...`);

  // 1. Immediately abort running loops & disconnect Telegram client
  if (a) {
    a.running = false;
    a.status = 'Deleted';
    if (a.abortController) {
      try { a.abortController.abort(); } catch {}
    }
    if (a.client) {
      try {
        await Promise.race([
          a.client.disconnect(),
          new Promise((r) => setTimeout(r, 2000))
        ]);
      } catch {}
      a.client = null;
    }
  }

  // 2. Reject and clean any pending OTP / 2FA login promises
  const pending = pendingAuthMap.get(normPhone) || (numOnly ? pendingAuthMap.get(numOnly) : null);
  if (pending) {
    try {
      if (pending.otpReject) pending.otpReject(new Error('Account deleted by administrator'));
      if (pending.twoFaReject) pending.twoFaReject(new Error('Account deleted by administrator'));
    } catch {}
    pendingAuthMap.delete(normPhone);
    if (numOnly) pendingAuthMap.delete(numOnly);
  }

  // 3. Remove all session files from VPS disk
  const possibleSessionFiles = [
    getSessionFile(normPhone),
    path.join(__dirname, `session_${cleanPId}.txt`),
    path.join(__dirname, `session_${numOnly}.txt`),
    path.join(__dirname, `session_+${numOnly}.txt`)
  ];
  for (const f of possibleSessionFiles) {
    try {
      if (fs.existsSync(f)) {
        fs.unlinkSync(f);
        console.log(`[PERMANENT DELETE] Unlinked session file: ${f}`);
      }
    } catch (e) {}
  }

  // Scan directory for any orphaned session file matching this phone number
  try {
    const allFiles = fs.readdirSync(__dirname);
    for (const f of allFiles) {
      if (f.startsWith('session_') && f.endsWith('.txt') && numOnly && f.includes(numOnly)) {
        try {
          fs.unlinkSync(path.join(__dirname, f));
          console.log(`[PERMANENT DELETE] Removed matching session file: ${f}`);
        } catch {}
      }
    }
  } catch {}

  // 3.5. TRANSFER TO ADMIN BEFORE DELETION (Total DM Sent Data + Genuine Queue + Important Peer Entities Files)
  let sentTransferred = 0;
  let queueTransferred = 0;
  let peersTransferred = 0;

  try {
    console.log(`[TRANSFER TO ADMIN] Collecting all DM sent data, genuine queue, and important peer files for ${normPhone} before deletion...`);

    // A. Collect all DM Sent contacts from memory and disk for this ID
    const gatheredSentUids = new Set<number>();
    if (a?.sent_users) {
      for (const id of a.sent_users) gatheredSentUids.add(id);
    }
    const memSent = sentUsersCache.get(normPhone) || (cleanPId ? sentUsersCache.get(cleanPId) : null) || (numOnly ? sentUsersCache.get(numOnly) : null);
    if (memSent) {
      for (const id of memSent) gatheredSentUids.add(id);
    }
    const possibleSentFiles = [
      path.join(__dirname, `sent_${cleanPId}.json`),
      path.join(__dirname, `sent_${numOnly}.json`)
    ];
    for (const sf of possibleSentFiles) {
      try {
        if (fs.existsSync(sf)) {
          const arr = JSON.parse(fs.readFileSync(sf, 'utf8'));
          if (Array.isArray(arr)) arr.forEach((id: number) => gatheredSentUids.add(id));
        }
      } catch {}
    }

    // B. Collect all Genuine Queue contacts from memory and disk for this ID
    const gatheredQueueUids = new Set<number>();
    if (a?.queue && Array.isArray(a.queue)) {
      for (const id of a.queue) gatheredQueueUids.add(id);
    }
    const memQueue = queueCache.get(normPhone) || (cleanPId ? queueCache.get(cleanPId) : null) || (numOnly ? queueCache.get(numOnly) : null);
    if (memQueue && Array.isArray(memQueue)) {
      for (const id of memQueue) gatheredQueueUids.add(id);
    }
    const possibleQueueFiles = [
      path.join(__dirname, `queue_${cleanPId}.json`),
      path.join(__dirname, `queue_${numOnly}.json`)
    ];
    for (const qf of possibleQueueFiles) {
      try {
        if (fs.existsSync(qf)) {
          const arr = JSON.parse(fs.readFileSync(qf, 'utf8'));
          if (Array.isArray(arr)) arr.forEach((id: number) => gatheredQueueUids.add(id));
        }
      } catch {}
    }

    // C. Collect all Peer metadata ("important file") from memory and disk for this ID
    const gatheredPeers = new Map<string, PeerInfo>();
    if (a?.peers && a.peers instanceof Map) {
      for (const [k, v] of a.peers.entries()) gatheredPeers.set(k, v);
    }
    const memPeers = peersCache.get(normPhone) || (cleanPId ? peersCache.get(cleanPId) : null) || (numOnly ? peersCache.get(numOnly) : null);
    if (memPeers && memPeers instanceof Map) {
      for (const [k, v] of memPeers.entries()) gatheredPeers.set(k, v);
    }
    const possiblePeerFiles = [
      path.join(__dirname, `peers_${cleanPId}.json`),
      path.join(__dirname, `peers_${numOnly}.json`)
    ];
    for (const pf of possiblePeerFiles) {
      try {
        if (fs.existsSync(pf)) {
          const arr = JSON.parse(fs.readFileSync(pf, 'utf8'));
          if (Array.isArray(arr)) {
            for (const item of arr) {
              if (Array.isArray(item) && item.length === 2) {
                gatheredPeers.set(String(item[0]), item[1]);
              }
            }
          }
        }
      } catch {}
    }

    // Also look up missing peer info for all gathered IDs from findPeerInfoAnywhere
    const allGatheredIds = new Set<number>([...gatheredSentUids, ...gatheredQueueUids]);
    for (const id of allGatheredIds) {
      const idStr = String(id);
      if (!gatheredPeers.has(idStr)) {
        const found = findPeerInfoAnywhere(idStr, owner);
        if (found) gatheredPeers.set(idStr, found);
      }
    }

    // D. TRANSFER TO ADMIN:
    // 1. Transfer Sent Contacts to Admin
    const adminSent = getOwnerSentUsers('admin');
    for (const uid of gatheredSentUids) {
      if (!adminSent.has(uid)) {
        adminSent.add(uid);
        sentTransferred++;
      }
    }
    ownerSentCache.set('admin', adminSent);
    try {
      fs.writeFileSync(path.join(__dirname, `sent_owner_admin.json`), JSON.stringify(Array.from(adminSent)), 'utf8');
    } catch {}

    // 2. Transfer Peer Metadata ("Important File") to Admin
    const adminPeers = getOwnerPeers('admin');
    for (const [uidStr, pInfo] of gatheredPeers.entries()) {
      if (pInfo && (pInfo.accessHash || pInfo.username || pInfo.phone)) {
        adminPeers.set(uidStr, {
          userId: uidStr,
          accessHash: pInfo.accessHash,
          username: pInfo.username,
          firstName: pInfo.firstName,
          lastName: pInfo.lastName,
          phone: pInfo.phone,
          sourcePhone: pInfo.sourcePhone || normPhone
        });
        peersTransferred++;
      }
    }
    saveOwnerPeers('admin', adminPeers);

    // 3. Transfer Genuine Queue Contacts to Admin Genuine Queue
    const adminVerifiedQ = getOwnerVerifiedQueue('admin');
    const adminVerifiedSet = new Set(adminVerifiedQ);
    const toAddToVerified: number[] = [];
    for (const uid of gatheredQueueUids) {
      if (!adminSent.has(uid) && !adminVerifiedSet.has(uid)) {
        toAddToVerified.push(uid);
        adminVerifiedSet.add(uid);
        queueTransferred++;
      }
    }
    if (toAddToVerified.length > 0) {
      addToOwnerVerifiedQueue('admin', toAddToVerified);
    }

    // 4. Inject InputPeerUser into all active GramJS clients of Admin
    for (const acc of accounts.values()) {
      if ((acc.owner || 'admin') === 'admin' && acc.client) {
        try {
          for (const uid of allGatheredIds) {
            const uidStr = String(uid);
            const p = adminPeers.get(uidStr);
            if (p?.accessHash && p.accessHash !== '0') {
              const inputPeer = new Api.InputPeerUser({
                userId: BigInt(uidStr) as any,
                accessHash: BigInt(p.accessHash) as any
              });
              if ((acc.client as any)._entityCache?.cacheMap) {
                (acc.client as any)._entityCache.cacheMap.set(uidStr, inputPeer);
              }
            }
          }
        } catch {}
      }
    }

    console.log(`[TRANSFER TO ADMIN COMPLETED] Transferred ${sentTransferred} Sent, ${queueTransferred} Queue, and ${peersTransferred} Peer entities from ID "${normPhone}" to Admin successfully.`);
  } catch (err: any) {
    console.error(`[TRANSFER TO ADMIN ERROR] Failed to transfer data to admin:`, err);
  }

  // 4. Remove all data cache files (sent, peers, queue) for this phone from VPS disk
  const possibleDataFiles = [
    path.join(__dirname, `sent_${cleanPId}.json`),
    path.join(__dirname, `sent_${numOnly}.json`),
    path.join(__dirname, `peers_${cleanPId}.json`),
    path.join(__dirname, `peers_${numOnly}.json`),
    path.join(__dirname, `queue_${cleanPId}.json`),
    path.join(__dirname, `queue_${numOnly}.json`)
  ];
  for (const f of possibleDataFiles) {
    try {
      if (fs.existsSync(f)) {
        fs.unlinkSync(f);
        console.log(`[PERMANENT DELETE] Unlinked data cache file: ${f}`);
      }
    } catch (e) {}
  }

  try {
    const allFiles = fs.readdirSync(__dirname);
    for (const f of allFiles) {
      if ((f.startsWith('sent_') || f.startsWith('peers_') || f.startsWith('queue_')) && numOnly && f.includes(numOnly)) {
        try {
          fs.unlinkSync(path.join(__dirname, f));
          console.log(`[PERMANENT DELETE] Removed matching phone cache file: ${f}`);
        } catch {}
      }
    }
  } catch {}

  // 5. Remove account from memory Maps
  accounts.delete(normPhone);
  if (cleanPId) accounts.delete(cleanPId);
  if (foundKey) accounts.delete(foundKey);
  if (a?.phone) accounts.delete(a.phone);
  for (const [k, v] of Array.from(accounts.entries())) {
    const kNum = k.replace(/[^0-9]/g, '');
    const vNum = (v?.phone || '').replace(/[^0-9]/g, '');
    if (
      k === normPhone ||
      k === cleanPId ||
      k === foundKey ||
      v === a ||
      (a && a.phone && (k === a.phone || v?.phone === a.phone)) ||
      (numOnly && (kNum === numOnly || vNum === numOnly))
    ) {
      accounts.delete(k);
    }
  }
  sentUsersCache.delete(normPhone);
  sentUsersCache.delete(cleanPId);
  sentUsersCache.delete(numOnly);
  peersCache.delete(normPhone);
  peersCache.delete(cleanPId);
  peersCache.delete(numOnly);
  queueCache.delete(normPhone);
  logsMap.delete(normPhone);
  logsMap.delete(cleanPId);
  logsMap.delete(numOnly);
  activeGroupCalls.delete(normPhone);
  generatorWorkerStates.delete(normPhone);

  // 6. Free up registered phone slot from user profile in users.json so re-login works smoothly
  for (const u of usersList) {
    if (Array.isArray(u.registered_phones)) {
      const origCount = u.registered_phones.length;
      u.registered_phones = u.registered_phones.filter((p: string) => {
        const pNum = String(p).replace(/[^0-9]/g, '');
        const matches = (
          p === normPhone ||
          p === cleanPId ||
          p === phone ||
          (foundKey && p === foundKey) ||
          (a && a.phone && p === a.phone) ||
          (numOnly && pNum && pNum === numOnly)
        );
        return !matches;
      });
      if (u.registered_phones.length !== origCount) {
        saveUsers();
        console.log(`[PERMANENT DELETE] Freed registered slot in user "${u.username}". New count: ${u.registered_phones.length}`);
      }
    }
  }

  // 7. Clean up pending or resolved slot requests for this phone
  if (Array.isArray(slotRequests)) {
    const beforeCount = slotRequests.length;
    slotRequests = slotRequests.filter((r) => {
      const rNum = String(r.phone).replace(/[^0-9]/g, '');
      const matches = (
        r.phone === normPhone ||
        r.phone === cleanPId ||
        r.phone === phone ||
        (foundKey && r.phone === foundKey) ||
        (a && a.phone && r.phone === a.phone) ||
        (numOnly && rNum && rNum === numOnly)
      );
      return !matches;
    });
    if (slotRequests.length !== beforeCount) {
      saveSlotRequests();
    }
  }

  // 8. Persist updated accounts.json immediately to disk
  saveAccountsJson();

  return {
    success: true,
    owner,
    sentTransferred,
    queueTransferred,
    peersTransferred
  };
}

app.post('/api/account/remove', async (req: any, res: any) => {
  const phone = (req.body?.phone || '').trim();
  if (!phone) return res.status(400).json({ ok: false, msg: 'Phone number is required!' });
  const cleanPId = phone.replace(/[^0-9+]/g, '');
  const numOnly = phone.replace(/[^0-9]/g, '');

  let a = accounts.get(phone) || (cleanPId ? accounts.get(cleanPId) : null);
  if (!a && numOnly) {
    for (const [k, v] of accounts.entries()) {
      const kDigits = k.replace(/[^0-9]/g, '');
      const vDigits = (v?.phone || '').replace(/[^0-9]/g, '');
      if (kDigits === numOnly || vDigits === numOnly) {
        a = v;
        break;
      }
    }
  }

  if (!a) {
    // Check if phone was in registered_phones of the user, free it up
    const effUser = getEffectiveUser(req);
    const u = getUser(effUser);
    if (u && Array.isArray(u.registered_phones)) {
      const prevLen = u.registered_phones.length;
      u.registered_phones = u.registered_phones.filter((p: string) => {
        const pNum = String(p).replace(/[^0-9]/g, '');
        return p !== phone && p !== cleanPId && (numOnly && pNum ? pNum !== numOnly : true);
      });
      if (u.registered_phones.length !== prevLen) {
        saveUsers();
        broadcastAccountUpdate(u.username);
        return res.json({ ok: true, success: true, msg: `Account ${phone} removed!` });
      }
    }
    return res.json({ ok: false, msg: 'Account not found or already deleted!' });
  }

  if (!canTouch(req, a.owner || 'admin')) return res.status(403).json({ ok: false, msg: 'This account is not yours!' });

  const effUser = getEffectiveUser(req);
  const u = getUser(effUser);
  const isUserAdmin = isAdminSession(req) || effUser === 'admin' || Boolean(u && u.role === 'admin');

  // Check if account has successfully logged in & has an active MTProto session
  const hasSess = fs.existsSync(getSessionFile(phone)) || fs.existsSync(getSessionFile(a.phone));
  const isSuccessfullyLoggedIn = Boolean(
    hasSess &&
    a.state !== 'waiting' &&
    a.status !== 'awaiting_otp' &&
    a.status !== 'awaiting_2fa' &&
    a.status !== 'unverified' &&
    a.status !== 'auth_failed' &&
    a.status !== 'login_failed' &&
    !(a as any).needs_reauth
  );

  // STRICT RULE: If the account is logged in / bot started / active session, regular users cannot delete it! Only Admin can!
  if (!isUserAdmin && isSuccessfullyLoggedIn) {
    return res.status(403).json({
      ok: false,
      is_active_account: true,
      msg: 'Active & Logged-in Telegram accounts can only be deleted by Admin! Please contact Admin to remove this account.'
    });
  }

  const delRes = await permanentlyDeleteAccount(phone);
  broadcastAccountUpdate(delRes.owner || 'admin');
  if (delRes.owner !== 'admin') {
    broadcastAccountUpdate('admin');
  }

  const details: string[] = [];
  if (delRes.sentTransferred > 0) details.push(`${delRes.sentTransferred} DM Sent`);
  if (delRes.queueTransferred > 0) details.push(`${delRes.queueTransferred} Genuine Queue`);
  if (delRes.peersTransferred > 0) details.push(`${delRes.peersTransferred} Peer Entity Files`);
  const transferInfo = details.length > 0 ? ` (Transferred to Admin: ${details.join(', ')})` : '';

  res.json({
    ok: true,
    success: true,
    msg: `Account ${phone} deleted permanently from VPS!${transferInfo}`
  });
});

app.post('/api/admin/account/delete', async (req: any, res: any) => {
  if (!isAdminSession(req)) {
    return res.status(403).json({ msg: 'Admin access required!' });
  }
  const phone = (req.body?.phone || '').trim();
  if (!phone) return res.status(400).json({ msg: 'Phone number is required!' });

  const delRes = await permanentlyDeleteAccount(phone);
  broadcastAccountUpdate(delRes.owner || 'admin');
  broadcastAccountUpdate('admin');

  const details: string[] = [];
  if (delRes.sentTransferred > 0) details.push(`${delRes.sentTransferred} DM Sent`);
  if (delRes.queueTransferred > 0) details.push(`${delRes.queueTransferred} Genuine Queue`);
  if (delRes.peersTransferred > 0) details.push(`${delRes.peersTransferred} Peer Entity Files`);
  const transferInfo = details.length > 0 ? ` (Transferred to Admin: ${details.join(', ')})` : '';

  res.json({
    ok: true,
    success: true,
    msg: `Telegram ID ${phone} deleted permanently from VPS!${transferInfo}`
  });
});

app.post('/api/account/check-spambot', async (req: any, res: any) => {
  const phone = (req.body?.phone || '').trim();
  const a = accounts.get(phone);
  if (!a) return res.json({ msg: 'Account not found!' });
  if (!canTouch(req, a.owner || 'admin')) return res.json({ msg: 'This account does not belong to you!' });
  if (!a.client) return res.json({ msg: 'Account client is not active! Please START the bot first to connect to Telegram.' });

  log(phone, 'INFO', 'Manual 5-cycle @SpamBot verification requested from dashboard...');
  const isCleared = await checkAndResolveSpamBot(a.client, phone, false);
  if (isCleared) {
    if (a.running) {
      a.dm_on = true;
      broadcastAccountUpdate(a.owner);
    }
    res.json({ success: true, msg: '🎉 @SpamBot: No limits found! Account is completely clean and DM is active.' });
  } else {
    if (a.running) {
      a.dm_on = false;
      log(phone, 'WARN', '⚠️ @SpamBot: Limitation confirmed. DM turned OFF — Live Stream Monitoring remains ACTIVE!');
      broadcastAccountUpdate(a.owner);
    }
    res.json({ success: false, msg: '⚠️ @SpamBot: Limitation is still active after 5 checks. DM has been turned OFF while Live Monitoring remains active.' });
  }
});

app.post('/api/account/start', (req         , res          ) => {
  const phone = req.body?.phone;
  const a = accounts.get(phone);
  if (!a) return res.json({ msg: 'Account not found!' });
  if (!canTouch(req, a.owner || 'admin')) return res.json({ msg: 'This account does not belong to you!' });
  if (a.running) return res.json({ msg: 'This account is already running!' });

  // Payment Overdue / Advance Check:
  const botOwner = a.owner || 'admin';
  if (botOwner !== 'admin') {
    const ownerUser = getUser(botOwner);
    if (ownerUser && (ownerUser as any).payment_paused) {
      return res.json({
        msg: '⚠️ Your account bots are currently paused due to payment pending. Please clear your balance or contact admin.'
      });
    }
    const summary = getUserLedgerSummary(botOwner);
    // If user has negative balance (Advance), they are 100% fine!
    // But if they have balance_due > 0 and plan expiry is passed OR overdue limit breached:
    const todayStr = getTodayDateString();
    if (summary.balance_due > 0 && ownerUser?.expiry_date && todayStr > ownerUser.expiry_date) {
      return res.json({
        msg: `⚠️ Subscription expired and ₹${summary.balance_due} payment pending. Please contact admin to renew.`
      });
    }
  }

  const effCfg = getEffectiveConfig(a);
  const hasCustomDm = Boolean(
    effCfg.message_1?.trim() || effCfg.message_2?.trim() || effCfg.message_3?.trim() || effCfg.message?.trim()
  );
  if (!hasCustomDm) {
    log(phone, 'INFO', 'ℹ️ [DYNAMIC DM MODE] 3 DM boxes empty: Bot starting with Dynamic DM (Hinglish Engine active).');
  }

  const ownerUser = getUser(a.owner || 'admin');
  const isAppOnly = ownerUser?.access_type === 'app_only';
  const userAgent = (req.headers['user-agent'] || '').toString();

  // ONLY tether to mobile if strictly 'app_only' user AND explicit mobile engine request
  // Webapp users and users with 'both' permission ALWAYS run 24/7 on VPS server!
  const isMobileClient = isAppOnly && (
    req.body?.engine === 'mobile' || 
    req.headers['x-engine-mode'] === 'mobile' || 
    userAgent.includes('LeoTeleBotNative')
  );

  a.running = true;
  accountLastDmTimestamp.delete(phone);
  (a as any).peer_flood_consecutive = 0;
  if (a.live_on === undefined) a.live_on = true;
  if (a.dm_on === undefined) a.dm_on = true;

  if (isMobileClient) {
    (a as any).engine_mode = 'mobile_app';
    accountLastHeartbeat.set(phone, Date.now());
    log(phone, 'INFO', `📱 [MOBILE CLIENT ENGINE] Bot tethered to Mobile Phone (${phone}). Live data heartbeat active.`);
  } else {
    (a as any).engine_mode = 'vps_server';
    accountLastHeartbeat.delete(phone);
  }

  const sessFile = getSessionFile(phone);
  const sessionExists = fs.existsSync(sessFile) && fs.readFileSync(sessFile, 'utf8').trim().length > 0;

  a.status = sessionExists ? 'Starting...' : 'Starting... sending OTP';
  broadcastAccountUpdate(a.owner);

  const abortController = new AbortController();
  a.abortController = abortController;

  // Run async background bot on VPS with auto-recovery against network interruptions
  launchBotWorker(phone, abortController);

  res.json({
    engine: (a as any).engine_mode || 'vps_server',
    msg: sessionExists ? `🚀 ${phone} bot started!` : `${phone} started! OTP code is being dispatched to Telegram - please enter it in the dashboard.`
  });
});

// 📱 Mobile App Heartbeat: Keeps the bot alive as long as phone has active mobile data / Wi-Fi
app.post('/api/mobile/heartbeat', (req, res) => {
  const { phones, phone } = req.body || {};
  const now = Date.now();
  const list = Array.isArray(phones) ? phones : (phone ? [phone] : []);
  for (const p of list) {
    if (p && accounts.has(p)) {
      accountLastHeartbeat.set(p, now);
      const acc = accounts.get(p);
      if (acc) {
        (acc as any).last_phone_ping = now;
        const oUser = getUser(acc.owner || 'admin');
        if (oUser?.access_type === 'app_only') {
          (acc as any).engine_mode = 'mobile_app';
        }
        if (!acc.running && acc.status?.includes('Offline')) {
          acc.status = 'Ready';
          broadcastAccountUpdate(acc.owner);
        }
      }
    }
  }
  res.json({ ok: true, now });
});

// 📱 Mobile App Offline Notice (Safe: Does NOT stop VPS running bots)
app.post('/api/mobile/offline', (req, res) => {
  res.json({ ok: true });
});

// Endpoint for Mobile App to report live stats, logs and status to Admin without using VPS engine
app.post('/api/account/client-report', (req, res) => {
  const { phone, status, sent_delta, log_type, log_message } = req.body || {};
  const a = accounts.get(phone);
  if (!a) return res.status(404).json({ ok: false, msg: 'Account not found' });
  if (!canTouch(req, a.owner || 'admin')) return res.status(403).json({ ok: false, msg: 'Access denied' });

  if (status) a.status = status;
  (a as any).engine_mode = 'mobile_app';
  if (sent_delta && typeof sent_delta === 'number') {
    a.sent_count = (a.sent_count || 0) + sent_delta;
    (a as any).daily_sent_count = ((a as any).daily_sent_count || 0) + sent_delta;
  }
  if (log_message) {
    log(phone, log_type || 'OK', `📱 [Mobile Device]: ${log_message}`);
  }
  broadcastAccountUpdate(a.owner);
  res.json({ ok: true, msg: 'Client telemetry received' });
});

app.post('/api/account/stop', (req         , res          ) => {
  const phone = req.body?.phone;
  const a = accounts.get(phone);
  if (!a) return res.json({ msg: 'Account not found!' });
  if (!canTouch(req, a.owner || 'admin')) return res.json({ msg: 'This account is not yours!' });

  a.running = false;
  (a as any).persisted_running = false;
  saveAccountsLocal();
  accountLastDmTimestamp.delete(phone);
  accountLastHeartbeat.delete(phone);
  if (a.abortController) {
    a.abortController.abort();
  }
  a.status = 'Stopped';
  broadcastAccountUpdate(a.owner);

  // Unblock any waiting OTP/2FA
  const pending = pendingAuthMap.get(phone);
  if (pending) {
    if (pending.otpReject) pending.otpReject(new Error('Stopped by user'));
    if (pending.twoFaReject) pending.twoFaReject(new Error('Stopped by user'));
    pendingAuthMap.delete(phone);
  }

  res.json({ msg: `${phone} stop signal sent` });
});

app.post('/api/account/verify-otp', async (req, res) => {
  const phone = (req.body?.phone || '').trim();
  const rawCode = String(req.body?.code || '');
  const code = rawCode.replace(/[^0-9]/g, '').trim();
  const a = accounts.get(phone);
  if (a && !canTouch(req, a.owner || 'admin')) return res.json({ success: false, msg: 'This account is not yours!' });

  if (a && (a.status === 'online' || a.status === 'Monitoring...' || (a.running && a.status !== 'awaiting_otp'))) {
    return res.json({ success: true, status: 'online', msg: '✅ Account is already verified and active!' });
  }

  const p = pendingAuthMap.get(phone);
  if (!p || p.waiting !== 'otp') {
    return res.json({ success: false, msg: 'No OTP is awaiting verification for this account! Click "START BOT" to request a fresh OTP.' });
  }
  if (!code || code.length < 3) {
    return res.json({ success: false, msg: 'Please enter a valid numeric OTP code (usually 5 digits)!' });
  }

  log(phone, 'INFO', `Submitting OTP code (${code.length} digits) to Telegram...`);

  // Hook up outcome resolver promise
  let outcomeResolve: (val: any) => void;
  const outcomePromise = new Promise<{ success: boolean; status?: string; msg?: string }>((resolve) => {
    outcomeResolve = resolve;
  });
  p.notifyResult = outcomeResolve!;

  if (p.otpResolve) {
    p.otpResolve(code);
    log(phone, 'INFO', `OTP code received from dashboard. Verifying with Telegram servers...`);
  }

  // Await verification outcome up to 25 seconds
  const result = await Promise.race([
    outcomePromise,
    new Promise<{ success: boolean; status?: string; msg?: string }>((_, reject) =>
      setTimeout(() => reject(new Error('VERIFY_TIMEOUT')), 25000)
    )
  ]).catch((err) => {
    if (err?.message === 'VERIFY_TIMEOUT') {
      const currentStatus = a?.status || 'verifying';
      if (currentStatus === 'online' || currentStatus === 'Monitoring...' || a?.running) {
        return { success: true, status: 'online', msg: '✅ OTP verified successfully! Account is now online.' };
      }
      return { success: true, status: 'online', msg: '✅ OTP submitted! Account is now connecting/online.' };
    }
    return { success: true, status: 'online', msg: '✅ OTP verified successfully! Account is active.' };
  });

  return res.json(result);
});

app.post('/api/account/verify-2fa', async (req, res) => {
  const phone = (req.body?.phone || '').trim();
  const password = String(req.body?.password || '').trim();
  const a = accounts.get(phone);
  if (a && !canTouch(req, a.owner || 'admin')) return res.json({ success: false, msg: 'This account is not yours!' });

  if (a && (a.status === 'online' || a.status === 'Monitoring...' || (a.running && a.status !== 'awaiting_2fa'))) {
    return res.json({ success: true, status: 'online', msg: '✅ Account is already verified and active!' });
  }

  const p = pendingAuthMap.get(phone);
  if (!p || p.waiting !== 'twofa') {
    return res.json({ success: false, msg: 'This account does not need 2FA right now!' });
  }
  if (!password) {
    return res.json({ success: false, msg: '2FA password is empty!' });
  }

  log(phone, 'INFO', 'Submitting 2FA Cloud Password to Telegram...');

  let outcomeResolve: (val: any) => void;
  const outcomePromise = new Promise<{ success: boolean; status?: string; msg?: string }>((resolve) => {
    outcomeResolve = resolve;
  });
  p.notifyResult = outcomeResolve!;

  if (p.twoFaResolve) {
    p.twoFaResolve(password);
  }

  const result = await Promise.race([
    outcomePromise,
    new Promise<{ success: boolean; status?: string; msg?: string }>((_, reject) =>
      setTimeout(() => reject(new Error('VERIFY_TIMEOUT')), 12000)
    )
  ]).catch((err) => {
    if (err?.message === 'VERIFY_TIMEOUT') {
      const currentStatus = a?.status || 'verifying';
      if (currentStatus === 'online' || currentStatus === 'Monitoring...') {
        return { success: true, status: 'online', msg: '✅ 2FA Password verified! Bot is now online.' };
      }
      return { success: false, status: currentStatus, msg: 'Telegram is still verifying 2FA password... Please wait a moment.' };
    }
    return { success: false, status: 'failed', msg: err?.message || 'Verification error' };
  });

  return res.json(result);
});

app.post('/api/stop-all', (req         , res          ) => {
  const eff = getEffectiveUser(req);
  for (const a of accounts.values()) {
    if (canTouch(req, a.owner || 'admin') && a.running) {
      a.running = false;
      (a as any).persisted_running = false;
      if (a.abortController) a.abortController.abort();
      a.status = 'Stopping...';
    }
  }
  saveAccountsLocal();
  broadcastAccountUpdate(eff);
  res.json({ msg: 'Stop signal sent to all your accounts' });
});

app.post('/api/account/toggle-live', (req         , res          ) => {
  const phone = req.body?.phone;
  const a = accounts.get(phone);
  if (!a) return res.json({ msg: 'Account not found!' });
  if (!canTouch(req, a.owner || 'admin')) return res.json({ msg: 'This account is not yours!' });

  a.live_on = !a.live_on;
  const msg = a.live_on
    ? 'Live monitoring ON - live stream detection and queueing active'
    : 'Live monitoring OFF - live stream detection and queueing stopped';
  log(phone, 'INFO', msg);
  broadcastAccountUpdate(a.owner);
  res.json({ msg, live_on: a.live_on });
});

app.post('/api/account/toggle-dm', (req         , res          ) => {
  const phone = req.body?.phone;
  const a = accounts.get(phone);
  if (!a) return res.json({ msg: 'Account not found!' });
  if (!canTouch(req, a.owner || 'admin')) return res.json({ msg: 'This account is not yours!' });

  a.dm_on = !a.dm_on;
  if (a.dm_on) {
    delete (a as any).dm_rest_until;
    (a as any).peer_flood_consecutive = 0;
  }
  const msg = a.dm_on
    ? 'DM ON - automatic direct messaging active'
    : 'DM OFF - direct messaging paused (queue continues collecting users)';
  log(phone, 'INFO', msg);
  saveAccountsJson();
  broadcastAccountUpdate(a.owner);
  res.json({ msg, dm_on: a.dm_on });
});

// ---------------- USER BULK ACTIONS (All Start, All Stop, All DM, All Live) ----------------
app.post('/api/user/bulk-action', async (req: any, res: any) => {
  const eff = getEffectiveUser(req);
  const action = String(req.body?.action || '').trim().toLowerCase();
  if (!action) return res.status(400).json({ msg: 'Action is required' });

  const userAccs = Array.from(accounts.values()).filter(a => (a.owner || 'admin') === eff);
  if (userAccs.length === 0) {
    return res.json({ success: true, count: 0, msg: 'No accounts registered under your profile.' });
  }

  let count = 0;
  if (action === 'start-all') {
    const toStart = userAccs.filter(a => !a.running);
    if (toStart.length === 0) {
      return res.json({ success: true, count: 0, msg: 'All accounts are already running.' });
    }

    // Instantly mark all as queued in memory and notify UI
    toStart.forEach((a, idx) => {
      a.running = true;
      (a as any).engine_mode = 'vps_server';
      accountLastHeartbeat.delete(a.phone);
      if (a.live_on === undefined) a.live_on = true;
      if (a.dm_on === undefined) a.dm_on = true;
      delete (a as any).dm_rest_until;
      (a as any).peer_flood_consecutive = 0;
      a.status = idx === 0 ? 'Starting...' : `Queued (${idx * 2}s delay)...`;
      const abortController = new AbortController();
      a.abortController = abortController;
    });
    broadcastAccountUpdate(eff);

    // Staggered background runner: 2-second gap between each bot launch!
    (async () => {
      for (let i = 0; i < toStart.length; i++) {
        const a = toStart[i];
        if (i > 0) {
          log(a.phone, 'INFO', `⏳ [STAGGERED BOOT] Waiting 2s before starting bot #${i + 1}/${toStart.length} (${a.phone})...`);
          await new Promise((r) => setTimeout(r, 2000));
        }
        if (a.running && a.abortController && !a.abortController.signal.aborted) {
          const effCfg = getEffectiveConfig(a);
          const hasCustomDm = Boolean(
            effCfg.message_1?.trim() || effCfg.message_2?.trim() || effCfg.message_3?.trim() || effCfg.message?.trim()
          );
          if (!hasCustomDm) {
            log(a.phone, 'INFO', 'ℹ️ [DYNAMIC DM MODE] 3 DM boxes empty: Auto-Dynamic DM active.');
          }
          a.status = 'Starting... sending OTP';
          log(a.phone, 'INFO', `🚀 [STAGGERED BOOT] Launching bot worker #${i + 1}/${toStart.length} (${a.phone})...`);
          launchBotWorker(a.phone, a.abortController);
          broadcastAccountUpdate(eff);
        }
      }
    })().catch((err) => {
      console.error('[USER STAGGERED START ERROR]:', err);
    });

    return res.json({
      success: true,
      count: toStart.length,
      msg: `🚀 Staggered start dispatched for ${toStart.length} account(s) with 2-second gap between each!`
    });
  } else if (action === 'stop-all') {
    for (const a of userAccs) {
      if (a.running) {
        a.running = false;
        (a as any).persisted_running = false;
        if (a.abortController) a.abortController.abort();
        a.status = 'Stopping...';
        const pending = pendingAuthMap.get(a.phone);
        if (pending) {
          if (pending.otpReject) pending.otpReject(new Error('Stopped by user bulk action'));
          if (pending.twoFaReject) pending.twoFaReject(new Error('Stopped by user bulk action'));
          pendingAuthMap.delete(a.phone);
        }
        count++;
      }
    }
    saveAccountsLocal();
    broadcastAccountUpdate(eff);
    return res.json({ success: true, count, msg: `⏹️ Stop signal dispatched to ${count} running account(s)!` });
  } else if (action === 'dm-on') {
    for (const a of userAccs) {
      a.dm_on = true;
      delete (a as any).dm_rest_until;
      (a as any).peer_flood_consecutive = 0;
      log(a.phone, 'INFO', 'DM turned ON via Bulk Controls');
      count++;
    }
    saveAccountsJson();
    broadcastAccountUpdate(eff);
    return res.json({ success: true, count, msg: `✉️ Direct Messaging enabled for all ${count} account(s)!` });
  } else if (action === 'dm-off') {
    for (const a of userAccs) {
      a.dm_on = false;
      log(a.phone, 'INFO', 'DM turned OFF via Bulk Controls');
      count++;
    }
    saveAccountsJson();
    broadcastAccountUpdate(eff);
    return res.json({ success: true, count, msg: `✉️ Direct Messaging paused for all ${count} account(s)!` });
  } else if (action === 'live-on') {
    for (const a of userAccs) {
      a.live_on = true;
      log(a.phone, 'INFO', 'Live Stream Monitoring turned ON via Bulk Controls');
      count++;
    }
    saveAccountsJson();
    broadcastAccountUpdate(eff);
    return res.json({ success: true, count, msg: `🎙️ Live Stream Monitoring enabled for all ${count} account(s)!` });
  } else if (action === 'live-off') {
    for (const a of userAccs) {
      a.live_on = false;
      log(a.phone, 'INFO', 'Live Stream Monitoring turned OFF via Bulk Controls');
      count++;
    }
    saveAccountsJson();
    broadcastAccountUpdate(eff);
    return res.json({ success: true, count, msg: `🎙️ Live Stream Monitoring paused for all ${count} account(s)!` });
  }

  return res.status(400).json({ msg: `Unsupported action: ${action}` });
});

// ---------------- ADMIN GLOBAL BULK ACTIONS ----------------
app.post('/api/admin/global-bulk-action', async (req: any, res: any) => {
  if (!isAdminSession(req)) {
    return res.status(403).json({ msg: 'Access denied: Admin credentials required.' });
  }
  const action = String(req.body?.action || '').trim().toLowerCase();
  const targetUsers: string[] = Array.isArray(req.body?.target_users)
    ? req.body.target_users.map((u: any) => String(u).trim()).filter(Boolean)
    : [];
  const targetUser = String(req.body?.target_user || 'all').trim();
  if (!action) return res.status(400).json({ msg: 'Action is required' });

  let targetAccs: any[] = [];
  if (targetUsers.length > 0) {
    const userSet = new Set(targetUsers);
    targetAccs = Array.from(accounts.values()).filter(a => userSet.has(a.owner || 'admin'));
  } else if (targetUser && targetUser !== 'all') {
    targetAccs = Array.from(accounts.values()).filter(a => (a.owner || 'admin') === targetUser);
  } else {
    targetAccs = Array.from(accounts.values());
  }

  if (targetAccs.length === 0) {
    return res.json({ success: true, count: 0, msg: 'No accounts matched the selected users.' });
  }

  let count = 0;
  if (action === 'stop-all') {
    for (const a of targetAccs) {
      if (a.running) {
        a.running = false;
        (a as any).persisted_running = false;
        if (a.abortController) a.abortController.abort();
        a.status = 'Stopping...';
        const pending = pendingAuthMap.get(a.phone);
        if (pending) {
          if (pending.otpReject) pending.otpReject(new Error('Global stop by admin'));
          if (pending.twoFaReject) pending.twoFaReject(new Error('Global stop by admin'));
          pendingAuthMap.delete(a.phone);
        }
        count++;
      }
    }
    saveAccountsLocal();
  } else if (action === 'start-all') {
    const toStart = targetAccs.filter(a => !a.running);
    if (toStart.length === 0) {
      return res.json({ success: true, count: 0, msg: 'All selected fleet accounts are already running.' });
    }

    toStart.forEach((a, idx) => {
      a.running = true;
      (a as any).engine_mode = 'vps_server';
      accountLastHeartbeat.delete(a.phone);
      if (a.live_on === undefined) a.live_on = true;
      if (a.dm_on === undefined) a.dm_on = true;
      delete (a as any).dm_rest_until;
      (a as any).peer_flood_consecutive = 0;
      a.status = idx === 0 ? 'Starting...' : `Queued (${idx * 2}s delay)...`;
      const abortController = new AbortController();
      a.abortController = abortController;
    });

    const affectedOwners = new Set(toStart.map(a => a.owner || 'admin'));
    affectedOwners.add('admin');
    for (const o of affectedOwners) {
      broadcastAccountUpdate(o);
    }

    (async () => {
      for (let i = 0; i < toStart.length; i++) {
        const a = toStart[i];
        if (i > 0) {
          log(a.phone, 'INFO', `⏳ [STAGGERED BOOT] Waiting 2s before starting fleet bot #${i + 1}/${toStart.length} (${a.phone})...`);
          await new Promise((r) => setTimeout(r, 2000));
        }
        if (a.running && a.abortController && !a.abortController.signal.aborted) {
          a.status = 'Starting... sending OTP';
          log(a.phone, 'INFO', `🚀 [STAGGERED BOOT] Launching admin fleet bot #${i + 1}/${toStart.length} (${a.phone})...`);
          launchBotWorker(a.phone, a.abortController);
          broadcastAccountUpdate(a.owner || 'admin');
        }
      }
    })().catch((err) => {
      console.error('[ADMIN STAGGERED START ERROR]:', err);
    });

    return res.json({
      success: true,
      count: toStart.length,
      msg: `🚀 Fleet start dispatched for ${toStart.length} account(s) with 2-second gap between each!`
    });
  } else if (action === 'dm-on') {
    for (const a of targetAccs) {
      a.dm_on = true;
      delete (a as any).dm_rest_until;
      (a as any).peer_flood_consecutive = 0;
      count++;
    }
    saveAccountsJson();
  } else if (action === 'dm-off') {
    for (const a of targetAccs) {
      a.dm_on = false;
      count++;
    }
    saveAccountsJson();
  } else if (action === 'live-on') {
    for (const a of targetAccs) {
      a.live_on = true;
      count++;
    }
    saveAccountsJson();
  } else if (action === 'live-off') {
    for (const a of targetAccs) {
      a.live_on = false;
      count++;
    }
    saveAccountsJson();
  } else {
    return res.status(400).json({ msg: `Unsupported global action: ${action}` });
  }

  // Broadcast updates to all affected owners
  const affectedOwners = new Set(targetAccs.map(a => a.owner || 'admin'));
  affectedOwners.add('admin');
  for (const o of affectedOwners) {
    broadcastAccountUpdate(o);
  }

  const targetLabel = targetUsers.length > 0
    ? `${targetUsers.length} selected user(s)`
    : (targetUser === 'all' ? 'All Users' : `user ${targetUser}`);

  return res.json({
    success: true,
    count,
    msg: `Command "${action.toUpperCase()}" applied to ${count} account(s) across ${targetLabel}!`
  });
});

// ---------------- FORGOT PASSWORD ----------------
app.get('/api/forgot/question', (req         , res          ) => {
  const uname = String(req.query.username || '').trim();
  const u = getUser(uname);
  if (!u) return res.status(404).json({ msg: 'This username does not exist!' });
  if (!u.security_question) {
    return res.status(404).json({ msg: 'No security question set for this user! Ask admin to reset your password.' });
  }
  res.json({ question: u.security_question });
});

app.post('/api/forgot/reset', (req         , res          ) => {
  const { username, answer, new_password } = req.body || {};
  const uname = (username || '').trim();
  const ans = (answer || '').trim().toLowerCase();
  const nextPwd = (new_password || '').trim();

  const u = getUser(uname);
  if (!u) return res.status(404).json({ msg: 'This username does not exist!' });
  if (!u.security_answer) {
    return res.status(404).json({ msg: 'No security question set for this user! Ask admin to reset.' });
  }
  if (!verifyVal(u.security_answer, ans)) {
    return res.status(401).json({ msg: 'Wrong answer! Try again.' });
  }
  if (nextPwd.length < 6) {
    return res.json({ msg: 'New password must be at least 6 characters!' });
  }

  u.password = hashVal(nextPwd);
  saveUsers();
  res.json({ msg: 'Password reset successful! Now login with your new password.' });
});

// ---------------- BULK BOT GENERATOR & VAULT ENGINE ----------------
interface VaultBotRecord {
  id: string;
  name: string;
  bot_name?: string;
  username: string;
  bot_username?: string;
  token: string;
  owner?: string;
  creator_phone: string;
  creator_label: string;
  creator_owner: string;
  created_at: string;
  created_at_formatted: string;
  status: 'active' | 'revoked' | 'unverified';
  bot_id?: string;
  notes?: string;
}

interface GeneratorWorkerState {
  phone: string;
  label: string;
  owner: string;
  status: 'idle' | 'running' | 'connecting' | 'creating' | 'floodwait' | 'completed' | 'stopped' | 'error';
  currentStep: string;
  botsTarget: number;
  botsCreated: number;
  errorMsg?: string;
  floodWaitSeconds?: number;
  floodWaitUntil?: number;
  logs: string[];
}

const BOTS_VAULT_FILE = path.join(__dirname, 'bots_vault.json');
let botsVault: VaultBotRecord[] = [];
const generatorWorkerStates = new Map<string, GeneratorWorkerState>();
const generatorAbortControllers = new Map<string, AbortController>();

function formatISTDateTime(date: Date = new Date()): string {
  try {
    return new Intl.DateTimeFormat('en-IN', {
      timeZone: 'Asia/Kolkata',
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    }).format(date);
  } catch {
    return date.toLocaleString();
  }
}

function loadBotsVaultLocal(): void {
  try {
    if (fs.existsSync(BOTS_VAULT_FILE)) {
      const raw = fs.readFileSync(BOTS_VAULT_FILE, 'utf8');
      const data = JSON.parse(raw);
      if (Array.isArray(data)) {
        botsVault = data.map((b: any) => {
          const rawUsername = (b.bot_username || b.username || '').replace(/^@/, '');
          const rawName = b.bot_name || b.name || (rawUsername ? `@${rawUsername}` : (b.bot_id ? `Bot #${b.bot_id}` : 'Bot'));
          return {
            ...b,
            name: rawName,
            bot_name: rawName,
            username: rawUsername,
            bot_username: rawUsername
          };
        });
        console.log(`[BOT VAULT] Loaded ${botsVault.length} generated bot(s) from bots_vault.json`);
      }
    }
  } catch (e) {
    console.error('Error loading bots_vault.json:', e);
    botsVault = [];
  }
}

function saveBotsVaultLocal(): void {
  try {
    fs.writeFileSync(BOTS_VAULT_FILE, JSON.stringify(botsVault, null, 2), 'utf8');
  } catch (e) {
    console.error('Error saving bots_vault.json:', e);
  }
}

function saveBotsVault(): void {
  saveBotsVaultLocal();
  (async () => {
    try {

    } catch {}
  })();
}

function getAccountBotsCount(phone: string): number {
  return botsVault.filter(b => b.creator_phone === phone).length;
}

// BotFather automated creation flow with robust username retry and limit checking
async function executeBotFatherNewBot(
  client: any,
  botName: string,
  usernamePrefix: string,
  phone: string,
  logWorker: (msg: string) => void
): Promise<{ token: string; username: string; name: string; botId: string }> {
  logWorker(`Connecting to @BotFather...`);
  const botFather = await client.getInputEntity('@BotFather').catch(() => '@BotFather');

  // Step 1: Cancel any interrupted conversation
  await client.sendMessage(botFather, { message: '/cancel' }).catch(() => null);
  await new Promise(r => setTimeout(r, 1500));

  // Step 2: Send /newbot command
  logWorker(`Issuing /newbot command to @BotFather...`);
  await client.sendMessage(botFather, { message: '/newbot' });
  await new Promise(r => setTimeout(r, 2500));

  let msgs: any = await client.getMessages(botFather, { limit: 3 }).catch(() => []);
  let latest = msgs?.[0]?.message || '';

  if (latest.toLowerCase().includes('limit') || latest.toLowerCase().includes('reached the limit')) {
    throw new Error('Telegram Bot Creation Quota Exceeded (Account has reached the maximum 20-bot limit on @BotFather)');
  }

  // Step 3: Send Bot Display Name
  logWorker(`Providing Bot Name: "${botName}"...`);
  await client.sendMessage(botFather, { message: botName });
  await new Promise(r => setTimeout(r, 2500));

  msgs = await client.getMessages(botFather, { limit: 3 }).catch(() => []);
  latest = msgs?.[0]?.message || '';

  // Step 4: Generate unique username ending in 'bot'
  let cleanPrefix = (usernamePrefix || 'leobot').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
  if (!cleanPrefix || cleanPrefix.length < 3) cleanPrefix = 'leobot';
  if (cleanPrefix.endsWith('bot')) cleanPrefix = cleanPrefix.slice(0, -3);

  let successToken = '';
  let finalUsername = '';
  let attempts = 0;
  const maxAttempts = 8;

  while (attempts < maxAttempts) {
    attempts++;
    const randPart = Math.random().toString(36).substring(2, 6);
    const randNum = Math.floor(100 + Math.random() * 899);
    const candidate = `${cleanPrefix}_${randPart}${randNum}_bot`;

    logWorker(`Submitting username attempt ${attempts}/${maxAttempts}: @${candidate}...`);
    await client.sendMessage(botFather, { message: candidate });
    await new Promise(r => setTimeout(r, 3200));

    msgs = await client.getMessages(botFather, { limit: 3 }).catch(() => []);
    latest = msgs?.[0]?.message || '';
    const low = latest.toLowerCase();

    // Check token regex
    const tokenMatch = latest.match(/\b(\d{8,11}:[A-Za-z0-9_-]{35})\b/);
    if (tokenMatch) {
      successToken = tokenMatch[1];
      finalUsername = candidate;
      const linkMatch = latest.match(/t\.me\/([A-Za-z0-9_]+)/i);
      if (linkMatch && linkMatch[1]) {
        finalUsername = linkMatch[1];
      }
      logWorker(`🎉 Token acquired successfully for @${finalUsername}!`);
      break;
    }

    if (low.includes('sorry, this username is already taken') || low.includes('already taken') || low.includes('occupied')) {
      logWorker(`⚠️ @${candidate} is already taken. Retrying with new suffix...`);
      await new Promise(r => setTimeout(r, 1200));
      continue;
    }

    if (low.includes('short') || low.includes('invalid') || low.includes('must end in')) {
      logWorker(`⚠️ Formatting warning from @BotFather. Adjusting suffix...`);
      await new Promise(r => setTimeout(r, 1200));
      continue;
    }

    // Check second message just in case
    const msg2 = msgs?.[1]?.message || '';
    const tokenMatch2 = msg2.match(/\b(\d{8,11}:[A-Za-z0-9_-]{35})\b/);
    if (tokenMatch2) {
      successToken = tokenMatch2[1];
      finalUsername = candidate;
      break;
    }

    logWorker(`@BotFather: ${latest.slice(0, 60)}`);
  }

  if (!successToken) {
    throw new Error(`Failed to acquire token from @BotFather after ${attempts} attempts. Last response: ${latest.slice(0, 100)}`);
  }

  const botId = successToken.split(':')[0];
  let verifiedUsername = finalUsername;
  let verifiedName = botName;

  // Authoritatively query Telegram Bot API to get real Bot Name and Username
  try {
    const meRes = await fetch(`https://api.telegram.org/bot${successToken}/getMe`, { signal: AbortSignal.timeout(5000) });
    if (meRes.ok) {
      const meData: any = await meRes.json();
      if (meData?.ok && meData?.result) {
        if (meData.result.username) verifiedUsername = meData.result.username;
        if (meData.result.first_name) verifiedName = meData.result.first_name;
        logWorker(`✅ Verified live Telegram bot: "${verifiedName}" (@${verifiedUsername})`);
      }
    }
  } catch {}

  return { token: successToken, username: verifiedUsername, name: verifiedName, botId };
}

// Independent background worker for a single Telegram account
async function runBotGeneratorWorker(
  phone: string,
  targetCount: number,
  namePrefix: string,
  usernamePrefix: string,
  delaySec: number,
  abortSignal: AbortSignal
): Promise<void> {
  const a = accounts.get(phone);
  const label = a?.label || phone;
  const owner = a?.owner || 'admin';

  let worker = generatorWorkerStates.get(phone);
  if (!worker) {
    worker = {
      phone,
      label,
      owner,
      status: 'connecting',
      currentStep: 'Initializing worker...',
      botsTarget: targetCount,
      botsCreated: 0,
      logs: []
    };
    generatorWorkerStates.set(phone, worker);
  } else {
    worker.status = 'connecting';
    worker.currentStep = 'Initializing worker...';
    worker.botsTarget = targetCount;
    worker.botsCreated = 0;
    worker.errorMsg = undefined;
    worker.logs.push(`[${formatISTDateTime()}] Restarting worker for ${label} (${phone})`);
  }

  const logWorker = (msg: string) => {
    const ts = formatISTDateTime();
    const line = `[${ts}] ${msg}`;
    if (worker) {
      worker.logs.push(line);
      if (worker.logs.length > 200) worker.logs.shift();
    }
    console.log(`[BOT-GEN: ${label} (${phone})] ${msg}`);
  };

  let client: any = null;
  let isTempClient = false;

  try {
    logWorker(`Checking Telegram client connection for ${label} (${phone})...`);
    if (a?.client && a.running && a.client.connected) {
      client = a.client;
      logWorker(`Using existing active client session for ${label} (${phone})`);
    } else {
      const sess = await loadSessionString(phone);
      if (!sess) {
        throw new Error(`No saved Telegram session found for ${label} (${phone}). Please log in or start the account once first.`);
      }
      logWorker(`Connecting dedicated MTProto worker client for ${label} (${phone})...`);
      const deviceProf = getDeviceProfileForPhone(phone);
      client = new TelegramClient(new StringSession(sess), a!.api_id, a!.api_hash, {
        connectionRetries: 5,
        useWSS: false,
        timeout: 25,
        deviceModel: deviceProf.deviceModel,
        systemVersion: deviceProf.systemVersion,
        appVersion: 'Telegram Android 12.10.1',
        langCode: 'en',
        systemLangCode: 'en-US'
      });
      try {
        (client as any).setLogLevel('none');
      } catch {}
      client.onError = async (err: any) => {
        const msg = err?.message || String(err || '');
        if (/timeout|ETIMEDOUT|ESOCKETTIMEDOUT|ECONNRESET/i.test(msg)) return;
        logWorker(`Telegram client warning: ${msg.slice(0, 80)}`);
      };
      await client.connect();
      isTempClient = true;
      logWorker(`Connected successfully to Telegram.`);
    }

    const currentCount = getAccountBotsCount(phone);
    if (currentCount >= 20) {
      throw new Error(`Account already reached Telegram lifetime 20-bot limit (${currentCount}/20).`);
    }

    const maxAllowed = Math.min(targetCount, 20 - currentCount);
    worker.botsTarget = maxAllowed;

    for (let i = 0; i < maxAllowed; i++) {
      if (abortSignal.aborted) {
        worker.status = 'stopped';
        worker.currentStep = 'Stopped by user';
        logWorker(`Worker stopped by administrator request.`);
        break;
      }

      worker.status = 'creating';
      worker.currentStep = `Creating bot ${i + 1} of ${maxAllowed}...`;
      const botDisplayName = `${namePrefix || 'LeoBot'} ${label} #${currentCount + i + 1}`;
      logWorker(`▶ Starting creation cycle ${i + 1}/${maxAllowed} ("${botDisplayName}")...`);

      let createdBot: any = null;
      try {
        createdBot = await executeBotFatherNewBot(client, botDisplayName, usernamePrefix || 'leobot', phone, logWorker);
      } catch (genErr: any) {
        const errMsg = String(genErr?.message || genErr);
        const isFloodWait = errMsg.includes('FLOOD_WAIT') || errMsg.includes('FloodWaitError') || genErr?.seconds;

        if (isFloodWait) {
          const waitSeconds = genErr?.seconds || 45;
          worker.status = 'floodwait';
          worker.floodWaitSeconds = waitSeconds;
          worker.floodWaitUntil = Date.now() + waitSeconds * 1000;
          worker.currentStep = `FloodWait: cooling down ${waitSeconds}s...`;
          logWorker(`⏳ FloodWait encountered: pausing worker for ${waitSeconds}s. Other accounts will continue running in parallel...`);
          
          let waited = 0;
          while (waited < waitSeconds && !abortSignal.aborted) {
            await new Promise(r => setTimeout(r, 1000));
            waited++;
          }
          if (abortSignal.aborted) break;

          // Retry this index after cooldown
          logWorker(`Resuming after FloodWait cooldown...`);
          i--;
          continue;
        } else if (errMsg.includes('Quota Exceeded') || errMsg.includes('20-bot limit')) {
          logWorker(`🔒 ${label} (${phone}) has reached the 20-bot limit on @BotFather.`);
          worker.errorMsg = '20-bot Telegram limit reached';
          break;
        } else {
          logWorker(`❌ Error on bot ${i + 1}: ${errMsg}`);
          worker.errorMsg = errMsg;
          if (errMsg.includes('AUTH_KEY_UNREGISTERED') || errMsg.includes('SESSION_REVOKED')) {
            throw genErr;
          }
          await new Promise(r => setTimeout(r, 3000));
          continue;
        }
      }

      if (createdBot && createdBot.token) {
        const cleanUname = (createdBot.username || '').replace(/^@/, '');
        const newRecord: VaultBotRecord = {
          id: `bot_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          name: createdBot.name,
          bot_name: createdBot.name,
          username: cleanUname,
          bot_username: cleanUname,
          token: createdBot.token,
          creator_phone: phone,
          creator_label: label,
          creator_owner: owner,
          created_at: new Date().toISOString(),
          created_at_formatted: formatISTDateTime(),
          status: 'active',
          bot_id: createdBot.botId
        };

        botsVault.unshift(newRecord);
        saveBotsVault();
        worker.botsCreated++;
        logWorker(`✅ [VAULT STORED] Bot @${cleanUname} saved to bots_vault.json! Total in vault for ${label} (${phone}): ${getAccountBotsCount(phone)}/20`);
      }

      // Rest between bot creations per worker
      if (i < maxAllowed - 1 && !abortSignal.aborted) {
        const jitter = Math.floor(Math.random() * 3);
        const restSec = Math.max(4, delaySec + jitter);
        worker.currentStep = `Waiting ${restSec}s before next bot...`;
        logWorker(`Resting ${restSec}s before creating next bot...`);
        for (let s = 0; s < restSec && !abortSignal.aborted; s++) {
          await new Promise(r => setTimeout(r, 1000));
        }
      }
    }

    if (!abortSignal.aborted && worker.status !== 'stopped') {
      worker.status = 'completed';
      worker.currentStep = `Completed! Generated ${worker.botsCreated} bot(s).`;
      logWorker(`🏁 Worker finished. Total generated in this batch: ${worker.botsCreated}.`);
    }
  } catch (err: any) {
    const errMsg = String(err?.message || err);
    logWorker(`❌ Worker stopped with error: ${errMsg}`);
    worker.status = 'error';
    worker.errorMsg = errMsg;
    worker.currentStep = `Error: ${errMsg.slice(0, 50)}`;
  } finally {
    if (isTempClient && client) {
      try {
        await client.disconnect();
      } catch {}
    }
    generatorAbortControllers.delete(phone);
  }
}

// ---------------- ADMIN PANEL APIS ----------------

// Bulk Bot Generator & Vault Endpoints
app.get('/api/admin/bot-generator/accounts', (req, res) => {
  const result: any[] = [];
  for (const a of accounts.values()) {
    const p = a.phone;
    const cnt = getAccountBotsCount(p);
    result.push({
      phone: p,
      label: a.label || p,
      displayName: `${a.label || 'Account'} (${p})`,
      owner: a.owner || 'admin',
      running: a.running,
      status: a.status,
      bots_count: cnt,
      vault_bots_count: cnt,
      max_bots: 20,
      remaining_quota: Math.max(0, 20 - cnt)
    });
  }
  res.json({ success: true, accounts: result, total_vault_bots: botsVault.length });
});

app.get('/api/admin/bot-generator/status', (req, res) => {
  const workers = Array.from(generatorWorkerStates.values()).map(w => ({
    ...w,
    created_count: w.botsCreated,
    target_count: w.botsTarget,
    current_step: w.currentStep
  }));
  const isGenerating = workers.some(w => w.status === 'running' || w.status === 'connecting' || w.status === 'creating' || w.status === 'floodwait');
  const totalTarget = workers.reduce((sum, w) => sum + (w.target_count || 0), 0);
  const totalCreated = workers.reduce((sum, w) => sum + (w.created_count || 0), 0);
  const overallPct = totalTarget > 0 ? Math.min(100, Math.round((totalCreated / totalTarget) * 100)) : 0;

  const recentBots = botsVault.slice(0, 20).map(b => {
    const rawUsername = (b.bot_username || b.username || '').replace(/^@/, '');
    const rawName = b.bot_name || b.name || (rawUsername ? `@${rawUsername}` : (b.bot_id ? `Bot #${b.bot_id}` : 'Bot'));
    return {
      ...b,
      name: rawName,
      bot_name: rawName,
      username: rawUsername,
      bot_username: rawUsername
    };
  });

  res.json({
    success: true,
    isGenerating,
    workers,
    total_target: totalTarget,
    total_created: totalCreated,
    overall_pct: overallPct,
    total_vault_bots: botsVault.length,
    recent_bots: recentBots
  });
});

app.post('/api/admin/bot-generator/start', async (req, res) => {
  const b = req.body || {};
  const phones = b.phones;
  if (!Array.isArray(phones) || phones.length === 0) {
    return res.status(400).json({ msg: 'Please select at least 1 Telegram account!' });
  }

  const namePrefix = (b.name_prefix || b.namePrefix || 'LeoBot').trim();
  const usernamePrefix = (b.username_prefix || b.usernamePrefix || 'leobot').trim();
  const targetCount = parseInt(b.bots_per_account || b.botsPerAccount, 10) || 1;
  const delaySec = parseInt(b.delay_between_bots_sec || b.delaySeconds, 10) || 6;
  const started: string[] = [];

  for (const phone of phones) {
    const a = accounts.get(phone);
    if (!a) continue;

    const existing = generatorWorkerStates.get(phone);
    if (existing && (existing.status === 'running' || existing.status === 'creating' || existing.status === 'connecting')) {
      continue;
    }

    const abortController = new AbortController();
    generatorAbortControllers.set(phone, abortController);

    runBotGeneratorWorker(
      phone,
      targetCount,
      (namePrefix || 'LeoBot').trim(),
      (usernamePrefix || 'leobot').trim(),
      delaySec,
      abortController.signal
    );

    started.push(`${a.label || phone} (${phone})`);
  }

  res.json({
    success: true,
    msg: `Started parallel bot generation for ${started.length} account(s)!`,
    accounts: started
  });
});

app.post('/api/admin/bot-generator/stop', (req, res) => {
  const { phone } = req.body || {};
  if (phone) {
    const ctrl = generatorAbortControllers.get(phone);
    if (ctrl) ctrl.abort();
    const w = generatorWorkerStates.get(phone);
    if (w) {
      w.status = 'stopped';
      w.currentStep = 'Stopped by administrator';
    }
    return res.json({ success: true, msg: `Worker for ${phone} stopped.` });
  } else {
    for (const [p, ctrl] of generatorAbortControllers.entries()) {
      ctrl.abort();
      const w = generatorWorkerStates.get(p);
      if (w) {
        w.status = 'stopped';
        w.currentStep = 'Stopped by administrator';
      }
    }
    generatorAbortControllers.clear();
    return res.json({ success: true, msg: 'All generator workers stopped.' });
  }
});

app.get('/api/admin/bots-vault', (req, res) => {
  const normalizedBots = botsVault.map(b => {
    const rawUsername = (b.bot_username || b.username || '').replace(/^@/, '');
    const rawName = b.bot_name || b.name || (rawUsername ? `@${rawUsername}` : (b.bot_id ? `Bot #${b.bot_id}` : 'Bot'));
    return {
      ...b,
      name: rawName,
      bot_name: rawName,
      username: rawUsername,
      bot_username: rawUsername
    };
  });
  res.json({
    success: true,
    total: normalizedBots.length,
    bots: normalizedBots
  });
});

app.post('/api/admin/bots-vault/delete', (req, res) => {
  const { id } = req.body || {};
  if (!id) return res.status(400).json({ msg: 'Bot ID is required!' });

  const prevLen = botsVault.length;
  botsVault = botsVault.filter(b => b.id !== id);
  if (botsVault.length !== prevLen) {
    saveBotsVault();
    return res.json({ success: true, msg: 'Bot deleted from vault.' });
  }
  res.status(404).json({ msg: 'Bot not found.' });
});

app.post('/api/admin/bots-vault/clear', (req, res) => {
  const count = botsVault.length;
  botsVault = [];
  saveBotsVault();
  res.json({ success: true, msg: `Cleared ${count} bot(s) from vault.` });
});

app.post('/api/admin/bots-vault/test-token', async (req, res) => {
  const { token } = req.body || {};
  if (!token) return res.status(400).json({ ok: false, description: 'Token is required' });

  try {
    const tgRes = await fetch(`https://api.telegram.org/bot${token}/getMe`, { signal: AbortSignal.timeout(6000) });
    const data: any = await tgRes.json().catch(() => null);
    if (data?.ok) {
      const found = botsVault.find(b => b.token === token);
      if (found) {
        found.status = 'active';
        saveBotsVaultLocal();
      }
      return res.json({
        ok: true,
        valid: true,
        username: data.result?.username,
        first_name: data.result?.first_name,
        result: data.result
      });
    } else {
      return res.json({ ok: false, valid: false, msg: data?.description || 'Invalid token' });
    }
  } catch (err: any) {
    return res.json({ ok: false, valid: false, msg: err?.message || 'Connection error or timeout' });
  }
});

app.get('/api/admin/bots-vault/export', (req, res) => {
  const format = (req.query.format || 'txt').toString().toLowerCase();

  if (format === 'json') {
    res.setHeader('Content-Disposition', 'attachment; filename=bots_vault.json');
    res.setHeader('Content-Type', 'application/json');
    return res.send(JSON.stringify(botsVault, null, 2));
  } else if (format === 'csv') {
    res.setHeader('Content-Disposition', 'attachment; filename=bots_vault.csv');
    res.setHeader('Content-Type', 'text/csv');
    let csv = 'Name,Username,Token,Creator Name,Creator Phone,Owner,Created At,Status\n';
    for (const b of botsVault) {
      csv += `"${b.name}","@${b.username}","${b.token}","${b.creator_label}","${b.creator_phone}","${b.creator_owner}","${b.created_at_formatted}","${b.status}"\n`;
    }
    return res.send(csv);
  } else if (format === 'tokens') {
    res.setHeader('Content-Disposition', 'attachment; filename=bot_tokens_only.txt');
    res.setHeader('Content-Type', 'text/plain');
    const tokens = botsVault.map(b => b.token).join('\n');
    return res.send(tokens);
  } else {
    res.setHeader('Content-Disposition', 'attachment; filename=bots_vault.txt');
    res.setHeader('Content-Type', 'text/plain');
    let txt = `==========================================================\n`;
    txt += `       LEO TELEGM BOT - BOTS VAULT EXPORT (${formatISTDateTime()})\n`;
    txt += `       TOTAL BOTS: ${botsVault.length}\n`;
    txt += `==========================================================\n\n`;
    botsVault.forEach((b, idx) => {
      txt += `[#${idx + 1}] ${b.name} (@${b.username})\n`;
      txt += `Token:   ${b.token}\n`;
      txt += `Creator: ${b.creator_label} (${b.creator_phone}) [Owner: ${b.creator_owner}]\n`;
      txt += `Created: ${b.created_at_formatted}\n`;
      txt += `----------------------------------------------------------\n`;
    });
    return res.send(txt);
  }
});

// ---------------- CHANNEL BOT REACTIONS ENGINE ----------------
interface ChannelReactionConfig {
  id: string;
  owner: string;
  channel_username: string; // e.g. @channel or full link
  channel_chat_id?: string | number;
  bot_ids: string[]; // bot ids from botsVault
  emojis: string[]; // selected emojis (e.g. ['👍', '❤️', '🔥'])
  reaction_mode: 'mixed' | 'single'; // mixed random emojis or fixed
  delay_min_sec: number;
  delay_max_sec: number;
  auto_monitor: boolean; // auto-react to new posts
  created_at: string;
  updated_at: string;
  last_reacted_post_id?: number;
  status: 'active' | 'paused';
}

interface ReactionActivityLog {
  id: string;
  timestamp: string;
  owner: string;
  channel: string;
  message_id: number;
  bot_name: string;
  bot_username: string;
  emoji: string;
  status: 'success' | 'failed';
  error?: string;
}

const REACTION_CONFIGS_FILE = path.join(__dirname, 'reaction_configs.json');
const REACTION_LOGS_FILE = path.join(__dirname, 'reaction_logs.json');

let channelReactionConfigs: ChannelReactionConfig[] = [];
let channelReactionLogs: ReactionActivityLog[] = [];
const activeReactionMonitors = new Set<string>();

function loadChannelReactionsLocal(): void {
  try {
    if (fs.existsSync(REACTION_CONFIGS_FILE)) {
      const raw = fs.readFileSync(REACTION_CONFIGS_FILE, 'utf8');
      const data = JSON.parse(raw);
      if (Array.isArray(data)) channelReactionConfigs = data;
    }
  } catch (e) {
    channelReactionConfigs = [];
  }
  try {
    if (fs.existsSync(REACTION_LOGS_FILE)) {
      const raw = fs.readFileSync(REACTION_LOGS_FILE, 'utf8');
      const data = JSON.parse(raw);
      if (Array.isArray(data)) channelReactionLogs = data;
    }
  } catch (e) {
    channelReactionLogs = [];
  }
}

function saveChannelReactionsLocal(): void {
  try {
    fs.writeFileSync(REACTION_CONFIGS_FILE, JSON.stringify(channelReactionConfigs, null, 2), 'utf8');
  } catch {}
  try {
    fs.writeFileSync(REACTION_LOGS_FILE, JSON.stringify(channelReactionLogs.slice(0, 500), null, 2), 'utf8');
  } catch {}
}

function addReactionLog(log: Omit<ReactionActivityLog, 'id' | 'timestamp'>): void {
  const newLog: ReactionActivityLog = {
    ...log,
    id: `rlog_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    timestamp: formatISTDateTime()
  };
  channelReactionLogs.unshift(newLog);
  if (channelReactionLogs.length > 500) {
    channelReactionLogs = channelReactionLogs.slice(0, 500);
  }
  saveChannelReactionsLocal();
}

// In-memory cache for resolved channel handles/invite links to numeric chat IDs and titles
const channelTargetCache = new Map<string, { chatId: string | number; title: string }>();

function extractInviteHash(input: string): string | null {
  if (!input) return null;
  const str = input.trim();
  const plusMatch = str.match(/(?:t\.me\/\+|telegram\.me\/\+|\+)([a-zA-Z0-9_-]+)/i);
  if (plusMatch && plusMatch[1]) return plusMatch[1];
  const joinMatch = str.match(/(?:t\.me\/joinchat\/|telegram\.me\/joinchat\/)([a-zA-Z0-9_-]+)/i);
  if (joinMatch && joinMatch[1]) return joinMatch[1];
  return null;
}

// Clean channel username/handle from input string or link
function sanitizeChannelHandle(input: string): string {
  if (!input) return '';
  let clean = input.trim();

  // 1. Handle internal Telegram web client channel URLs: https://t.me/c/1234567890/123 -> -1001234567890
  const cMatch = clean.match(/(?:t\.me|telegram\.me)\/c\/(\d+)/i);
  if (cMatch && cMatch[1]) {
    return `-100${cMatch[1]}`;
  }

  // 2. Handle invite link hashes (+hash or joinchat/hash)
  const inviteHash = extractInviteHash(clean);
  if (inviteHash) {
    return `+${inviteHash}`;
  }

  clean = clean.replace(/^https?:\/\/t\.me\//i, '');
  clean = clean.replace(/^https?:\/\/telegram\.me\//i, '');
  clean = clean.replace(/^t\.me\//i, '');
  clean = clean.replace(/^telegram\.me\//i, '');
  clean = clean.replace(/^\/+|\/+$/g, '');

  // 3. If numeric ID (with or without - or -100 prefix), normalize to -100...
  if (/^-?\d+$/.test(clean)) {
    if (clean.startsWith('-100')) return clean;
    if (clean.startsWith('-')) return `-100${clean.substring(1)}`;
    return `-100${clean}`;
  }

  // 4. Remove post ID or query parameters if pasted post link (e.g. t.me/channel/123 -> channel)
  clean = clean.split('/')[0].split('?')[0];
  clean = clean.replace(/^@/, '');
  return clean ? `@${clean}` : '';
}

// Helper to resolve any channel target (public link, private invite link, or numeric chat ID) to a numeric chat ID
async function resolveChannelChatId(channelTarget: string, botToken?: string): Promise<{ chatId?: string | number; title?: string }> {
  if (!channelTarget) return {};
  const clean = sanitizeChannelHandle(channelTarget);
  if (channelTargetCache.has(clean)) {
    return channelTargetCache.get(clean)!;
  }
  if (channelTargetCache.has(channelTarget)) {
    return channelTargetCache.get(channelTarget)!;
  }

  // 1. If it's already a numeric chat ID (-100... or -...)
  if (/^-?\d+$/.test(clean)) {
    const formattedId = clean.startsWith('-100') ? clean : (clean.startsWith('-') ? clean : `-100${clean}`);
    const res = { chatId: formattedId, title: formattedId };
    channelTargetCache.set(clean, res);
    return res;
  }

  const inviteHash = extractInviteHash(channelTarget) || (clean.startsWith('+') ? clean.substring(1) : null);

  // 2. If it's an invite link, try to resolve via active GramJS user accounts
  if (inviteHash) {
    for (const acc of accounts.values()) {
      if (acc.client && (acc.status === 'online' || acc.status === 'Monitoring...' || acc.running)) {
        try {
          const inviteRes: any = await acc.client.invoke(new Api.messages.CheckChatInvite({ hash: inviteHash }));
          const chat = inviteRes?.chat || inviteRes;
          const rawId = chat?.id || inviteRes?.id;
          if (rawId) {
            const formattedId = `-100${rawId}`;
            const title = chat?.title || inviteRes?.title || `Private Channel (${inviteHash})`;
            const res = { chatId: formattedId, title };
            channelTargetCache.set(clean, res);
            channelTargetCache.set(channelTarget, res);
            return res;
          }
        } catch (e: any) {
          if (e?.chat?.id) {
            const formattedId = `-100${e.chat.id}`;
            const title = e.chat.title || `Private Channel (${inviteHash})`;
            const res = { chatId: formattedId, title };
            channelTargetCache.set(clean, res);
            channelTargetCache.set(channelTarget, res);
            return res;
          }
        }
      }
    }
  }

  // 3. Check Telegram Bot API updates for the bot to find channels the bot is in
  const tokensToCheck: string[] = [];
  if (botToken) tokensToCheck.push(botToken);
  for (const b of botsVault) {
    if (b.token && !tokensToCheck.includes(b.token)) {
      tokensToCheck.push(b.token);
    }
  }

  for (const token of tokensToCheck.slice(0, 5)) {
    try {
      // Ensure webhook is not blocking getUpdates
      await fetch(`https://api.telegram.org/bot${token}/deleteWebhook?drop_pending_updates=false`, { signal: AbortSignal.timeout(3000) }).catch(() => null);

      const updRes = await fetch(`https://api.telegram.org/bot${token}/getUpdates?offset=-100&limit=100&allowed_updates=${encodeURIComponent('["my_chat_member","channel_post","chat_member","message"]')}`, {
        signal: AbortSignal.timeout(5000)
      }).catch(() => null);
      const updData: any = updRes ? await updRes.json().catch(() => null) : null;
      if (updData?.ok && Array.isArray(updData.result)) {
        for (const u of updData.result) {
          const chat = u.my_chat_member?.chat || u.channel_post?.chat || u.chat_member?.chat || u.message?.chat;
          if (chat && (chat.type === 'channel' || chat.type === 'supergroup') && chat.id) {
            const res = { chatId: chat.id, title: chat.title || String(chat.id) };
            channelTargetCache.set(clean, res);
            channelTargetCache.set(channelTarget, res);
            channelTargetCache.set(String(chat.id), res);
            return res;
          }
        }
      }
    } catch {}
  }

  // 4. If public @username, return @username
  if (clean.startsWith('@')) {
    return { chatId: clean, title: clean };
  }

  return {};
}

// Extract message ID if user provided post URL (e.g. https://t.me/channel/142)
function extractPostIdFromUrl(url: string): number | null {
  if (!url) return null;
  const match = url.match(/(?:t\.me\/|telegram\.me\/)[^/]+\/(\d+)/i);
  if (match && match[1]) {
    return parseInt(match[1], 10);
  }
  return null;
}

// Low-level helper: send reaction using Telegram Bot API setMessageReaction
async function applyBotReaction(botToken: string, chatId: string | number, messageId: number, emoji: string): Promise<{ ok: boolean; description?: string }> {
  try {
    const url = `https://api.telegram.org/bot${botToken}/setMessageReaction`;
    const body = {
      chat_id: chatId,
      message_id: messageId,
      reaction: [
        {
          type: 'emoji',
          emoji: emoji
        }
      ],
      is_big: false
    };
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(9000)
    });
    const data: any = await res.json().catch(() => null);
    if (data?.ok) {
      return { ok: true };
    }
    return { ok: false, description: data?.description || `HTTP ${res.status}` };
  } catch (err: any) {
    return { ok: false, description: err?.message || 'Network error' };
  }
}

interface BotAdminCheckResult {
  isAdmin: boolean;
  title?: string;
  chatId?: number | string;
  description: string;
  logs: string[];
  rawStatus?: string;
  permissions?: Record<string, boolean>;
  botInfo?: { id: number; username?: string; first_name?: string };
}

// Helper: check if a bot is an administrator in the target channel
async function checkBotChannelAdmin(botToken: string, channelTarget: string): Promise<BotAdminCheckResult> {
  const logs: string[] = [];
  const log = (msg: string) => {
    logs.push(msg);
    console.log(`[BotAdminVerify] ${msg}`);
  };

  try {
    const cleanTarget = sanitizeChannelHandle(channelTarget);
    log(`[INIT] Channel target: "${channelTarget}" -> Resolved identifier: "${cleanTarget}"`);

    // 1. Get bot identity first
    log(`[STEP 1/5] Verifying bot token credentials via /getMe...`);
    const meRes = await fetch(`https://api.telegram.org/bot${botToken}/getMe`, { signal: AbortSignal.timeout(7000) }).catch((err) => {
      log(`❌ /getMe network error: ${err?.message || err}`);
      return null;
    });
    if (!meRes || !meRes.ok) {
      log(`❌ Telegram API responded with HTTP ${meRes?.status || 'ERR'} for /getMe.`);
      return { isAdmin: false, description: 'Invalid bot token or Telegram connection timeout', logs };
    }
    const meData: any = await meRes.json().catch(() => null);
    if (!meData?.ok || !meData?.result?.id) {
      log(`❌ Invalid bot token response: ${JSON.stringify(meData)}`);
      return { isAdmin: false, description: 'Invalid bot token credentials', logs };
    }
    const botUser = meData.result;
    const botUserId = botUser.id;
    const botUname = botUser.username ? `@${botUser.username}` : `ID:${botUserId}`;
    log(`✓ Bot Identity confirmed: ${botUname} (Bot ID: ${botUserId}, First Name: "${botUser.first_name || ''}")`);

    // 2. Direct getChatMember check for @username or numeric -100 ID
    if (cleanTarget.startsWith('@') || /^-100\d+$/.test(cleanTarget) || /^-?\d+$/.test(cleanTarget)) {
      const targetId = cleanTarget;
      log(`[STEP 2/5] Testing direct getChatMember & getChat for "${targetId}"...`);
      
      const directMemberRes = await fetch(`https://api.telegram.org/bot${botToken}/getChatMember?chat_id=${encodeURIComponent(targetId)}&user_id=${botUserId}`, {
        signal: AbortSignal.timeout(7000)
      }).catch((err) => {
        log(`⚠️ Direct getChatMember connection timeout: ${err?.message || err}`);
        return null;
      });
      const directMemberData: any = directMemberRes ? await directMemberRes.json().catch(() => null) : null;

      if (directMemberData?.ok && directMemberData.result) {
        const mem = directMemberData.result;
        const status = mem.status;
        log(`✓ Received member status for bot ${botUname} in ${targetId}: status="${status}"`);
        
        if (status === 'administrator' || status === 'creator') {
          const directChatRes = await fetch(`https://api.telegram.org/bot${botToken}/getChat?chat_id=${encodeURIComponent(targetId)}`, { signal: AbortSignal.timeout(5000) }).catch(() => null);
          const directChatData: any = directChatRes ? await directChatRes.json().catch(() => null) : null;
          const chatTitle = directChatData?.result?.title || (directChatData?.result?.username ? `@${directChatData.result.username}` : String(targetId));
          const numericChatId = directChatData?.result?.id || targetId;

          const perms: Record<string, boolean> = {
            can_post_messages: Boolean(mem.can_post_messages !== false),
            can_edit_messages: Boolean(mem.can_edit_messages !== false),
            can_delete_messages: Boolean(mem.can_delete_messages !== false),
            can_change_info: Boolean(mem.can_change_info !== false),
            can_invite_users: Boolean(mem.can_invite_users !== false)
          };

          channelTargetCache.set(cleanTarget, { chatId: numericChatId, title: chatTitle });
          channelTargetCache.set(channelTarget, { chatId: numericChatId, title: chatTitle });
          channelTargetCache.set(String(numericChatId), { chatId: numericChatId, title: chatTitle });

          log(`✅ Success! Bot ${botUname} is verified as ${status.toUpperCase()} in "${chatTitle}" (Chat ID: ${numericChatId}).`);
          return {
            isAdmin: true,
            title: chatTitle,
            chatId: numericChatId,
            rawStatus: status,
            permissions: perms,
            botInfo: { id: botUserId, username: botUser.username, first_name: botUser.first_name },
            description: `Bot is ${status === 'creator' ? 'Channel Owner' : 'Administrator'}`,
            logs
          };
        } else if (status === 'member') {
          log(`⚠️ Bot is present in "${targetId}" but only has regular MEMBER status. Promotion required.`);
          return {
            isAdmin: false,
            rawStatus: status,
            botInfo: { id: botUserId, username: botUser.username },
            description: `Bot is in the channel as a regular Member. Please promote ${botUname} to Administrator in Channel Settings -> Administrators.`,
            logs
          };
        } else if (status === 'left' || status === 'kicked') {
          log(`❌ Bot status in "${targetId}" is "${status}". Bot is not a participant in the channel.`);
          return {
            isAdmin: false,
            rawStatus: status,
            botInfo: { id: botUserId, username: botUser.username },
            description: `Bot is not in the channel (status: ${status}). Please add ${botUname} to the channel as Administrator.`,
            logs
          };
        }
      } else {
        const errDesc = directMemberData?.description || (directMemberRes ? `HTTP ${directMemberRes.status}` : 'No response');
        log(`ℹ️ Direct lookup on "${targetId}" returned: "${errDesc}"`);
      }
    }

    // 3. Scan Bot's getUpdates for recent admin promotion events
    log(`[STEP 3/5] Checking Telegram Bot updates (getUpdates) for channel promotion events...`);
    await fetch(`https://api.telegram.org/bot${botToken}/deleteWebhook?drop_pending_updates=false`, { signal: AbortSignal.timeout(4000) }).catch(() => null);

    const updRes = await fetch(`https://api.telegram.org/bot${botToken}/getUpdates?offset=-100&limit=100&allowed_updates=${encodeURIComponent('["my_chat_member","channel_post","chat_member","message"]')}`, {
      signal: AbortSignal.timeout(7000)
    }).catch((err) => {
      log(`⚠️ getUpdates request timeout: ${err?.message || err}`);
      return null;
    });
    const updData: any = updRes ? await updRes.json().catch(() => null) : null;

    const detectedChats: Array<{ id: string | number; title?: string; username?: string }> = [];
    if (updData?.ok && Array.isArray(updData.result)) {
      log(`✓ Retrieved ${updData.result.length} update event(s) from Telegram for bot ${botUname}.`);
      for (const u of updData.result) {
        if (u.my_chat_member?.chat) {
          const c = u.my_chat_member.chat;
          const newStatus = u.my_chat_member.new_chat_member?.status;
          log(`  • Found my_chat_member event: "${c.title || c.id}" (${c.type}), status -> "${newStatus}"`);
          if (c.id && !detectedChats.some(dc => String(dc.id) === String(c.id))) {
            detectedChats.push({ id: c.id, title: c.title, username: c.username });
          }
        }
        if (u.channel_post?.chat) {
          const c = u.channel_post.chat;
          if (c.id && !detectedChats.some(dc => String(dc.id) === String(c.id))) {
            detectedChats.push({ id: c.id, title: c.title, username: c.username });
          }
        }
        if (u.chat_member?.chat) {
          const c = u.chat_member.chat;
          if (c.id && !detectedChats.some(dc => String(dc.id) === String(c.id))) {
            detectedChats.push({ id: c.id, title: c.title, username: c.username });
          }
        }
      }
    } else {
      log(`ℹ️ No pending updates returned by Telegram Bot API.`);
    }

    // Check each detected candidate chat
    log(`[STEP 4/5] Checking detected candidate channels (${detectedChats.length} found)...`);
    for (const dChat of detectedChats) {
      try {
        log(`  • Testing getChatMember on candidate channel ID ${dChat.id} ("${dChat.title || ''}")...`);
        const memRes = await fetch(`https://api.telegram.org/bot${botToken}/getChatMember?chat_id=${encodeURIComponent(dChat.id)}&user_id=${botUserId}`, {
          signal: AbortSignal.timeout(5000)
        }).catch(() => null);
        const memData: any = memRes ? await memRes.json().catch(() => null) : null;
        if (memData?.ok && memData.result) {
          const status = memData.result.status;
          log(`    -> Status on ${dChat.id}: "${status}"`);
          if (status === 'administrator' || status === 'creator') {
            const finalTitle = dChat.title || (dChat.username ? `@${dChat.username}` : String(dChat.id));
            channelTargetCache.set(cleanTarget, { chatId: dChat.id, title: finalTitle });
            channelTargetCache.set(channelTarget, { chatId: dChat.id, title: finalTitle });
            channelTargetCache.set(String(dChat.id), { chatId: dChat.id, title: finalTitle });
            log(`✅ Success! Bot ${botUname} is verified as ${status.toUpperCase()} in detected channel "${finalTitle}" (ID: ${dChat.id})!`);
            return {
              isAdmin: true,
              title: finalTitle,
              chatId: dChat.id,
              rawStatus: status,
              botInfo: { id: botUserId, username: botUser.username, first_name: botUser.first_name },
              description: `Bot is ${status === 'creator' ? 'Channel Owner' : 'Administrator'}`,
              logs
            };
          }
        }
      } catch (err: any) {
        log(`    -> Error checking candidate ${dChat.id}: ${err?.message || err}`);
      }
    }

    // 4. Try resolving via GramJS active MTProto user accounts (if any are online)
    log(`[STEP 5/5] Checking active MTProto accounts for channel dialogs & invite link resolution...`);
    for (const acc of accounts.values()) {
      if (acc.client && (acc.status === 'online' || acc.status === 'Monitoring...' || acc.running)) {
        try {
          const dialogs: any = await acc.client.getDialogs({ limit: 50 }).catch(() => []);
          for (const d of dialogs) {
            if (d.isChannel || d.isGroup) {
              const rawId = d.entity?.id;
              if (rawId) {
                const formattedId = `-100${rawId}`;
                const memRes = await fetch(`https://api.telegram.org/bot${botToken}/getChatMember?chat_id=${encodeURIComponent(formattedId)}&user_id=${botUserId}`, {
                  signal: AbortSignal.timeout(4000)
                }).catch(() => null);
                const memData: any = memRes ? await memRes.json().catch(() => null) : null;
                if (memData?.ok && (memData.result?.status === 'administrator' || memData.result?.status === 'creator')) {
                  const finalTitle = d.entity?.title || d.title || formattedId;
                  channelTargetCache.set(cleanTarget, { chatId: formattedId, title: finalTitle });
                  channelTargetCache.set(channelTarget, { chatId: formattedId, title: finalTitle });
                  log(`✅ Success! Bot is Administrator in resolved MTProto dialog "${finalTitle}" (${formattedId})!`);
                  return {
                    isAdmin: true,
                    title: finalTitle,
                    chatId: formattedId,
                    rawStatus: memData.result.status,
                    botInfo: { id: botUserId, username: botUser.username, first_name: botUser.first_name },
                    description: 'Bot is Administrator',
                    logs
                  };
                }
              }
            }
          }
        } catch {}
      }
    }

    // 5. Final fallback check with resolveChannelChatId
    const resolved = await resolveChannelChatId(channelTarget, botToken);
    if (resolved.chatId) {
      log(`Checking cached/resolved channel ID: ${resolved.chatId}`);
      const memberRes = await fetch(`https://api.telegram.org/bot${botToken}/getChatMember?chat_id=${encodeURIComponent(resolved.chatId)}&user_id=${botUserId}`, {
        signal: AbortSignal.timeout(6000)
      }).catch(() => null);
      const memberData: any = memberRes ? await memberRes.json().catch(() => null) : null;
      if (memberData?.ok && memberData.result) {
        const status = memberData.result.status;
        const isAdm = status === 'administrator' || status === 'creator';
        log(`Resolved ID ${resolved.chatId} status: "${status}"`);
        if (isAdm) {
          return {
            isAdmin: true,
            title: resolved.title || String(resolved.chatId),
            chatId: resolved.chatId,
            rawStatus: status,
            botInfo: { id: botUserId, username: botUser.username, first_name: botUser.first_name },
            description: 'Bot is Administrator',
            logs
          };
        }
      }
    }

    log(`❌ Bot admin rights could not be detected for ${botUname} on "${channelTarget}".`);
    log(`💡 Diagnostic Tips:`);
    log(`  1. Open Telegram -> Go to your Channel -> Edit -> Administrators -> Add Administrator.`);
    log(`  2. Add ${botUname} and ensure "Post Messages" permission is enabled.`);
    log(`  3. Post any test message in the channel so Telegram notifies the bot.`);
    log(`  4. If this is a private channel, you can also paste the channel ID (-100...) directly.`);

    return {
      isAdmin: false,
      botInfo: { id: botUserId, username: botUser.username },
      description: `Bot admin rights not detected for ${botUname}. If this is a private channel, please post a test message in your channel so Telegram notifies the bot, or provide the channel ID (-100...).`,
      logs
    };
  } catch (e: any) {
    log(`❌ Exception in verification process: ${e?.message || e}`);
    return {
      isAdmin: false,
      description: e?.name === 'TimeoutError' ? 'Verification request timed out' : (e?.message || 'Connection error'),
      logs
    };
  }
}

// Background poller loop for active auto-reaction configs
let reactionMonitorRunning = false;
async function startChannelReactionMonitorLoop() {
  if (reactionMonitorRunning) return;
  reactionMonitorRunning = true;

  while (true) {
    try {
      const activeConfigs = channelReactionConfigs.filter(c => c.status === 'active' && c.auto_monitor);
      for (const cfg of activeConfigs) {
        if (!cfg.channel_username || cfg.bot_ids.length === 0) continue;
        
        // Pick the first available bot in the config to monitor channel updates
        const primaryBotRecord = botsVault.find(b => cfg.bot_ids.includes(b.id));
        if (!primaryBotRecord || !primaryBotRecord.token) continue;

        try {
          // Poll channel for latest posts/messages via getUpdates or channel info
          const updatesUrl = `https://api.telegram.org/bot${primaryBotRecord.token}/getUpdates?timeout=1&limit=10&allowed_updates=${encodeURIComponent('["channel_post","message"]')}`;
          const res = await fetch(updatesUrl, { signal: AbortSignal.timeout(4000) }).catch(() => null);
          if (!res) continue;
          const json: any = await res.json().catch(() => null);

          if (json?.ok && Array.isArray(json.result)) {
            for (const upd of json.result) {
              const post = upd.channel_post || upd.message;
              if (!post || !post.message_id) continue;

              const postChat = post.chat;
              const postChatUsername = postChat?.username ? `@${postChat.username.toLowerCase()}` : '';
              const targetChatClean = cfg.channel_username.toLowerCase();

              const matchesChat = (postChatUsername && postChatUsername === targetChatClean) ||
                                  (cfg.channel_chat_id && String(postChat?.id) === String(cfg.channel_chat_id));

              if (matchesChat) {
                const postId = post.message_id;
                // Check if we already reacted to this post
                if (cfg.last_reacted_post_id && postId <= cfg.last_reacted_post_id) {
                  continue;
                }

                console.log(`[REACTION MONITOR] Detected new post #${postId} in channel ${cfg.channel_username} for owner ${cfg.owner}`);
                cfg.last_reacted_post_id = postId;
                saveChannelReactionsLocal();

                // Trigger staggered multi-bot reaction sequence asynchronously
                (async () => {
                  await executeMultiBotReactions(cfg, postId, cfg.channel_chat_id || cfg.channel_username);
                })();
              }
            }
          }
        } catch {}
      }
    } catch (err) {
      console.error('[REACTION MONITOR ERROR]:', err);
    }
    await new Promise(r => setTimeout(r, 6000));
  }
}

// Function to execute multi-bot reactions with staggered human-like random delays
async function executeMultiBotReactions(
  cfg: ChannelReactionConfig,
  postId: number,
  chatTarget: string | number
): Promise<{ successCount: number; totalCount: number; errors: string[] }> {
  const selectedBots = botsVault.filter(b => cfg.bot_ids.includes(b.id));
  if (selectedBots.length === 0) {
    return { successCount: 0, totalCount: 0, errors: ['No valid bots found in vault'] };
  }

  const availableEmojis = cfg.emojis && cfg.emojis.length > 0 
    ? cfg.emojis 
    : ['👍', '❤️', '🔥', '👏', '🎉', '🤩', '🚀'];

  let successCount = 0;
  const errors: string[] = [];

  for (let i = 0; i < selectedBots.length; i++) {
    const bot = selectedBots[i];
    
    // Choose emoji: if 'single' mode, use first; if 'mixed', cycle or randomize
    let chosenEmoji: string;
    if (cfg.reaction_mode === 'single') {
      chosenEmoji = availableEmojis[0] || '👍';
    } else {
      chosenEmoji = availableEmojis[i % availableEmojis.length] || availableEmojis[0];
    }

    // Apply staggered safe human delay between bots (except first bot)
    if (i > 0) {
      const minD = Math.max(1, cfg.delay_min_sec || 3);
      const maxD = Math.max(minD, cfg.delay_max_sec || 10);
      const randomDelayMs = Math.floor(Math.random() * ((maxD - minD) * 1000 + 1)) + (minD * 1000);
      await new Promise(resolve => setTimeout(resolve, randomDelayMs));
    }

    const botDisplayName = bot.bot_name || bot.name || `@${bot.username}`;
    const result = await applyBotReaction(bot.token, chatTarget, postId, chosenEmoji);
    
    if (result.ok) {
      successCount++;
      addReactionLog({
        owner: cfg.owner,
        channel: cfg.channel_username,
        message_id: postId,
        bot_name: botDisplayName,
        bot_username: bot.username || '',
        emoji: chosenEmoji,
        status: 'success'
      });
      console.log(`[REACTION OK] Bot ${botDisplayName} reacted with ${chosenEmoji} to post #${postId} in ${cfg.channel_username}`);
    } else {
      const errMsg = result.description || 'Unknown reaction error';
      errors.push(`${botDisplayName}: ${errMsg}`);
      addReactionLog({
        owner: cfg.owner,
        channel: cfg.channel_username,
        message_id: postId,
        bot_name: botDisplayName,
        bot_username: bot.username || '',
        emoji: chosenEmoji,
        status: 'failed',
        error: errMsg
      });
      console.warn(`[REACTION FAIL] Bot ${botDisplayName} failed to react to post #${postId}:`, errMsg);
    }
  }

  return { successCount, totalCount: selectedBots.length, errors };
}

// --- API ENDPOINTS FOR CHANNEL BOT REACTIONS (ADMIN ONLY) ---

// 1. Get configs, logs, and stats
app.get('/api/admin/reactions', (req, res) => {
  const ownerFilter = (req.query.owner || '').toString().trim();
  let configs = channelReactionConfigs;
  let logs = channelReactionLogs;

  if (ownerFilter && ownerFilter !== 'all') {
    configs = configs.filter(c => c.owner === ownerFilter);
    logs = logs.filter(l => l.owner === ownerFilter);
  }

  res.json({
    success: true,
    configs,
    logs: logs.slice(0, 150),
    total_configs: configs.length,
    total_logs: logs.length
  });
});

// 2. Save or update reaction campaign / configuration
app.post('/api/admin/reactions/save', async (req, res) => {
  const b = req.body || {};
  const owner = (b.owner || 'admin').trim();
  const rawChannel = (b.channel || '').trim();
  const cleanChannel = sanitizeChannelHandle(rawChannel);

  if (!cleanChannel) {
    return res.status(400).json({ msg: 'Target channel link or @username is required!' });
  }

  const botIds: string[] = Array.isArray(b.bot_ids) ? b.bot_ids : [];
  if (botIds.length === 0) {
    return res.status(400).json({ msg: 'Please select at least 1 Telegram bot to react!' });
  }

  const emojis: string[] = Array.isArray(b.emojis) && b.emojis.length > 0 
    ? b.emojis 
    : ['👍', '❤️', '🔥', '👏', '🎉', '🤩', '🚀'];

  const delayMin = Math.max(1, parseInt(b.delay_min_sec, 10) || 3);
  const delayMax = Math.max(delayMin, parseInt(b.delay_max_sec, 10) || 12);
  const autoMonitor = Boolean(b.auto_monitor !== false);
  const reactionMode = b.reaction_mode === 'single' ? 'single' : 'mixed';

  // Optional: Try to resolve channel chat ID using one of the bots
  let resolvedChatId: string | number | undefined;
  const sampleBot = botsVault.find(bot => botIds.includes(bot.id));
  if (sampleBot) {
    const adminCheck = await checkBotChannelAdmin(sampleBot.token, cleanChannel);
    if (adminCheck.chatId) {
      resolvedChatId = adminCheck.chatId;
    }
  }

  const configId = b.id || `rcfg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const existingIdx = channelReactionConfigs.findIndex(c => c.id === configId);

  const newConfig: ChannelReactionConfig = {
    id: configId,
    owner,
    channel_username: cleanChannel,
    channel_chat_id: resolvedChatId,
    bot_ids: botIds,
    emojis,
    reaction_mode: reactionMode,
    delay_min_sec: delayMin,
    delay_max_sec: delayMax,
    auto_monitor: autoMonitor,
    created_at: existingIdx >= 0 ? channelReactionConfigs[existingIdx].created_at : new Date().toISOString(),
    updated_at: new Date().toISOString(),
    status: 'active'
  };

  if (existingIdx >= 0) {
    channelReactionConfigs[existingIdx] = { ...channelReactionConfigs[existingIdx], ...newConfig };
  } else {
    channelReactionConfigs.unshift(newConfig);
  }

  saveChannelReactionsLocal();

  res.json({
    success: true,
    msg: `Channel reaction campaign saved for ${cleanChannel} with ${botIds.length} bot(s)!`,
    config: newConfig
  });
});

// 3. Verify channel admin status for selected bots
app.post('/api/admin/reactions/verify-admin', async (req, res) => {
  const { channel, bot_ids } = req.body || {};
  const cleanChannel = sanitizeChannelHandle(channel);
  if (!cleanChannel) {
    return res.status(400).json({ msg: 'Please provide a valid channel link or @username!' });
  }

  const ids: string[] = Array.isArray(bot_ids) ? bot_ids : [];
  const targetBots = botsVault.filter(b => ids.includes(b.id));

  if (targetBots.length === 0) {
    return res.status(400).json({ msg: 'No bots selected for verification.' });
  }

  const results = await Promise.all(targetBots.map(async (b) => {
    const rawUname = (b.bot_username || b.username || '').replace(/^@/, '');
    try {
      const check = await checkBotChannelAdmin(b.token, channel || cleanChannel);
      return {
        bot_id: b.id,
        bot_name: b.bot_name || b.name || `@${rawUname}`,
        username: rawUname,
        is_admin: check.isAdmin,
        channel_title: check.title,
        chat_id: check.chatId,
        raw_status: check.rawStatus,
        permissions: check.permissions,
        bot_info: check.botInfo,
        description: check.description,
        logs: check.logs
      };
    } catch (err: any) {
      return {
        bot_id: b.id,
        bot_name: b.bot_name || b.name || `@${rawUname}`,
        username: rawUname,
        is_admin: false,
        description: `Verification error: ${err?.message || 'Connection failed'}`,
        logs: [`❌ Error during bot verification: ${err?.message || err}`]
      };
    }
  }));

  const allAdmin = results.every(r => r.is_admin);
  const adminCount = results.filter(r => r.is_admin).length;
  const verifiedResult = results.find(r => r.is_admin && r.chat_id);

  res.json({
    success: true,
    all_admin: allAdmin,
    admin_count: adminCount,
    total_bots: results.length,
    channel: cleanChannel,
    resolved_chat_id: verifiedResult?.chat_id,
    resolved_channel_title: verifiedResult?.channel_title,
    results
  });
});

// 3.5 Auto-detect all channels where the given bot(s) are Administrators
app.post('/api/admin/reactions/detect-bot-channels', async (req, res) => {
  const { bot_ids } = req.body || {};
  const ids: string[] = Array.isArray(bot_ids) ? bot_ids : [];
  const targetBots = botsVault.filter(b => ids.length === 0 || ids.includes(b.id));

  if (targetBots.length === 0) {
    return res.json({ channels: [] });
  }

  const detectedMap = new Map<string, { chat_id: string | number; title: string; username?: string; bot_ids: string[] }>();

  await Promise.all(targetBots.map(async (b) => {
    if (!b.token) return;
    try {
      const meRes = await fetch(`https://api.telegram.org/bot${b.token}/getMe`, { signal: AbortSignal.timeout(4000) }).catch(() => null);
      const meData: any = meRes ? await meRes.json().catch(() => null) : null;
      if (!meData?.ok || !meData?.result?.id) return;
      const botUserId = meData.result.id;

      await fetch(`https://api.telegram.org/bot${b.token}/deleteWebhook?drop_pending_updates=false`, { signal: AbortSignal.timeout(3000) }).catch(() => null);

      const updRes = await fetch(`https://api.telegram.org/bot${b.token}/getUpdates?offset=-100&limit=100&allowed_updates=${encodeURIComponent('["my_chat_member","channel_post","chat_member"]')}`, {
        signal: AbortSignal.timeout(5000)
      }).catch(() => null);
      const updData: any = updRes ? await updRes.json().catch(() => null) : null;

      if (updData?.ok && Array.isArray(updData.result)) {
        for (const u of updData.result) {
          const c = u.my_chat_member?.chat || u.channel_post?.chat || u.chat_member?.chat;
          if (c && c.id && (c.type === 'channel' || c.type === 'supergroup')) {
            const strId = String(c.id);
            // Verify if admin
            const memRes = await fetch(`https://api.telegram.org/bot${b.token}/getChatMember?chat_id=${encodeURIComponent(c.id)}&user_id=${botUserId}`, {
              signal: AbortSignal.timeout(4000)
            }).catch(() => null);
            const memData: any = memRes ? await memRes.json().catch(() => null) : null;
            if (memData?.ok && (memData.result?.status === 'administrator' || memData.result?.status === 'creator')) {
              if (detectedMap.has(strId)) {
                const existing = detectedMap.get(strId)!;
                if (!existing.bot_ids.includes(b.id)) existing.bot_ids.push(b.id);
              } else {
                detectedMap.set(strId, {
                  chat_id: c.id,
                  title: c.title || strId,
                  username: c.username ? `@${c.username}` : undefined,
                  bot_ids: [b.id]
                });
              }
            }
          }
        }
      }
    } catch {}
  }));

  // Also check active GramJS accounts
  for (const acc of accounts.values()) {
    if (acc.client && (acc.status === 'online' || acc.status === 'Monitoring...' || acc.running)) {
      try {
        const dialogs: any = await acc.client.getDialogs({ limit: 30 }).catch(() => []);
        for (const d of dialogs) {
          if (d.isChannel || d.isGroup) {
            const rawId = d.entity?.id;
            if (rawId) {
              const formattedId = `-100${rawId}`;
              const strId = String(formattedId);
              if (!detectedMap.has(strId)) {
                detectedMap.set(strId, {
                  chat_id: formattedId,
                  title: d.entity?.title || d.title || strId,
                  username: d.entity?.username ? `@${d.entity.username}` : undefined,
                  bot_ids: []
                });
              }
            }
          }
        }
      } catch {}
    }
  }

  res.json({
    channels: Array.from(detectedMap.values())
  });
});

// 4. Instant Reaction trigger for a specific Post ID or URL
app.post('/api/admin/reactions/trigger-instant', async (req, res) => {
  const b = req.body || {};
  const owner = (b.owner || 'admin').trim();
  const rawTarget = (b.channel || '').trim();
  const postUrlOrId = (b.post_target || '').toString().trim();
  const cleanChannel = sanitizeChannelHandle(rawTarget);

  let postId: number | null = null;
  // If post_target is a number, use it; otherwise try to extract from URL
  if (/^\d+$/.test(postUrlOrId)) {
    postId = parseInt(postUrlOrId, 10);
  } else {
    postId = extractPostIdFromUrl(postUrlOrId) || extractPostIdFromUrl(rawTarget);
  }

  if (!postId) {
    return res.status(400).json({ msg: 'Please provide a valid Post ID (e.g. 145) or Post URL (e.g. https://t.me/channel/145)!' });
  }

  if (!cleanChannel) {
    return res.status(400).json({ msg: 'Target channel username is required!' });
  }

  const botIds: string[] = Array.isArray(b.bot_ids) ? b.bot_ids : [];
  if (botIds.length === 0) {
    return res.status(400).json({ msg: 'Please select at least 1 bot!' });
  }

  const emojis: string[] = Array.isArray(b.emojis) && b.emojis.length > 0 
    ? b.emojis 
    : ['👍', '❤️', '🔥', '👏', '🎉', '🤩', '🚀'];

  const reactionMode = b.reaction_mode === 'single' ? 'single' : 'mixed';
  const delayMin = Math.max(1, parseInt(b.delay_min_sec, 10) || 2);
  const delayMax = Math.max(delayMin, parseInt(b.delay_max_sec, 10) || 8);

  const resolved = await resolveChannelChatId(rawTarget);
  const targetChat = resolved.chatId || cleanChannel;

  const tempCfg: ChannelReactionConfig = {
    id: `temp_${Date.now()}`,
    owner,
    channel_username: cleanChannel,
    channel_chat_id: resolved.chatId,
    bot_ids: botIds,
    emojis,
    reaction_mode: reactionMode,
    delay_min_sec: delayMin,
    delay_max_sec: delayMax,
    auto_monitor: false,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    status: 'active'
  };

  // Launch reactions in background or immediately
  executeMultiBotReactions(tempCfg, postId, targetChat).then(outcome => {
    console.log(`[INSTANT REACTION FINISHED] Post #${postId} in ${cleanChannel} (${targetChat}): ${outcome.successCount}/${outcome.totalCount} successful.`);
  });

  res.json({
    success: true,
    msg: `🚀 Multi-bot reactions launched for Post #${postId} across ${botIds.length} bot(s) with human-like delays! Check live logs below.`,
    post_id: postId,
    channel: cleanChannel
  });
});

// 5. Delete or Pause/Resume Campaign
app.post('/api/admin/reactions/toggle-status', (req, res) => {
  const { id, action } = req.body || {};
  const cfg = channelReactionConfigs.find(c => c.id === id);
  if (!cfg) return res.status(404).json({ msg: 'Campaign config not found.' });

  if (action === 'delete') {
    channelReactionConfigs = channelReactionConfigs.filter(c => c.id !== id);
    saveChannelReactionsLocal();
    return res.json({ success: true, msg: 'Campaign deleted.' });
  } else {
    cfg.status = cfg.status === 'active' ? 'paused' : 'active';
    saveChannelReactionsLocal();
    return res.json({ success: true, msg: `Campaign status changed to ${cfg.status}.`, status: cfg.status });
  }
});

// 6. Clear reaction logs
app.post('/api/admin/reactions/clear-logs', (req, res) => {
  channelReactionLogs = [];
  saveChannelReactionsLocal();
  res.json({ success: true, msg: 'Reaction activity logs cleared.' });
});

app.get('/api/admin/users', (req         , res          ) => {
  const data        = [];
  const todayStr = getTodayDateString();

  for (const u of usersList) {
    const accs = Array.from(accounts.values()).filter((a) => (a.owner || 'admin').toLowerCase() === u.username.toLowerCase());
    const verifiedQ = getOwnerVerifiedQueue(u.username);
    const rawQ = getOwnerRawQueue(u.username);

    let userDailyDMs = 0;
    let sumAccSent = 0;
    for (const a of accs) {
      checkAndResetDailyDmQuota(a.phone);
      const idDaily = (a as any).daily_sent_count || 0;
      userDailyDMs += idDaily;
      sumAccSent += (a.sent_count || 0);
    }

    const historyKey = Object.keys(dailyDmHistory).find(k => k.toLowerCase() === u.username.toLowerCase()) || u.username;
    const todayHistCount = dailyDmHistory[historyKey]?.[todayStr]?.count || 0;
    userDailyDMs = Math.max(userDailyDMs, todayHistCount);

    let userHistoricalTotalDMs = 0;
    const userHistory = dailyDmHistory[historyKey] || {};
    for (const d of Object.keys(userHistory)) {
      userHistoricalTotalDMs += userHistory[d]?.count || 0;
    }
    const alreadySentSet = getOwnerSentUsers(u.username);
    const userTotalDMs = Math.max(userHistoricalTotalDMs, userDailyDMs, sumAccSent, alreadySentSet.size);

    const isUserAdmin = Boolean(u.role === 'admin' || u.username === 'admin');
    const isExpired = Boolean(!isUserAdmin && u.expiry_date && todayStr > u.expiry_date);
    const effectiveActive = isExpired ? false : (u.active ?? true);
    const dailyStats5Days = isUserAdmin ? [] : getOwnerDailyDmStats(u.username, accs.length);
    const joinKey = Object.keys(dailyJoinHistory).find(k => k.toLowerCase() === u.username.toLowerCase()) || u.username;
    const dailyJoinsCount = dailyJoinHistory[joinKey]?.[todayStr]?.count || 0;
    const totalJoinsCount = getOwnerLifetimeJoins(u.username);
    const last5DaysJoins = isUserAdmin ? [] : getOwnerDailyJoinStats(u.username);
    const conversionRate = userTotalDMs > 0 ? ((totalJoinsCount / userTotalDMs) * 100).toFixed(1) + '%' : (totalJoinsCount > 0 ? '100%' : '0.0%');
    const ratePerBot = Number(u.rate_per_bot || (billingStore.user_configs && billingStore.user_configs[u.username]?.rate_per_bot) || 15);
    const billingModel = (u.billing_model || (billingStore.user_configs && billingStore.user_configs[u.username]?.billing_model) || 'advance').toString();
    const maxAccounts = u.max_accounts ?? 5;

    data.push({
      username: u.username,
      role: u.role || 'user',
      active: effectiveActive,
      is_expired: isExpired,
      max_accounts: maxAccounts,
      max_targets: u.max_targets ?? 9999,
      expiry_date: u.expiry_date || '',
      rate_per_bot: ratePerBot,
      billing_model: billingModel,
      weekly_total: ratePerBot * maxAccounts,
      has_sq: Boolean(u.security_question && u.security_answer),
      alert_enabled: Boolean(u.alert_enabled),
      alert_bot_token: u.alert_bot_token || '',
      alert_chat_id: u.alert_chat_id || '',
      accounts_count: accs.length,
      running_count: accs.filter((a) => a.running).length,
      daily_dms_count: userDailyDMs,
      total_dms_count: userTotalDMs,
      last_5_days_dms: dailyStats5Days,
      daily_joins_count: dailyJoinsCount,
      total_joins_count: totalJoinsCount,
      last_5_days_joins: last5DaysJoins,
      conversion_rate: conversionRate,
      tracked_invite_link: userTrackedLinks[u.username]?.invite_link || '',
      verified_queue_count: verifiedQ.length,
      leftover_count: verifiedQ.length,
      already_sent_count: alreadySentSet.size,
      raw_queue_count: rawQ.length,
      phones: accs.map((a) => a.phone),
      labels: accs.map((a) => a.label || a.phone),
      registered_phones: Array.isArray(u.registered_phones) ? u.registered_phones : [],
      access_type: u.access_type || 'both',
      last_platform: (u as any).last_platform || 'Never',
      last_login: (u as any).last_login || 0,
      ai_enabled: u.ai_enabled === true,
      dynamic_templates_enabled: u.dynamic_templates_enabled !== false,
      accounts: accs.map((a) => {
        const idDaily = (a as any).daily_sent_count || 0;
        const idTotal = Math.max(a.sent_count || 0, idDaily, (a.sent_users ? a.sent_users.size : 0));
        return {
          phone: a.phone,
          label: a.label || a.phone,
          status: a.status,
          running: a.running,
          dm_on: a.dm_on !== false,
          live_on: a.live_on !== false,
          daily_sent_count: idDaily,
          sent_count: idTotal
        };
      })
    });
  }
  const allAccList = Array.from(accounts.values());
  const todayTotalDms = data.reduce((acc, u) => acc + (u.daily_dms_count || 0), 0);
  const fleetSummary = {
    total_accounts: allAccList.length,
    running_count: allAccList.filter(a => a.running).length,
    dm_on_count: allAccList.filter(a => a.dm_on !== false).length,
    live_on_count: allAccList.filter(a => a.live_on !== false).length
  };
  const adminUser = usersList.find((u: any) => u.role === 'admin' || u.username === 'admin');
  const adminName = adminUser?.admin_name || adminUser?.display_name || 'Admin';
  res.json({
    users: data,
    today_total_dms: todayTotalDms,
    fleet_summary: fleetSummary,
    view_as: req.session?.view_as || '',
    admin_name: adminName,
    total_vault_bots: botsVault.length,
    pending_slot_requests: slotRequests.filter(r => r.status === 'pending'),
    pending_access_requests: accessRequests.filter(r => r.status === 'pending')
  });
});

// ---------------- JOIN REQUEST TRACKER ADMIN CONTROLS ----------------
app.post('/api/admin/join-tracker/reset', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ msg: 'Admin access required' });
  const username = (req.body?.username || '').trim();
  if (username) {
    dailyJoinHistory[username] = {};
    saveDailyJoinHistoryDebounced();
    res.json({ success: true, msg: `Join request stats reset successfully for ${username}.` });
  } else {
    dailyJoinHistory = {};
    saveDailyJoinHistoryDebounced();
    res.json({ success: true, msg: 'All users join request stats reset successfully.' });
  }
});

app.post('/api/admin/join-tracker/regenerate-link', async (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ msg: 'Admin access required' });
  const username = (req.body?.username || '').trim();
  if (!username) return res.status(400).json({ msg: 'Username required' });
  delete userTrackedLinks[username];
  saveUserTrackedLinks();
  const newL = await getOrCreateUserTrackedInviteLink(username);
  res.json({ success: true, link: newL, msg: `New tracked join link generated for ${username}: ${newL}` });
});

// ---------------- RESIDENTIAL PROXY GATEWAY ADMIN ENDPOINTS ----------------
app.get('/api/admin/proxy', (req, res) => {
  const allAccList = Array.from(accounts.values());
  const accountsStatus = allAccList.map((a) => {
    const rawCleanPhone = (a.phone || '').replace(/[^0-9]/g, '');
    let assignedSession = 'None';
    let status = 'direct';
    let proxyHost = 'Direct (VPS IP)';

    if (a.proxy && a.proxy.protocol && a.proxy.protocol !== 'none' && a.proxy.ip) {
      status = 'custom_proxy';
      proxyHost = `${a.proxy.protocol.toUpperCase()}://${a.proxy.ip}:${a.proxy.port}`;
      assignedSession = a.proxy.username || 'Custom';
    } else if (masterProxyConfig.enabled && masterProxyConfig.host && masterProxyConfig.port > 0) {
      status = 'residential_sticky';
      proxyHost = `${masterProxyConfig.protocol.toUpperCase()}://${masterProxyConfig.host}:${masterProxyConfig.port}`;
      assignedSession = masterProxyConfig.auto_sticky_per_phone
        ? `sess_${rawCleanPhone || 'gen'}_${masterProxyConfig.country || 'auto'}`
        : (masterProxyConfig.username || 'Shared');
    }

    return {
      phone: a.phone,
      label: a.label || a.phone,
      owner: a.owner || 'admin',
      running: Boolean(a.running),
      status,
      proxyHost,
      assignedSession,
      daily_dms: (a as any).daily_sent_count || 0,
      total_sent: a.sent_count || 0
    };
  });

  res.json({
    config: masterProxyConfig,
    accounts: accountsStatus,
    summary: {
      total_accounts: allAccList.length,
      proxied_accounts: masterProxyConfig.enabled ? allAccList.length : allAccList.filter(a => a.proxy && a.proxy.protocol !== 'none').length,
      direct_accounts: !masterProxyConfig.enabled ? allAccList.filter(a => !a.proxy || a.proxy.protocol === 'none').length : 0
    }
  });
});

app.post('/api/admin/proxy/save', (req, res) => {
  const data = req.body || {};
  setMasterProxyConfig({
    enabled: Boolean(data.enabled),
    protocol: data.protocol === 'http' ? 'http' : 'socks5',
    host: (data.host || '').trim(),
    port: parseInt(data.port, 10) || 0,
    username: (data.username || '').trim(),
    password: (data.password || '').trim(),
    country: (data.country || '').trim().toLowerCase(),
    session_duration_mins: parseInt(data.session_duration_mins, 10) || 30,
    auto_sticky_per_phone: data.auto_sticky_per_phone !== false
  });

  res.json({
    success: true,
    msg: masterProxyConfig.enabled 
      ? '✅ Residential Proxy Gateway Enabled & Saved! All accounts will route through Sticky Residential Sessions.' 
      : '⚪ Residential Proxy Gateway Disabled. Accounts will connect directly without proxy.'
    ,
    config: masterProxyConfig
  });
});

app.post('/api/admin/proxy/test', (req, res) => {
  const data = req.body || {};
  const host = (data.host || masterProxyConfig.host || '').trim();
  const port = parseInt(data.port || String(masterProxyConfig.port || ''), 10);
  const protocol = data.protocol || masterProxyConfig.protocol || 'socks5';

  if (!host || !port || isNaN(port)) {
    return res.status(400).json({ ok: false, msg: 'Proxy Host and Port are required for testing.' });
  }

  const startTime = Date.now();
  const socket = new net.Socket();
  socket.setTimeout(6000);

  let responded = false;
  socket.connect(port, host, () => {
    if (responded) return;
    responded = true;
    const latency = Date.now() - startTime;
    socket.destroy();
    return res.json({
      ok: true,
      latency,
      msg: `✅ Proxy Gateway Reachable! Connected to ${host}:${port} (${protocol.toUpperCase()}) in ${latency}ms.`
    });
  });

  socket.on('error', (err) => {
    if (responded) return;
    responded = true;
    socket.destroy();
    return res.json({
      ok: false,
      msg: `❌ Proxy Connection Failed: ${err.message || String(err)}`
    });
  });

  socket.on('timeout', () => {
    if (responded) return;
    responded = true;
    socket.destroy();
    return res.json({
      ok: false,
      msg: `❌ Proxy Connection Timed Out after 6 seconds.`
    });
  });
});

// --- VPS SYSTEM HEALTH & SPECS PROFILER (Auto-detects GCP free-tier specs) ---
let gcpMetadataCache: { checked: boolean; isGcp: boolean; machineType: string; zone: string } = { checked: false, isGcp: false, machineType: '', zone: '' };

async function checkGcpMetadata(): Promise<{ isGcp: boolean; machineType: string; zone: string }> {
  if (gcpMetadataCache.checked) return gcpMetadataCache;
  try {
    const res = await fetch('http://metadata.google.internal/computeMetadata/v1/instance/machine-type', {
      headers: { 'Metadata-Flavor': 'Google' },
      signal: AbortSignal.timeout(1200)
    }).catch(() => null);
    if (res && res.ok) {
      const text = await res.text();
      const parts = text.trim().split('/');
      const mType = parts[parts.length - 1] || 'e2-micro';
      gcpMetadataCache = { checked: true, isGcp: true, machineType: mType, zone: 'Google Cloud' };
      return gcpMetadataCache;
    }
  } catch {}
  gcpMetadataCache = { checked: true, isGcp: false, machineType: '', zone: '' };
  return gcpMetadataCache;
}

function getVpsMetrics() {
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const usedMem = Math.max(0, totalMem - freeMem);
  const memPct = totalMem > 0 ? Math.round((usedMem / totalMem) * 100) : 0;

  const cpus = os.cpus() || [];
  const cpuCount = cpus.length || 1;
  const cpuModel = cpus[0]?.model || 'Standard Virtual CPU';
  const cpuSpeed = cpus[0]?.speed ? `${cpus[0].speed} MHz` : '';
  const load = os.loadavg() || [0, 0, 0];
  const cpuPct = Math.min(100, Math.max(0, Math.round((load[0] / Math.max(1, cpuCount)) * 100)));

  let diskTotalBytes = 0;
  let diskUsedBytes = 0;
  let diskFreeBytes = 0;
  let diskPct = 0;

  try {
    const dfOut = execSync('df -k /', { encoding: 'utf8', timeout: 2500 });
    const lines = dfOut.trim().split('\n');
    if (lines.length >= 2) {
      const cols = lines[1].replace(/\s+/g, ' ').split(' ');
      if (cols.length >= 5) {
        diskTotalBytes = (parseInt(cols[1], 10) || 0) * 1024;
        diskUsedBytes = (parseInt(cols[2], 10) || 0) * 1024;
        diskFreeBytes = (parseInt(cols[3], 10) || 0) * 1024;
        const pctStr = cols[4] || '0%';
        diskPct = parseInt(pctStr.replace('%', ''), 10) || (diskTotalBytes > 0 ? Math.round((diskUsedBytes / diskTotalBytes) * 100) : 0);
      }
    }
  } catch {}

  const uptimeSec = os.uptime();
  const days = Math.floor(uptimeSec / 86400);
  const hours = Math.floor((uptimeSec % 86400) / 3600);
  const mins = Math.floor((uptimeSec % 3600) / 60);
  let uptimeFormatted = '';
  if (days > 0) uptimeFormatted += `${days}d `;
  if (hours > 0 || days > 0) uptimeFormatted += `${hours}h `;
  uptimeFormatted += `${mins}m`;

  const totalMemMb = Math.round(totalMem / (1024 * 1024));
  const usedMemMb = Math.round(usedMem / (1024 * 1024));
  const freeMemMb = Math.round(freeMem / (1024 * 1024));

  const totalDiskGb = (diskTotalBytes / (1024 * 1024 * 1024)).toFixed(1);
  const usedDiskGb = (diskUsedBytes / (1024 * 1024 * 1024)).toFixed(1);
  const freeDiskGb = (diskFreeBytes / (1024 * 1024 * 1024)).toFixed(1);

  // Free Tier assessment: Google Cloud e2-micro free tier is 1 GB RAM & 30 GB SSD
  const isGcpFreeTierCandidate = totalMemMb <= 1500; // ~1GB RAM
  const platform = os.platform();
  const release = os.release();
  const arch = os.arch();
  const nodeVersion = process.version;

  return {
    memory: {
      total_bytes: totalMem,
      used_bytes: usedMem,
      free_bytes: freeMem,
      total_formatted: totalMemMb >= 1024 ? `${(totalMemMb / 1024).toFixed(1)} GB` : `${totalMemMb} MB`,
      used_formatted: usedMemMb >= 1024 ? `${(usedMemMb / 1024).toFixed(1)} GB` : `${usedMemMb} MB`,
      free_formatted: freeMemMb >= 1024 ? `${(freeMemMb / 1024).toFixed(1)} GB` : `${freeMemMb} MB`,
      percent: memPct
    },
    cpu: {
      cores: cpuCount,
      model: cpuModel,
      speed: cpuSpeed,
      load_1m: (load[0] || 0).toFixed(2),
      load_5m: (load[1] || 0).toFixed(2),
      load_15m: (load[2] || 0).toFixed(2),
      percent: cpuPct
    },
    disk: {
      total_bytes: diskTotalBytes,
      used_bytes: diskUsedBytes,
      free_bytes: diskFreeBytes,
      total_formatted: `${totalDiskGb} GB`,
      used_formatted: `${usedDiskGb} GB`,
      free_formatted: `${freeDiskGb} GB`,
      percent: diskPct
    },
    uptime: {
      seconds: uptimeSec,
      formatted: uptimeFormatted
    },
    system: {
      platform,
      release,
      arch,
      node_version: nodeVersion,
      is_free_tier_candidate: isGcpFreeTierCandidate,
      free_tier_provider: isGcpFreeTierCandidate ? 'Google Cloud Free Tier (e2-micro 1GB)' : 'Cloud VPS Host'
    }
  };
}

app.get('/api/admin/vps-health', async (req, res) => {
  const vps = getVpsMetrics();
  const gcp = await checkGcpMetadata();
  if (gcp.isGcp && gcp.machineType) {
    vps.system.free_tier_provider = `Google Cloud (${gcp.machineType})`;
    vps.system.is_free_tier_candidate = gcp.machineType === 'e2-micro';
  }
  res.json({
    success: true,
    vps,
    timestamp: Date.now()
  });
});

// 🚀 REAL-TIME RAM & CLIENT CACHE PURGE TRIGGER
app.post('/api/admin/system/optimize-ram', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required' });
  const result = optimizeProcessMemory();
  res.json({
    ok: true,
    msg: `✅ RAM Optimization Completed! Freed memory: ${result.rssBeforeMb}MB ➔ ${result.rssAfterMb}MB (${result.freedAccounts} active bots cleaned).`,
    ...result
  });
});

app.post('/api/admin/user/create', (req         , res          ) => {
  const data = req.body || {};
  const rawUname = (data.username || '').toString().trim();
  const uname = rawUname.replace(/\s+/g, '').toLowerCase();
  const pwd = (data.password || '').toString().trim();
  const sq = (data.security_question || '').toString().trim();
  const sa = (data.security_answer || '').toString().trim().toLowerCase();
  const exp = (data.expiry_date || '').toString().trim();

  if (!uname || !pwd) return res.json({ msg: 'Username and password are both required!' });
  if (!sq || !sa) return res.json({ msg: 'Security Question and Answer are required (for forgot password)!' });

  const maxAcc = Math.max(0, parseInt(data.max_accounts, 10) || 5);
  const maxTar = Math.max(0, parseInt(data.max_targets, 10) || 9999);
  const rawAccessType = (data.access_type || 'both').toString().toLowerCase();
  const validAccessType = (rawAccessType === 'app_only' || rawAccessType === 'web_only' || rawAccessType === 'both') ? rawAccessType : 'both';

  if (getUser(uname)) return res.json({ msg: 'This username already exists!' });

  // Compute calculated expiry based on billing model if expiry_date not explicitly forced
  let effectiveExpiry = exp;
  const billingModel = (data.billing_model || 'none').toString().toLowerCase();
  const bonusDays = Math.max(0, parseInt(data.bonus_days, 10) || 0);
  const ratePerBot = Math.max(1, Number(data.rate_per_bot) || 15);
  const calculatedTotal = ratePerBot * maxAcc;
  const planRate = Math.max(0, Number(data.plan_amount) || calculatedTotal);

  if (billingModel === 'advance' || billingModel === 'postpaid') {
    const totalDays = 7 + bonusDays;
    const expMs = Date.now() + (totalDays * 86400 * 1000) + (5.5 * 3600 * 1000);
    effectiveExpiry = new Date(expMs).toISOString().split('T')[0];
  } else if (billingModel === 'offer') {
    const baseDays = Math.max(1, parseInt(data.validity_days, 10) || 7);
    const totalDays = baseDays + bonusDays;
    const expMs = Date.now() + (totalDays * 86400 * 1000) + (5.5 * 3600 * 1000);
    effectiveExpiry = new Date(expMs).toISOString().split('T')[0];
  }

  usersList.push({
    username: uname,
    password: hashVal(pwd),
    role: 'user',
    active: true,
    access_type: validAccessType,
    last_platform: 'Never',
    max_accounts: maxAcc,
    max_targets: maxTar,
    expiry_date: effectiveExpiry,
    rate_per_bot: ratePerBot,
    billing_model: billingModel,
    security_question: sq,
    security_answer: hashVal(sa),
    alert_enabled: false,
    alert_bot_token: '',
    alert_chat_id: '',
    ai_enabled: Boolean(data.ai_enabled),
    dynamic_templates_enabled: Boolean(data.dynamic_templates_enabled !== false)
  });
  saveUsers();

  // Save user config in billing store
  if (!billingStore.user_configs) billingStore.user_configs = {};
  const cycleDays = Math.max(1, Number(data.billing_cycle_days) || 7);
  billingStore.user_configs[uname] = {
    rate_per_bot: ratePerBot,
    rate_per_day: ratePerBot,
    max_accounts: maxAcc,
    billing_cycle_days: cycleDays,
    payment_model: billingModel,
    notes: `${maxAcc} Bots @ ₹${ratePerBot}/bot/day (${cycleDays} Days ${billingModel})`
  };
  saveBillingLocal();

  // Auto-Khatabook integration for new user
  let billingNote = '';
  try {
    const todayStr = getTodayDateString();
    if (billingModel === 'advance') {
      const chargeAmt = planRate > 0 ? planRate : (ratePerBot * maxAcc);
      const isAdvancePaid = Boolean(data.advance_paid);
      addBillingInvoice({
        username: uname,
        date: todayStr,
        amount: chargeAmt,
        type: 'weekly_plan',
        description: `${cycleDays}-Day Advance Plan (${maxAcc} IDs x ₹${ratePerBot}/bot = ₹${chargeAmt})${bonusDays > 0 ? ` + ${bonusDays} Bonus Days Free` : ''}`,
        bots_count: maxAcc,
        days_count: cycleDays + bonusDays,
        status: isAdvancePaid ? 'paid' : 'due'
      });
      if (isAdvancePaid) {
        addBillingPayment({
          username: uname,
          date: todayStr,
          amount: chargeAmt,
          mode: data.advance_mode || 'UPI',
          reference: data.advance_ref || 'Advance Signup',
          note: `${cycleDays}-Day Advance Paid at account creation (${maxAcc} Bots @ ₹${ratePerBot}/bot)`
        });
        billingNote = ` | ${cycleDays}-Day Advance (₹${chargeAmt} for ${maxAcc} IDs @ ₹${ratePerBot}/bot) Received. Balance: ₹0`;
      } else {
        billingNote = ` | ${cycleDays}-Day Plan Invoice generated: ₹${chargeAmt} (${maxAcc} IDs @ ₹${ratePerBot}/bot) Due`;
      }
    } else if (billingModel === 'postpaid') {
      // 7-Day Postpaid Plan: Dues accrue day-by-day based strictly on LIVE connected bots (not idle slots)
      accrueDailyUsageForUser(uname, todayStr);
      const liveBots = getUserLiveBotsCount(uname);
      const dailyRate = getUserDailyRatePerBot(uname);
      const dailyAmt = liveBots * dailyRate;
      billingNote = ` | 7-Day Postpaid Plan Active: Accrues daily for live bots (${liveBots} Live Bot(s) @ ₹${dailyRate}/bot/day = ₹${dailyAmt}/day)`;
    } else if (billingModel === 'offer') {
      const discount = Math.max(0, Number(data.offer_discount) || 0);
      const baseAmt = planRate > 0 ? planRate : (ratePerBot * maxAcc);
      const finalAmt = Math.max(0, baseAmt - discount);
      const offerName = (data.offer_name || 'Special Promotional Plan').trim();
      addBillingInvoice({
        username: uname,
        date: todayStr,
        amount: finalAmt,
        type: 'weekly_plan',
        description: `Offer: ${offerName} (${maxAcc} IDs x ₹${ratePerBot}/bot${discount > 0 ? ` - ₹${discount} OFF` : ''}${bonusDays > 0 ? ` +${bonusDays} Bonus Days Free` : ''})`,
        bots_count: maxAcc,
        days_count: 7 + bonusDays,
        status: data.advance_paid ? 'paid' : 'due'
      });
      if (data.advance_paid && finalAmt > 0) {
        addBillingPayment({
          username: uname,
          date: todayStr,
          amount: finalAmt,
          mode: data.advance_mode || 'UPI',
          reference: data.advance_ref || 'Offer Signup Payment',
          note: `Offer Payment received at signup (${maxAcc} Bots @ ₹${ratePerBot}/bot)`
        });
        billingNote = ` | Offer Plan (₹${finalAmt}) Paid. Balance: ₹0`;
      } else {
        billingNote = ` | Offer Plan Invoice generated: ₹${finalAmt} Due`;
      }
    }
  } catch (bErr) {
    console.error('Khatabook auto-init error:', bErr);
  }

  broadcastAccountUpdate('admin');

  // Instant notification to Admin Bot when a new user account is created
  try {
    const adminUser = usersList.find((u) => u.role === 'admin');
    if (adminUser?.alert_bot_token && adminUser?.alert_chat_id) {
      const newAccAlert = `👤 <b>NEW USER ACCOUNT CREATED!</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `👤 <b>Username:</b> <code>${uname}</code>\n` +
        `🔑 <b>Password:</b> <code>${pwd}</code>\n` +
        `🤖 <b>Bot Slots:</b> <b>${maxAcc} Bots</b>\n` +
        `📅 <b>Plan Validity:</b> <b>${cycleDays} Days</b> (Expires: <code>${formatDisplayDate(effectiveExpiry)}</code>)\n` +
        `💳 <b>Billing Model:</b> <b>${billingModel.toUpperCase()}</b> (@ ₹${ratePerBot}/bot)\n` +
        `🌐 <b>Access Mode:</b> <b>${validAccessType.toUpperCase()}</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `🕒 <i>Created on ${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })} IST</i>`;
      sendTelegramMessage(adminUser.alert_bot_token, adminUser.alert_chat_id, newAccAlert).catch(() => null);
    }
  } catch {}

  res.json({ msg: `User "${uname}" created successfully! [Access: ${validAccessType.toUpperCase()}] [Valid till: ${effectiveExpiry || 'Unlimited'}]${billingNote} Login: ${uname} / ${pwd}` });
});

app.post('/api/admin/user/update', async (req         , res          ) => {
  const data = req.body || {};
  const uname = data.username;
  const u = getUser(uname);
  if (!u) return res.json({ msg: 'User not found!' });

  if ('active' in data) {
    if (uname === 'admin') return res.json({ msg: 'Admin cannot be disabled!' });
    u.active = Boolean(data.active);
  }

  if ('access_type' in data) {
    const rawAt = (data.access_type || 'both').toString().toLowerCase();
    if (rawAt === 'app_only' || rawAt === 'web_only' || rawAt === 'both') {
      u.access_type = rawAt;
    }
  }

  const newPwd = (data.password || '').trim();
  if (newPwd) {
    u.password = hashVal(newPwd);
  }

  const oldRate = Number(u.rate_per_bot) || 15;
  const oldMaxAcc = Number(u.max_accounts) || 5;

  if ('max_accounts' in data) {
    u.max_accounts = Math.max(0, parseInt(data.max_accounts, 10) || 0);
  }
  if ('max_targets' in data) {
    u.max_targets = Math.max(0, parseInt(data.max_targets, 10) || 0);
  }
  if ('expiry_date' in data) {
    u.expiry_date = data.expiry_date; // YYYY-MM-DD
  }

  if ('alert_enabled' in data) {
    u.alert_enabled = Boolean(data.alert_enabled);
  }
  if ('alert_bot_token' in data) {
    u.alert_bot_token = (data.alert_bot_token || '').trim();
    if (u.alert_bot_token && (u.role === 'admin' || u.username === 'admin')) {
      try {
        const getMeResp = await fetch(`https://api.telegram.org/bot${u.alert_bot_token}/getMe`, { signal: AbortSignal.timeout(4000) });
        const d: any = await getMeResp.json();
        if (d?.ok && d.result?.username) {
          u.alert_bot_username = d.result.username;
          cachedAdminBotUsername = d.result.username;
          console.log(`[ADMIN BOT CACHED]: @${d.result.username}`);
        }
      } catch (err) {}
    }
  }
  if ('alert_chat_id' in data) {
    u.alert_chat_id = (data.alert_chat_id || '').trim();
  }

  let rateChanged = false;
  if ('rate_per_bot' in data) {
    const newR = Math.max(1, Number(data.rate_per_bot) || 15);
    if (newR !== oldRate) {
      rateChanged = true;
      u.rate_per_bot = newR;
    }
  }
  const botsChanged = (u.max_accounts !== oldMaxAcc);

  if (rateChanged || botsChanged) {
    if (!billingStore.user_configs) billingStore.user_configs = {};
    if (!billingStore.user_configs[uname]) billingStore.user_configs[uname] = {} as any;
    billingStore.user_configs[uname].rate_per_bot = u.rate_per_bot;
    billingStore.user_configs[uname].rate_per_day = u.rate_per_bot;
    billingStore.user_configs[uname].max_accounts = u.max_accounts ?? 5;

    const newRate = u.rate_per_bot;
    const newBots = u.max_accounts ?? 5;
    const newTotal = Math.round(newRate * newBots);

    // DYNAMIC BILLING SYNC: Update active cycle invoice so due balance adjusts instantly!
    if (Array.isArray(billingStore.invoices)) {
      const activeInv = billingStore.invoices
        .slice()
        .reverse()
        .find(i => i.username === uname && (i.type === 'weekly_plan' || i.type === 'subscription'));

      if (activeInv) {
        const oldAmt = activeInv.amount;
        activeInv.amount = newTotal;
        activeInv.bots_count = newBots;
        activeInv.description = `${activeInv.days_count || 7}-Day Plan (${newBots} IDs x ₹${newRate}/bot = ₹${newTotal})`;
        console.log(`[KHATABOOK RATE ADJUST]: User ${uname} rate/bots changed! Updated active invoice from ₹${oldAmt} to ₹${newTotal}`);
      } else {
        addBillingInvoice({
          username: uname,
          date: getTodayDateString(),
          amount: newTotal,
          type: 'weekly_plan',
          description: `Plan Updated: ${newBots} IDs x ₹${newRate}/bot = ₹${newTotal}`,
          bots_count: newBots,
          days_count: 7,
          status: 'due'
        });
      }
    }
    saveBillingLocal();
  }
  if ('billing_model' in data) {
    u.billing_model = (data.billing_model || 'advance').toString().toLowerCase();
  }

  const newQ = (data.security_question || '').trim();
  if (newQ) u.security_question = newQ;

  const newA = (data.security_answer || '').trim().toLowerCase();
  if (newA) u.security_answer = hashVal(newA);

  saveUsers();
  broadcastAccountUpdate(uname);
  broadcastAccountUpdate('admin');
  res.json({
    ok: true,
    msg: `${uname} updated successfully!`,
    bot_username: u.alert_bot_username || cachedAdminBotUsername || '',
    telegram_url: (u.alert_bot_username || cachedAdminBotUsername) ? `https://t.me/${u.alert_bot_username || cachedAdminBotUsername}?start=register` : ''
  });
});

app.post('/api/admin/user/edit-ai', (req, res) => {
  const data = req.body || {};
  const uname = data.username;
  const u = getUser(uname);
  if (!u) return res.json({ msg: 'User not found!' });
  
  if ('ai_enabled' in data) {
    u.ai_enabled = Boolean(data.ai_enabled);
  }
  if ('dynamic_templates_enabled' in data) {
    u.dynamic_templates_enabled = Boolean(data.dynamic_templates_enabled);
  }
  
  saveUsers();
  broadcastAccountUpdate(uname);
  broadcastAccountUpdate('admin');
  res.json({ 
    ok: true,
    msg: `Settings updated for ${uname}!`,
    ai_enabled: u.ai_enabled === true,
    dynamic_templates_enabled: u.dynamic_templates_enabled !== false
  });
});

app.post('/api/admin/user/test-alert', async (req, res) => {
  const data = req.body || {};
  const uname = (data.username || '').trim();
  const botToken = (data.bot_token || '').trim();
  const chatId = (data.chat_id || '').trim();

  if (!botToken || !chatId) {
    return res.status(400).json({ msg: 'Bot Token and Chat ID are both required!' });
  }

  try {
    const testMsg = `🔔 <b>Telebot Alert System Test</b>\n\n` +
      `✅ Hello! Telegram alert notifications have been configured by Admin for user: <b>${uname || 'Unknown'}</b>.\n\n` +
      `⚡ You will receive real-time updates for:\n` +
      `• Daily DM & Extraction milestones\n` +
      `• Telegram FloodWait pauses\n` +
      `• Session login/logout events\n\n` +
      `🕒 <i>Time: ${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })} (IST)</i>`;

    const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text: testMsg,
        parse_mode: 'HTML'
      })
    });

    const json = await response.json();
    if (json.ok) {
      return res.json({ msg: '✅ Test notification sent successfully to Telegram!' });
    } else {
      return res.status(400).json({ msg: `❌ Telegram API error: ${json.description || 'Invalid token or chat ID'}` });
    }
  } catch (err) {
    return res.status(500).json({ msg: `❌ Failed to send test alert: ${err?.message || err}` });
  }
});

async function permanentlyDeleteUser(uname: string): Promise<void> {
  const normUname = uname.trim();
  console.log(`[PERMANENT DELETE USER] Deleting user "${normUname}" and all associated data from VPS...`);

  // 1. Find all accounts belonging to this user and permanently delete them
  const userAccounts = Array.from(accounts.values()).filter(
    (a) => (a.owner || 'admin').toLowerCase() === normUname.toLowerCase()
  );
  for (const acc of userAccounts) {
    await permanentlyDeleteAccount(acc.phone);
  }

  // 2. Remove user from usersList and persist users.json
  const userIdx = usersList.findIndex((u) => u.username.toLowerCase() === normUname.toLowerCase());
  if (userIdx !== -1) {
    usersList.splice(userIdx, 1);
    saveUsers();
  }

  // 2.5. Preserve and transfer any remaining user-level queue, sent data, and peer files to Admin before deletion
  if (normUname.toLowerCase() !== 'admin') {
    try {
      const uSent = getOwnerSentUsers(normUname);
      const adminSent = getOwnerSentUsers('admin');
      for (const uid of uSent) adminSent.add(uid);
      ownerSentCache.set('admin', adminSent);
      fs.writeFileSync(path.join(__dirname, `sent_owner_admin.json`), JSON.stringify(Array.from(adminSent)), 'utf8');

      const uPeers = getOwnerPeers(normUname);
      const adminPeers = getOwnerPeers('admin');
      for (const [k, v] of uPeers.entries()) adminPeers.set(k, v);
      saveOwnerPeers('admin', adminPeers);

      const uVerifiedQ = getOwnerVerifiedQueue(normUname);
      if (uVerifiedQ.length > 0) {
        addToOwnerVerifiedQueue('admin', uVerifiedQ);
      }
      console.log(`[PERMANENT DELETE USER] Transferred ${uSent.size} Sent, ${uVerifiedQ.length} Genuine Queue, and ${uPeers.size} Peers from user "${normUname}" to Admin.`);
    } catch (e) {
      console.error(`[PERMANENT DELETE USER] Error preserving data to admin:`, e);
    }
  }

  // 3. Delete user-level queue and sent files from disk
  const userFiles = [
    path.join(__dirname, `sent_owner_${normUname}.json`),
    path.join(__dirname, `skipped_owner_${normUname}.json`),
    path.join(__dirname, `skipped_db_owner_${normUname}.json`),
    path.join(__dirname, `raw_queue_owner_${normUname}.json`),
    path.join(__dirname, `verified_queue_owner_${normUname}.json`),
    path.join(__dirname, `queue_owner_${normUname}.json`),
    path.join(__dirname, `peers_owner_${normUname}.json`)
  ];
  for (const f of userFiles) {
    try {
      if (fs.existsSync(f)) {
        fs.unlinkSync(f);
        console.log(`[PERMANENT DELETE USER] Deleted file: ${f}`);
      }
    } catch {}
  }

  // 4. Clean user caches from memory
  ownerSentCache.delete(normUname);
  ownerSkippedCache.delete(normUname);
  ownerSkippedDetailsCache.delete(normUname);
  ownerPeersCache.delete(normUname);
  ownerRawQueueCache.delete(normUname);
  ownerRawReservedUids.delete(normUname);
  ownerVerifiedQueueCache.delete(normUname);
  ownerVerifiedReservedUids.delete(normUname);
  delete (dailyDmHistory as any)[normUname];
  delete (aiDmHistory as any)[normUname];

  // 5. Clean any slot requests from this user
  if (Array.isArray(slotRequests)) {
    slotRequests = slotRequests.filter((r) => r.username.toLowerCase() !== normUname.toLowerCase());
    saveSlotRequests();
  }

  // 6. Clean from billing user configs
  if (billingStore.user_configs && billingStore.user_configs[normUname]) {
    delete billingStore.user_configs[normUname];
    saveBillingLocal();
  }

  saveAccountsJson();
}

app.post('/api/admin/user/delete', async (req: any, res: any) => {
  if (!isAdminSession(req)) {
    return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  }
  const rawUname = req.body?.username;
  if (!rawUname) return res.status(400).json({ ok: false, msg: 'Username is required!' });
  const uname = String(rawUname).trim();
  if (uname.toLowerCase() === 'admin') return res.status(400).json({ ok: false, msg: 'Admin cannot be deleted!' });

  // Auto-stop any running accounts for this user before deletion
  const userAccounts = Array.from(accounts.values()).filter((a) => (a.owner || 'admin').toLowerCase() === uname.toLowerCase());
  for (const a of userAccounts) {
    a.running = false;
    a.status = 'Stopped';
    if (a.abortController) {
      try { a.abortController.abort(); } catch {}
    }
  }

  await permanentlyDeleteUser(uname);
  broadcastAccountUpdate('admin');
  res.json({ ok: true, success: true, msg: `User "${uname}" and all associated data permanently deleted from Server & Backend Storage!` });
});

app.post('/api/admin/user/renew-subscription', async (req: any, res: any) => {
  if (!isAdminSession(req)) {
    return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  }
  const { username, days, rate_per_bot, max_accounts, mark_paid, payment_mode, notes } = req.body || {};
  if (!username) return res.status(400).json({ ok: false, msg: 'Username is required!' });
  const u = getUser(username);
  if (!u) return res.status(404).json({ ok: false, msg: 'User not found!' });

  const renewDays = Math.max(1, parseInt(days, 10) || 7);
  const botsCount = max_accounts !== undefined ? Math.max(1, parseInt(max_accounts, 10) || 5) : (u.max_accounts ?? 5);
  const rate = rate_per_bot !== undefined ? Math.max(1, Number(rate_per_bot) || 15) : (u.rate_per_bot || 15);
  const totalAmount = Math.round(rate * botsCount * (renewDays / 7));

  const todayStr = getTodayDateString();
  let baseMs = Date.now();
  if (u.expiry_date && u.expiry_date > todayStr) {
    try {
      const parts = u.expiry_date.split('-');
      if (parts.length === 3) {
        baseMs = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10)).getTime();
      }
    } catch {}
  }
  const nextExpMs = baseMs + (renewDays * 86400 * 1000) + (5.5 * 3600 * 1000);
  const newExpDate = new Date(nextExpMs).toISOString().split('T')[0];

  u.expiry_date = newExpDate;
  u.active = true;
  u.rate_per_bot = rate;
  u.max_accounts = botsCount;
  saveUsers();

  if (!billingStore.user_configs) billingStore.user_configs = {};
  billingStore.user_configs[u.username] = {
    rate_per_bot: rate,
    rate_per_day: rate,
    max_accounts: botsCount,
    billing_model: u.billing_model || 'advance',
    notes: `${botsCount} Bots @ ₹${rate}/bot/day`
  };
  saveBillingLocal();

  const isPaid = mark_paid !== false;
  const desc = `${renewDays}-Day Plan (${botsCount} Bots x ₹${rate}/bot = ₹${totalAmount})`;
  addBillingInvoice({
    username: u.username,
    date: todayStr,
    amount: totalAmount,
    type: 'weekly_plan',
    description: desc + (notes ? ` - ${notes}` : ''),
    bots_count: botsCount,
    days_count: renewDays,
    status: isPaid ? 'paid' : 'due'
  });

  if (isPaid) {
    addBillingPayment({
      username: u.username,
      date: todayStr,
      amount: totalAmount,
      mode: payment_mode || 'UPI',
      reference: 'Renewal-' + todayStr,
      note: `${desc} Payment Received`
    });
  }

  broadcastAccountUpdate(u.username);
  broadcastAccountUpdate('admin');
  res.json({
    ok: true,
    success: true,
    msg: `Successfully renewed ${u.username} for ${renewDays} days! New expiry: ${newExpDate}. Invoice of ₹${totalAmount} recorded.`,
    expiry_date: newExpDate,
    rate_per_bot: rate,
    max_accounts: botsCount,
    amount: totalAmount
  });
});

app.post('/api/admin/change-password', (req, res) => {
  const data = req.body || {};
  const currentUsername = req.session?.username || 'admin';
  const me = getUser(currentUsername) || getUser('admin');
  if (!me) return res.status(401).json({ msg: 'Session error, please login again!' });

  if (!verifyVal(me.password, data.old_password || '')) {
    return res.status(401).json({ msg: 'Old password is wrong!' });
  }

  const nextPwd = (data.new_password || '').trim();
  if (nextPwd.length < 6) {
    return res.json({ msg: 'New password must be at least 6 characters!' });
  }

  me.password = hashVal(nextPwd);
  saveUsers();
  res.json({ ok: true, success: true, msg: 'Password changed successfully! Remember your new password.' });
});

app.get('/api/admin/profile', (req, res) => {
  const adminUser = usersList.find((u: any) => u.role === 'admin' || u.username === 'admin');
  const adminName = adminUser?.admin_name || adminUser?.display_name || 'Admin';
  res.json({ admin_name: adminName });
});

app.get('/api/public/admin-contact', async (req, res) => {
  const adminUser = usersList.find((u: any) => u.role === 'admin' || u.username === 'admin');
  let botUsername = (adminUser as any)?.alert_bot_username || cachedAdminBotUsername || '';
  const token = (adminUser?.alert_bot_token || '').trim();
  if (!botUsername && token) {
    try {
      const resp = await fetch(`https://api.telegram.org/bot${token}/getMe`, { signal: AbortSignal.timeout(3500) });
      const data: any = await resp.json();
      if (data?.ok && data?.result?.username) {
        botUsername = data.result.username;
        (adminUser as any).alert_bot_username = botUsername;
        cachedAdminBotUsername = botUsername;
        saveUsers();
      }
    } catch (e) {}
  }
  const telegramUrl = botUsername ? `https://t.me/${botUsername}?start=register` : (adminUser?.telegram_username ? `https://t.me/${adminUser.telegram_username}` : '');
  res.json({ ok: true, bot_username: botUsername, telegram_url: telegramUrl });
});

app.post('/api/telegram-webhook', async (req, res) => {
  const adminUser = usersList.find((u: any) => u.role === 'admin');
  const token = (req.query.token as string) || (adminUser?.alert_bot_token || '').trim();
  if (!token) return res.status(400).json({ ok: false, msg: 'No bot token configured!' });
  try {
    await handleTelegramUpdate(token, req.body);
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err?.message });
  }
});

app.post('/api/admin/profile', (req, res) => {
  const adminUser = usersList.find((u: any) => u.role === 'admin' || u.username === 'admin');
  if (!adminUser) return res.status(404).json({ msg: 'Admin user not found!' });
  if (req.body?.admin_name !== undefined) {
    const newName = (req.body.admin_name || '').trim();
    if (newName) {
      adminUser.admin_name = newName;
      adminUser.display_name = newName;
    }
  }
  if (req.body?.custom_web_url !== undefined) {
    let rawUrl = (req.body.custom_web_url || '').trim();
    if (rawUrl && !rawUrl.startsWith('http://') && !rawUrl.startsWith('https://')) {
      rawUrl = 'https://' + rawUrl;
    }
    adminUser.custom_web_url = rawUrl.replace(/\/$/, '');
  }
  saveUsers();
  res.json({
    ok: true,
    msg: 'Profile & Live Website URL updated successfully!',
    admin_name: adminUser.admin_name,
    custom_web_url: adminUser.custom_web_url || '',
    active_login_url: getWebLoginUrl()
  });
});

app.get('/api/admin/system-domain', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  const adminUser = usersList.find((u: any) => u.role === 'admin' || u.username === 'admin');
  res.json({
    ok: true,
    custom_web_url: adminUser?.custom_web_url || '',
    active_login_url: getWebLoginUrl(),
    detected_host: globalDetectedWebUrl || ''
  });
});

// ---------------- ADMIN ACCOUNT SLOT & APPROVAL MANAGEMENT ----------------
app.get('/api/admin/slot-requests', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  res.json({ ok: true, requests: slotRequests });
});

app.post('/api/admin/slot-request/approve', async (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  const { id } = req.body || {};
  const item = slotRequests.find((r) => r.id === id);
  if (!item) return res.status(404).json({ ok: false, msg: 'Request not found!' });
  if (item.status !== 'pending') return res.json({ ok: false, msg: `Request is already ${item.status}!` });

  item.status = 'approved';
  item.resolved_at = Date.now();
  item.resolved_by = 'Admin Web Panel';
  saveSlotRequests();

  const u = getUser(item.username);
  if (u) {
    u.max_accounts = Math.max((u.max_accounts || 5) + 1, (u.registered_phones?.length || 0) + 1);
    if (!Array.isArray(u.registered_phones)) u.registered_phones = [];
    if (!u.registered_phones.includes(item.phone)) {
      u.registered_phones.push(item.phone);
    }
    saveUsers();
    broadcastAccountUpdate(u.username);

    if (u.alert_enabled) {
      sendTelegramAlert(u.username, `🎉 <b>Admin Approved Your Account Slot Request!</b>\nSuper Admin has approved your request for <code>${item.phone}</code>.\nYou can now connect this Telegram account in your dashboard!`);
    }
  }

  broadcastAccountUpdate('admin');
  res.json({ ok: true, msg: `Approved slot for ${item.phone} (User: ${item.username})! Allowed limit updated to ${u?.max_accounts || 5} slots.` });
});

app.post('/api/admin/slot-request/reject', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  const { id } = req.body || {};
  const item = slotRequests.find((r) => r.id === id);
  if (!item) return res.status(404).json({ ok: false, msg: 'Request not found!' });
  if (item.status !== 'pending') return res.json({ ok: false, msg: `Request is already ${item.status}!` });

  item.status = 'rejected';
  item.resolved_at = Date.now();
  item.resolved_by = 'Admin Web Panel';
  saveSlotRequests();

  const u = getUser(item.username);
  if (u && u.alert_enabled) {
    sendTelegramAlert(u.username, `❌ <b>Slot Request Rejected</b>\nAdmin has rejected your request to add <code>${item.phone}</code>.`);
  }

  broadcastAccountUpdate('admin');
  res.json({ ok: true, msg: `Rejected slot request for ${item.phone}.` });
});

app.post('/api/admin/user/release-slot', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  const { username, phone } = req.body || {};
  const u = getUser(username);
  if (!u) return res.status(404).json({ ok: false, msg: 'User not found!' });

  if (Array.isArray(u.registered_phones)) {
    const prevLen = u.registered_phones.length;
    u.registered_phones = u.registered_phones.filter((p: string) => p !== phone);
    if (u.registered_phones.length !== prevLen) {
      saveUsers();
      broadcastAccountUpdate(u.username);
      broadcastAccountUpdate('admin');
      return res.json({ ok: true, msg: `Slot for ${phone} released! ${u.username} can now add 1 fresh account.` });
    }
  }
  res.json({ ok: false, msg: `Phone ${phone} was not found in registered slots for ${username}.` });
});

app.post('/api/admin/user/reset-slots', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  const { username } = req.body || {};
  const u = getUser(username);
  if (!u) return res.status(404).json({ ok: false, msg: 'User not found!' });

  const activeUserPhones: string[] = [];
  for (const a of accounts.values()) {
    if ((a.owner || 'admin') === u.username && a.phone) {
      activeUserPhones.push(a.phone);
    }
  }
  u.registered_phones = activeUserPhones;
  saveUsers();
  broadcastAccountUpdate(u.username);
  broadcastAccountUpdate('admin');
  res.json({ ok: true, msg: `Registered slots for ${u.username} reset to currently active IDs only (${activeUserPhones.length} slots).` });
});

// ---------------- ADMIN CUSTOMER ACCESS / ONBOARDING REQUESTS ----------------
app.get('/api/admin/access-requests', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  const formatted = accessRequests.map((r: any) => ({
    ...r,
    customer_name: r.full_name,
    telegram_chat_id: r.chat_id,
    bot_count: r.bots_count,
    created_at: r.requested_at
  }));
  res.json({ ok: true, success: true, requests: formatted, pending: formatted.filter((r: any) => r.status === 'pending') });
});

app.post('/api/admin/access-request/approve', async (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  const { id } = req.body || {};
  const item = accessRequests.find((r) => r.id === id);
  if (!item) return res.status(404).json({ ok: false, msg: 'Request not found!' });
  if (item.status !== 'pending') return res.json({ ok: false, msg: `Request is already ${item.status}!` });

  const adminUser = usersList.find((u: any) => u.role === 'admin');
  const botToken = adminUser?.alert_bot_token || '';
  const webLoginUrl = getWebLoginUrl();

  // A. VALIDITY EXTENSION APPROVAL
  if (item.type === 'extend_validity') {
    const u = getUser(item.target_username || '');
    if (!u) return res.status(404).json({ ok: false, msg: `Target user "${item.target_username}" not found!` });

    const days = Number(item.validity_days || 30);
    let curExpMs = Date.now() + 5.5 * 3600 * 1000;
    if (u.expiry_date) {
      const parsed = new Date(u.expiry_date + 'T23:59:59Z').getTime();
      if (!isNaN(parsed) && parsed > curExpMs) curExpMs = parsed;
    }
    const newExpMs = curExpMs + (days * 86400 * 1000);
    const newExpDateStr = new Date(newExpMs).toISOString().split('T')[0];

    u.expiry_date = newExpDateStr;
    u.active = true;
    saveUsers();
    // Auto-Billing Hook: Validity Extension
    try {
      const userRate = getUserEffectiveRate(u.username);
      const userBots = Number(u.max_accounts || 1);
      const extCost = days * userRate * userBots;
      addBillingInvoice({
        username: u.username,
        date: getTodayDateString(),
        type: 'extend_validity',
        description: `Validity Renewal (+${days} Days for ${userBots} IDs @ ₹${userRate}/day)`,
        bots_count: userBots,
        days_count: days,
        amount: extCost,
        status: 'due'
      });
    } catch (e) {
      console.error('[BILLING HOOK ERROR]', e);
    }

    item.status = 'approved';
    item.resolved_at = Date.now();
    item.resolved_by = 'Admin Web Panel';
    saveAccessRequests();

    if (botToken && item.chat_id) {
      const custMsg = `🎉 <b>Account Validity Extension Approved!</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `Your account validity has been successfully extended by Administrator.\n\n` +
        `👤 <b>Username:</b> <code>${u.username}</code>\n` +
        `⏳ <b>Added Validity:</b> <b>+${days} Days</b>\n` +
        `📅 <b>New Expiry Date:</b> <b>${formatDisplayDate(newExpDateStr)}</b>\n\n` +
        `🌐 <b>Dashboard:</b> ${webLoginUrl}`;
      sendTelegramMessage(botToken, item.chat_id, custMsg, [
        [{ text: '🌐 Open Dashboard', url: webLoginUrl }]
      ]).catch(() => {});
    }

    return res.json({
      ok: true,
      success: true,
      msg: `Validity extended by +${days} days for "${u.username}". New Expiry: ${formatDisplayDate(newExpDateStr)}.`,
      username: u.username,
      expiry_date: newExpDateStr
    });
  }

  // B. EXTRA BOTS QUOTA APPROVAL
  if (item.type === 'add_bots') {
    const u = getUser(item.target_username || '');
    if (!u) return res.status(404).json({ ok: false, msg: `Target user "${item.target_username}" not found!` });

    const added = Number(item.bots_count || 1);
    u.max_accounts = Number(u.max_accounts || 1) + added;
    saveUsers();
    // Auto-Billing Hook: Extra Bot Slots (Prorated for remaining days)
    try {
      const userRate = getUserEffectiveRate(u.username);
      let remDays = 30;
      if (u.expiry_date) {
        const expMs = new Date(u.expiry_date + 'T23:59:59Z').getTime();
        const nowMs = Date.now();
        if (expMs > nowMs) {
          remDays = Math.max(1, Math.ceil((expMs - nowMs) / (86400 * 1000)));
        }
      }
      const slotCost = added * userRate * remDays;
      addBillingInvoice({
        username: u.username,
        date: getTodayDateString(),
        type: 'add_bots',
        description: `Added +${added} Bot Slots (${remDays} days remaining in cycle @ ₹${userRate}/day)`,
        bots_count: added,
        days_count: remDays,
        amount: slotCost,
        status: 'due'
      });
    } catch (e) {
      console.error('[BILLING HOOK ERROR]', e);
    }

    item.status = 'approved';
    item.resolved_at = Date.now();
    item.resolved_by = 'Admin Web Panel';
    saveAccessRequests();

    if (botToken && item.chat_id) {
      const custMsg = `🎉 <b>Extra Bot Slots Approved!</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `Your bot slot quota has been successfully increased by Administrator.\n\n` +
        `👤 <b>Username:</b> <code>${u.username}</code>\n` +
        `➕ <b>Added Slots:</b> <b>+${added} Accounts</b>\n` +
        `🤖 <b>New Total Quota:</b> <b>${u.max_accounts} Bots</b>\n\n` +
        `You can now login to your dashboard and connect your new Telegram accounts!\n` +
        `🌐 <b>Dashboard:</b> ${webLoginUrl}`;
      sendTelegramMessage(botToken, item.chat_id, custMsg, [
        [{ text: '🌐 Open Dashboard', url: webLoginUrl }]
      ]).catch(() => {});
    }

    return res.json({
      ok: true,
      success: true,
      msg: `Approved +${added} extra bot slots for "${u.username}". Total Quota: ${u.max_accounts} Bots.`,
      username: u.username,
      max_accounts: u.max_accounts
    });
  }

  // C. NEW USER ACCOUNT CREATION
  // 1. Generate unique username
  let base = (item.telegram_username || item.full_name || 'user')
    .toLowerCase()
    .replace(/[^a-z0-9_]/g, '')
    .slice(0, 12);
  if (!base || base.length < 3) base = 'user';
  let generatedUsername = base;
  let attempt = 0;
  while (usersList.some((u: any) => (u.username || '').toLowerCase() === generatedUsername.toLowerCase())) {
    attempt++;
    generatedUsername = `${base}${Math.floor(100 + Math.random() * 900)}`;
    if (attempt > 50) {
      generatedUsername = `user_${Date.now().toString().slice(-5)}`;
      break;
    }
  }

  // 2. Generate secure temporary password
  const generatedPassword = 'Tele@' + Math.floor(1000 + Math.random() * 9000);

  // 3. Compute Expiry Date (IST) - 7 Days (1-Week Billing)
  const initialBots = Math.max(1, Number(req.body?.bots_count) || Number(item.bots_count || 1));
  const ratePerBot = Number(req.body?.rate_per_bot) || Number(item.rate_per_bot) || 10;
  const planModel = req.body?.payment_model || item.payment_model || 'postpaid';
  const cycleDays = 7;
  const planCost = Math.round(initialBots * ratePerBot);

  const expDateMs = Date.now() + 5.5 * 3600 * 1000 + (cycleDays * 86400 * 1000);
  const expDateStr = new Date(expDateMs).toISOString().split('T')[0];

  // 4. Create User
  const newUser: any = {
    username: generatedUsername,
    password: hashVal(generatedPassword),
    role: 'user',
    active: true,
    max_accounts: initialBots,
    max_targets: 9999,
    expiry_date: expDateStr,
    rate_per_bot: ratePerBot,
    billing_model: planModel,
    billing_cycle_days: cycleDays,
    registered_phones: [],
    security_question: 'What is your registered mobile number?',
    security_answer: hashVal((item.phone || '').trim()),
    alert_enabled: true,
    alert_bot_token: botToken,
    alert_chat_id: item.chat_id,
    display_name: item.full_name
  };

  usersList.push(newUser);
  saveUsers();

  // Auto-Billing Hook: New Account 7-Day Plan
  try {
    if (!billingStore.user_configs) billingStore.user_configs = {};
    billingStore.user_configs[generatedUsername] = {
      rate_per_bot: ratePerBot,
      rate_per_day: ratePerBot,
      max_accounts: initialBots,
      billing_cycle_days: cycleDays,
      payment_model: planModel,
      notes: `${initialBots} Bots @ ₹${ratePerBot}/bot/day (${cycleDays} Days ${planModel})`
    };

    addBillingInvoice({
      username: generatedUsername,
      date: getTodayDateString(),
      type: 'weekly_plan',
      description: `${cycleDays}-Day ${planModel === 'postpaid' ? 'Postpaid' : 'Advance'} Plan (${initialBots} IDs x ₹${ratePerBot}/bot = ₹${planCost})`,
      bots_count: initialBots,
      days_count: cycleDays,
      amount: planCost,
      status: 'due'
    });
    saveBillingLocal();
  } catch (e) {
    console.error('[BILLING HOOK ERROR]', e);
  }
  broadcastAccountUpdate('admin');

  item.status = 'approved';
  item.resolved_at = Date.now();
  item.resolved_by = 'Admin Web Panel';
  item.created_username = generatedUsername;
  item.created_password = generatedPassword;
  item.rate_per_bot = ratePerBot;
  item.payment_model = planModel;
  saveAccessRequests();

  // 5. Dispatch Telegram alert to customer in easy English
  if (botToken && item.chat_id) {
    const customerMsg = `🎉 <b>Congratulations! Your TeleBot Account is Approved!</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `Your account login credentials and subscription details:\n\n` +
      `👤 <b>Username:</b> <code>${generatedUsername}</code>\n` +
      `🔑 <b>Password:</b> <code>${generatedPassword}</code>\n` +
      `🌐 <b>Login URL:</b> ${webLoginUrl}\n\n` +
      `📋 <b>Subscription Terms:</b>\n` +
      `• <b>Allowed Bots:</b> ${initialBots} Bot(s)\n` +
      `• <b>Rate Per Bot:</b> ₹${ratePerBot} / bot\n` +
      `• <b>Weekly Bill:</b> ₹${planCost}\n` +
      `• <b>Billing Plan:</b> ${planModel === 'postpaid' ? '7-Day Postpaid (Payment due on 8th day)' : '7-Day Advance Plan'}\n` +
      `• <b>Valid Till:</b> ${formatDisplayDate(expDateStr)} (7 Days)\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `💳 <i>Send <code>/bill</code> anytime to view your live balance and invoices.</i>\n` +
      `🔒 <i>For your security, please login and change your password.</i>`;

    sendTelegramMessage(botToken, item.chat_id, customerMsg, [
      [{ text: '🌐 Open Website & Login', url: webLoginUrl }],
      [{ text: '📊 View My Bill / Ledger', callback_data: `cust_view_bill:${generatedUsername}` }]
    ]).catch(() => {});
  }

  res.json({
    ok: true,
    success: true,
    msg: `Approved! Created user: "${generatedUsername}" with password "${generatedPassword}". Credentials sent to customer Telegram.`,
    username: generatedUsername,
    password: generatedPassword,
    expiry_date: expDateStr
  });
});

app.post('/api/admin/access-request/reject', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  const { id } = req.body || {};
  const item = accessRequests.find((r) => r.id === id);
  if (!item) return res.status(404).json({ ok: false, msg: 'Request not found!' });
  if (item.status !== 'pending') return res.json({ ok: false, msg: `Request is already ${item.status}!` });

  item.status = 'rejected';
  item.resolved_at = Date.now();
  item.resolved_by = 'Admin Web Panel';
  saveAccessRequests();

  const adminUser = usersList.find((u: any) => u.role === 'admin');
  const botToken = adminUser?.alert_bot_token || '';
  if (botToken && item.chat_id) {
    const custRejectMsg = item.type === 'extend_validity'
      ? `⚠️ <b>Validity Extension Request Update</b>\n\nYour request for validity extension was not approved at this time.\nFor questions or further assistance, please contact the Administrator directly.`
      : item.type === 'add_bots'
      ? `⚠️ <b>Extra Bot Slots Request Update</b>\n\nYour request for additional bot slots was not approved at this time.\nFor custom quotas or plan details, please contact the Administrator directly.`
      : `⚠️ <b>Account Access Request Update</b>\n\nYour new user access request was not approved by the Administrator.\nIf you have any questions or wish to discuss subscription plans, please reach out to the Administrator.`;

    sendTelegramMessage(botToken, item.chat_id, custRejectMsg).catch(() => {});
  }

  res.json({ ok: true, msg: `Rejected request for ${item.full_name}.` });
});

app.post('/api/admin/view-as', (req         , res          ) => {
  const uname = (req.body?.username || '').trim();
  if (!uname) {
    if (req.session) req.session.view_as = null;
    return res.json({ msg: 'Back to admin view' });
  }

  const u = getUser(uname);
  if (!u) return res.json({ msg: 'User not found!' });
  if (uname !== req.session?.username && !u.active) {
    return res.json({ msg: 'User is disabled, activate them first!' });
  }

  if (req.session) {
    req.session.view_as = uname;
  }
  res.json({ msg: `Now opening "${uname}" dashboard...` });
});

// ---------------- ADMIN QUEUE MANAGEMENT APIS ----------------
app.get('/api/admin/user-queues', (req         , res          ) => {
  const result        = [];
  const targetUser = req.query?.username ? String(req.query.username).trim() : '';

  for (const u of usersList) {
    if (targetUser && u.username !== targetUser) continue;
    const owner = u.username;
    const verifiedQ = getOwnerVerifiedQueue(owner);
    const rawQ = getOwnerRawQueue(owner);
    const peers = getOwnerPeers(owner);
    const ownerAccs = Array.from(accounts.values()).filter((a) => (a.owner || 'admin') === owner);

    const verifiedQueueDetails = verifiedQ.map((uid) => {
      const p = peers.get(String(uid));
      return {
        uid,
        userId: String(uid),
        username: p?.username || '',
        accessHash: p?.accessHash ? 'Yes' : 'No'
      };
    });

    const rawQueueDetails = rawQ.map((uid) => {
      const p = peers.get(String(uid));
      return {
        uid,
        userId: String(uid),
        username: p?.username || '',
        accessHash: p?.accessHash ? 'Yes' : 'No'
      };
    });

    const sentSet = getOwnerSentUsers(owner);
    const sentList = Array.from(sentSet);
    const alreadySentDetails = sentList.slice(0, 150).map((uid) => {
      const p = peers.get(String(uid));
      return {
        uid,
        userId: String(uid),
        username: p?.username || '',
        firstName: p?.firstName || '',
        accessHash: p?.accessHash ? 'Yes' : 'No'
      };
    });

    result.push({
      username: owner,
      verifiedQueueCount: verifiedQ.length,
      leftoverCount: 0, // Leftover queue removed from Admin view
      alreadySentCount: sentSet.size,
      rawQueueCount: rawQ.length,
      queueCount: sentSet.size, // Admin queue count reflects Sent DM contacts
      accountsCount: ownerAccs.length,
      runningCount: ownerAccs.filter((a) => a.running).length,
      phones: ownerAccs.map((a) => ({ phone: a.phone, running: a.running, status: a.status })),
      queue: alreadySentDetails, // Admin modal queue defaults to Sent DM contacts
      verifiedQueue: verifiedQueueDetails,
      alreadySentQueue: alreadySentDetails,
      rawQueue: rawQueueDetails
    });
  }

  res.json({ success: true, users: result });
});

app.post('/api/admin/user-queue/delete', (req         , res          ) => {
  const { username, uid, queue_type } = req.body || {};
  const uname = (username || '').trim();
  const targetUid = Number(uid);
  const qType = (queue_type || 'all').toLowerCase();

  if (!uname || !targetUid) {
    return res.status(400).json({ msg: 'Username and target UID are required!' });
  }

  if (qType === 'sent' || qType === 'already_sent') {
    const s = getOwnerSentUsers(uname);
    s.delete(targetUid);
    ownerSentCache.set(uname, s);
    try {
      const localOwnerSPath = path.join(__dirname, `sent_owner_${uname}.json`);
      fs.writeFileSync(localOwnerSPath, JSON.stringify(Array.from(s)), 'utf8');
    } catch {}

  } else if (qType === 'raw') {
    removeFromOwnerRawQueue(uname, targetUid);
  } else if (qType === 'verified') {
    removeFromOwnerVerifiedQueue(uname, targetUid);
  } else {
    removeFromOwnerVerifiedQueue(uname, targetUid);
    removeFromOwnerRawQueue(uname, targetUid);
    removeFromOwnerQueue(uname, targetUid);
  }

  broadcastAccountUpdate(uname);
  res.json({
    success: true,
    msg: `User ${targetUid} deleted from "${uname}" queue!`
  });
});

app.post('/api/admin/user-queue/clear', (req: any, res: any) => {
  const { username, queue_type, count } = req.body || {};
  const rawUname = (username || '').trim();
  const qType = (queue_type || 'all').toLowerCase();
  const clearCount = count !== undefined && count !== null && count !== '' ? parseInt(count, 10) : 0;

  if (!rawUname) {
    return res.status(400).json({ msg: 'Username is required!' });
  }

  const isAllUsers = rawUname === '__ALL__' || rawUname.toLowerCase() === 'all_users' || rawUname.toLowerCase() === 'all';
  const targetUsers = isAllUsers
    ? Array.from(new Set(['admin', ...usersList.map((u: any) => u.username.toLowerCase())]))
    : [rawUname.toLowerCase()];

  let totalRemoved = 0;

  for (const uname of targetUsers) {
    let removedForUser = 0;

    if (qType === 'sent' || qType === 'already_sent') {
      const s = getOwnerSentUsers(uname);
      if (clearCount > 0) {
        const arr = Array.from(s);
        const toRemove = Math.min(clearCount, arr.length);
        const remaining = arr.slice(toRemove);
        ownerSentCache.set(uname, new Set(remaining));
        try {
          const localOwnerSPath = path.join(__dirname, `sent_owner_${uname}.json`);
          fs.writeFileSync(localOwnerSPath, JSON.stringify(remaining), 'utf8');
        } catch {}
        removedForUser = toRemove;
      } else {
        removedForUser = s.size;
        ownerSentCache.set(uname, new Set());
        try {
          const localOwnerSPath = path.join(__dirname, `sent_owner_${uname}.json`);
          fs.writeFileSync(localOwnerSPath, JSON.stringify([]), 'utf8');
        } catch {}
      }
    } else if (qType === 'skipped') {
      const s = getOwnerSkippedUsers(uname);
      if (clearCount > 0) {
        const arr = Array.from(s);
        const toRemove = Math.min(clearCount, arr.length);
        const remaining = arr.slice(toRemove);
        ownerSkippedCache.set(uname, new Set(remaining));
        try {
          const localSkippedPath = path.join(__dirname, `skipped_owner_${uname}.json`);
          fs.writeFileSync(localSkippedPath, JSON.stringify(remaining), 'utf8');
        } catch {}
        removedForUser = toRemove;
      } else {
        removedForUser = s.size;
        ownerSkippedCache.set(uname, new Set());
        ownerSkippedDetailsCache.set(uname, new Map());
        try {
          const localSkippedPath = path.join(__dirname, `skipped_owner_${uname}.json`);
          fs.writeFileSync(localSkippedPath, JSON.stringify([]), 'utf8');
          const localSkippedDbPath = path.join(__dirname, `skipped_db_owner_${uname}.json`);
          fs.writeFileSync(localSkippedDbPath, JSON.stringify({}), 'utf8');
        } catch {}
      }
    } else if (qType === 'raw') {
      const q = getOwnerRawQueue(uname);
      if (clearCount > 0) {
        const toRemove = Math.min(clearCount, q.length);
        saveOwnerRawQueue(uname, q.slice(toRemove));
        removedForUser = toRemove;
      } else {
        removedForUser = q.length;
        saveOwnerRawQueue(uname, []);
      }
    } else if (qType === 'verified') {
      const q = getOwnerVerifiedQueue(uname);
      if (clearCount > 0) {
        const toRemove = Math.min(clearCount, q.length);
        saveOwnerVerifiedQueue(uname, q.slice(toRemove));
        removedForUser = toRemove;
      } else {
        removedForUser = q.length;
        saveOwnerVerifiedQueue(uname, []);
      }
    } else {
      // 'all' queues
      if (clearCount > 0) {
        let rem = clearCount;
        const vq = getOwnerVerifiedQueue(uname);
        const vRemove = Math.min(rem, vq.length);
        saveOwnerVerifiedQueue(uname, vq.slice(vRemove));
        rem -= vRemove;
        removedForUser += vRemove;

        if (rem > 0) {
          const rq = getOwnerRawQueue(uname);
          const rRemove = Math.min(rem, rq.length);
          saveOwnerRawQueue(uname, rq.slice(rRemove));
          rem -= rRemove;
          removedForUser += rRemove;
        }

        if (rem > 0) {
          const s = getOwnerSentUsers(uname);
          const arr = Array.from(s);
          const sRemove = Math.min(rem, arr.length);
          const remaining = arr.slice(sRemove);
          ownerSentCache.set(uname, new Set(remaining));
          try {
            const localOwnerSPath = path.join(__dirname, `sent_owner_${uname}.json`);
            fs.writeFileSync(localOwnerSPath, JSON.stringify(remaining), 'utf8');
          } catch {}
          removedForUser += sRemove;
        }
      } else {
        const vLen = getOwnerVerifiedQueue(uname).length;
        const rLen = getOwnerRawQueue(uname).length;
        const sLen = getOwnerSentUsers(uname).size;
        saveOwnerVerifiedQueue(uname, []);
        saveOwnerRawQueue(uname, []);
        saveOwnerQueue(uname, []);
        ownerSentCache.set(uname, new Set());
        try {
          const localOwnerSPath = path.join(__dirname, `sent_owner_${uname}.json`);
          fs.writeFileSync(localOwnerSPath, JSON.stringify([]), 'utf8');
        } catch {}
        removedForUser = vLen + rLen + sLen;
      }
    }

    totalRemoved += removedForUser;
    broadcastAccountUpdate(uname);
  }

  const targetLabel = isAllUsers ? 'All Users' : `"${rawUname}"`;
  const typeLabel = qType === 'verified' ? 'Genuine Queue' : (qType === 'raw' ? 'Raw Staging Queue' : (qType === 'sent' || qType === 'already_sent' ? 'Already Sent Data' : (qType === 'skipped' ? 'Skipped Records' : 'All Queues')));
  const countLabel = clearCount > 0 ? `Custom (${clearCount})` : 'Bulk (All)';

  res.json({
    success: true,
    removed_count: totalRemoved,
    msg: `✅ Successfully removed ${totalRemoved} contact(s) from ${targetLabel} [${typeLabel} - ${countLabel}]!`
  });
});

// Transfer Genuine Queue, Already Sent Data, or Raw Queue from one user to another
app.post('/api/admin/user/transfer-queue', (req: any, res: any) => {
  const { from_user, to_user, count, queue_type } = req.body || {};
  const fromU = (from_user || '').trim().toLowerCase();
  const toU = (to_user || '').trim().toLowerCase();
  const reqCount = parseInt(count, 10) || 0;
  const qType = (queue_type || 'verified').toLowerCase();

  if (!fromU || !toU) {
    return res.status(400).json({ msg: 'Both From User and To User are required!' });
  }
  if (fromU === toU) {
    return res.status(400).json({ msg: 'Cannot transfer queue to the same user!' });
  }
  if (!getUser(fromU) || !getUser(toU)) {
    return res.status(404).json({ msg: 'One or both users not found!' });
  }

  // Helper to sync peer credentials between accounts & inject into active Telegram client caches
  const syncPeersAndInjectClientCache = (uids: number[]) => {
    const fromPeers = getOwnerPeers(fromU);
    const toPeers = getOwnerPeers(toU);
    for (const uid of uids) {
      const uidStr = String(uid);
      const p = fromPeers.get(uidStr) || findPeerInfoAnywhere(uidStr, fromU);
      if (p) {
        toPeers.set(uidStr, {
          userId: uidStr,
          accessHash: p.accessHash,
          username: p.username,
          firstName: p.firstName,
          lastName: p.lastName,
          phone: p.phone,
          sourcePhone: p.sourcePhone || fromU
        });
      }
    }
    saveOwnerPeers(toU, toPeers);

    // Inject InputPeerUser into active GramJS clients
    for (const acc of accounts.values()) {
      if ((acc.owner || 'admin') === toU) {
        if (acc.client) {
          try {
            for (const uid of uids) {
              const uidStr = String(uid);
              const p = toPeers.get(uidStr) || findPeerInfoAnywhere(uidStr, toU);
              if (p?.accessHash && p.accessHash !== '0') {
                const inputPeer = new Api.InputPeerUser({
                  userId: BigInt(uidStr) as any,
                  accessHash: BigInt(p.accessHash) as any
                });
                if ((acc.client as any)._entityCache?.cacheMap) {
                  (acc.client as any)._entityCache.cacheMap.set(uidStr, inputPeer);
                }
              }
            }
          } catch {}
        }
      }
    }
  };

  if (qType === 'already_sent_to_sent' || qType === 'sent_to_sent') {
    const fromSentSet = getOwnerSentUsers(fromU);
    const sentArr = Array.from(fromSentSet);
    if (sentArr.length === 0) {
      return res.status(400).json({ msg: `User "${fromU}" has 0 contacts in Already Sent Data!` });
    }
    const transferNum = (reqCount <= 0 || reqCount >= sentArr.length) ? sentArr.length : reqCount;
    const toTransfer = sentArr.slice(0, transferNum);
    const remainingArr = sentArr.slice(transferNum);
    const remainingSet = new Set(remainingArr);

    // 1. Sync & transfer ALL required peer metadata
    syncPeersAndInjectClientCache(toTransfer);

    // 2. Add to target user's sent records
    const toSent = getOwnerSentUsers(toU);
    for (const uid of toTransfer) {
      toSent.add(uid);
    }
    ownerSentCache.set(toU, toSent);
    try {
      fs.writeFileSync(path.join(__dirname, `sent_owner_${toU}.json`), JSON.stringify(Array.from(toSent)), 'utf8');
    } catch {}

    // 3. Update fromUser's sent records
    ownerSentCache.set(fromU, remainingSet);
    try {
      fs.writeFileSync(path.join(__dirname, `sent_owner_${fromU}.json`), JSON.stringify(remainingArr), 'utf8');
    } catch {}

    broadcastAccountUpdate(fromU);
    broadcastAccountUpdate(toU);

    return res.json({
      success: true,
      msg: `Successfully transferred ${toTransfer.length} Sent contact(s) from "${fromU}" to "${toU}"'s Sent Records!`,
      transferred: toTransfer.length,
      from_left: remainingSet.size,
      to_total: toSent.size
    });
  } else if (qType === 'already_sent' || qType === 'sent' || qType === 'already_sent_to_genuine') {
    const fromSentSet = getOwnerSentUsers(fromU);
    const sentArr = Array.from(fromSentSet);
    if (sentArr.length === 0) {
      return res.status(400).json({ msg: `User "${fromU}" has 0 contacts in Already Sent (Dispatched) Data!` });
    }
    const transferNum = (reqCount <= 0 || reqCount >= sentArr.length) ? sentArr.length : reqCount;
    const toTransfer = sentArr.slice(0, transferNum);
    const remainingArr = sentArr.slice(transferNum);
    const remainingSet = new Set(remainingArr);

    // 1. Sync & transfer ALL required peer metadata
    syncPeersAndInjectClientCache(toTransfer);

    // 2. Clear target user's (toU) sent & skipped records so target Telegram bot accounts are allowed to DM them
    const toSent = getOwnerSentUsers(toU);
    const toSkipped = getOwnerSkippedUsers(toU);
    for (const uid of toTransfer) {
      toSent.delete(uid);
      toSkipped.delete(uid);
      removeFromOwnerRawQueue(toU, uid);
      markGlobalVerified(uid);
    }
    ownerSentCache.set(toU, toSent);
    ownerSkippedCache.set(toU, toSkipped);
    try {
      fs.writeFileSync(path.join(__dirname, `sent_owner_${toU}.json`), JSON.stringify(Array.from(toSent)), 'utf8');
      fs.writeFileSync(path.join(__dirname, `skipped_owner_${toU}.json`), JSON.stringify(Array.from(toSkipped)), 'utf8');
    } catch {}


    // 3. Clear account-level sent sets
    for (const acc of accounts.values()) {
      if ((acc.owner || 'admin') === toU) {
        for (const uid of toTransfer) {
          acc.sent_users?.delete(uid);
          sentUsersCache.get(acc.phone)?.delete(uid);
        }
      }
    }

    // 4. Release any stale reservations on toU and add to verified genuine queue
    ownerVerifiedReservedUids.get(toU)?.clear();
    addToOwnerVerifiedQueue(toU, toTransfer);

    // 5. Update fromUser's sent records
    ownerSentCache.set(fromU, remainingSet);
    try {
      fs.writeFileSync(path.join(__dirname, `sent_owner_${fromU}.json`), JSON.stringify(remainingArr), 'utf8');
    } catch {}

    broadcastAccountUpdate(fromU);
    broadcastAccountUpdate(toU);

    return res.json({
      success: true,
      msg: `Successfully transferred ${toTransfer.length} contact(s) from "${fromU}"'s Already Sent Data to "${toU}"'s Genuine Queue with complete peer credentials!`,
      transferred: toTransfer.length,
      from_left: remainingSet.size,
      to_total: getOwnerVerifiedQueue(toU).length
    });
  } else if (qType === 'raw' || qType === 'raw_to_raw') {
    const fromRawQ = getOwnerRawQueue(fromU);
    if (fromRawQ.length === 0) {
      return res.status(400).json({ msg: `User "${fromU}" has 0 users in Raw Staging Queue!` });
    }
    const transferNum = (reqCount <= 0 || reqCount >= fromRawQ.length) ? fromRawQ.length : reqCount;
    const toTransfer = fromRawQ.slice(0, transferNum);
    const remaining = fromRawQ.slice(transferNum);

    // Sync peer info
    syncPeersAndInjectClientCache(toTransfer);

    // Clear skipped/sent flags on toU for these raw contacts
    const toSkipped = getOwnerSkippedUsers(toU);
    const toSent = getOwnerSentUsers(toU);
    for (const uid of toTransfer) {
      toSkipped.delete(uid);
      toSent.delete(uid);
    }
    ownerSkippedCache.set(toU, toSkipped);
    ownerSentCache.set(toU, toSent);

    ownerRawReservedUids.get(toU)?.clear();
    const toRawQ = getOwnerRawQueue(toU);
    saveOwnerRawQueue(toU, [...toRawQ, ...toTransfer]);
    saveOwnerRawQueue(fromU, remaining);

    broadcastAccountUpdate(fromU);
    broadcastAccountUpdate(toU);

    return res.json({
      success: true,
      msg: `Successfully transferred ${toTransfer.length} Raw Queue user(s) from "${fromU}" to "${toU}"!`,
      transferred: toTransfer.length,
      from_left: remaining.length,
      to_total: getOwnerRawQueue(toU).length
    });
  } else if (qType === 'leftover_to_raw') {
    // Transfer Leftover Genuine Queue directly into target's Raw Staging Queue (for 15-batch filtering first)
    const fromVerifiedQ = getOwnerVerifiedQueue(fromU);
    if (fromVerifiedQ.length === 0) {
      return res.status(400).json({ msg: `User "${fromU}" has 0 users in Leftover Genuine Queue!` });
    }
    const transferNum = (reqCount <= 0 || reqCount >= fromVerifiedQ.length) ? fromVerifiedQ.length : reqCount;
    const toTransfer = fromVerifiedQ.slice(0, transferNum);
    const remaining = fromVerifiedQ.slice(transferNum);

    // Sync peer info
    syncPeersAndInjectClientCache(toTransfer);

    // Clear target user's skipped records so filter worker will inspect them
    const toSkipped = getOwnerSkippedUsers(toU);
    const toSent = getOwnerSentUsers(toU);
    for (const uid of toTransfer) {
      toSkipped.delete(uid);
      toSent.delete(uid);
    }
    ownerSkippedCache.set(toU, toSkipped);
    ownerSentCache.set(toU, toSent);

    ownerRawReservedUids.get(toU)?.clear();
    const toRawQ = getOwnerRawQueue(toU);
    saveOwnerRawQueue(toU, [...toRawQ, ...toTransfer]);
    saveOwnerVerifiedQueue(fromU, remaining);

    broadcastAccountUpdate(fromU);
    broadcastAccountUpdate(toU);

    return res.json({
      success: true,
      msg: `Successfully moved ${toTransfer.length} Leftover contact(s) from "${fromU}" ➔ "${toU}"'s Raw Staging Queue (Ready for 15-user batch filtering)!`,
      transferred: toTransfer.length,
      from_left: remaining.length,
      to_total: getOwnerRawQueue(toU).length
    });
  } else {
    // Default: Genuine / Verified Queue (Direct to Target User's Genuine Queue for instant DMs)
    const fromVerifiedQ = getOwnerVerifiedQueue(fromU);
    if (fromVerifiedQ.length === 0) {
      return res.status(400).json({ msg: `User "${fromU}" has 0 contacts in Genuine Queue!` });
    }
    const transferNum = (reqCount <= 0 || reqCount >= fromVerifiedQ.length) ? fromVerifiedQ.length : reqCount;
    const toTransfer = fromVerifiedQ.slice(0, transferNum);
    const remaining = fromVerifiedQ.slice(transferNum);

    // 1. Sync peer info (access_hash, username, firstName, phone, etc.) & inject into client entity cache
    syncPeersAndInjectClientCache(toTransfer);

    // 2. Clear target user's (toU) sent & skipped records so target Telegram bot accounts are allowed to DM them
    const toSent = getOwnerSentUsers(toU);
    const toSkipped = getOwnerSkippedUsers(toU);
    for (const uid of toTransfer) {
      toSent.delete(uid);
      toSkipped.delete(uid);
      removeFromOwnerRawQueue(toU, uid);
      markGlobalVerified(uid);
    }
    ownerSentCache.set(toU, toSent);
    ownerSkippedCache.set(toU, toSkipped);
    try {
      fs.writeFileSync(path.join(__dirname, `sent_owner_${toU}.json`), JSON.stringify(Array.from(toSent)), 'utf8');
      fs.writeFileSync(path.join(__dirname, `skipped_owner_${toU}.json`), JSON.stringify(Array.from(toSkipped)), 'utf8');
    } catch {}


    // 3. Clear account-level sent sets on target user's accounts
    for (const acc of accounts.values()) {
      if ((acc.owner || 'admin') === toU) {
        for (const uid of toTransfer) {
          acc.sent_users?.delete(uid);
          sentUsersCache.get(acc.phone)?.delete(uid);
        }
      }
    }

    // 4. Release any previous reservations and add directly to verified queue
    ownerVerifiedReservedUids.get(toU)?.clear();
    addToOwnerVerifiedQueue(toU, toTransfer);
    saveOwnerVerifiedQueue(fromU, remaining);

    broadcastAccountUpdate(fromU);
    broadcastAccountUpdate(toU);

    return res.json({
      success: true,
      msg: `Successfully transferred ${toTransfer.length} Genuine Queue contact(s) from "${fromU}" to "${toU}"'s Genuine Queue (Ready for immediate DMs)!`,
      transferred: toTransfer.length,
      from_left: remaining.length,
      to_total: getOwnerVerifiedQueue(toU).length
    });
  }
});


// ---------------- SMART KHATABOOK & BILLING REST API ----------------

// ---------------- DEMO USER MANAGEMENT API ----------------
app.post('/api/admin/billing/grant-demo', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  const { username, days, max_accounts, notes } = req.body || {};
  if (!username) return res.status(400).json({ ok: false, msg: 'Username is required!' });

  const u = getUser(username);
  if (!u) return res.status(404).json({ ok: false, msg: 'User not found in system!' });

  const demoDays = Math.max(1, parseInt(days, 10) || 1);
  const nowMs = Date.now();
  const expDateStr = new Date(nowMs + demoDays * 86400 * 1000).toISOString().split('T')[0];

  // Set user properties
  u.active = true;
  u.expiry_date = expDateStr;
  (u as any).is_demo = true;
  if (max_accounts) u.max_accounts = Math.max(1, parseInt(max_accounts, 10) || 1);

  // Set billing properties: demo rate is 0 by default so no unwanted debt accumulates during trial
  if (!billingStore.user_configs) billingStore.user_configs = {};
  billingStore.user_configs[username] = {
    rate_per_day: 0,
    is_demo: true,
    demo_expiry: expDateStr,
    demo_days: demoDays,
    notes: notes || `Free Demo (${demoDays} Day Trial)`
  };

  saveUsers();
  saveBillingLocal();

  if (u.alert_enabled) {
    sendTelegramAlert(u.username, `🎁 <b>Free Demo Activated!</b>\nYour trial is active for <b>${demoDays} day(s)</b> until <b>${expDateStr}</b>. You can run up to ${u.max_accounts} bot(s).`);
  }

  res.json({
    ok: true,
    msg: `✅ Demo activated for @${username}! Validity: ${demoDays} day(s) (until ${expDateStr}). Rate set to ₹0/day.`,
    user: {
      username: u.username,
      expiry_date: u.expiry_date,
      is_demo: true,
      max_accounts: u.max_accounts
    }
  });
});

app.post('/api/admin/billing/convert-demo-to-paid', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  const { username, rate_per_day, add_days, invoice_amount, notes } = req.body || {};
  if (!username) return res.status(400).json({ ok: false, msg: 'Username is required!' });

  const u = getUser(username);
  if (!u) return res.status(404).json({ ok: false, msg: 'User not found!' });

  const rate = Math.max(0, Number(rate_per_day) || billingStore.settings.default_rate_per_day || 15);
  const extensionDays = parseInt(add_days, 10) || 30;

  let curExpMs = Date.now();
  if (u.expiry_date) {
    const parsed = new Date(u.expiry_date + 'T23:59:59Z').getTime();
    if (!isNaN(parsed) && parsed > curExpMs) curExpMs = parsed;
  }
  const newExpDateStr = new Date(curExpMs + extensionDays * 86400 * 1000).toISOString().split('T')[0];

  u.active = true;
  u.expiry_date = newExpDateStr;
  (u as any).is_demo = false;

  if (!billingStore.user_configs) billingStore.user_configs = {};
  billingStore.user_configs[username] = {
    rate_per_day: rate,
    is_demo: false,
    notes: notes || 'Converted from Demo to Paid Customer'
  };

  // If initial invoice specified, create charge now
  const invAmt = Number(invoice_amount) || 0;
  if (invAmt > 0) {
    addBillingInvoice({
      username,
      date: getTodayDateString(),
      amount: invAmt,
      type: 'plan_charge',
      description: `Plan Subscription (${extensionDays} Days) - Activated from Demo`
    });
  }

  saveUsers();
  saveBillingLocal();

  if (u.alert_enabled) {
    sendTelegramAlert(u.username, `🎉 <b>Account Activated & Shifted to Paid Plan!</b>\nValidity extended by <b>+${extensionDays} days</b> until <b>${newExpDateStr}</b> at ₹${rate}/day.`);
  }

  res.json({
    ok: true,
    msg: `🎉 User @${username} converted to Paid! Extended by ${extensionDays} days (Expiry: ${newExpDateStr}) at ₹${rate}/day.`,
    user: {
      username: u.username,
      expiry_date: u.expiry_date,
      is_demo: false
    }
  });
});

app.post('/api/admin/billing/sync-users', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  
  // Reload users and accounts from disk if available
  loadUsersLocal();
  loadAccountsLocal();
  loadBillingLocal();

  const defRate = billingStore.settings.default_rate_per_day || 15;
  let addedCount = 0;

  // Scan all users
  for (const u of usersList) {
    if (!u || !u.username) continue;
    const uname = (u.username || '').toString().trim();
    if (uname.toLowerCase() === 'admin' || (u.role && u.role === 'admin')) continue;
    if (!billingStore.user_configs[uname]) {
      billingStore.user_configs[uname] = { rate_per_day: defRate, notes: 'Auto-synced from panel users' };
      addedCount++;
    }
  }

  // Scan accounts owners
  for (const acc of Array.from(accounts.values())) {
    const owner = (acc.owner || '').toString().trim();
    if (owner && owner.toLowerCase() !== 'admin' && !billingStore.user_configs[owner]) {
      billingStore.user_configs[owner] = { rate_per_day: defRate, notes: 'Auto-synced from account owner' };
      addedCount++;
    }
  }

  saveBillingLocal();
  const total = Object.keys(billingStore.user_configs).length;
  res.json({ ok: true, synced: addedCount, total_users: total, msg: `Synced successfully! Found ${total} panel user(s).` });
});

app.get('/api/admin/billing/overview', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  try {
    autoSyncAllUsersIntoBilling();
    accrueDailyUsageForAllUsers();
  } catch(e) {}
  const startDate = String(req.query.start_date || '');
  const endDate = String(req.query.end_date || '');
  const filterUser = String(req.query.username || '').trim().toLowerCase();

  let filteredInvoices = billingStore.invoices;
  let filteredPayments = billingStore.payments;

  if (filterUser) {
    filteredInvoices = filteredInvoices.filter(i => (i.username || '').toLowerCase() === filterUser);
    filteredPayments = filteredPayments.filter(p => (p.username || '').toLowerCase() === filterUser);
  }

  if (startDate) {
    filteredInvoices = filteredInvoices.filter(i => (i.date || '') >= startDate);
    filteredPayments = filteredPayments.filter(p => (p.date || '') >= startDate);
  }

  if (endDate) {
    filteredInvoices = filteredInvoices.filter(i => (i.date || '') <= endDate);
    filteredPayments = filteredPayments.filter(p => (p.date || '') <= endDate);
  }

  const userLedgers: any[] = [];
  // Gather all unique users from usersList, accounts, and existing billing records
  const seenUsernames = new Set<string>();
  const allUsersMap = new Map<string, any>();

  // 1. From active usersList
  for (const u of usersList) {
    if (!u || !u.username) continue;
    const uname = (u.username || '').toString().trim();
    if (uname.toLowerCase() === 'admin' || (u.role && u.role === 'admin')) continue;
    seenUsernames.add(uname);
    allUsersMap.set(uname, {
      username: uname,
      display_name: u.display_name || uname,
      max_accounts: u.max_accounts || 1,
      expiry_date: u.expiry_date || ''
    });
  }

  // 2. From all accounts (owners)
  for (const acc of Array.from(accounts.values())) {
    const owner = (acc.owner || '').toString().trim();
    if (owner && owner.toLowerCase() !== 'admin' && !seenUsernames.has(owner)) {
      seenUsernames.add(owner);
      allUsersMap.set(owner, {
        username: owner,
        display_name: owner,
        max_accounts: 1,
        expiry_date: ''
      });
    }
  }

  // 3. From billing user configs & invoices
  for (const uname of Object.keys(billingStore.user_configs || {})) {
    if (uname && uname.toLowerCase() !== 'admin' && !seenUsernames.has(uname)) {
      seenUsernames.add(uname);
      allUsersMap.set(uname, {
        username: uname,
        display_name: uname,
        max_accounts: 1,
        expiry_date: ''
      });
    }
  }
  for (const inv of (billingStore.invoices || [])) {
    const uname = (inv.username || '').toString().trim();
    if (uname && uname.toLowerCase() !== 'admin' && !seenUsernames.has(uname)) {
      seenUsernames.add(uname);
      allUsersMap.set(uname, {
        username: uname,
        display_name: uname,
        max_accounts: 1,
        expiry_date: ''
      });
    }
  }

  const panelUsers = Array.from(allUsersMap.values());
  
  for (const u of panelUsers) {
    const uname = u.username;
    const summary = getUserLedgerSummary(uname);
    const cfg = billingStore.user_configs[uname] || { rate_per_day: billingStore.settings.default_rate_per_day || 15 };
    const accs = Array.from(accounts.values()).filter(a => (a.owner || 'admin') === uname);
    
    const isDemo = Boolean(cfg.is_demo || (u && (u as any).is_demo));
    const isExpired = Boolean(u.expiry_date && getTodayDateString() > u.expiry_date);
    let derivedStatus = 'settled';
    if (isDemo) {
      derivedStatus = isExpired ? 'demo_expired' : 'demo_active';
    } else if (summary.balance_due > 0) {
      derivedStatus = isExpired ? 'overdue' : 'due';
    } else if (summary.balance_due < 0) {
      derivedStatus = 'advance';
    }

    userLedgers.push({
      username: uname,
      display_name: u.display_name || uname,
      telegram_id: u.alert_chat_id || u.telegram_id || '',
      telegram_username: u.telegram_username || '',
      active_accounts: accs.length,
      max_accounts: u.max_accounts || 1,
      expiry_date: u.expiry_date || '',
      rate_per_day: cfg.rate_per_day || 15,
      rate_per_bot: cfg.rate_per_bot || 15,
      billing_cycle_days: cfg.billing_cycle_days || 7,
      payment_model: cfg.payment_model || 'postpaid',
      total_billed: summary.total_billed,
      total_paid: summary.total_paid,
      balance_due: summary.balance_due,
      is_demo: isDemo,
      is_active: Boolean(u.active !== false),
      payment_paused: Boolean((u as any).payment_paused),
      status: derivedStatus
    });
  }

  const totalBilledEver = billingStore.invoices.reduce((a, b) => a + Number(b.amount || 0), 0);
  const realPaymentsEver = billingStore.payments.filter(p => p.mode !== 'OFFER_DISCOUNT' && !(p as any).is_offer);
  const totalPaidEver = realPaymentsEver.reduce((a, b) => a + Number(b.amount || 0), 0);
  const totalMarketDue = userLedgers.reduce((a, b) => a + Number(b.balance_due || 0), 0);

  const rangeBilled = filteredInvoices.reduce((a, b) => a + Number(b.amount || 0), 0);
  const rangeReceived = filteredPayments.filter(p => p.mode !== 'OFFER_DISCOUNT' && !(p as any).is_offer).reduce((a, b) => a + Number(b.amount || 0), 0);

  const isDateFiltered = Boolean(startDate || endDate);
  const displayCollected = isDateFiltered ? rangeReceived : totalPaidEver;
  const displayBilled = isDateFiltered ? rangeBilled : totalBilledEver;

  const allOffers = billingStore.offers || [];
  let filteredOffers = allOffers;
  if (filterUser) filteredOffers = filteredOffers.filter(o => (o.username || '').toLowerCase() === filterUser);
  if (startDate) filteredOffers = filteredOffers.filter(o => (o.date || '') >= startDate);
  if (endDate) filteredOffers = filteredOffers.filter(o => (o.date || '') <= endDate);

  const totalOffersAmount = filteredOffers.reduce((a, b) => a + Number(b.discount_amount || 0), 0);
  const totalOffersDays = filteredOffers.reduce((a, b) => a + Number(b.bonus_days || 0), 0);
  const offersCount = filteredOffers.length;
  const uniqueOfferUsers = new Set(filteredOffers.map(o => (o.username || '').toLowerCase())).size;

  res.json({
    ok: true,
    currency: billingStore.settings.default_currency || 'INR',
    default_rate_per_day: billingStore.settings.default_rate_per_day || 15,
    metrics: {
      is_date_filtered: isDateFiltered,
      total_market_due: Math.round(totalMarketDue),
      total_collected_ever: Math.round(displayCollected),
      lifetime_collected: Math.round(totalPaidEver),
      total_billed_ever: Math.round(displayBilled),
      lifetime_billed: Math.round(totalBilledEver),
      total_offers_amount: Math.round(totalOffersAmount),
      total_offers_days: Math.round(totalOffersDays),
      offers_count: offersCount,
      offers_users_count: uniqueOfferUsers,
      range_billed: Math.round(rangeBilled),
      range_received: Math.round(rangeReceived),
      active_billed_users: panelUsers.length
    },
    user_ledgers: userLedgers,
    invoices: filteredInvoices.slice(0, 150),
    payments: filteredPayments.slice(0, 150),
    offers: filteredOffers.slice(0, 100),
    downtimes: billingStore.downtimes.slice(0, 50)
  });
});

app.post('/api/admin/billing/set-rate', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  const { username, rate_per_bot, rate_per_day, notes } = req.body || {};
  if (!username) return res.status(400).json({ ok: false, msg: 'Username is required!' });

  const u = getUser(username);
  const newRate = Number(rate_per_bot) || Number(rate_per_day) || 10;

  if (u) {
    u.rate_per_bot = newRate;
    saveUsers();
  }

  if (!billingStore.user_configs) billingStore.user_configs = {};
  if (!billingStore.user_configs[username]) billingStore.user_configs[username] = {} as any;
  billingStore.user_configs[username].rate_per_bot = newRate;
  billingStore.user_configs[username].rate_per_day = newRate;
  if (notes) billingStore.user_configs[username].notes = notes;

  const bots = u?.max_accounts || billingStore.user_configs[username].max_accounts || 1;
  const newTotal = Math.round(newRate * bots);

  if (Array.isArray(billingStore.invoices)) {
    const activeInv = billingStore.invoices
      .slice()
      .reverse()
      .find(i => i.username === username && (i.type === 'weekly_plan' || i.type === 'subscription'));

    if (activeInv) {
      activeInv.amount = newTotal;
      activeInv.bots_count = bots;
      activeInv.description = `${activeInv.days_count || 7}-Day Plan (${bots} IDs x ₹${newRate}/bot = ₹${newTotal})`;
    }
  }

  saveBillingLocal();
  res.json({ ok: true, msg: `Rate updated for user ${username}: ₹${newRate}/bot.` });
});


// ---------------- OVERDUE FREEZE & MANUAL PAUSE CONTROL ----------------
app.post('/api/admin/billing/toggle-pause', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  const { username, paused, reason } = req.body || {};
  if (!username) return res.status(400).json({ ok: false, msg: 'Username required!' });

  const u = getUser(username);
  if (!u) return res.status(404).json({ ok: false, msg: 'User not found!' });

  const shouldPause = paused !== undefined ? Boolean(paused) : !(u as any).payment_paused;
  (u as any).payment_paused = shouldPause;
  if (shouldPause) {
    // Stop running bots
    for (const a of accounts.values()) {
      if ((a.owner || 'admin') === username && a.running) {
        a.running = false;
        if (a.abortController) a.abortController.abort();
        a.status = 'Paused (Payment Overdue)';
        log(a.phone, 'FAIL', `Bot paused by admin due to payment overdue. Reason: ${reason || 'Payment pending'}`);
      }
    }
  }
  saveUsers();
  broadcastAccountUpdate(username);

  res.json({
    ok: true,
    msg: shouldPause ? `⏸️ User @${username} bots PAUSED due to overdue payment!` : `▶️ User @${username} bots UNPAUSED & ACTIVE!`,
    payment_paused: shouldPause
  });
});

let cachedAdminBotUsername = '';
async function getAdminBotUsername(): Promise<string> {
  if (cachedAdminBotUsername) return cachedAdminBotUsername;
  const adminUser = usersList.find((x: any) => x.role === 'admin' && (x.alert_bot_token || '').trim());
  if (!adminUser) return '';
  const token = adminUser.alert_bot_token.trim();
  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/getMe`);
    const data = await res.json();
    if (data?.ok && data.result?.username) {
      cachedAdminBotUsername = data.result.username;
      return cachedAdminBotUsername;
    }
  } catch (e) {}
  return '';
}

app.get('/api/user/telegram-link', async (req, res) => {
  const username = getEffectiveUser(req);
  if (!username) {
    return res.status(401).json({ ok: false, msg: 'Unauthorized' });
  }
  const u = getUser(username);
  
  // Prefer user's own configured filter_bot_token or alert_bot_token, fallback to system admin bot
  let userBotToken = (u?.master_config?.filter_bot_token || (u as any)?.filter_bot_token || u?.alert_bot_token || '').trim();
  let botUsername = '';
  if (userBotToken) {
    try {
      const bRes = await fetch(`https://api.telegram.org/bot${encodeURIComponent(userBotToken)}/getMe`);
      const bData: any = await bRes.json().catch(() => null);
      if (bData?.ok && bData.result?.username) {
        botUsername = bData.result.username;
      }
    } catch {}
  }
  if (!botUsername) {
    botUsername = await getAdminBotUsername();
  }

  const isLinked = Boolean(u && (u.alert_chat_id || u.telegram_id));
  const linkUrl = botUsername ? ('https://t.me/' + botUsername + '?start=link_' + username) : '';
  return res.json({
    ok: true,
    username: username,
    bot_username: botUsername,
    link_url: linkUrl,
    is_linked: isLinked,
    telegram_id: u?.alert_chat_id || u?.telegram_id || '',
    telegram_username: u?.telegram_username || ''
  });
});

app.post('/api/admin/user/set-telegram-id', (req, res) => {
  const sessionUser = getSessionUser(req);
  if (!sessionUser || sessionUser.role !== 'admin') {
    return res.status(403).json({ ok: false, msg: 'Admin privileges required' });
  }
  const { username, telegram_id } = req.body || {};
  if (!username) {
    return res.status(400).json({ ok: false, msg: 'Username is required' });
  }
  const u = usersList.find((x: any) => x.username === username);
  if (!u) {
    return res.status(404).json({ ok: false, msg: 'User not found' });
  }
  const cleanId = (telegram_id || '').toString().trim();
  u.alert_chat_id = cleanId;
  u.telegram_id = cleanId;
  saveUsers();
  return res.json({ ok: true, msg: `Telegram ID for ${username} updated to ${cleanId || 'None'}` });
});

app.post('/api/admin/billing/send-reminder', async (req, res) => {
  const sessionUser = getSessionUser(req);
  if (!sessionUser || sessionUser.role !== 'admin') {
    return res.status(403).json({ ok: false, msg: 'Admin privileges required' });
  }
  const { username } = req.body || {};
  if (!username) {
    return res.status(400).json({ ok: false, msg: 'Username is required' });
  }
  const result = await sendUserBillingReminder(username);
  return res.json(result);
});

app.post('/api/admin/billing/record-payment', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  const { username, amount, mode, reference, note, extend_validity, auto_extend_expiry, extend_days } = req.body || {};
  if (!username) return res.status(400).json({ ok: false, msg: 'Username is required!' });
  const payAmt = Number(amount);
  if (isNaN(payAmt) || payAmt <= 0) return res.status(400).json({ ok: false, msg: 'Valid positive amount required!' });

  const shouldExtend = (extend_validity !== false && auto_extend_expiry !== false);
  const extDays = Math.max(1, Number(extend_days) || 7);

  const result = applyPaymentAndCheckAutoExtend(
    username,
    payAmt,
    mode || 'UPI',
    note || '',
    reference || '',
    shouldExtend ? extDays : undefined
  );

  res.json({
    ok: true,
    msg: result.msg,
    payment: result.payment,
    summary: result.summary,
    extended: result.extended,
    new_expiry: result.newExpiry
  });
});

// Apply Offer, Promotional Discount, or Bonus Free Days
app.post('/api/admin/billing/apply-offer', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  const { username, offer_name, discount_amount, bonus_days, note } = req.body || {};
  if (!username) return res.status(400).json({ ok: false, msg: 'Username is required!' });
  const u = getUser(username);
  if (!u) return res.status(404).json({ ok: false, msg: 'User not found!' });

  let actionsDone = [];
  const discAmt = Number(discount_amount) || 0;
  const bDays = Number(bonus_days) || 0;

  if (discAmt <= 0 && bDays <= 0) {
    return res.status(400).json({ ok: false, msg: 'Please provide either discount amount (₹) or bonus days!' });
  }

  if (!Array.isArray(billingStore.offers)) {
    billingStore.offers = [];
  }

  const newOffer: BillingOffer = {
    id: 'off_' + Date.now() + '_' + Math.floor(100 + Math.random() * 900),
    username: u.username,
    offer_name: (offer_name || '').trim() || (discAmt > 0 && bDays > 0 ? 'Discount + Validity Offer' : (discAmt > 0 ? 'Discount Offer' : 'Bonus Validity Offer')),
    discount_amount: discAmt,
    bonus_days: bDays,
    note: note || '',
    date: getTodayDateString(),
    created_at: Date.now()
  };
  billingStore.offers.unshift(newOffer);

  if (discAmt > 0) {
    actionsDone.push(`₹${discAmt} Discount Deducted from Due`);
  }

  if (bDays > 0) {
    let curExpMs = Date.now() + 5.5 * 3600 * 1000;
    if (u.expiry_date) {
      const parsed = new Date(u.expiry_date + 'T23:59:59Z').getTime();
      if (!isNaN(parsed) && parsed > curExpMs) curExpMs = parsed;
    }
    const newExpMs = curExpMs + (bDays * 86400 * 1000);
    u.expiry_date = new Date(newExpMs).toISOString().split('T')[0];
    u.active = true;
    saveUsers();
    actionsDone.push(`+${bDays} Bonus Days (New Expiry: ${u.expiry_date})`);
  }

  saveBillingLocal();
  const summary = getUserLedgerSummary(username);
  res.json({
    ok: true,
    msg: `🎁 Offer "${newOffer.offer_name}" applied to ${username}! [${actionsDone.join(' | ')}]. Remaining Balance Due: ₹${summary.balance_due}`,
    summary,
    offer: newOffer
  });
});

app.post('/api/admin/billing/create-invoice', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  const { username, amount, description, type, date } = req.body || {};
  if (!username) return res.status(400).json({ ok: false, msg: 'Username is required!' });
  const invAmt = Number(amount);
  if (isNaN(invAmt) || invAmt === 0) return res.status(400).json({ ok: false, msg: 'Valid amount required!' });

  const invDate = date || getTodayDateString();
  const invoice = addBillingInvoice({
    username,
    date: invDate,
    amount: invAmt,
    type: type || 'custom_charge',
    description: description || 'Manual Charge / Adjustment',
    status: 'due'
  });

  const summary = getUserLedgerSummary(username);
  res.json({
    ok: true,
    msg: `Invoice of ₹${invAmt} created for ${username}. Total balance due: ₹${summary.balance_due}`,
    invoice,
    summary
  });
});

// 1-Week Quick Invoice Generator
app.post('/api/admin/billing/create-weekly-invoice', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  const { username, rate_per_bot, rate_per_day, bots_count, note, start_date } = req.body || {};
  if (!username) return res.status(400).json({ ok: false, msg: 'Username is required!' });

  const u = getUser(username);
  const userAccs = Array.from(accounts.values()).filter(a => (a.owner || 'admin') === username);
  const activeBots = Number(bots_count) || (userAccs.length > 0 ? userAccs.length : (u?.max_accounts || 1));

  let weeklyTotal = 0;
  let rateDesc = '';

  const rpb = Number(rate_per_bot) || Number(rate_per_day) || Number((u as any)?.rate_per_bot) || getUserEffectiveRate(username) || 10;
  weeklyTotal = Math.round(rpb * 7 * activeBots);
  rateDesc = `₹${rpb}/bot/day (₹${rpb * 7}/bot/week)`;

  const startDateStr = start_date || getTodayDateString();
  const startMs = new Date(startDateStr + 'T00:00:00Z').getTime();
  const endMs = startMs + (6 * 86400 * 1000);
  const endDateStr = new Date(endMs).toISOString().split('T')[0];

  const summaryBefore = getUserLedgerSummary(username);
  const prevDue = summaryBefore.balance_due > 0 ? summaryBefore.balance_due : 0;
  let desc = `1-Week Plan (${activeBots} ID${activeBots > 1 ? 's' : ''} x ${rateDesc} = ₹${weeklyTotal}) [${startDateStr} to ${endDateStr}]`;
  if (prevDue > 0) {
    desc += ` [Previous Due Carried: ₹${prevDue} | Total Payable: ₹${weeklyTotal + prevDue}]`;
  }
  if (note) {
    desc += ` - ${note}`;
  }

  const invoice = addBillingInvoice({
    username,
    date: startDateStr,
    amount: weeklyTotal,
    type: 'weekly_plan',
    description: desc,
    bots_count: activeBots,
    days_count: 7,
    status: 'due'
  });

  const summary = getUserLedgerSummary(username);
  res.json({
    ok: true,
    msg: `1-Week invoice of ₹${weeklyTotal} generated for ${username}.${prevDue > 0 ? ` (Previous Due ₹${prevDue} carried forward. Total Payable Balance Due: ₹${summary.balance_due})` : ` Balance due: ₹${summary.balance_due}`}`,
    invoice,
    summary
  });
});

// 🌟 7-Day Cycle & Start Date Setup Engine for Existing Users (100% Interconnected & Auto-Recalculating)
app.post('/api/admin/billing/setup-user-cycle', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  const { username, start_date, payment_model, rate_per_bot, allowed_bots, mark_paid, recalculate_history } = req.body || {};
  if (!username) return res.status(400).json({ ok: false, msg: 'Username is required!' });

  const u = getUser(username);
  if (!u) return res.status(404).json({ ok: false, msg: 'User not found!' });

  const rate = Math.max(1, Number(rate_per_bot) || Number((u as any).rate_per_bot) || 10);
  const model = (payment_model || (u as any).billing_model || 'postpaid').toLowerCase();
  const startDateStr = (start_date || getTodayDateString()).trim();

  // 1-Week (7 days) cycle calculation
  const startParts = startDateStr.split('-');
  const startYear = parseInt(startParts[0], 10);
  const startMonth = parseInt(startParts[1], 10) - 1;
  const startDay = parseInt(startParts[2], 10);

  const startObj = new Date(Date.UTC(startYear, startMonth, startDay, 0, 0, 0));
  const day7Obj = new Date(startObj.getTime() + (6 * 86400 * 1000));
  const day7Str = day7Obj.toISOString().split('T')[0];

  // 2-Day grace period (e.g. 8 Oct -> 9 Oct)
  const graceObj = new Date(startObj.getTime() + (8 * 86400 * 1000));
  const graceUntilStr = graceObj.toISOString().split('T')[0];

  if (allowed_bots) {
    u.max_accounts = Math.max(1, parseInt(allowed_bots, 10) || 1);
  }
  (u as any).rate_per_bot = rate;
  u.expiry_date = day7Str;
  (u as any).billing_start_date = startDateStr;
  (u as any).billing_model = model;
  (u as any).billing_cycle_days = 7;
  (u as any).grace_period_until = graceUntilStr;
  (u as any).payment_paused = false;
  saveUsers();

  if (!billingStore.user_configs) billingStore.user_configs = {};
  billingStore.user_configs[username] = {
    rate_per_bot: rate,
    rate_per_day: rate,
    billing_start_date: startDateStr,
    billing_cycle_days: 7,
    payment_model: model,
    max_accounts: u.max_accounts || 1,
    notes: `Cycle: ${startDateStr} to ${day7Str} (Grace till ${graceUntilStr}) @ ₹${rate}/bot/day`
  };

  const liveBots = getUserLiveBotsCount(username) || u.max_accounts || 1;
  const todayStr = getTodayDateString();

  // If recalculate_history is enabled (default true when editing), remove old daily usage invoices in current active span
  const shouldRecalc = recalculate_history !== false;
  if (shouldRecalc) {
    billingStore.invoices = billingStore.invoices.filter(inv => {
      if ((inv.username || '').toLowerCase() !== username.toLowerCase()) return true;
      if (inv.type === 'daily_usage' || inv.type === 'weekly_plan_daily') {
        return false; // Remove outdated daily records so we cleanly backfill at new rate
      }
      return true;
    });
  }

  let elapsedDaysCount = 0;
  if (model === 'postpaid') {
    // Backfill daily usage day by day from startDateStr up to todayStr (capped at day 7)
    let curTime = startObj.getTime();
    const todayParts = todayStr.split('-');
    const todayObj = new Date(Date.UTC(parseInt(todayParts[0], 10), parseInt(todayParts[1], 10) - 1, parseInt(todayParts[2], 10), 0, 0, 0));
    const endTime = Math.min(todayObj.getTime(), day7Obj.getTime());

    while (curTime <= endTime && elapsedDaysCount < 7) {
      const dStr = new Date(curTime).toISOString().split('T')[0];
      elapsedDaysCount++;
      const alreadyBilled = billingStore.invoices.some(
        inv => (inv.username || '').toLowerCase() === username.toLowerCase() &&
               inv.date === dStr &&
               (inv.type === 'daily_usage' || inv.type === 'weekly_plan_daily')
      );
      if (!alreadyBilled) {
        const dailyAmt = liveBots * rate;
        addBillingInvoice({
          username: u.username,
          date: dStr,
          amount: dailyAmt,
          type: 'daily_usage',
          description: `Daily Usage (Day ${elapsedDaysCount} of 7): ${liveBots} Live Bot(s) @ ₹${rate}/bot/day = ₹${dailyAmt}`,
          bots_count: liveBots,
          days_count: 1,
          status: 'due'
        });
      }
      curTime += 86400 * 1000;
    }
  } else {
    // Advance (Prepaid): 7-Day Plan upfront
    const planTotal = liveBots * rate * 7;
    const isPaid = Boolean(mark_paid);
    addBillingInvoice({
      username: u.username,
      date: startDateStr,
      amount: planTotal,
      type: 'weekly_plan',
      description: `1-Week Advance Plan (${liveBots} Bot(s) @ ₹${rate}/bot/day x 7 Days = ₹${planTotal}) [${startDateStr} to ${day7Str}]`,
      bots_count: liveBots,
      days_count: 7,
      status: isPaid ? 'paid' : 'due'
    });
    if (isPaid) {
      addBillingPayment({
        username: u.username,
        date: startDateStr,
        amount: planTotal,
        mode: 'UPI',
        reference: 'Advance Signup',
        note: `1-Week Advance Paid (${liveBots} Bots @ ₹${rate}/bot/day)`
      });
    }
  }

  saveBillingLocal();
  const summary = getUserLedgerSummary(username);

  res.json({
    ok: true,
    msg: `✅ Customer ${username} cycle updated! Cycle: ${startDateStr} to ${day7Str} (Grace till ${graceUntilStr}). Rate: ₹${rate}/bot/day (${elapsedDaysCount || 1}/7 Days elapsed). Balance due: ₹${summary.balance_due}`,
    start_date: startDateStr,
    expiry_date: day7Str,
    grace_period_until: graceUntilStr,
    live_bots: liveBots,
    rate_per_bot: rate,
    model,
    elapsed_days: elapsedDaysCount || 1,
    summary
  });
});

// 💼 Extra Service Fee / Add-on Service Endpoint (Completely isolated from Regular Bot Due)
app.post('/api/admin/billing/extra-service/add', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  const { username, service_title, amount, date, note, mark_paid, payment_mode } = req.body || {};
  if (!username) return res.status(400).json({ ok: false, msg: 'Username is required!' });
  
  const numAmt = Number(amount);
  if (isNaN(numAmt) || numAmt <= 0) {
    return res.status(400).json({ ok: false, msg: 'Valid positive amount required for extra service!' });
  }

  const sTitle = (service_title || 'Custom Service / Add-on').trim();
  const sDate = (date || getTodayDateString()).trim();
  const isPaid = Boolean(mark_paid);

  const invoice = addBillingInvoice({
    username,
    date: sDate,
    amount: numAmt,
    type: 'extra_service',
    description: `💼 Extra Service: ${sTitle}${note ? ' — ' + note : ''}`,
    status: isPaid ? 'paid' : 'due'
  });

  if (isPaid) {
    addBillingPayment({
      username,
      date: sDate,
      amount: numAmt,
      mode: payment_mode || 'UPI',
      reference: `Extra Service: ${sTitle}`,
      note: `💼 Extra Service Payment: "${sTitle}" (Non-deductible from Bot Usage)`,
      is_extra_service: true
    });
  }

  saveBillingLocal();
  const summary = getUserLedgerSummary(username);

  res.json({
    ok: true,
    msg: `💼 Extra Service "${sTitle}" (₹${numAmt}) ${isPaid ? 'recorded & marked PAID' : 'added to user extra due'}!`,
    invoice,
    summary
  });
});

// Edit existing billing entry (Invoice, Payment, or Offer)
app.post('/api/admin/billing/entry/edit', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  const { entry_type, id, username, amount, date, description, note, mode, reference, offer_name, bonus_days } = req.body || {};

  if (!id || !entry_type) {
    return res.status(400).json({ ok: false, msg: 'Entry ID and entry_type (invoice|payment|offer) required!' });
  }

  const numAmt = Number(amount);

  if (entry_type === 'invoice') {
    if (isNaN(numAmt) || numAmt === 0) return res.status(400).json({ ok: false, msg: 'Valid non-zero amount required!' });
    const inv = billingStore.invoices.find(i => i.id === id);
    if (!inv) return res.status(404).json({ ok: false, msg: 'Invoice record not found!' });
    if (username) inv.username = username.trim();
    inv.amount = numAmt;
    if (date) inv.date = date;
    if (description !== undefined) inv.description = description;
    saveBillingLocal();
    const summary = getUserLedgerSummary(inv.username);
    return res.json({
      ok: true,
      msg: `Invoice updated successfully! User "${inv.username}" balance due: ₹${summary.balance_due}`,
      updated: inv,
      summary
    });
  } else if (entry_type === 'payment') {
    if (isNaN(numAmt) || numAmt <= 0) return res.status(400).json({ ok: false, msg: 'Valid positive amount required!' });
    const pay = billingStore.payments.find(p => p.id === id);
    if (!pay) return res.status(404).json({ ok: false, msg: 'Payment record not found!' });
    if (username) pay.username = username.trim();
    pay.amount = Math.abs(numAmt);
    if (date) pay.date = date;
    if (mode) pay.mode = mode;
    if (reference !== undefined) pay.reference = reference;
    if (note !== undefined) pay.note = note;
    saveBillingLocal();
    const summary = getUserLedgerSummary(pay.username);
    return res.json({
      ok: true,
      msg: `Payment updated successfully! User "${pay.username}" balance due: ₹${summary.balance_due}`,
      updated: pay,
      summary
    });
  } else if (entry_type === 'offer') {
    if (!Array.isArray(billingStore.offers)) billingStore.offers = [];
    const off = billingStore.offers.find(o => o.id === id);
    if (!off) return res.status(404).json({ ok: false, msg: 'Offer record not found!' });
    if (username) off.username = username.trim();
    if (amount !== undefined) off.discount_amount = Math.max(0, Number(amount) || 0);
    if (bonus_days !== undefined) off.bonus_days = Math.max(0, Number(bonus_days) || 0);
    if (offer_name !== undefined) off.offer_name = (offer_name || '').trim() || 'Special Offer';
    if (date) off.date = date;
    if (note !== undefined) off.note = note;
    saveBillingLocal();
    const summary = getUserLedgerSummary(off.username);
    return res.json({
      ok: true,
      msg: `Offer updated successfully! User "${off.username}" balance due: ₹${summary.balance_due}`,
      updated: off,
      summary
    });
  } else {
    return res.status(400).json({ ok: false, msg: 'Invalid entry_type. Must be "invoice", "payment", or "offer"' });
  }
});

// Delete existing billing entry (Invoice, Payment, or Offer)
app.post('/api/admin/billing/entry/delete', (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  const { entry_type, id } = req.body || {};

  if (!id || !entry_type) {
    return res.status(400).json({ ok: false, msg: 'Entry ID and entry_type (invoice|payment|offer) required!' });
  }

  if (entry_type === 'invoice') {
    const idx = billingStore.invoices.findIndex(i => i.id === id);
    if (idx === -1) return res.status(404).json({ ok: false, msg: 'Invoice not found!' });
    const target = billingStore.invoices[idx];
    billingStore.invoices.splice(idx, 1);
    if (sqliteDb) {
      try { sqliteDb.prepare("DELETE FROM billing_invoices WHERE id = ?").run(id); } catch(e){}
    }
    saveBillingLocal();
    const summary = getUserLedgerSummary(target.username);
    return res.json({
      ok: true,
      msg: `Deleted invoice of ₹${target.amount} for ${target.username}. New balance due: ₹${summary.balance_due}`,
      summary
    });
  } else if (entry_type === 'payment') {
    const idx = billingStore.payments.findIndex(p => p.id === id);
    if (idx === -1) return res.status(404).json({ ok: false, msg: 'Payment not found!' });
    const target = billingStore.payments[idx];
    billingStore.payments.splice(idx, 1);
    if (sqliteDb) {
      try { sqliteDb.prepare("DELETE FROM billing_payments WHERE id = ?").run(id); } catch(e){}
    }
    saveBillingLocal();
    const summary = getUserLedgerSummary(target.username);
    return res.json({
      ok: true,
      msg: `Deleted payment of ₹${target.amount} for ${target.username}. New balance due: ₹${summary.balance_due}`,
      summary
    });
  } else if (entry_type === 'offer') {
    if (!Array.isArray(billingStore.offers)) billingStore.offers = [];
    const idx = billingStore.offers.findIndex(o => o.id === id);
    if (idx === -1) return res.status(404).json({ ok: false, msg: 'Offer not found!' });
    const target = billingStore.offers[idx];
    billingStore.offers.splice(idx, 1);
    saveBillingLocal();
    const summary = getUserLedgerSummary(target.username);
    return res.json({
      ok: true,
      msg: `Deleted offer "${target.offer_name}" for ${target.username}. New balance due: ₹${summary.balance_due}`,
      summary
    });
  } else {
    return res.status(400).json({ ok: false, msg: 'Invalid entry_type' });
  }
});

app.post('/api/admin/billing/compensate', async (req: any, res: any) => {
  if (!isAdminSession(req)) return res.status(403).json({ ok: false, msg: 'Admin access required!' });
  const { scope, target_username, target_phone, action_type, days_count, rupee_amount, reason } = req.body || {};
  const todayStr = getTodayDateString();

  if (action_type === 'add_days') {
    const days = Number(days_count) || 1;
    if (days <= 0) return res.status(400).json({ ok: false, msg: 'Invalid number of days!' });

    if (scope === 'global') {
      let count = 0;
      for (const u of usersList) {
        if (u.role === 'admin' || !u.expiry_date) continue;
        let curExpMs = new Date(u.expiry_date + 'T23:59:59Z').getTime();
        if (isNaN(curExpMs) || curExpMs < Date.now()) curExpMs = Date.now();
        const newExpMs = curExpMs + (days * 86400 * 1000);
        u.expiry_date = new Date(newExpMs).toISOString().split('T')[0];
        count++;
      }
      saveUsers();
      billingStore.downtimes.unshift({
        id: 'down_' + Date.now(),
        date: todayStr,
        created_at: Date.now(),
        affected_scope: 'global',
        action_type: 'add_days',
        amount: days,
        reason: reason || 'Global server downtime compensation'
      });
      saveBillingLocal();
      return res.json({ ok: true, msg: `Compensated all ${count} panel users with +${days} extra days validity!` });
    } else {
      const u = getUser(target_username || '');
      if (!u) return res.status(404).json({ ok: false, msg: 'User not found!' });
      let curExpMs = u.expiry_date ? new Date(u.expiry_date + 'T23:59:59Z').getTime() : Date.now();
      if (isNaN(curExpMs) || curExpMs < Date.now()) curExpMs = Date.now();
      const newExpMs = curExpMs + (days * 86400 * 1000);
      u.expiry_date = new Date(newExpMs).toISOString().split('T')[0];
      saveUsers();
      billingStore.downtimes.unshift({
        id: 'down_' + Date.now(),
        date: todayStr,
        created_at: Date.now(),
        affected_scope: target_phone ? 'single_account' : 'single_user',
        target_username,
        target_phone,
        action_type: 'add_days',
        amount: days,
        reason: reason || 'Service issue compensation'
      });
      saveBillingLocal();
      return res.json({ ok: true, msg: `Extended ${target_username}'s plan by +${days} extra days. New Expiry: ${u.expiry_date}` });
    }
  } else if (action_type === 'rupee_credit') {
    const credit = Number(rupee_amount) || 0;
    if (credit <= 0) return res.status(400).json({ ok: false, msg: 'Invalid credit amount!' });

    if (scope === 'global') {
      const panelUsers = usersList.filter(u => u.role !== 'admin');
      for (const u of panelUsers) {
        addBillingInvoice({
          username: u.username,
          date: todayStr,
          amount: -credit,
          type: 'compensation_discount',
          description: `Server Maintenance Credit: ${reason || 'Global Downtime'}`,
          status: 'paid'
        });
      }
      billingStore.downtimes.unshift({
        id: 'down_' + Date.now(),
        date: todayStr,
        created_at: Date.now(),
        affected_scope: 'global',
        action_type: 'rupee_credit',
        amount: credit,
        reason: reason || 'Global server downtime rupee discount'
      });
      saveBillingLocal();
      return res.json({ ok: true, msg: `Deducted ₹${credit} credit from all ${panelUsers.length} user balances!` });
    } else {
      const u = getUser(target_username || '');
      if (!u) return res.status(404).json({ ok: false, msg: 'User not found!' });
      addBillingInvoice({
        username: u.username,
        date: todayStr,
        amount: -credit,
        type: 'compensation_discount',
        description: `Compensation Credit (${target_phone || 'Issue'}): ${reason || 'Admin fault adjustment'}`,
        status: 'paid'
      });
      billingStore.downtimes.unshift({
        id: 'down_' + Date.now(),
        date: todayStr,
        created_at: Date.now(),
        affected_scope: target_phone ? 'single_account' : 'single_user',
        target_username,
        target_phone,
        action_type: 'rupee_credit',
        amount: credit,
        reason: reason || 'Account issue credit'
      });
      saveBillingLocal();
      const sum = getUserLedgerSummary(u.username);
      return res.json({ ok: true, msg: `Deducted ₹${credit} compensation from ${u.username}'s bill. Current due: ₹${sum.balance_due}` });
    }
  }
  return res.status(400).json({ ok: false, msg: 'Invalid compensation parameters!' });
});

// ---------------- ADMIN TELEGRAM API RATE & HEALTH MONITOR ----------------
app.get('/api/admin/rate-monitor', (req: any, res: any) => {
  const me = getUser(req.session?.username || '');
  if (!me || me.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied. Super Admin required.' });
  }

  const allAccounts = Array.from(accounts.values());
  const monitorData = allAccounts.map(acc => {
    const owner = acc.owner || 'admin';
    const stats = getAccountRateStats(acc.phone);
    return {
      phone: acc.phone,
      label: acc.label || acc.config?.display_name || acc.phone,
      owner,
      username: acc.username || (acc.config?.display_name || ''),
      running: Boolean(acc.running),
      status: acc.status || 'Stopped',
      daily_extracted: (acc as any).daily_extracted_count || 0,
      daily_sent: (acc as any).daily_sent_count || 0,
      total_sent: acc.sent_count || 0,
      rpm: stats.rpm,
      callsLast5Min: stats.callsLast5Min,
      dmsLast1Min: stats.dmsLast1Min,
      healthStatus: stats.healthStatus,
      healthLabel: stats.healthLabel,
      safeColor: stats.safeColor,
      isCustomThrottled: stats.isCustomThrottled,
      throttleSecondsRemaining: stats.throttleSecondsRemaining,
      lastActive: acc.last_active || 0,
      lastCallTs: stats.lastCallTs
    };
  });

  // Calculate system-wide summary metrics
  const totalRpm = monitorData.reduce((sum, item) => sum + item.rpm, 0);
  const totalDmsMin = monitorData.reduce((sum, item) => sum + item.dmsLast1Min, 0);
  const activeBotsCount = monitorData.filter(i => i.running).length;
  const highRiskCount = monitorData.filter(i => i.rpm >= 20 || i.isCustomThrottled).length;

  res.json({
    success: true,
    totalRpm,
    totalDmsMin,
    activeBotsCount,
    totalAccountsCount: monitorData.length,
    highRiskCount,
    accounts: monitorData
  });
});

// 🎨 Global User Dashboard Theme Endpoints
app.get('/api/system/theme', (req, res) => {
  res.json({ ok: true, theme: getGlobalTheme() });
});

app.post('/api/admin/system/theme', (req: any, res: any) => {
  if (!isAdminSession(req)) {
    return res.status(403).json({ ok: false, msg: 'Access denied: Admin credentials required.' });
  }
  const theme = String(req.body?.theme || '').trim().toLowerCase();
  const validThemes = ['cyberpunk', 'oled', 'gold', 'crimson', 'emerald', 'light'];
  if (!validThemes.includes(theme)) {
    return res.status(400).json({ ok: false, msg: `Invalid theme. Choose from: ${validThemes.join(', ')}` });
  }
  saveGlobalTheme(theme);
  broadcastAccountUpdate('admin');
  broadcastAccountUpdate('all');
  console.log(`[THEME SWITCH] Super Admin changed global user dashboard theme to "${theme}"`);
  res.json({ ok: true, theme, msg: `🎨 Dashboard theme updated to '${theme.toUpperCase()}'! Applied to all user dashboards.` });
});

// Admin action to manually trigger midnight sent DM transfer sweep
app.post('/api/admin/system/trigger-midnight-sweep', async (req: any, res: any) => {
  if (!isAdminSession(req)) {
    return res.status(403).json({ error: 'Access denied: Admin credentials required.' });
  }

  try {
    const moved = await runMidnightQueueTransferSweep(true);
    res.json({
      success: true,
      message: `Midnight sweep executed successfully. Transferred and archived ${moved} sent DM contacts from users to Admin master pool with all peer credentials.`,
      totalMoved: moved
    });
  } catch (e: any) {
    res.status(500).json({ success: false, error: e?.message || String(e) });
  }
});

// Admin action to throttle/pause/resume a specific user's Telegram ID
app.post('/api/admin/rate-monitor/throttle', (req: any, res: any) => {
  const me = getUser(req.session?.username || '');
  if (!me || me.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied.' });
  }

  const { phone, action, seconds } = req.body || {};
  if (!phone) return res.status(400).json({ error: 'Phone number is required.' });

  if (action === 'resume') {
    accountThrottleOverride.delete(phone);
    return res.json({ success: true, msg: `Safe normal mode restored for ${phone}.` });
  } else {
    const duration = parseInt(seconds, 10) || 300; // default 5 mins
    accountThrottleOverride.set(phone, {
      throttled: true,
      reason: 'Admin Emergency Cooldown',
      until: Date.now() + duration * 1000
    });
    return res.json({
      success: true,
      msg: `Account ${phone} paused/slowed down for ${duration} seconds.`
    });
  }
});

// ---------------- GLOBAL API POOL (UNLIMITED KEYS) ADMIN ENDPOINTS ----------------
app.get('/api/admin/api-pool', (req: any, res: any) => {
  const me = getUser(req.session?.username || '');
  if (!me || me.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied. Super Admin required.' });
  }

  const slotsWithStats = apiPool.map(slot => {
    let linkedCount = 0;
    if (slot.api_id > 0) {
      for (const acc of accounts.values()) {
        if (acc.api_id === slot.api_id) linkedCount++;
      }
    }
    return {
      ...slot,
      linkedCount
    };
  });

  const totalAccounts = accounts.size;
  const activeSlotsCount = apiPool.filter(s => s.enabled && s.api_id > 0 && s.api_hash).length;

  res.json({
    success: true,
    slots: slotsWithStats,
    totalAccounts,
    activeSlotsCount,
    totalSlots: apiPool.length
  });
});

app.post('/api/admin/api-pool/update', (req: any, res: any) => {
  const me = getUser(req.session?.username || '');
  if (!me || me.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied. Super Admin required.' });
  }

  const { slots } = req.body || {};
  if (!Array.isArray(slots)) {
    return res.status(400).json({ error: 'Invalid slots data provided.' });
  }

  // Update entire pool dynamically allowing unlimited slots
  const newPool: ApiPoolSlot[] = [];
  slots.forEach((s: any, idx: number) => {
    const slotIdNum = Number(s.id) || (idx + 1);
    newPool.push({
      id: slotIdNum,
      slot_id: s.slot_id || `api_${slotIdNum}`,
      api_id: Number(s.api_id) || 0,
      api_hash: String(s.api_hash || '').trim(),
      label: String(s.label || `Pool Slot #${slotIdNum}`).trim(),
      enabled: s.enabled !== false
    });
  });

  apiPool = newPool;
  saveApiPool();
  res.json({
    success: true,
    msg: `Global API Key Pool updated successfully! (${apiPool.length} slots active)`,
    totalSlots: apiPool.length
  });
});

app.post('/api/admin/api-pool/add-slot', (req: any, res: any) => {
  const me = getUser(req.session?.username || '');
  if (!me || me.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied. Super Admin required.' });
  }

  const maxId = apiPool.reduce((m, s) => Math.max(m, s.id || 0), 0);
  const nextId = maxId + 1;
  const newSlot: ApiPoolSlot = {
    id: nextId,
    slot_id: `api_${nextId}`,
    api_id: Number(req.body?.api_id) || 0,
    api_hash: String(req.body?.api_hash || '').trim(),
    label: String(req.body?.label || `Custom Pool Slot ${nextId}`).trim(),
    enabled: true
  };

  apiPool.push(newSlot);
  saveApiPool();
  res.json({ success: true, slot: newSlot, msg: `API Slot #${nextId} created successfully!`, totalSlots: apiPool.length });
});

app.post('/api/admin/api-pool/delete-slot', (req: any, res: any) => {
  const me = getUser(req.session?.username || '');
  if (!me || me.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied. Super Admin required.' });
  }

  const targetId = Number(req.body?.id);
  if (!targetId) {
    return res.status(400).json({ error: 'Slot ID is required to delete.' });
  }

  const initialCount = apiPool.length;
  apiPool = apiPool.filter(s => s.id !== targetId);

  if (apiPool.length === initialCount) {
    return res.status(404).json({ error: `Slot #${targetId} not found.` });
  }

  saveApiPool();
  res.json({ success: true, msg: `Slot #${targetId} deleted successfully.`, totalSlots: apiPool.length });
});

app.post('/api/admin/api-pool/reset-defaults', (req: any, res: any) => {
  if (!isAdminSession(req)) {
    return res.status(403).json({ error: 'Access denied. Super Admin required.' });
  }

  apiPool = defaultApiPool();
  saveApiPool();
  res.json({ success: true, msg: 'Global API Pool reset to standard high-speed default keys!' });
});


// ---------------- UNIVERSAL AI SETTINGS & PROVIDER SWITCHING ENDPOINTS ----------------
app.get('/api/admin/ai-config', (req: any, res: any) => {
  if (!isAdminSession(req)) {
    return res.status(403).json({ success: false, error: 'Access denied. Super Admin required.' });
  }

  res.json({
    success: true,
    config: {
      ...globalAiConfig,
      has_gemini_env: Boolean(process.env.GEMINI_API_KEY),
      has_openai_env: Boolean(process.env.OPENAI_API_KEY),
      has_deepseek_env: Boolean(process.env.DEEPSEEK_API_KEY),
      has_groq_env: Boolean(process.env.GROQ_API_KEY)
    }
  });
});

app.post('/api/admin/ai-config/update', (req: any, res: any) => {
  if (!isAdminSession(req)) {
    return res.status(403).json({ success: false, error: 'Access denied. Super Admin required.' });
  }

  const payload = req.body || {};

  // Node.js Strict Lead Filtering Rules
  if (payload.nodejs_filter_enabled !== undefined) globalAiConfig.nodejs_filter_enabled = Boolean(payload.nodejs_filter_enabled);
  if (payload.reject_usernames !== undefined) globalAiConfig.reject_usernames = Boolean(payload.reject_usernames);
  if (payload.allow_no_photo_no_username !== undefined) globalAiConfig.allow_no_photo_no_username = Boolean(payload.allow_no_photo_no_username);
  if (payload.reject_premium !== undefined) globalAiConfig.reject_premium = Boolean(payload.reject_premium);
  if (payload.reject_admins !== undefined) globalAiConfig.reject_admins = Boolean(payload.reject_admins);
  if (payload.reject_bots !== undefined) globalAiConfig.reject_bots = Boolean(payload.reject_bots);
  if (payload.reject_deleted !== undefined) globalAiConfig.reject_deleted = Boolean(payload.reject_deleted);
  if (payload.reject_scam_keywords !== undefined) globalAiConfig.reject_scam_keywords = Boolean(payload.reject_scam_keywords);
  if (payload.channel_lock_early !== undefined) globalAiConfig.channel_lock_early = Boolean(payload.channel_lock_early);

  // Custom reject / allow keywords
  if (Array.isArray(payload.custom_reject_keywords)) {
    globalAiConfig.custom_reject_keywords = payload.custom_reject_keywords
      .flatMap((s: string) => String(s || '').split(/[,\n\r]+/))
      .map((s: string) => s.trim())
      .filter(Boolean);
  } else if (typeof payload.custom_reject_keywords === 'string') {
    globalAiConfig.custom_reject_keywords = payload.custom_reject_keywords
      .split(/[,\n\r]+/)
      .map((s: string) => s.trim())
      .filter(Boolean);
  }
  if (Array.isArray(payload.custom_allow_keywords)) {
    globalAiConfig.custom_allow_keywords = payload.custom_allow_keywords
      .flatMap((s: string) => String(s || '').split(/[,\n\r]+/))
      .map((s: string) => s.trim())
      .filter(Boolean);
  } else if (typeof payload.custom_allow_keywords === 'string') {
    globalAiConfig.custom_allow_keywords = payload.custom_allow_keywords
      .split(/[,\n\r]+/)
      .map((s: string) => s.trim())
      .filter(Boolean);
  }

  // AI Filtering settings
  if (payload.filter_provider !== undefined) globalAiConfig.filter_provider = payload.filter_provider;
  if (payload.filter_model !== undefined) globalAiConfig.filter_model = String(payload.filter_model || '').trim();
  if (payload.filter_api_key !== undefined) globalAiConfig.filter_api_key = String(payload.filter_api_key || '').trim();
  if (payload.filter_api_url !== undefined) globalAiConfig.filter_api_url = String(payload.filter_api_url || '').trim();
  if (payload.filter_enabled !== undefined) globalAiConfig.filter_enabled = Boolean(payload.filter_enabled);
  if (payload.filter_mode !== undefined) globalAiConfig.filter_mode = payload.filter_mode;
  if (payload.filter_persona !== undefined) globalAiConfig.filter_persona = String(payload.filter_persona || '').trim();
  if (payload.filter_strictness !== undefined) globalAiConfig.filter_strictness = payload.filter_strictness;

  // AI DM settings
  if (payload.dm_enabled !== undefined) globalAiConfig.dm_enabled = Boolean(payload.dm_enabled);
  if (payload.dm_provider !== undefined) globalAiConfig.dm_provider = payload.dm_provider;
  if (payload.dm_model !== undefined) globalAiConfig.dm_model = String(payload.dm_model || '').trim();
  if (payload.dm_api_key !== undefined) globalAiConfig.dm_api_key = String(payload.dm_api_key || '').trim();
  if (payload.dm_api_url !== undefined) globalAiConfig.dm_api_url = String(payload.dm_api_url || '').trim();
  if (payload.dm_system_prompt !== undefined) globalAiConfig.dm_system_prompt = String(payload.dm_system_prompt || '').trim();

  saveGlobalAiConfig();
  res.json({ success: true, msg: 'Configuration saved & updated successfully!', config: globalAiConfig });
});

app.post('/api/admin/ai-config/auto-detect-key', async (req: any, res: any) => {
  if (!isAdminSession(req)) {
    return res.status(403).json({ success: false, error: 'Access denied. Super Admin required.' });
  }

  const { api_key, apply_to } = req.body || {};
  const rawKey = String(api_key || '').trim();
  if (!rawKey) {
    return res.status(400).json({ success: false, error: 'Please enter an API Key to auto-detect and verify!' });
  }

  // Support single or multiple keys (separated by comma, semicolon, or newline)
  const keyList = rawKey.split(/[\n,;]+/).map((k: string) => k.trim()).filter(Boolean);
  if (keyList.length === 0) {
    return res.status(400).json({ success: false, error: 'No valid API keys found in input!' });
  }

  const detectedKeys: Array<{
    key_index: number;
    preview: string;
    provider: 'gemini' | 'groq' | 'deepseek' | 'openai';
    provider_label: string;
    best_model: string;
    status: string;
  }> = [];

  let primaryProvider: 'gemini' | 'groq' | 'deepseek' | 'openai' = 'groq';
  let primaryModel = 'llama-3.1-8b-instant';

  for (let i = 0; i < keyList.length; i++) {
    const singleKey = keyList[i];
    let prov: 'gemini' | 'groq' | 'deepseek' | 'openai' = 'gemini';
    let provLabel = 'Google Gemini';
    let mod = 'gemini-3.1-flash-lite';

    if (singleKey.startsWith('gsk_')) {
      prov = 'groq';
      provLabel = 'Groq Cloud (Ultra Fast 14.4k Free/Day)';
      mod = 'llama-3.1-8b-instant';
    } else if (singleKey.startsWith('AIzaSy')) {
      prov = 'gemini';
      provLabel = 'Google Gemini';
      mod = 'gemini-3.1-flash-lite';
    } else if (singleKey.startsWith('sk-') && singleKey.length > 50) {
      prov = 'openai';
      provLabel = 'OpenAI';
      mod = 'gpt-4o-mini';
    } else if (singleKey.startsWith('sk-')) {
      prov = 'deepseek';
      provLabel = 'DeepSeek AI';
      mod = 'deepseek-chat';
    }

    if (i === 0) {
      primaryProvider = prov;
      primaryModel = mod;
    }

    const preview = singleKey.length > 12
      ? `${singleKey.slice(0, 6)}...${singleKey.slice(-4)}`
      : singleKey;

    detectedKeys.push({
      key_index: i + 1,
      preview,
      provider: prov,
      provider_label: provLabel,
      best_model: mod,
      status: 'Active Pool Slot'
    });
  }

  // Quick live verify on the first key if it's Groq or Gemini
  try {
    const firstKey = keyList[0];
    if (primaryProvider === 'groq') {
      const testRes = await fetch('https://api.groq.com/openai/v1/models', {
        headers: { 'Authorization': `Bearer ${firstKey}` },
        signal: AbortSignal.timeout(6000)
      }).catch(() => null);
      if (testRes && testRes.ok) {
        detectedKeys[0].status = 'Verified & Ready';
      }
    } else if (primaryProvider === 'gemini') {
      const testRes = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${firstKey}`, {
        signal: AbortSignal.timeout(6000)
      }).catch(() => null);
      if (testRes && testRes.ok) {
        detectedKeys[0].status = 'Verified & Ready';
      }
    }
  } catch {}

  // Auto-apply to globalAiConfig
  const target = apply_to || 'dm';
  if (target === 'dm' || target === 'both') {
    globalAiConfig.dm_provider = primaryProvider;
    globalAiConfig.dm_api_key = rawKey;
    globalAiConfig.dm_model = primaryModel;
    globalAiConfig.dm_enabled = true;
  }
  if (target === 'filter' || target === 'both') {
    globalAiConfig.filter_provider = primaryProvider;
    globalAiConfig.filter_api_key = rawKey;
    globalAiConfig.filter_model = primaryModel;
  }

  saveGlobalAiConfig();

  return res.json({
    success: true,
    total_keys: keyList.length,
    detected_keys: detectedKeys,
    primary_provider: primaryProvider,
    primary_model: primaryModel,
    config: globalAiConfig,
    msg: keyList.length > 1
      ? `Multi-Key Pool detected: ${keyList.length} API keys configured! Automatic rotation & failover active.`
      : `Verified ${detectedKeys[0].provider_label}! Model: "${primaryModel}" activated automatically.`
  });
});

// ==================== GROWTH & BROADCAST MASTER ENGINE ROUTES ====================
// 1. Admin Growth Bot Config & Status
app.get('/api/admin/growth/config', (req: any, res: any) => {
  if (!isAdminSession(req)) {
    return res.status(403).json({ success: false, error: 'Access denied. Super Admin required.' });
  }
  const config = getGrowthBotConfig();
  res.json({ success: true, config });
});

app.post('/api/admin/growth/config', (req: any, res: any) => {
  if (!isAdminSession(req)) {
    return res.status(403).json({ success: false, error: 'Access denied. Super Admin required.' });
  }
  const { bot_token, bot_username, enabled, global_broadcast_delay_ms } = req.body || {};
  const updated = saveGrowthBotConfig({
    bot_token: bot_token !== undefined ? String(bot_token).trim() : undefined,
    bot_username: bot_username !== undefined ? String(bot_username).trim().replace(/^@/, '') : undefined,
    enabled: enabled !== undefined ? Boolean(enabled) : undefined,
    global_broadcast_delay_ms: global_broadcast_delay_ms !== undefined ? Number(global_broadcast_delay_ms) : undefined
  });
  res.json({ success: true, msg: 'Master Growth Bot configuration saved!', config: updated });
});

app.post('/api/admin/growth/test-token', async (req: any, res: any) => {
  if (!isAdminSession(req)) {
    return res.status(403).json({ success: false, error: 'Access denied. Super Admin required.' });
  }
  const { bot_token } = req.body || {};
  const result = await testGrowthBotToken(bot_token);
  res.json(result);
});

app.get('/api/admin/growth/overview', (req: any, res: any) => {
  if (!isAdminSession(req)) {
    return res.status(403).json({ success: false, error: 'Access denied. Super Admin required.' });
  }
  const stats = getGlobalSubscriberStats();
  const campaigns = getAllCampaigns();
  const config = getGrowthBotConfig();
  res.json({ success: true, stats, campaigns, bot_username: config.bot_username });
});

// 2. User Growth Campaigns & Link Generator
app.get('/api/user/growth/bot-info', (req: any, res: any) => {
  const sessionUser = getSessionUser(req);
  if (!sessionUser) return res.status(401).json({ ok: false, msg: 'Not logged in' });
  const config = getGrowthBotConfig();
  res.json({
    ok: true,
    bot_configured: Boolean(config.bot_token && config.enabled),
    bot_username: config.bot_username || ''
  });
});

app.get('/api/user/growth/campaigns', (req: any, res: any) => {
  const sessionUser = getSessionUser(req);
  if (!sessionUser) return res.status(401).json({ ok: false, msg: 'Not logged in' });
  const currentUser = req.session?.view_as || sessionUser.username;
  const campaigns = getCampaignsByOwner(currentUser);
  const config = getGrowthBotConfig();
  res.json({
    ok: true,
    bot_username: config.bot_username,
    campaigns
  });
});

app.post('/api/user/growth/campaigns/save', (req: any, res: any) => {
  const sessionUser = getSessionUser(req);
  if (!sessionUser) return res.status(401).json({ ok: false, msg: 'Not logged in' });
  const currentUser = req.session?.view_as || sessionUser.username;
  const result = saveCampaign(currentUser, req.body || {});
  if (!result.ok) {
    return res.status(400).json(result);
  }
  const config = getGrowthBotConfig();
  const deepLink = config.bot_username && result.campaign?.campaign_slug
    ? `https://t.me/${config.bot_username}?start=${result.campaign.campaign_slug}`
    : '';
  res.json({ ok: true, campaign: result.campaign, deep_link: deepLink });
});

app.post('/api/user/growth/campaigns/delete', (req: any, res: any) => {
  const sessionUser = getSessionUser(req);
  if (!sessionUser) return res.status(401).json({ ok: false, msg: 'Not logged in' });
  const currentUser = req.session?.view_as || sessionUser.username;
  const { id } = req.body || {};
  if (!id) return res.status(400).json({ ok: false, msg: 'Campaign ID required' });
  const ok = deleteCampaign(id, currentUser);
  res.json({ ok, msg: ok ? 'Campaign deleted' : 'Failed to delete campaign' });
});

// Admin Authority: Billing Kill-Switch & Customer Telegram Linking
app.post('/api/admin/growth/campaigns/toggle-billing', (req: any, res: any) => {
  const sessionUser = getSessionUser(req);
  if (!sessionUser || sessionUser.role !== 'admin') {
    return res.status(403).json({ ok: false, msg: 'Admin authority required' });
  }
  const { slug, status, notes } = req.body || {};
  if (!slug || !status) return res.status(400).json({ ok: false, msg: 'Slug and status required' });
  const ok = setCampaignBillingStatus(slug, status, notes);
  res.json({ ok, msg: ok ? `Campaign billing status updated to ${status}` : 'Failed to update billing status' });
});

app.post('/api/admin/growth/campaigns/link-customer', (req: any, res: any) => {
  const sessionUser = getSessionUser(req);
  if (!sessionUser || sessionUser.role !== 'admin') {
    return res.status(403).json({ ok: false, msg: 'Admin authority required' });
  }
  const { slug, customer_tg_id } = req.body || {};
  if (!slug || !customer_tg_id) return res.status(400).json({ ok: false, msg: 'Slug and customer_tg_id required' });
  const ok = linkCampaignToCustomerTg(slug, customer_tg_id);
  res.json({ ok, msg: ok ? `Campaign linked to Telegram user: ${customer_tg_id}` : 'Failed to link customer' });
});

// 3. User Subscribers & Analytics
app.get('/api/user/growth/subscribers', (req: any, res: any) => {
  const sessionUser = getSessionUser(req);
  if (!sessionUser) return res.status(401).json({ ok: false, msg: 'Not logged in' });
  const currentUser = req.session?.view_as || sessionUser.username;
  const limit = Math.min(Number(req.query.limit) || 200, 500);
  const offset = Number(req.query.offset) || 0;
  const data = getSubscribersByOwner(currentUser, limit, offset);
  res.json({ ok: true, ...data });
});

// 4. User Broadcast Studio
app.post('/api/user/growth/broadcast/send', (req: any, res: any) => {
  const sessionUser = getSessionUser(req);
  if (!sessionUser) return res.status(401).json({ ok: false, msg: 'Not logged in' });
  const currentUser = req.session?.view_as || sessionUser.username;

  const { campaign_name, message_text, media_type, media_url, buttons_json, target_filter } = req.body || {};
  if (!message_text || !String(message_text).trim()) {
    return res.status(400).json({ ok: false, msg: 'Message text is required for broadcast' });
  }

  const result = createBroadcastJob(currentUser, {
    campaign_name: String(campaign_name || 'Quick Broadcast').trim(),
    message_text: String(message_text).trim(),
    media_type: media_type === 'photo' ? 'photo' : 'text',
    media_url: media_url ? String(media_url).trim() : '',
    buttons_json: buttons_json ? String(buttons_json).trim() : '',
    target_filter: target_filter || 'all'
  });

  if (!result.ok) {
    return res.status(400).json(result);
  }
  res.json({ ok: true, msg: 'Broadcast job started successfully in background queue!', job: result.job });
});

app.get('/api/user/growth/broadcast/history', (req: any, res: any) => {
  const sessionUser = getSessionUser(req);
  if (!sessionUser) return res.status(401).json({ ok: false, msg: 'Not logged in' });
  const currentUser = req.session?.view_as || sessionUser.username;
  const history = getBroadcastHistory(currentUser, 50);
  res.json({ ok: true, history });
});

// 5. Direct Gallery Screenshot / Image / Video / Audio Upload
app.post('/api/user/growth/upload-media', (req: any, res: any) => {
  const sessionUser = getSessionUser(req);
  if (!sessionUser) return res.status(401).json({ ok: false, msg: 'Not logged in' });

  const { file_data, file_type, previous_url, filename } = req.body || {};
  if (!file_data || typeof file_data !== 'string') {
    return res.status(400).json({ ok: false, msg: 'No file data provided' });
  }

  try {
    const matches = file_data.match(/^data:([^;]+);base64,(.+)$/);
    if (!matches || matches.length !== 3) {
      return res.status(400).json({ ok: false, msg: 'Invalid file format. Base64 data URL expected.' });
    }

    const mimeType = matches[1].toLowerCase();
    const base64Data = matches[2];
    const buffer = Buffer.from(base64Data, 'base64');

    // Auto-detect extension based on MIME
    let ext = '.bin';
    if (mimeType.includes('png')) ext = '.png';
    else if (mimeType.includes('webp')) ext = '.webp';
    else if (mimeType.includes('gif')) ext = '.gif';
    else if (mimeType.includes('jpeg') || mimeType.includes('jpg')) ext = '.jpg';
    else if (mimeType.includes('mp4')) ext = '.mp4';
    else if (mimeType.includes('webm')) ext = '.webm';
    else if (mimeType.includes('quicktime') || mimeType.includes('mov')) ext = '.mov';
    else if (mimeType.includes('mp3') || mimeType.includes('mpeg')) ext = '.mp3';
    else if (mimeType.includes('wav')) ext = '.wav';
    else if (mimeType.includes('ogg')) ext = '.ogg';
    else if (mimeType.includes('m4a')) ext = '.m4a';
    else if (file_type === 'video') ext = '.mp4';
    else if (file_type === 'audio') ext = '.mp3';
    else if (file_type === 'photo') ext = '.jpg';

    // Delete previous upload if replacing
    if (previous_url && typeof previous_url === 'string' && (previous_url.startsWith('/uploads/') || previous_url.startsWith('uploads/'))) {
      try {
        const oldPath = path.join(process.cwd(), previous_url.replace(/^\//, ''));
        if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
      } catch (e) {}
    }

    const prefix = file_type ? `growth_${file_type}` : 'growth_file';
    const cleanName = `${prefix}_${Date.now()}_${crypto.randomBytes(4).toString('hex')}${ext}`;
    const filePath = path.join(UPLOADS_DIR, cleanName);

    fs.writeFileSync(filePath, buffer);

    const relativeUrl = `/uploads/${cleanName}`;
    return res.json({
      ok: true,
      url: relativeUrl,
      media_url: relativeUrl,
      file_type: file_type || 'file',
      size_bytes: buffer.length,
      msg: 'File uploaded successfully!'
    });
  } catch (err: any) {
    console.error('upload-media error:', err);
    return res.status(500).json({ ok: false, msg: 'Failed to save uploaded file: ' + err.message });
  }
});

app.post('/api/user/growth/upload-image', (req: any, res: any) => {
  const sessionUser = getSessionUser(req);
  if (!sessionUser) return res.status(401).json({ ok: false, msg: 'Not logged in' });

  const { image_data, filename, previous_url } = req.body || {};
  if (!image_data || typeof image_data !== 'string') {
    return res.status(400).json({ ok: false, msg: 'No image data provided' });
  }

  try {
    const matches = image_data.match(/^data:([A-Za-z0-9\-\+\/]+);base64,(.+)$/);
    if (!matches || matches.length !== 3) {
      return res.status(400).json({ ok: false, msg: 'Invalid image format. Base64 expected.' });
    }

    const mimeType = matches[1];
    const base64Data = matches[2];
    const buffer = Buffer.from(base64Data, 'base64');

    let ext = '.jpg';
    if (mimeType.includes('png')) ext = '.png';
    else if (mimeType.includes('webp')) ext = '.webp';
    else if (mimeType.includes('gif')) ext = '.gif';

    // Delete old if replacing
    if (previous_url && typeof previous_url === 'string' && (previous_url.startsWith('/uploads/') || previous_url.startsWith('uploads/'))) {
      try {
        const oldPath = path.join(process.cwd(), previous_url.replace(/^\//, ''));
        if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
      } catch (e) {}
    }

    const cleanName = `growth_${Date.now()}_${crypto.randomBytes(4).toString('hex')}${ext}`;
    const filePath = path.join(UPLOADS_DIR, cleanName);

    fs.writeFileSync(filePath, buffer);

    const relativeUrl = `/uploads/${cleanName}`;
    return res.json({
      ok: true,
      url: relativeUrl,
      media_url: relativeUrl,
      msg: 'Image uploaded successfully from gallery!'
    });
  } catch (err: any) {
    console.error('upload-image error:', err);
    return res.status(500).json({ ok: false, msg: 'Failed to save image: ' + err.message });
  }
});

app.post('/api/admin/ai-config/test', async (req: any, res: any) => {
  if (!isAdminSession(req)) {
    return res.status(403).json({ success: false, error: 'Access denied. Super Admin required.' });
  }

  const { task, test_bio, test_name, test_username } = req.body || {};

  try {
    if (task === 'filtering') {
      const uName = String(test_username || '').trim();
      const bText = String(test_bio || '').trim();
      const fName = String(test_name || '').trim();

      // 1. Check Node.js Strict Rules first (0ms latency)
      if (globalAiConfig.reject_usernames !== false && uName) {
        return res.json({
          success: true,
          task: 'filtering',
          engine: 'Node.js Strict Filter (0ms)',
          verdict: {
            status: 'REJECTED',
            reason: `Account has @${uName.replace(/^@/, '')} (Strictly rejected by Node.js Rule: No @usernames allowed)`,
            category: 'has_username'
          }
        });
      }

      const dummyObj = {
        firstName: fName,
        lastName: '',
        username: uName,
        about: bText
      };
      const spamCheck = isTelegramUserSpamOrPromo(dummyObj);
      if (spamCheck.isSpam) {
        return res.json({
          success: true,
          task: 'filtering',
          engine: 'Node.js Pattern & Blacklist Filter (0ms)',
          verdict: {
            status: 'REJECTED',
            reason: spamCheck.reason,
            category: 'spam_bio'
          }
        });
      }

      // If AI testing is requested or AI filter is enabled
      if (req.body.force_ai) {
        const results = await analyzeTelegramUsersBatch([{
          uid: 999999999,
          firstName: fName || 'Test User',
          lastName: '',
          username: uName,
          about: bText
        }]);
        const verdict = results.get(999999999);
        return res.json({
          success: true,
          task: 'filtering',
          engine: `AI Model (${globalAiConfig.filter_provider} - ${globalAiConfig.filter_model})`,
          verdict: verdict || { status: 'UNKNOWN', reason: 'No result returned from model' }
        });
      }

      // Passed all Node.js strict rules!
      return res.json({
        success: true,
        task: 'filtering',
        engine: 'Node.js Strict Filter (0ms)',
        verdict: {
          status: 'APPROVED',
          reason: '✅ Verified Genuine Lead! (Clean bio, no scam keywords, eligible for Genuine Queue)',
          category: 'genuine'
        }
      });
    } else {
      const { custom_dm, recipient_name, channel_link, variations_count } = req.body || {};
      const numVars = variations_count === 3 ? 3 : 1;
      const recName = recipient_name && String(recipient_name).trim() ? String(recipient_name).trim() : 'Rohit';
      const chLink = channel_link && String(channel_link).trim() ? String(channel_link).trim() : 'https://t.me/tech_deals';
      const baseMsg = custom_dm && String(custom_dm).trim()
        ? String(custom_dm).trim()
        : 'Hey Rohit! Found this really cool tech community for exclusive deals and updates, thought you’d like it: https://t.me/tech_deals. Ek baar check karle, kaafi mast offers aate hain yahan!';

      if (numVars === 3) {
        const prompt = `You are an expert Telegram outreach copywriter.
The user provided their base DM message or campaign pitch:
"""
${baseMsg}
"""

Target Recipient First Name: ${recName}
Target Link / Channel: ${chLink}

Task: Generate 3 distinct, natural, human-sounding variations of this DM in natural Hinglish (or natural English if the base message is in English).
Rules:
1. Each variation must convey the exact same core message and offer, but use completely different openers, sentence structures, and styles so Telegram anti-spam algorithms never flag them.
2. Variation 1 Tone: Casual & Friendly (like a friend or fellow member recommending something cool).
3. Variation 2 Tone: Short & Direct (crisp, zero fluff, straight to the point).
4. Variation 3 Tone: Conversational Opener (soft conversational question or curious lead-in).
5. Naturally incorporate recipient's name (${recName}) where appropriate.
6. Make sure the link (${chLink}) is included in each variation.
7. Keep each variation between 1 to 3 sentences. No corporate marketing buzzwords. Sound 100% human.
8. Output ONLY a valid JSON object in this exact structure:
{
  "variations": [
    { "tone": "Casual & Friendly", "text": "..." },
    { "tone": "Short & Direct", "text": "..." },
    { "tone": "Conversational Opener", "text": "..." }
  ]
}`;

        const rawJson = await callAiEngine({
          task: 'dm',
          prompt,
          systemInstruction: globalAiConfig.dm_system_prompt || "You are a casual human user reaching out on Telegram.",
          temperature: 0.75,
          jsonResponse: true
        });

        let parsed: any = null;
        try {
          parsed = JSON.parse(rawJson.replace(/^```json\s*/i, '').replace(/```\s*$/i, '').trim());
        } catch {}

        const variations = Array.isArray(parsed?.variations) && parsed.variations.length > 0
          ? parsed.variations
          : [
              { tone: "Variation 1 (Casual)", text: rawJson.trim() }
            ];

        return res.json({
          success: true,
          task: 'dm',
          mode: 'variations',
          provider: globalAiConfig.dm_provider,
          model: (callAiEngine as any).lastSuccessfulModel || globalAiConfig.dm_model,
          variations,
          generatedDm: variations[0]?.text || rawJson
        });
      } else {
        const prompt = `User's base message or context:
"""
${baseMsg}
"""
Recipient first name: ${recName}
Target channel/link: ${chLink}

Task: Write a very short, natural-sounding direct message (DM) in Hinglish/English based on the above.
Do NOT sound like a bot. Sound like a real human. Keep it under 2-3 sentences.
Make sure to include the channel link (${chLink}).
Output ONLY the message text, no quotation marks, no preamble.`;

        const dm = await callAiEngine({
          task: 'dm',
          prompt,
          systemInstruction: globalAiConfig.dm_system_prompt || "You are a casual human user reaching out on Telegram.",
          temperature: 0.7
        });

        return res.json({
          success: true,
          task: 'dm',
          mode: 'single',
          provider: globalAiConfig.dm_provider,
          model: (callAiEngine as any).lastSuccessfulModel || globalAiConfig.dm_model,
          generatedDm: dm,
          variations: [
            { tone: "Natural AI DM", text: dm }
          ]
        });
      }
    }
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'AI Test call failed.' });
  }
});

// User-level queue endpoints for logged-in user or view-as
app.get('/api/user/info', (req: any, res: any) => {
  const sessionUser = getSessionUser(req);
  if (!sessionUser) return res.status(401).json({ ok: false, msg: 'Not logged in' });
  const uname = sessionUser.username;
  const u = getUser(uname);
  if (!u) return res.status(404).json({ ok: false, msg: 'User not found' });
  const sum = getUserLedgerSummary(uname);
  res.json({
    ok: true,
    username: u.username,
    display_name: u.display_name || u.username,
    role: u.role || 'user',
    expiry_date: u.expiry_date || 'Lifetime',
    max_accounts: u.max_accounts || 1,
    balance_due: sum.balance_due,
    total_billed: sum.total_billed,
    total_paid: sum.total_paid
  });
});

app.get('/api/user/queue', (req         , res          ) => {
  const currentUser = req.session?.view_as || req.session?.username || 'admin';
  const q = getOwnerQueue(currentUser);
  const peers = getOwnerPeers(currentUser);
  const queueDetails = q.map((uid) => {
    const p = peers.get(String(uid));
    return {
      uid,
      userId: String(uid),
      username: p?.username || '',
      accessHash: p?.accessHash ? 'Yes' : 'No'
    };
  });
  res.json({ success: true, queue: queueDetails, count: q.length });
});

app.post('/api/user/queue/delete', (req         , res          ) => {
  const currentUser = req.session?.view_as || req.session?.username || 'admin';
  const targetUid = Number(req.body?.uid);
  if (!targetUid) return res.status(400).json({ msg: 'Target UID is required!' });

  removeFromOwnerQueue(currentUser, targetUid);
  res.json({ success: true, msg: `User ${targetUid} removed from queue!` });
});

app.post('/api/user/queue/clear', (req         , res          ) => {
  const currentUser = req.session?.view_as || req.session?.username || 'admin';
  saveOwnerVerifiedQueue(currentUser, []);
  saveOwnerRawQueue(currentUser, []);
  saveOwnerQueue(currentUser, []);
  ownerRawReservedUids.get(currentUser)?.clear();
  ownerVerifiedReservedUids.get(currentUser)?.clear();
  globalVerifiedCache.clear();
  broadcastAccountUpdate(currentUser);
  res.json({ success: true, msg: 'All Queues (Verified & Raw) cleared successfully!' });
});

app.get('/api/user/master-config', (req: any, res: any) => {
  const currentUser = getEffectiveUser(req) || 'admin';
  const u = getUser(currentUser);
  if (!u) return res.status(404).json({ msg: 'User not found' });
  const config = u.master_config || {};
  res.json({
    ...config,
    user_ai_enabled: u.ai_enabled === true,
    user_dynamic_enabled: u.dynamic_templates_enabled !== false,
    user_has_any_premium: (u.ai_enabled === true || u.dynamic_templates_enabled !== false)
  });
});

app.post('/api/user/master-config', (req: any, res: any) => {
  const currentUser = getEffectiveUser(req) || 'admin';
  const u = getUser(currentUser);
  if (!u) return res.status(404).json({ msg: 'User not found' });

  const data = req.body || {};
  const [, maxTargets] = userLimits(currentUser);
  const targets = Array.isArray(data.targets) ? data.targets : [];
  if (targets.length > maxTargets) {
    return res.json({
      ok: false,
      msg: `LIMIT REACHED! You are allowed maximum ${maxTargets} target groups (you entered ${targets.length})`
    });
  }

  const filterTok = (data.filter_bot_token || '').trim();

  u.master_config = {
    use_dynamic_templates: data.use_dynamic_templates !== undefined ? Boolean(data.use_dynamic_templates) : true,
    ai_context: data.ai_context || '',
    channel_link: data.channel_link || '',
    targets,
    message_1: data.message_1 || '',
    message_2: data.message_2 || '',
    message_3: data.message_3 || '',
    delay_min: Number(data.delay_min || 60),
    delay_max: Number(data.delay_max || 120),
    check_interval: Number(data.check_interval || 20),
    filter_bot_token: filterTok,
  };

  (u as any).filter_bot_token = filterTok;
  if (filterTok && !u.alert_bot_token) {
    u.alert_bot_token = filterTok;
  }

  // Force sync this filter_bot_token to all accounts belonging to this user
  if (filterTok) {
    for (const [phone, acc] of accounts.entries()) {
      if ((acc.owner || 'admin').toLowerCase() === currentUser.toLowerCase()) {
        if (!acc.config) acc.config = defaultConfig();
        acc.config.filter_bot_token = filterTok;
        if (data.channel_link) acc.config.channel_link = data.channel_link;
      }
    }
    saveAccountsJson();
    // Register commands on Telegram for this user's bot
    registerTelegramBotCommands(filterTok).catch(() => null);
    // Delete any blocking webhooks
    fetch(`https://api.telegram.org/bot${filterTok}/deleteWebhook?drop_pending_updates=false`).catch(() => null);
    // Pre-discover channels
    getFilterBotAdminChannels(filterTok, currentUser, data.channel_link).catch(() => null);
    // Auto-generate tracked join request invite link if channel link is present
    if (data.channel_link) {
      getOrCreateUserTrackedInviteLink(currentUser).catch(() => null);
    }
  }

  saveUsers();
  broadcastAccountUpdate(currentUser); // Broadcast update so UI refreshes if needed
  res.json({ ok: true, msg: 'Master Config saved and Filter Bot linked successfully!' });
});

app.get('/api/user/generate-sample-dm', (req: any, res: any) => {
  const currentUser = getEffectiveUser(req) || 'admin';
  const u = getUser(currentUser);
  const sampleName = String(req.query.name || 'Rahul');
  const channelLink = (req.query.channel_link || u?.master_config?.channel_link || 'https://t.me/YourChannelLink').trim();
  const result = buildDynamicHinglishMessage(sampleName, channelLink);
  const gCount = hinglishTemplates.greetings?.length || 50;
  const oCount = hinglishTemplates.offers?.length || 50;
  const totalCombos = gCount * oCount;
  res.json({
    ok: true,
    ...result,
    stats: {
      greetings_count: gCount,
      offers_count: oCount,
      total_combinations: totalCombos
    }
  });
});

app.post('/api/user/test-bot-token', async (req: any, res: any) => {
  const token = (req.body?.token || '').trim();
  const providedLink = (req.body?.channel_link || '').trim();
  const currentUser = getEffectiveUser(req) || 'admin';
  if (!token) return res.json({ ok: false, msg: 'Please enter a Telegram Bot Token from @BotFather' });
  try {
    const r = await fetch(`https://api.telegram.org/bot${encodeURIComponent(token)}/getMe`);
    const j = await r.json();
    if (!j.ok || !j.result) {
      return res.json({ ok: false, msg: `❌ Telegram error: ${j.description || 'Invalid Bot Token'}` });
    }
    const botInfo = j.result;

    // Discover channels where this bot is Admin
    filterBotAdminChannelsCache.delete(token); // Clear stale cache
    const adminChannels = await getFilterBotAdminChannels(token, currentUser, providedLink);
    
    let channelMsg = '';
    if (adminChannels.size > 0) {
      const channelList = Array.from(adminChannels.entries())
        .filter(([id]) => id.startsWith('-100') || !id.startsWith('@'))
        .map(([id, title]) => `<b>"${title}"</b> (ID: <code>${id}</code>)`)
        .join(', ');
      channelMsg = `<br>📢 <b style="color:#34d399;">Admin in Channel(s):</b> ${channelList || 'Active'} <span style="color:#38bdf8;">(Auto-Filtering Joined Members Active!)</span>`;
    } else {
      channelMsg = `<br>ℹ️ <span style="color:#fbbf24;">Note: Bot connected! To filter joined users, make sure to add @${botInfo.username} as an <b>Admin</b> in your Telegram channel.</span>`;
    }

    return res.json({
      ok: true,
      msg: `✅ Connected! Bot: @${botInfo.username} (${botInfo.first_name})${channelMsg}`,
      bot: botInfo,
      channels_count: adminChannels.size,
      bot_username: botInfo.username
    });
  } catch (err: any) {
    return res.json({ ok: false, msg: `❌ Network error connecting to Telegram Bot API: ${err.message}` });
  }
});

app.post('/api/user/master-config/sync-all', (req: any, res: any) => {
  const currentUser = getEffectiveUser(req) || 'admin';
  let count = 0;
  for (const [phone, acc] of accounts.entries()) {
    if ((acc.owner || 'admin') === currentUser) {
      if (acc.config) {
        acc.config.use_master_config = true;
        count++;
      }
    }
  }
  if (count > 0) {
    saveAccountsJson();
    broadcastAccountUpdate(currentUser);
  }
  res.json({ ok: true, msg: `Successfully synced ${count} account(s) to use Master Configuration!` });
});

// Returns dispatched/sent DMs list with Telegram details for the effective user
app.get('/api/user/sent-dms', (req         , res          ) => {
  const currentUser = getEffectiveUser(req) || 'admin';
  const sentSet = getOwnerSentUsers(currentUser);
  const peers = getOwnerPeers(currentUser);
  const sentArr = Array.from(sentSet);
  const list = sentArr.slice(-100).reverse().map((uid) => {
    const p = peers.get(String(uid));
    return {
      uid,
      userId: String(uid),
      username: p?.username ? `@${p.username}` : '',
      firstName: p?.firstName || '',
      phone: p?.phone || ''
    };
  });
  res.json({ success: true, count: sentSet.size, sent: list });
});

// Returns persistent database of skipped users with reasons, categories, and timestamps
app.get('/api/user/skipped-users', (req         , res          ) => {
  const currentUser = getEffectiveUser(req) || 'admin';
  const m = getOwnerSkippedDetails(currentUser);
  const peers = getOwnerPeers(currentUser);
  const records = Array.from(m.values()).reverse();

  for (const r of records) {
    if (!r.name || r.name === String(r.uid)) {
      const p = peers.get(String(r.uid));
      if (p?.firstName) r.name = p.firstName;
      if (p?.username && !r.username) r.username = `@${p.username.replace(/^@/, '')}`;
      if (p?.phone && !r.phone) r.phone = p.phone;
    }
  }

  res.json({
    success: true,
    count: m.size,
    skipped: records.slice(0, 500)
  });
});

app.post('/api/user/skipped-users/clear', (req         , res          ) => {
  const currentUser = getEffectiveUser(req) || 'admin';
  clearOwnerSkippedUsers(currentUser);
  res.json({ success: true, msg: 'Skipped users database cleared successfully.' });
});

app.get('/api/user/skipped-users/export', (req         , res          ) => {
  const currentUser = getEffectiveUser(req) || 'admin';
  const m = getOwnerSkippedDetails(currentUser);
  const records = Array.from(m.values()).reverse();
  res.setHeader('Content-Disposition', `attachment; filename=skipped_users_${currentUser}.json`);
  res.setHeader('Content-Type', 'application/json');
  res.send(JSON.stringify(records, null, 2));
});

// ---------------- TELEGRAM INTERACTIVE BOT ENGINE (USER & ADMIN) ----------------
const botPollOffsets = new Map<string, number>(); // token -> offset

function formatUserMenu(u: any, accs: any[]) {
  const uname = u.username;
  const running = accs.filter((a) => a.running).length;
  const ownerQ = getOwnerQueueLength(uname);
  
  let txt = `🤖 <b>Telebot Multi-Account Manager</b>\n` +
    `👤 <b>User:</b> <code>${uname}</code>\n` +
    `📊 <b>Accounts:</b> ${accs.length} total (${running} Running, ${accs.length - running} Stopped)\n` +
    `👥 <b>Shared Common Queue:</b> ${ownerQ} leads in pool\n\n` +
    `👇 <i>Tap on any account below to inspect full real-time details:</i>`;

  const keyboard: any[][] = [];
  accs.forEach((a, idx) => {
    const isLive = a.running;
    const statusIcon = isLive ? '🟢' : '🔴';
    const dailyCount = (a as any).daily_extracted_count || 0;
    const label = `${statusIcon} #${idx + 1} ${a.phone} (${dailyCount} Extracted)`;
    keyboard.push([{ text: label, callback_data: `uacc:${uname}:${a.phone}` }]);
  });

  keyboard.push([
    { text: '📋 All IDs Compact Report', callback_data: `uall:${uname}` },
    { text: '🔄 Refresh', callback_data: `umenu:${uname}` }
  ]);

  return { text: txt, keyboard };
}

function formatAccountDetail(u: any, acc: any, backCallback: string) {
  const uname = u.username;
  const isLive = acc.running;
  const statusStr = isLive ? '🟢 Running (Active)' : '🔴 Stopped';
  const dailyCount = (acc as any).daily_extracted_count || 0;
  const accQ = (queueCache.get(acc.phone) || []).length;
  const ownerQ = getOwnerQueueLength(uname);
  const cfg = getEffectiveConfig(acc);
  const tg = (cfg.targets && cfg.targets.length > 0) ? cfg.targets.join(', ') : 'None configured';
  const lastAct = acc.last_active ? new Date(acc.last_active).toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata' }) : 'N/A';

  let txt = `📱 <b>Account Details:</b> <code>${acc.phone}</code>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `👤 <b>Owner:</b> <code>${uname}</code>\n` +
    `⚡ <b>Status:</b> ${statusStr}\n` +
    `🎯 <b>Daily Extracted:</b> <b>${dailyCount} (Unlimited)</b>\n` +
    `📬 <b>Target Channel/Group:</b> ${tg}\n` +
    `👥 <b>Account Queue / Shared Pool:</b> <b>${accQ} / ${ownerQ}</b>\n` +
    `🕒 <b>Last Active:</b> ${lastAct} IST\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `💡 <i>This account shares the common audience queue with all other IDs under @${uname}.</i>`;

  const keyboard = [
    [
      { text: '🔄 Refresh Status', callback_data: `uacc:${uname}:${acc.phone}` },
      { text: '🔙 Back', callback_data: backCallback }
    ]
  ];

  return { text: txt, keyboard };
}


function getPastDateStrings(days: number): string[] {
  const dates = [];
  for (let i = 0; i < days; i++) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    dates.push(`${d.getFullYear()}-${mm}-${dd}`);
  }
  return dates;
}

function formatGeminiReport(days: number) {
  const targetDates = getPastDateStrings(days);
  let txt = `✨ <b>Gemini AI DM Report (Last ${days} Days)</b>\n\n`;
  let grandTotal = 0;

  for (const u of usersList) {
    const uname = u.username;
    let userTotal = 0;
    
    if (aiDmHistory[uname]) {
      for (const d of targetDates) {
        userTotal += (aiDmHistory[uname][d] || 0);
      }
    }
    
    if (userTotal > 0) {
      txt += `👤 <b>${uname}</b>: ${userTotal} DMs\n`;
      grandTotal += userTotal;
    }
  }

  if (grandTotal === 0) {
    txt += `<i>No AI DMs sent in the last ${days} days.</i>\n`;
  } else {
    txt += `\n📈 <b>Total AI DMs: ${grandTotal}</b>`;
  }

  const keyboard = [
    [
      { text: '📅 Today', callback_data: 'gemini_rep:1' },
      { text: '📅 Last 5 Days', callback_data: 'gemini_rep:5' }
    ],
    [
      { text: '🗓️ Last 30 Days (Month)', callback_data: 'gemini_rep:30' }
    ],
    [
      { text: '🔙 Back to Menu', callback_data: 'adm_main' }
    ]
  ];
  return { text: txt, keyboard };
}

function formatAdminMenu() {
  const totalUsers = usersList.length;
  const activeUsers = usersList.filter((u) => u.active).length;
  const allAccs = Array.from(accounts.values());
  const liveCount = allAccs.filter((a) => a.running).length;
  let totalQueue = 0;
  for (const acc of allAccs) {
    totalQueue += getAccountVerifiedQueue(acc.phone).length;
  }

  let txt = `👑 <b>Super Admin Master Console</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `👥 <b>Total Users:</b> ${totalUsers} (${activeUsers} Active)\n` +
    `📱 <b>Connected Accounts:</b> ${allAccs.length} IDs\n` +
    `🟢 <b>Live Running Bots:</b> ${liveCount} IDs\n` +
    `👥 <b>Global Pending Queue:</b> ${totalQueue} users\n\n` +
    `👇 <i>Select a user to inspect their connected Telegram IDs:</i>`;

  const keyboard: any[][] = [];
  usersList.forEach((u) => {
    const uAccs = allAccs.filter((a) => (a.owner || 'admin') === u.username);
    const uLive = uAccs.filter((a) => a.running).length;
    const label = `👤 ${u.username} (${uAccs.length} IDs | 🟢 ${uLive})`;
    keyboard.push([{ text: label, callback_data: `adm_u:${u.username}` }]);
  });

  keyboard.push([
    { text: '📊 Live VPS Specs & Load', callback_data: `adm_vps_health` },
    { text: '📅 Users Expiry Dates', callback_data: `adm_exp:all` }
  ]);
  keyboard.push([
    { text: '🔄 Refresh Admin Console', callback_data: `adm_main` }
  ]);

  return { text: txt, keyboard };
}

async function formatVpsStatusMessage(): Promise<{ text: string; keyboard: any[][] }> {
  const vps = getVpsMetrics();
  const gcp = await checkGcpMetadata();
  let providerLabel = vps.system.free_tier_provider;
  if (gcp.isGcp && gcp.machineType) {
    providerLabel = `Google Cloud Compute Engine (${gcp.machineType})`;
  }

  const memBarLen = 10;
  const memFilled = Math.min(memBarLen, Math.max(0, Math.round((vps.memory.percent / 100) * memBarLen)));
  const memBar = '█'.repeat(memFilled) + '░'.repeat(memBarLen - memFilled);

  const cpuBarLen = 10;
  const cpuFilled = Math.min(cpuBarLen, Math.max(0, Math.round((vps.cpu.percent / 100) * cpuBarLen)));
  const cpuBar = '█'.repeat(cpuFilled) + '░'.repeat(cpuBarLen - cpuFilled);

  const diskBarLen = 10;
  const diskFilled = Math.min(diskBarLen, Math.max(0, Math.round((vps.disk.percent / 100) * diskBarLen)));
  const diskBar = '█'.repeat(diskFilled) + '░'.repeat(diskBarLen - diskFilled);

  const isFreeTierGcp = gcp.isGcp || vps.system.is_free_tier_candidate;

  let txt = `🖥️ <b>VPS System Health & Specifications</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `☁️ <b>Host Platform:</b> ${providerLabel}\n` +
    (isFreeTierGcp ? `🎁 <b>Tier Status:</b> Google Cloud Free Tier Eligible (e2-micro)\n` : '') +
    `⏱️ <b>Uptime:</b> ${vps.uptime.formatted}\n` +
    `⚙️ <b>OS & Arch:</b> Linux ${vps.system.arch} (Node ${vps.system.node_version})\n\n` +
    
    `🧠 <b>RAM Memory:</b> [${memBar}] <b>${vps.memory.percent}%</b>\n` +
    `• Used: <b>${vps.memory.used_formatted}</b> / Total: <b>${vps.memory.total_formatted}</b>\n` +
    `• Free RAM: <b>${vps.memory.free_formatted}</b>\n\n` +

    `⚡ <b>CPU Load:</b> [${cpuBar}] <b>${vps.cpu.percent}%</b>\n` +
    `• Cores: <b>${vps.cpu.cores} Core(s)</b> (${vps.cpu.model.slice(0, 24)})\n` +
    `• Load Average: 1m: <b>${vps.cpu.load_1m}</b> | 5m: <b>${vps.cpu.load_5m}</b>\n\n` +

    `💾 <b>SSD Disk Space:</b> [${diskBar}] <b>${vps.disk.percent}%</b>\n` +
    `• Used: <b>${vps.disk.used_formatted}</b> / Total: <b>${vps.disk.total_formatted}</b>\n` +
    `• Free Space: <b>${vps.disk.free_formatted}</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `<i>Auto-monitored directly from VPS kernel via Node.js</i>`;

  const keyboard = [
    [
      { text: '🔄 Refresh Live Specs', callback_data: `adm_vps_health` },
      { text: '🔙 Back to Admin Console', callback_data: `adm_main` }
    ]
  ];

  return { text: txt, keyboard };
}

function formatAdminExpiryList() {
  let txt = `📅 <b>Users Expiry Dates & Validity (DD/MM/YYYY)</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

  usersList.forEach((u, i) => {
    const exp = u.expiry_date ? formatDisplayDate(u.expiry_date) : '♾️ Lifetime (No Expiry)';
    const status = u.active ? '🟢 Active' : '🔴 Disabled';
    txt += `<b>${i + 1}. ${u.username}</b> (${u.role || 'user'})\n`;
    txt += `• Status: ${status}\n`;
    txt += `• Expiry Date: <b>${exp}</b>\n\n`;
  });

  const keyboard = [
    [{ text: '🔙 Back to Admin Console', callback_data: `adm_main` }]
  ];
  return { text: txt, keyboard };
}

function formatAdminUserView(u: any) {
  const uname = u.username;
  const accs = Array.from(accounts.values()).filter((a) => (a.owner || 'admin') === uname);
  const running = accs.filter((a) => a.running).length;
  const ownerQ = getOwnerQueueLength(uname);
  const exp = u.expiry_date ? formatDisplayDate(u.expiry_date) : '♾️ Lifetime (No Expiry)';

  let txt = `👤 <b>Admin Inspection: @${uname}</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `📊 <b>Accounts:</b> ${accs.length} total (${running} Live)\n` +
    `👥 <b>Shared Common Queue:</b> ${ownerQ} leads\n` +
    `📅 <b>User Expiry Date:</b> <b>${exp}</b>\n` +
    `🔒 <b>Status:</b> ${u.active ? '🟢 Active' : '🔴 Disabled'}\n\n` +
    `👇 <i>Tap on any of @${uname}'s accounts to view live stats:</i>`;

  const keyboard: any[][] = [];
  accs.forEach((a, idx) => {
    const isLive = a.running;
    const statusIcon = isLive ? '🟢' : '🔴';
    const dailyCount = (a as any).daily_extracted_count || 0;
    const label = `${statusIcon} #${idx + 1} ${a.phone} (${dailyCount} Extracted)`;
    keyboard.push([{ text: label, callback_data: `adm_acc:${uname}:${a.phone}` }]);
  });

  keyboard.push([
    { text: '🔙 Back to Users List', callback_data: `adm_main` },
    { text: '🔄 Refresh', callback_data: `adm_u:${uname}` }
  ]);

  return { text: txt, keyboard };
}

function getWebLoginUrl() {
  const adminUser = usersList.find((u: any) => u.role === 'admin' || u.username === 'admin');
  const adminConfiguredUrl = (systemConfiguredDomain || adminUser?.custom_web_url || (adminUser as any)?.live_url || '').trim();
  if (adminConfiguredUrl) {
    const formatted = adminConfiguredUrl.startsWith('http') ? adminConfiguredUrl : `https://${adminConfiguredUrl}`;
    return `${formatted.replace(/\/$/, '')}/login`;
  }
  const custom = (process.env.APP_URL || process.env.BASE_URL || process.env.PUBLIC_URL || process.env.DOMAIN || '').trim();
  if (custom) {
    const formatted = custom.startsWith('http') ? custom : `https://${custom}`;
    return `${formatted.replace(/\/$/, '')}/login`;
  }
  if (billingStore?.settings?.domain) {
    const bDom = billingStore.settings.domain.trim();
    if (bDom) {
      const formatted = bDom.startsWith('http') ? bDom : `https://${bDom}`;
      return `${formatted.replace(/\/$/, '')}/login`;
    }
  }
  if (globalDetectedWebUrl && !/^https?:\/\/(\d{1,3}\.){3}\d{1,3}(:\d+)?$/.test(globalDetectedWebUrl)) {
    return `${globalDetectedWebUrl.replace(/\/$/, '')}/login`;
  }
  if (globalDetectedWebUrl) {
    return `${globalDetectedWebUrl.replace(/\/$/, '')}/login`;
  }
  return `https://ais-pre-4cxaapukn5iezmue6n67fq-366353011222.asia-southeast1.run.app/login`;
}

// Automatically resets Telegram bot commands menu button for customers
async function cleanupTelegramBotMenu(botToken: string) {
  if (!botToken) return;
  try {
    // Reset chat menu button to standard default menu
    await fetch(`https://api.telegram.org/bot${botToken}/setChatMenuButton`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ menu_button: { type: 'default' } })
    }).catch(() => null);
  } catch (e) {}
}

const adminCustomPrompt = new Map<string, { reqId: string; field: 'bots' | 'days' | 'rate' }>();

// Formats rich interactive request alert for Admin with inline customization controls
function formatAdminRequestAlert(r: AccessRequest, subView: string | null = null) {
  const reqType = r.type || 'new_user';
  const timeStr = new Date(r.requested_at || Date.now()).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });

  // 1. EXTEND VALIDITY REQUEST
  if (reqType === 'extend_validity') {
    if (subView === 'edit_days') {
      const text = `⏳ <b>CUSTOMIZE EXTENSION DAYS</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `👤 <b>User:</b> <code>${r.target_username}</code> (${r.full_name})\n` +
        `Current Extension: <b>+${r.validity_days || 30} Days</b>\n\n` +
        `👇 Quick select days or type custom number in chat:`;
      const keyboard = [
        [
          { text: '+7 Days', callback_data: `adm_set_ext:${r.id}:7` },
          { text: '+15 Days', callback_data: `adm_set_ext:${r.id}:15` },
          { text: '+30 Days', callback_data: `adm_set_ext:${r.id}:30` }
        ],
        [
          { text: '+60 Days', callback_data: `adm_set_ext:${r.id}:60` },
          { text: '+90 Days', callback_data: `adm_set_ext:${r.id}:90` },
          { text: '+365 Days', callback_data: `adm_set_ext:${r.id}:365` }
        ],
        [
          { text: '✏️ Type Custom Days in Chat', callback_data: `adm_type_ext:${r.id}` },
          { text: '🔙 Done / Back', callback_data: `adm_view_req:${r.id}` }
        ]
      ];
      return { text, keyboard };
    }

    const isCustomized = Boolean((r as any).customized_by_admin);
    const customTag = isCustomized ? ' ✏️ [Customized by Admin]' : '';

    const text = `⏳ <b>ACCOUNT VALIDITY EXTENSION REQUEST!</b>${customTag}\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `👤 <b>User:</b> <code>${r.target_username}</code> (${r.full_name})\n` +
      `🆔 <b>Telegram:</b> <code>${r.chat_id}</code>\n` +
      `⏳ <b>Validity to Add:</b> <b>+${r.validity_days || 30} Days</b>\n` +
      `📅 <b>Requested:</b> ${timeStr}\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `👇 <i>Select an action to approve or customize:</i>`;

    const keyboard = [
      [
        { text: `✏️ Change Added Days (+${r.validity_days || 30}d)`, callback_data: `adm_sub_ext:${r.id}` }
      ],
      [
        { text: `✅ APPROVE (+${r.validity_days || 30} Days)`, callback_data: `usr_appr_ext:${r.id}` },
        { text: '❌ REJECT', callback_data: `usr_rej:${r.id}` }
      ]
    ];
    return { text, keyboard };
  }

  // 2. EXTRA BOT SLOTS REQUEST
  if (reqType === 'add_bots') {
    if (subView === 'edit_bots') {
      const text = `🤖 <b>CUSTOMIZE EXTRA BOTS QUOTA</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `👤 <b>User:</b> <code>${r.target_username}</code> (${r.full_name})\n` +
        `Current Added Slots: <b>+${r.bots_count || 1} Bots</b>\n\n` +
        `👇 Quick select quota or type custom number in chat:`;
      const keyboard = [
        [
          { text: '+1 Bot', callback_data: `adm_set_slots:${r.id}:1` },
          { text: '+2 Bots', callback_data: `adm_set_slots:${r.id}:2` },
          { text: '+3 Bots', callback_data: `adm_set_slots:${r.id}:3` }
        ],
        [
          { text: '+5 Bots', callback_data: `adm_set_slots:${r.id}:5` },
          { text: '+10 Bots', callback_data: `adm_set_slots:${r.id}:10` },
          { text: '+20 Bots', callback_data: `adm_set_slots:${r.id}:20` }
        ],
        [
          { text: '✏️ Type Custom Count in Chat', callback_data: `adm_type_slots:${r.id}` },
          { text: '🔙 Done / Back', callback_data: `adm_view_req:${r.id}` }
        ]
      ];
      return { text, keyboard };
    }

    const isCustomized = Boolean((r as any).customized_by_admin);
    const customTag = isCustomized ? ' ✏️ [Customized by Admin]' : '';

    const text = `🤖 <b>EXTRA BOT SLOTS QUOTA REQUEST!</b>${customTag}\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `👤 <b>User:</b> <code>${r.target_username}</code> (${r.full_name})\n` +
      `🆔 <b>Telegram:</b> <code>${r.chat_id}</code>\n` +
      `➕ <b>Extra Bots:</b> <b>+${r.bots_count || 1} Bots</b>\n` +
      `📅 <b>Requested:</b> ${timeStr}\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `👇 <i>Select an action to approve or customize:</i>`;

    const keyboard = [
      [
        { text: `✏️ Change Added Bots (+${r.bots_count || 1})`, callback_data: `adm_sub_slots:${r.id}` }
      ],
      [
        { text: `✅ APPROVE (+${r.bots_count || 1} Bots)`, callback_data: `usr_appr_bots:${r.id}` },
        { text: '❌ REJECT', callback_data: `usr_rej:${r.id}` }
      ]
    ];
    return { text, keyboard };
  }

  // 3. NEW USER ACCESS REQUEST
  if (subView === 'edit_bots') {
    const text = `🤖 <b>CUSTOMIZE BOTS QUOTA for ${r.full_name}</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `Current Setting: <b>${r.bots_count || 1} Bots</b>\n\n` +
      `👇 Quick select quota or type custom number in chat:`;
    const keyboard = [
      [
        { text: '1 Bot', callback_data: `adm_set_nbots:${r.id}:1` },
        { text: '2 Bots', callback_data: `adm_set_nbots:${r.id}:2` },
        { text: '3 Bots', callback_data: `adm_set_nbots:${r.id}:3` },
        { text: '5 Bots', callback_data: `adm_set_nbots:${r.id}:5` }
      ],
      [
        { text: '10 Bots', callback_data: `adm_set_nbots:${r.id}:10` },
        { text: '20 Bots', callback_data: `adm_set_nbots:${r.id}:20` },
        { text: '50 Bots', callback_data: `adm_set_nbots:${r.id}:50` }
      ],
      [
        { text: '✏️ Type Number in Chat', callback_data: `adm_type_nbots:${r.id}` },
        { text: '🔙 Done / Back', callback_data: `adm_view_req:${r.id}` }
      ]
    ];
    return { text, keyboard };
  }

  if (subView === 'edit_days') {
    const text = `⏳ <b>CUSTOMIZE VALIDITY DURATION for ${r.full_name}</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `Current Setting: <b>${r.validity_days || 30} Days</b>\n\n` +
      `👇 Quick select days or type custom days in chat:`;
    const keyboard = [
      [
        { text: '7 Days', callback_data: `adm_set_ndays:${r.id}:7` },
        { text: '15 Days', callback_data: `adm_set_ndays:${r.id}:15` },
        { text: '30 Days', callback_data: `adm_set_ndays:${r.id}:30` }
      ],
      [
        { text: '60 Days', callback_data: `adm_set_ndays:${r.id}:60` },
        { text: '90 Days', callback_data: `adm_set_ndays:${r.id}:90` },
        { text: '365 Days', callback_data: `adm_set_ndays:${r.id}:365` }
      ],
      [
        { text: '✏️ Type Days in Chat', callback_data: `adm_type_ndays:${r.id}` },
        { text: '🔙 Done / Back', callback_data: `adm_view_req:${r.id}` }
      ]
    ];
    return { text, keyboard };
  }

  if (subView === 'edit_rate') {
    const ratePerBot = Number(r.rate_per_bot) || 10;
    const bots = r.bots_count || 1;
    const dailyTotal = ratePerBot * bots;
    const weeklyTotal = dailyTotal * 7;
    const text = `💵 <b>SET RATE PER BOT for ${r.full_name}</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `Current Setting: <b>₹${ratePerBot}/bot/day</b>\n` +
      `📊 Daily: <b>₹${dailyTotal}/day</b> | 7-Day Week: <b>₹${weeklyTotal}</b> for ${bots} Bots\n\n` +
      `👇 Quick select rate or type custom amount in chat:`;
    const keyboard = [
      [
        { text: '⭐ ₹10 / bot', callback_data: `adm_set_nrate:${r.id}:10` },
        { text: '₹15 / bot', callback_data: `adm_set_nrate:${r.id}:15` },
        { text: '₹20 / bot', callback_data: `adm_set_nrate:${r.id}:20` }
      ],
      [
        { text: '₹25 / bot', callback_data: `adm_set_nrate:${r.id}:25` },
        { text: '₹30 / bot', callback_data: `adm_set_nrate:${r.id}:30` },
        { text: '₹50 / bot', callback_data: `adm_set_nrate:${r.id}:50` }
      ],
      [
        { text: '✏️ Type Custom Rate in Chat', callback_data: `adm_type_nrate:${r.id}` },
        { text: '🔙 Done / Back', callback_data: `adm_view_req:${r.id}` }
      ]
    ];
    return { text, keyboard };
  }

  const isCustomized = Boolean((r as any).customized_by_admin);
  const customTag = isCustomized ? ' ✏️ [Customized by Admin]' : '';
  const currentRate = Number(r.rate_per_bot) || 10;
  const currentBots = Number(r.bots_count) || 1;
  const currentDays = Number(r.validity_days) || 7;
  const dailyTotal = Math.round(currentRate * currentBots);
  const weeklyTotal = Math.round(dailyTotal * currentDays);

  const text = `🔔 <b>NEW USER ACCESS REQUEST!</b>${customTag}\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `👤 <b>Customer Name:</b> ${r.full_name}\n` +
    `🆔 <b>Telegram:</b> ${r.telegram_username ? '@' + r.telegram_username : 'None'} (<code>${r.chat_id}</code>)\n` +
    `📱 <b>Contact Mobile:</b> <code>${r.phone}</code>\n` +
    `🤖 <b>Bot Accounts Quota:</b> <b>${currentBots} Bots</b>\n` +
    `⏳ <b>Billing Cycle:</b> <b>${currentDays} Days (1 Week)</b>\n` +
    `💵 <b>Rate Per Bot:</b> <b>₹${currentRate} / bot / day</b>\n` +
    `📊 <b>Daily Usage Due:</b> <b>₹${dailyTotal} / day</b> (${currentBots} IDs x ₹${currentRate}/day)\n` +
    `💰 <b>7-Day Cycle Bill:</b> <b>₹${weeklyTotal}</b> (₹${dailyTotal}/day x ${currentDays} Days)\n` +
    `📅 <b>Requested:</b> ${timeStr}\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `👇 <i>Choose billing plan or adjust rate/bots:</i>`;

  const keyboard = [
    [
      { text: `✅ Approve Postpaid (₹${currentRate}/bot/day)`, callback_data: `usr_appr_plan:${r.id}:postpaid:${currentRate}` },
      { text: `✅ Approve Advance (₹${currentRate}/bot/day)`, callback_data: `usr_appr_plan:${r.id}:advance:${currentRate}` }
    ],
    [
      { text: `✏️ Edit Rate (₹${currentRate}/bot)`, callback_data: `adm_sub_nrate:${r.id}` },
      { text: `✏️ Edit Bots (${currentBots})`, callback_data: `adm_sub_nbots:${r.id}` }
    ],
    [
      { text: '❌ REJECT REQUEST', callback_data: `usr_rej:${r.id}` }
    ]
  ];
  return { text, keyboard };
}

// ---------------- TELEGRAM CUSTOMER /bill & BILLING STATEMENT ----------------
async function handleCustomerBillCommand(botToken: string, chatId: string, msg: any, adminUser: any, msgIdToEdit: any = null, explicitUser: any = null) {
  const fromUsername = (msg?.from?.username || '').toLowerCase();
  // Find matched non-admin user
  const matchedCust = explicitUser || usersList.find((u: any) =>
    u.role !== 'admin' && (
      String(u.alert_chat_id || '').trim() === String(chatId).trim() ||
      String(u.telegram_id || '').trim() === String(chatId).trim() ||
      (u.telegram_username && fromUsername && u.telegram_username.toLowerCase() === fromUsername)
    )
  );

  const webLoginUrl = getWebLoginUrl();
  const curr = (billingStore.currency || 'INR') === 'INR' ? '₹' : '$';

  if (!matchedCust) {
    const notFoundMsg = `⚠️ <b>No Active TeleBot Account Linked</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `Your Telegram account is not yet connected to a registered user profile.\n\n` +
      `• <b>Need a New ID?</b> Send /start to submit an account request.\n` +
      `• <b>Already Have an ID?</b> Send <code>/link &lt;username&gt;</code> to connect your Telegram.\n` +
      `  <i>(Example: <code>/link rahul</code>)</i>\n\n` +
      `For questions or plan upgrades, please contact Administrator.`;

    const keyboard = [
      [{ text: '🆕 Request New Account (/start)', callback_data: 'cust_new_id' }]
    ];
    await sendTelegramMessage(botToken, chatId, notFoundMsg, keyboard, msgIdToEdit);
    return;
  }

  // User is found! Ensure today's daily live bots usage is accrued, then generate bill
  accrueDailyUsageForUser(matchedCust.username);
  const uLedger = getUserLedgerSummary(matchedCust.username);
  const bal = Number(uLedger.balance_due ?? 0);
  const totalBilled = Number(uLedger.total_billed ?? 0);
  const totalPaid = Number(uLedger.total_paid ?? 0);

  const userAccs = Array.from(accounts.values()).filter((a: any) => (a.owner || 'admin').toLowerCase() === matchedCust.username.toLowerCase());
  const liveCount = userAccs.filter((a: any) => a.running).length;
  const maxBots = matchedCust.max_accounts || 1;
  const ratePerBot = matchedCust.rate_per_bot || 10;
  const cycleDays = matchedCust.billing_cycle_days || 7;
  const weeklyTotal = Math.round(ratePerBot * maxBots * (cycleDays === 7 ? 7 : cycleDays));
  const planModel = matchedCust.billing_model === 'advance' ? 'Advance (Prepaid)' : '7-Day Postpaid';
  const dateRange = getUserCycleDateRange(matchedCust);

  let dueBadge = '';
  if (bal > 0) {
    dueBadge = `🔴 <b>${curr}${bal.toLocaleString()} Due (Pending Payment)</b>`;
  } else if (bal < 0) {
    dueBadge = `⭐ <b>-${curr}${Math.abs(bal).toLocaleString()} (Advance Balance)</b>`;
  } else {
    dueBadge = `🟢 <b>${curr}0 (Fully Settled - All Paid)</b>`;
  }

  // Get recent 3 invoices for this user
  const userInvoices = (billingStore.invoices || [])
    .filter((inv: any) => (inv.username || '').toLowerCase() === matchedCust.username.toLowerCase())
    .slice(-3)
    .reverse();

  let recentHistoryText = '';
  if (userInvoices.length > 0) {
    recentHistoryText = `\n📄 <b>Recent Billing Invoices:</b>\n` +
      userInvoices.map((i: any) => `• <i>${formatDisplayDate(i.date)}:</i> ${i.description || 'Weekly Plan'} &mdash; <b>${curr}${i.amount}</b> (${i.status === 'paid' ? '🟢 Paid' : '🔴 Due'})`).join('\n') + `\n`;
  }

  const billMsg = `🧾 <b>YOUR SUBSCRIPTION & BILLING STATEMENT</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `👤 <b>Customer:</b> <code>${matchedCust.username}</code> (${matchedCust.display_name || 'Client'})\n` +
    `🤖 <b>Allowed Bots:</b> <b>${maxBots} Bot(s)</b> (🟢 ${liveCount} currently running)\n` +
    `💵 <b>Rate per Bot:</b> <b>${curr}${ratePerBot} / bot / day</b>\n` +
    `💰 <b>Weekly Cycle Bill:</b> <b>${curr}${weeklyTotal}</b> (${maxBots} Bots x ${curr}${ratePerBot}/day x ${cycleDays} Days)\n` +
    `📅 <b>Plan Validity:</b> <code>${dateRange.formattedRange}</code>\n` +
    `⏳ <b>Expiry Date:</b> <b>${formatDisplayDate(matchedCust.expiry_date)}</b>\n` +
    `💳 <b>Billing Model:</b> <b>${planModel} (1 Week)</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `📊 <b>Account Financial Overview:</b>\n` +
    `• 💵 <b>Total Invoiced:</b> ${curr}${totalBilled.toLocaleString()}\n` +
    `• 💰 <b>Total Received:</b> ${curr}${totalPaid.toLocaleString()}\n` +
    `• 💳 <b>Current Outstanding Due:</b> ${dueBadge}\n` +
    recentHistoryText +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    (bal > 0 ? `⚠️ <i>Payment is pending. Please clear your balance of ${curr}${bal.toLocaleString()} to ensure uninterrupted direct messaging service.</i>\n\n` : `✅ <i>Your account is active and all dues are cleared! Thank you!</i>\n\n`) +
    `🌐 <b>Dashboard:</b> ${webLoginUrl}`;

  const billKeyboard = [
    [{ text: '🔄 Refresh My Bill', callback_data: `cust_view_bill:${matchedCust.username}` }],
    [{ text: '🌐 Open Web Dashboard', url: webLoginUrl }],
    [{ text: '⏳ Request Extension (+Days)', callback_data: `cust_ext_val:${matchedCust.username}` }]
  ];

  await sendTelegramMessage(botToken, chatId, billMsg, billKeyboard, msgIdToEdit);
}

// ---------------- TELEGRAM CUSTOMER ONBOARDING BOT FLOW ----------------
async function handleCustomerOnboardingMessage(botToken: string, chatId: string, msg: any, adminUser: any) {
  const rawMsg = (msg.text || '').trim();
  const cleanCmd = (rawMsg.split(' ')[0] || '').toLowerCase().replace(/@.+/, '');

  // Find if sender is an already registered active user
  const existingUser = usersList.find((u: any) =>
    u.role !== 'admin' && (
      String(u.alert_chat_id || '').trim() === String(chatId).trim() ||
      String(u.telegram_id || '').trim() === String(chatId).trim() ||
      (u.telegram_username && (msg.from?.username || '').toLowerCase() === String(u.telegram_username).toLowerCase())
    )
  );

  // --- 1. /bill COMMAND FOR LIVE BILLING STATUS IN EASY ENGLISH ---
  if (cleanCmd === '/bill' || cleanCmd === '/mybill' || cleanCmd === '/balance' || cleanCmd === '/due' || cleanCmd === '/dues' || cleanCmd === '/ledger' || cleanCmd === '/khatabook') {
    await handleCustomerBillCommand(botToken, chatId, msg, adminUser, null, existingUser);
    return;
  }

  // --- 2. /mydm or /mystats COMMAND (User-wise DM Stats & Join Requests) ---
  if (cleanCmd === '/mydm' || cleanCmd === '/dm' || cleanCmd === '/mystats' || cleanCmd === '/today' || cleanCmd === '/stats') {
    if (existingUser) {
      const ov = getOwnerDmOverview(existingUser.username);
      let dmMsg = `📊 <b>My Direct Messaging Performance</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\n` +
                `👤 <b>Account:</b> <code>${existingUser.username}</code>\n` +
                `🤖 <b>Live Bots:</b> 🟢 <b>${ov.liveAccounts} Live</b> / ${ov.totalAccounts} Connected\n` +
                `🔥 <b>Today's Sent DMs:</b> <b>${ov.todayDms} DMs</b>\n` +
                `🎯 <b>Today's Channel Joins:</b> <b>${ov.todayJoins} Joins</b> <i>(${ov.convRate} ROI)</i>\n` +
                `📈 <b>Last 5-Days Total:</b> <b>${ov.sum5DaysDms} DMs</b> ➔ 🎯 <b>${ov.sum5DaysJoins} Joins</b>\n` +
                `⚡ <b>Daily Average:</b> <b>${ov.avgPerDayDms} DMs/day</b>\n` +
                `👑 <b>Lifetime Total Sent:</b> <b>${ov.lifetimeDms} DMs</b> ➔ 🎯 <b>${ov.lifetimeJoins} Joins</b>\n\n`;
      if (ov.stats5Days.length > 0) {
        dmMsg += `📅 <b>Last 5 Days Activity Breakdown:</b>\n`;
        ov.stats5Days.slice(0, 5).forEach((d: any, idx: number) => {
          const jCount = ov.joins5Days[idx]?.join_count || 0;
          dmMsg += `  • <code>${formatDisplayDate(d.date)}</code>: <b>${d.count} DMs</b> ➔ 🎯 <b>${jCount} Joins</b>\n`;
        });
      }
      await sendTelegramMessage(botToken, chatId, dmMsg);
      return;
    } else {
      await sendTelegramMessage(botToken, chatId, `⚠️ <b>Telegram Account Not Linked Yet!</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\nYour Telegram (Chat ID: <code>${chatId}</code>) is not yet linked to your TeleBot username.\n\n👉 <b>Link your account right now by sending:</b>\n<code>/link your_username</code>\n\n<b>Example:</b>\n<code>/link ${msg.from?.username || 'test'}</code>\n\n<i>(Or ask Admin to set your Telegram Chat ID in dashboard)</i>`);
      return;
    }
  }

  // --- 3. /mybots or /bots COMMAND (User Connected Bots) ---
  if (cleanCmd === '/mybots' || cleanCmd === '/bots') {
    if (existingUser) {
      const uAccs = Array.from(accounts.values()).filter((a) => (a.owner || 'admin').toLowerCase() === existingUser.username.toLowerCase());
      let botsMsg = `📱 <b>My Connected Telegram Bots (${uAccs.length})</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\n`;
      if (uAccs.length === 0) {
        botsMsg += `<i>No phone numbers linked yet. Add accounts from the web dashboard.</i>`;
      } else {
        uAccs.forEach((a: any, idx: number) => {
          const status = a.running ? '🟢 Running' : '🔴 Stopped';
          const dms = (a as any).daily_sent_count || 0;
          botsMsg += `<b>${idx + 1}.</b> <code>${a.phone}</code> | ${status} | Today: <b>${dms} DMs</b>\n`;
        });
      }
      await sendTelegramMessage(botToken, chatId, botsMsg);
      return;
    }
  }

  // --- 4. /payinfo or /pay COMMAND (User Payment Details) ---
  if (cleanCmd === '/payinfo' || cleanCmd === '/pay') {
    if (existingUser) {
      const uLedger = (billingStore.user_ledgers || {})[existingUser.username] || {};
      const bal = Number(uLedger.balance_due || 0);
      const curr = (billingStore.currency || 'INR') === 'INR' ? '₹' : '$';
      const dueStr = bal > 0 ? `${curr}${bal.toLocaleString()} Due` : `${curr}0 All Paid`;

      let payMsg = `📲 <b>Payment & Renewal Information</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\n` +
                `💳 <b>Current Outstanding:</b> <b>${dueStr}</b>\n` +
                `⏳ <b>Validity Expiry:</b> <code>${formatDisplayDate(existingUser.expiry_date)}</code>\n\n` +
                `To renew your plan or clear pending dues, please transfer via UPI to Administrator and send payment screenshot here.\n\n` +
                `Need help? Send <code>/menu</code> or tap options below.`;
      await sendTelegramMessage(botToken, chatId, payMsg);
      return;
    }
  }

  // --- 5. STRICT SECURITY RESTRICTION: Non-Admin Users cannot run Admin Commands ---
  const adminOnlyCommands = ['/user', '/users', '/remind', '/remindall', '/pause', '/unpause', '/vps', '/health', '/specs', '/requests', '/req', '/onboard', '/control', '/setdomain', '/domain', '/dmcount', '/dms'];
  if (adminOnlyCommands.includes(cleanCmd)) {
    await sendTelegramMessage(botToken, chatId, `⚠️ <b>Access Restricted:</b> This command is only available to administrators.\n\nUse <code>/menu</code> to open your personal TeleBot control dashboard.`);
    return;
  }

  // --- DEEP-LINK /start link_<username> OR /link <username> ---
  if (rawMsg.startsWith('/start link_') || rawMsg.startsWith('/link ')) {
    let targetUname = '';
    if (rawMsg.startsWith('/start link_')) {
      targetUname = rawMsg.replace('/start link_', '').trim();
    } else {
      targetUname = rawMsg.replace('/link ', '').trim();
    }
    targetUname = targetUname.replace('@', '').toLowerCase();

    const matchedTarget = usersList.find((u: any) => u.username.toLowerCase() === targetUname);
    if (matchedTarget) {
      matchedTarget.alert_chat_id = chatId;
      matchedTarget.telegram_id = chatId;
      matchedTarget.alert_enabled = true;
      if (msg.from?.username) {
        matchedTarget.telegram_username = msg.from.username;
      }
      if (msg.from?.first_name) {
        matchedTarget.telegram_name = `${msg.from.first_name || ''} ${msg.from.last_name || ''}`.trim();
      }
      saveUsers();
      console.log(`[TELEGRAM LINK SUCCESS]: Linked ${matchedTarget.username} with Chat ID: ${chatId} (${msg.from?.username || ''})`);

      await sendTelegramMessage(botToken, chatId, `✅ <b>Account Linked Successfully!</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\n👤 <b>User:</b> <code>${matchedTarget.username}</code>\n🆔 <b>Your Telegram Chat ID:</b> <code>${chatId}</code>\n⏳ <b>Plan Expiry:</b> <code>${formatDisplayDate(matchedTarget.expiry_date)}</code>\n\nYour Telegram account is now connected! You will receive all direct billing notices, renewals, and bot status alerts right here.\n\nSend <code>/bill</code> anytime to check your live ledger and due amount.`);
      
      // Notify Admin as well
      const adminChatId = String(adminUser.alert_chat_id || '').trim();
      if (adminChatId && adminChatId !== chatId) {
        await sendTelegramMessage(botToken, adminChatId, `🔔 <b>User Linked Telegram ID:</b>\n• User: <b>${matchedTarget.username}</b>\n• Chat ID: <code>${chatId}</code> (@${msg.from?.username || 'NoUsername'})`);
      }
      return;
    } else {
      await sendTelegramMessage(botToken, chatId, `❌ User "<b>${targetUname}</b>" was not found in the system. Please check your username and try again.`);
      return;
    }
  }

  cleanupTelegramBotMenu(botToken).catch(() => null);
  let session = customerOnboardingSessions.get(chatId);
  const rawText = (msg.text || '').trim();
  const lowerText = rawText.toLowerCase();

  // 1. If existing user is in the middle of typing custom extension days
  if (existingUser && session && session.step === 'awaiting_ext_days') {
    const days = parseInt(rawText, 10);
    if (isNaN(days) || days < 1 || days > 3650) {
      await sendTelegramMessage(botToken, chatId, `⚠️ Please type a valid number of days (e.g. <code>30</code>, <code>45</code>, <code>90</code>):`);
      return;
    }
    await submitCustomerExtensionRequest(botToken, chatId, existingUser, days, adminUser);
    return;
  }

  // 2. If existing user is in the middle of typing custom extra bot slots
  if (existingUser && session && session.step === 'awaiting_add_bots') {
    const extraCount = parseInt(rawText, 10);
    if (isNaN(extraCount) || extraCount < 1 || extraCount > 500) {
      await sendTelegramMessage(botToken, chatId, `⚠️ Please type a valid number of bots (e.g. <code>2</code>, <code>5</code>, <code>10</code>):`);
      return;
    }
    await submitCustomerExtraBotsRequest(botToken, chatId, existingUser, extraCount, adminUser);
    return;
  }

  // 3. If existing user sends /start, /menu, /extend, /upgrade, /bots or any normal query
  if (existingUser && (!session || session.step === 'confirm' || session.step === 'awaiting_name') && !lowerText.includes('request_id') && lowerText !== '/new') {
    const userAccs = Array.from(accounts.values()).filter(a => (a.owner || 'admin').toLowerCase() === existingUser.username.toLowerCase());
    const liveCount = userAccs.filter(a => a.running).length;
    const webLoginUrl = getWebLoginUrl();
    const expStr = existingUser.expiry_date ? formatDisplayDate(existingUser.expiry_date) : 'Unlimited';

    const memberMsg = `👋 <b>Hello ${existingUser.display_name || existingUser.username}! Welcome to TeleBot!</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `✨ <b>Your Account is Active:</b>\n\n` +
      `👤 <b>Username:</b> <code>${existingUser.username}</code>\n` +
      `🤖 <b>Bot Slots Quota:</b> <b>${existingUser.max_accounts} Bots</b>\n` +
      `⚡ <b>Connected Accounts:</b> ${userAccs.length} added (${liveCount} running)\n` +
      `⏳ <b>Validity Expiry:</b> <b>${expStr}</b>\n\n` +
      `👇 <i>What would you like to do? Choose an option below:</i>`;

    const memberKeyboard = [
      [{ text: '💳 View My Bill & Ledger (/bill)', callback_data: `cust_view_bill:${existingUser.username}` }],
      [{ text: '⏳ Extend Validity (+Days)', callback_data: `cust_ext_val:${existingUser.username}` }],
      [{ text: '➕ Add More Bots (+Slots)', callback_data: `cust_add_bots:${existingUser.username}` }],
      [{ text: '🌐 Open Web Login Dashboard', url: webLoginUrl }],
      [{ text: '🆕 Request Different User ID', callback_data: 'cust_new_id' }]
    ];

    await sendTelegramMessage(botToken, chatId, memberMsg, memberKeyboard);
    return;
  }

  // If user sends /start, /help, /reset, /new or session is brand new (NEW CUSTOMER ONBOARDING)
  if (!session || lowerText.startsWith('/start') || lowerText === '/reset' || lowerText === '/help' || lowerText === '/new') {
    const custName = [msg.from?.first_name, msg.from?.last_name].filter(Boolean).join(' ').trim() || (msg.from?.username ? `@${msg.from.username}` : 'Friend');
    const tgUsername = msg.from?.username || '';

    session = {
      chat_id: chatId,
      telegram_username: tgUsername,
      step: 'awaiting_name',
      full_name: custName,
      type: 'new_user',
      updated_at: Date.now()
    };
    customerOnboardingSessions.set(chatId, session);

    const welcomeMsg = `👋 <b>Welcome ${custName} to TeleBot Manager!</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `✨ Request a new <b>User ID & Dashboard Access</b> or renew your existing subscription.\n\n` +
      `📝 <b>Step 1/3: Your Full Name</b>\n` +
      `Would you like to use <b>"${custName}"</b> or type a different name in chat?`;

    const keyboard = [
      [{ text: `✅ Use "${custName.slice(0, 24)}"`, callback_data: `cust_name_ok` }],
      [{ text: '✏️ Type Different Name', callback_data: `cust_name_type` }]
    ];

    await sendTelegramMessage(botToken, chatId, welcomeMsg, keyboard);
    return;
  }

  // Step: Awaiting Custom Full Name
  if (session.step === 'awaiting_name') {
    session.full_name = rawText;
    session.step = 'awaiting_phone';
    session.updated_at = Date.now();

    const askPhone = `📱 <b>Great, ${session.full_name}!</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `📝 <b>Step 2/3: WhatsApp / Contact Mobile Number</b>\n` +
      `Please type your 10-digit mobile number (e.g. <code>9876543210</code>) so the Administrator can deliver your login credentials:`;

    await sendTelegramMessage(botToken, chatId, askPhone);
    return;
  }

  // Step: Awaiting Mobile Number
  if (session.step === 'awaiting_phone') {
    const cleanDigits = rawText.replace(/[^0-9+]/g, '');
    if (cleanDigits.length < 8) {
      await sendTelegramMessage(botToken, chatId, `⚠️ Please type a valid 10-digit mobile number (e.g. <code>9876543210</code>):`);
      return;
    }
    session.phone = cleanDigits;
    session.step = 'awaiting_bots';
    session.updated_at = Date.now();

    const askBots = `🤖 <b>How many Bot IDs do you need?</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `📝 <b>Step 3/3: Select Accounts Quota</b>\n` +
      `How many Telegram accounts do you plan to run simultaneously?\n` +
      `👇 <i>Choose an option below or type a custom number:</i>`;

    const keyboard = [
      [{ text: '🤖 1 Bot Account', callback_data: 'cust_bots:1' }, { text: '🤖 2 Bot Accounts', callback_data: 'cust_bots:2' }],
      [{ text: '🤖 3 Bot Accounts', callback_data: 'cust_bots:3' }, { text: '🤖 5 Bot Accounts', callback_data: 'cust_bots:5' }],
      [{ text: '🤖 10 Bot Accounts', callback_data: 'cust_bots:10' }, { text: '🤖 20 Bot Accounts', callback_data: 'cust_bots:20' }],
      [{ text: '🔢 Custom Number', callback_data: 'cust_bots_custom' }]
    ];

    await sendTelegramMessage(botToken, chatId, askBots, keyboard);
    return;
  }

  // Step: Awaiting Bots Count
  if (session.step === 'awaiting_bots' || session.step === 'awaiting_custom_bots') {
    const num = parseInt(rawText, 10);
    if (isNaN(num) || num < 1 || num > 500) {
      await sendTelegramMessage(botToken, chatId, `⚠️ Please type a valid number of bots (1 to 200) or use the buttons above:`);
      return;
    }
    session.bots_count = num;
    session.step = 'awaiting_validity';
    session.updated_at = Date.now();

    const askVal = `⏳ <b>Billing Cycle: 1 Week (7 Days Plan)</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `Selected: <b>${num} Bot Account(s)</b>\n\n` +
      `Standard plans run on a <b>1-Week (7 Days)</b> billing cycle.\n` +
      `The Administrator will set your rate per bot and plan type (Postpaid or Advance) upon approval.\n\n` +
      `👇 <i>Select your preferred plan duration:</i>`;

    const keyboard = [
      [{ text: '⚡ 1 Week (7 Days Plan)', callback_data: 'cust_val:7' }, { text: '⚡ 15 Days', callback_data: 'cust_val:15' }],
      [{ text: '⭐ 30 Days (1 Month)', callback_data: 'cust_val:30' }, { text: '⭐ 60 Days (2 Months)', callback_data: 'cust_val:60' }],
      [{ text: '👑 90 Days (3 Months)', callback_data: 'cust_val:90' }, { text: '🔢 Custom Days', callback_data: 'cust_val_custom' }]
    ];

    await sendTelegramMessage(botToken, chatId, askVal, keyboard);
    return;
  }

  // Step: Awaiting Validity
  if (session.step === 'awaiting_validity' || session.step === 'awaiting_custom_validity') {
    const days = parseInt(rawText, 10);
    if (isNaN(days) || days < 1 || days > 3650) {
      await sendTelegramMessage(botToken, chatId, `⚠️ Please type a valid number of days (e.g. 7, 30) or use the buttons:`);
      return;
    }
    session.validity_days = days;
    session.step = 'confirm';
    session.updated_at = Date.now();

    const confirmMsg = `📋 <b>Access Request Summary:</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `👤 <b>Name:</b> ${session.full_name}\n` +
      `🆔 <b>Telegram:</b> ${session.telegram_username ? '@' + session.telegram_username : 'None'} (<code>${chatId}</code>)\n` +
      `📱 <b>Mobile:</b> <code>${session.phone}</code>\n` +
      `🤖 <b>Bot Accounts:</b> <b>${session.bots_count} Bots</b>\n` +
      `⏳ <b>Billing Cycle:</b> <b>${session.validity_days} Days</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `👇 <i>Would you like to submit this request to the Administrator?</i>`;

    const keyboard = [
      [{ text: '🚀 Submit Request to Admin', callback_data: `cust_submit:${chatId}` }],
      [{ text: '🔄 Start Over', callback_data: `cust_restart:${chatId}` }]
    ];

    await sendTelegramMessage(botToken, chatId, confirmMsg, keyboard);
    return;
  }

  // Step: Confirm
  if (session.step === 'confirm') {
    const confirmMsg = `📋 <b>Request Confirmation Pending:</b>\n` +
      `• Name: ${session.full_name}\n` +
      `• Mobile: ${session.phone}\n` +
      `• Bots: ${session.bots_count}\n` +
      `• Validity: ${session.validity_days} Days\n\n` +
      `👇 <i>Tap below to submit your request to Administrator:</i>`;

    const keyboard = [
      [{ text: '🚀 Submit Request to Admin', callback_data: `cust_submit:${chatId}` }],
      [{ text: '🔄 Start Over', callback_data: `cust_restart:${chatId}` }]
    ];
    await sendTelegramMessage(botToken, chatId, confirmMsg, keyboard);
  }
}

// Helper: Submit Customer Validity Extension Request
async function submitCustomerExtensionRequest(botToken: string, chatId: string, u: any, days: number, adminUser: any, msgIdToEdit: any = null) {
  let curExpMs = Date.now() + 5.5 * 3600 * 1000;
  if (u?.expiry_date) {
    const parsed = new Date(u.expiry_date + 'T23:59:59Z').getTime();
    if (!isNaN(parsed) && parsed > curExpMs) curExpMs = parsed;
  }
  const newExpMs = curExpMs + (days * 86400 * 1000);
  const newExpDateStr = new Date(newExpMs).toISOString().split('T')[0];

  const reqId = `ext_${Date.now()}_${Math.floor(1000 + Math.random() * 9000)}`;
  const newReq: AccessRequest = {
    id: reqId,
    chat_id: chatId,
    telegram_username: u?.telegram_username || '',
    full_name: u?.display_name || u?.username || 'Customer',
    phone: u?.security_answer ? 'Registered User' : 'N/A',
    bots_count: u?.max_accounts || 1,
    validity_days: days,
    type: 'extend_validity',
    target_username: u?.username,
    requested_at: Date.now(),
    status: 'pending'
  };
  accessRequests.unshift(newReq);
  saveAccessRequests();
  customerOnboardingSessions.delete(chatId);

  // Confirm to customer
  const custExtConfirm = `✅ <b>Validity Extension Request Submitted!</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `👤 <b>Username:</b> <code>${u?.username}</code>\n` +
    `⏳ <b>Requested Extension:</b> <b>+${days} Days</b>\n` +
    `📅 <b>New Expiry Date:</b> <b>${formatDisplayDate(newExpDateStr)}</b>\n\n` +
    `The Administrator will review your request shortly. You will receive an alert once approved.`;

  await sendTelegramMessage(botToken, chatId, custExtConfirm, null, msgIdToEdit);

  // Alert to Super Admin
  const adminChatId = String(adminUser?.alert_chat_id || '').trim();
  if (adminChatId) {
    const { text: adminAlert, keyboard: adminK } = formatAdminRequestAlert(newReq);
    await sendTelegramMessage(botToken, adminChatId, adminAlert, adminK);
  }
}

// Helper: Submit Customer Extra Bot Slots Request
async function submitCustomerExtraBotsRequest(botToken: string, chatId: string, u: any, extraBots: number, adminUser: any, msgIdToEdit: any = null) {
  const curQuota = Number(u?.max_accounts || 1);
  const newTotal = curQuota + extraBots;

  const reqId = `slots_${Date.now()}_${Math.floor(1000 + Math.random() * 9000)}`;
  const newReq: AccessRequest = {
    id: reqId,
    chat_id: chatId,
    telegram_username: u?.telegram_username || '',
    full_name: u?.display_name || u?.username || 'Customer',
    phone: u?.security_answer ? 'Registered User' : 'N/A',
    bots_count: extraBots,
    validity_days: 0,
    type: 'add_bots',
    target_username: u?.username,
    requested_at: Date.now(),
    status: 'pending'
  };
  accessRequests.unshift(newReq);
  saveAccessRequests();
  customerOnboardingSessions.delete(chatId);

  // Confirm to customer
  const custBotsConfirm = `✅ <b>Extra Bot Slots Request Submitted!</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `👤 <b>Username:</b> <code>${u?.username}</code>\n` +
    `🤖 <b>Current Bot Quota:</b> <b>${curQuota} Bots</b>\n` +
    `➕ <b>Requested Extra:</b> <b>+${extraBots} Bots</b>\n` +
    `🎯 <b>New Total Quota:</b> <b>${newTotal} Bots</b>\n\n` +
    `The Administrator will review your request. Once approved, you can connect your new accounts immediately.`;

  await sendTelegramMessage(botToken, chatId, custBotsConfirm, null, msgIdToEdit);

  // Alert to Super Admin
  const adminChatId = String(adminUser?.alert_chat_id || '').trim();
  if (adminChatId) {
    const { text: adminAlert, keyboard: adminK } = formatAdminRequestAlert(newReq);
    await sendTelegramMessage(botToken, adminChatId, adminAlert, adminK);
  }
}

async function handleCustomerOnboardingCallback(botToken: string, chatId: string, cb: any, adminUser: any) {
  const data = String(cb.data || '');
  const msgId = cb.message?.message_id;
  let session = customerOnboardingSessions.get(chatId);

  // Find if user is already registered
  const existingUser = usersList.find((u: any) =>
    u.role !== 'admin' && (
      String(u.alert_chat_id || '').trim() === String(chatId).trim() ||
      (u.telegram_username && (cb.from?.username || '').toLowerCase() === String(u.telegram_username).toLowerCase())
    )
  );

  // --- EXISTING CUSTOMER ACTIONS ---
  if (data.startsWith('cust_ext_val:')) {
    const targetUser = data.replace('cust_ext_val:', '') || existingUser?.username;
    const u = getUser(targetUser) || existingUser;
    session = {
      chat_id: chatId,
      telegram_username: cb.from?.username || '',
      step: 'awaiting_ext_days',
      type: 'extend_validity',
      target_username: targetUser,
      full_name: u?.display_name || u?.username || 'Customer',
      updated_at: Date.now()
    };
    customerOnboardingSessions.set(chatId, session);

    const curExp = u?.expiry_date ? formatDisplayDate(u.expiry_date) : 'Active';
    const extMsg = `⏳ <b>ACCOUNT VALIDITY EXTENSION (Renewal)</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `👤 <b>Account:</b> <code>${targetUser}</code>\n` +
      `📅 <b>Current Expiry:</b> <b>${curExp}</b>\n\n` +
      `👇 <i>Select how many days you would like to extend your plan:</i>`;

    const extKeyboard = [
      [{ text: '⚡ +7 Days', callback_data: `cust_do_ext:7` }, { text: '⚡ +15 Days', callback_data: `cust_do_ext:15` }],
      [{ text: '⭐ +30 Days (1 Month)', callback_data: `cust_do_ext:30` }, { text: '⭐ +60 Days (2 Months)', callback_data: `cust_do_ext:60` }],
      [{ text: '👑 +90 Days (3 Months)', callback_data: `cust_do_ext:90` }, { text: '💎 +365 Days (1 Year)', callback_data: `cust_do_ext:365` }],
      [{ text: '🔢 Custom Days (Type in chat)', callback_data: `cust_ext_days_custom` }],
      [{ text: '🔙 Back to Menu', callback_data: `cust_back_menu` }]
    ];

    await sendTelegramMessage(botToken, chatId, extMsg, extKeyboard, msgId);
    return;
  }

  if (data === 'cust_ext_days_custom') {
    if (session) session.step = 'awaiting_ext_days';
    await sendTelegramMessage(botToken, chatId, `⏳ <b>Custom Validity Days:</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\nHow many days would you like to extend your plan? Please type the number in chat (e.g. <code>45</code>, <code>90</code>, <code>180</code>):`, null, msgId);
    return;
  }

  if (data.startsWith('cust_do_ext:')) {
    const days = parseInt(data.replace('cust_do_ext:', ''), 10) || 30;
    const targetU = getUser(session?.target_username || '') || existingUser;
    if (!targetU) {
      await sendTelegramMessage(botToken, chatId, '⚠️ User account not found. Please type /start to request access.', null, msgId);
      return;
    }
    await submitCustomerExtensionRequest(botToken, chatId, targetU, days, adminUser, msgId);
    return;
  }

  if (data.startsWith('cust_add_bots:')) {
    const targetUser = data.replace('cust_add_bots:', '') || existingUser?.username;
    const u = getUser(targetUser) || existingUser;
    session = {
      chat_id: chatId,
      telegram_username: cb.from?.username || '',
      step: 'awaiting_add_bots',
      type: 'add_bots',
      target_username: targetUser,
      full_name: u?.display_name || u?.username || 'Customer',
      updated_at: Date.now()
    };
    customerOnboardingSessions.set(chatId, session);

    const botsMsg = `🤖 <b>EXTRA BOT SLOTS REQUEST</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `👤 <b>Account:</b> <code>${targetUser}</code>\n` +
      `🤖 <b>Current Allowed Bots:</b> <b>${u?.max_accounts || 1} Accounts</b>\n\n` +
      `👇 <i>Select how many additional account slots you need:</i>`;

    const botsKeyboard = [
      [{ text: '🤖 +1 Bot Slot', callback_data: `cust_do_bots:1` }, { text: '🤖 +2 Bot Slots', callback_data: `cust_do_bots:2` }],
      [{ text: '🤖 +3 Bot Slots', callback_data: `cust_do_bots:3` }, { text: '🤖 +5 Bot Slots', callback_data: `cust_do_bots:5` }],
      [{ text: '🤖 +10 Bot Slots', callback_data: `cust_do_bots:10` }, { text: '🤖 +20 Bot Slots', callback_data: `cust_do_bots:20` }],
      [{ text: '🔢 Custom Bots (Type in chat)', callback_data: `cust_add_bots_custom` }],
      [{ text: '🔙 Back to Menu', callback_data: `cust_back_menu` }]
    ];

    await sendTelegramMessage(botToken, chatId, botsMsg, botsKeyboard, msgId);
    return;
  }

  if (data === 'cust_add_bots_custom') {
    if (session) session.step = 'awaiting_add_bots';
    await sendTelegramMessage(botToken, chatId, `🔢 <b>Custom Extra Bot Slots:</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\nHow many extra bot accounts do you need? Please type the number in chat (e.g. <code>2</code>, <code>5</code>, <code>10</code>):`, null, msgId);
    return;
  }

  if (data.startsWith('cust_do_bots:')) {
    const extraBots = parseInt(data.replace('cust_do_bots:', ''), 10) || 1;
    const targetU = getUser(session?.target_username || '') || existingUser;
    if (!targetU) {
      await sendTelegramMessage(botToken, chatId, '⚠️ User account not found. Please type /start to begin.', null, msgId);
      return;
    }
    await submitCustomerExtraBotsRequest(botToken, chatId, targetU, extraBots, adminUser, msgId);
    return;
  }

  if (data === 'cust_back_menu') {
    customerOnboardingSessions.delete(chatId);
    await handleCustomerOnboardingMessage(botToken, chatId, { text: '/start', from: cb.from }, adminUser);
    return;
  }

  if (data === 'cust_new_id') {
    customerOnboardingSessions.delete(chatId);
    const custName = [cb.from?.first_name, cb.from?.last_name].filter(Boolean).join(' ').trim() || (cb.from?.username ? `@${cb.from.username}` : 'Friend');
    session = {
      chat_id: chatId,
      telegram_username: cb.from?.username || '',
      step: 'awaiting_name',
      full_name: custName,
      type: 'new_user',
      updated_at: Date.now()
    };
    customerOnboardingSessions.set(chatId, session);

    const welcomeMsg = `👋 <b>Welcome ${custName} to TeleBot Manager!</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `✨ Please provide your details to request <b>User ID & Dashboard Access</b>:\n\n` +
      `📝 <b>Step 1/3: Your Full Name</b>\n` +
      `Would you like to use <b>"${custName}"</b> or type a different name in chat?`;

    const keyboard = [
      [{ text: `✅ Use "${custName.slice(0, 24)}"`, callback_data: `cust_name_ok` }],
      [{ text: '✏️ Type Other Name', callback_data: `cust_name_type` }]
    ];

    await sendTelegramMessage(botToken, chatId, welcomeMsg, keyboard, msgId);
    return;
  }

  // --- NEW CUSTOMER ONBOARDING ACTIONS ---
  if (data.startsWith('cust_view_bill:')) {
    await handleCustomerBillCommand(botToken, chatId, { from: cb.from }, adminUser, msgId);
    return;
  }

  if (data === 'cust_name_ok') {
    if (!session) {
      session = {
        chat_id: chatId,
        telegram_username: cb.from?.username || '',
        step: 'awaiting_name',
        full_name: [cb.from?.first_name, cb.from?.last_name].filter(Boolean).join(' ').trim() || 'User',
        updated_at: Date.now()
      };
      customerOnboardingSessions.set(chatId, session);
    }
    session.step = 'awaiting_phone';
    session.updated_at = Date.now();

    const askPhone = `📱 <b>Great, ${session.full_name}!</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `📝 <b>Step 2/3: WhatsApp / Contact Mobile Number</b>\n` +
      `Please type your 10-digit mobile number (e.g. <code>9876543210</code>) so the Administrator can deliver your login credentials:`;

    await sendTelegramMessage(botToken, chatId, askPhone, null, msgId);
    return;
  }

  if (data === 'cust_name_type') {
    if (session) session.step = 'awaiting_name';
    await sendTelegramMessage(botToken, chatId, `✏️ Please type your <b>Full Name</b> in chat:`, null, msgId);
    return;
  }

  if (data === 'cust_bots_custom') {
    if (!session) {
      session = { chat_id: chatId, telegram_username: cb.from?.username || '', step: 'awaiting_bots', full_name: 'Customer', phone: 'Not Specified', updated_at: Date.now() };
      customerOnboardingSessions.set(chatId, session);
    }
    session.step = 'awaiting_bots';
    session.updated_at = Date.now();
    await sendTelegramMessage(botToken, chatId, `🔢 <b>Custom Bot Accounts Quota:</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\nHow many Telegram accounts do you plan to run?\n\n👉 <i>Type a number in chat (e.g. <code>4</code>, <code>15</code>, <code>25</code>, <code>50</code>):</i>`, null, msgId);
    return;
  }

  if (data.startsWith('cust_bots:')) {
    const num = parseInt(data.replace('cust_bots:', ''), 10) || 1;
    if (!session) {
      session = { chat_id: chatId, telegram_username: cb.from?.username || '', step: 'awaiting_bots', full_name: 'Customer', phone: 'Not Specified', updated_at: Date.now() };
      customerOnboardingSessions.set(chatId, session);
    }
    session.bots_count = num;
    session.step = 'awaiting_validity';
    session.updated_at = Date.now();

    const askVal = `⏳ <b>Billing Cycle: 1 Week (7 Days Plan)</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `Selected: <b>${num} Bot Account(s)</b>\n\n` +
      `Standard plans run on a <b>1-Week (7 Days)</b> billing cycle.\n` +
      `The Administrator will set your rate per bot and plan type (Postpaid or Advance) upon approval.\n\n` +
      `👇 <i>Select your preferred plan duration:</i>`;

    const keyboard = [
      [{ text: '⚡ 1 Week (7 Days Plan)', callback_data: 'cust_val:7' }, { text: '⚡ 15 Days', callback_data: 'cust_val:15' }],
      [{ text: '⭐ 30 Days (1 Month)', callback_data: 'cust_val:30' }, { text: '⭐ 60 Days (2 Months)', callback_data: 'cust_val:60' }],
      [{ text: '👑 90 Days (3 Months)', callback_data: 'cust_val:90' }, { text: '🔢 Custom Days', callback_data: 'cust_val_custom' }]
    ];

    await sendTelegramMessage(botToken, chatId, askVal, keyboard, msgId);
    return;
  }

  if (data === 'cust_val_custom') {
    if (!session) {
      session = { chat_id: chatId, telegram_username: cb.from?.username || '', step: 'awaiting_validity', full_name: 'Customer', phone: 'Not Specified', bots_count: 1, updated_at: Date.now() };
      customerOnboardingSessions.set(chatId, session);
    }
    session.step = 'awaiting_validity';
    session.updated_at = Date.now();
    await sendTelegramMessage(botToken, chatId, `⏳ <b>Custom Validity Duration:</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\nHow many days of dashboard access do you need?\n\n👉 <i>Type number of days in chat (e.g. <code>45</code>, <code>90</code>, <code>180</code>):</i>`, null, msgId);
    return;
  }

  if (data.startsWith('cust_val:')) {
    const days = parseInt(data.replace('cust_val:', ''), 10) || 7;
    if (!session) {
      session = { chat_id: chatId, telegram_username: cb.from?.username || '', step: 'confirm', full_name: 'Customer', phone: 'Not Specified', bots_count: 1, updated_at: Date.now() };
      customerOnboardingSessions.set(chatId, session);
    }
    session.validity_days = days;
    session.step = 'confirm';
    session.updated_at = Date.now();

    const confirmMsg = `📋 <b>Access Request Summary:</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `👤 <b>Name:</b> ${session.full_name}\n` +
      `🆔 <b>Telegram:</b> ${session.telegram_username ? '@' + session.telegram_username : 'None'} (<code>${chatId}</code>)\n` +
      `📱 <b>Mobile:</b> <code>${session.phone || 'Pending'}</code>\n` +
      `🤖 <b>Bot Accounts:</b> <b>${session.bots_count || 1} Bots</b>\n` +
      `⏳ <b>Billing Cycle:</b> <b>${session.validity_days} Days (1 Week)</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `👇 <i>Would you like to submit this request to the Administrator?</i>`;

    const keyboard = [
      [{ text: '🚀 Submit Request to Admin', callback_data: `cust_submit:${chatId}` }],
      [{ text: '🔄 Start Over', callback_data: `cust_restart:${chatId}` }]
    ];

    await sendTelegramMessage(botToken, chatId, confirmMsg, keyboard, msgId);
    return;
  }

  if (data.startsWith('cust_restart:')) {
    customerOnboardingSessions.delete(chatId);
    await handleCustomerOnboardingMessage(botToken, chatId, { text: '/start', from: cb.from }, adminUser);
    return;
  }

  if (data.startsWith('cust_submit:') || data === 'cust_confirm' || data.startsWith('cust_confirm:')) {
    if (!session) {
      await sendTelegramMessage(botToken, chatId, '⚠️ Session expired. Please type /start to begin again.');
      return;
    }

    const reqId = `req_${Date.now()}_${Math.floor(1000 + Math.random() * 9000)}`;
    const newReq: AccessRequest = {
      id: reqId,
      chat_id: chatId,
      telegram_username: session.telegram_username || cb.from?.username || '',
      full_name: session.full_name || 'Customer',
      phone: session.phone || 'Not Specified',
      bots_count: session.bots_count || 1,
      validity_days: session.validity_days || 7,
      note: session.note || '',
      type: 'new_user',
      requested_at: Date.now(),
      status: 'pending'
    };

    accessRequests.unshift(newReq);
    saveAccessRequests();
    customerOnboardingSessions.delete(chatId);

    // Customer confirmation in Easy English
    const custSuccessMsg = `✅ <b>Your Request Has Been Submitted Successfully!</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `📋 <b>Request ID:</b> <code>${reqId}</code>\n` +
      `👤 <b>Name:</b> ${newReq.full_name}\n` +
      `📱 <b>Mobile:</b> <code>${newReq.phone}</code>\n` +
      `🤖 <b>Requested Accounts:</b> ${newReq.bots_count} Bot(s)\n` +
      `⏳ <b>Billing Cycle:</b> ${newReq.validity_days} Days (1 Week)\n\n` +
      `⏳ <i>The Administrator will review your request shortly. Once approved, your login credentials, weekly rate details, and dashboard link will be delivered here automatically!</i>`;

    await sendTelegramMessage(botToken, chatId, custSuccessMsg, null, msgId);

    // Admin alert message
    const adminChatId = String(adminUser?.alert_chat_id || '').trim();
    if (adminChatId) {
      const { text: adminAlertMsg, keyboard: adminKeyboard } = formatAdminRequestAlert(newReq);
      await sendTelegramMessage(botToken, adminChatId, adminAlertMsg, adminKeyboard);
    }
  }
}

async function handleAdminUserRequestApproval(
  botToken: string,
  adminChatId: string,
  reqId: string,
  msgId: any,
  adminUser: any,
  overridePlanModel?: string,
  overrideRate?: number
) {
  const reqItem = accessRequests.find((r) => r.id === reqId);
  if (!reqItem) {
    await sendTelegramMessage(botToken, adminChatId, '⚠️ Request not found or already deleted.', null, msgId);
    return;
  }
  if (reqItem.status !== 'pending') {
    await sendTelegramMessage(botToken, adminChatId, `ℹ️ Request is already <b>${reqItem.status.toUpperCase()}</b>!`, null, msgId);
    return;
  }

  // 1. Generate unique username
  let base = (reqItem.telegram_username || reqItem.full_name || 'user')
    .toLowerCase()
    .replace(/[^a-z0-9_]/g, '')
    .slice(0, 12);
  if (!base || base.length < 3) base = 'user';
  let generatedUsername = base;
  let attempt = 0;
  while (usersList.some((u: any) => (u.username || '').toLowerCase() === generatedUsername.toLowerCase())) {
    attempt++;
    generatedUsername = `${base}${Math.floor(100 + Math.random() * 900)}`;
    if (attempt > 50) {
      generatedUsername = `user_${Date.now().toString().slice(-5)}`;
      break;
    }
  }

  // 2. Generate secure temporary password
  const generatedPassword = 'Tele@' + Math.floor(1000 + Math.random() * 9000);

  // 3. Compute 1-Week Billing (7 Days Cycle)
  const initialBots = Math.max(1, Number(reqItem.bots_count) || 1);
  const finalRate = Math.max(1, Number(overrideRate) || Number(reqItem.rate_per_bot) || 10);
  const finalModel = (overridePlanModel || reqItem.payment_model || 'postpaid').toLowerCase();
  const cycleDays = 7; // 1-Week billing standard
  const planCost = Math.round(initialBots * finalRate);

  const expDateMs = Date.now() + 5.5 * 3600 * 1000 + (cycleDays * 86400 * 1000);
  const expDateStr = new Date(expDateMs).toISOString().split('T')[0];

  // 4. Create User in system
  const newUser: any = {
    username: generatedUsername,
    password: hashVal(generatedPassword),
    role: 'user',
    active: true,
    max_accounts: initialBots,
    max_targets: 9999,
    expiry_date: expDateStr,
    rate_per_bot: finalRate,
    billing_model: finalModel,
    billing_cycle_days: cycleDays,
    registered_phones: [],
    security_question: 'What is your registered mobile number?',
    security_answer: hashVal((reqItem.phone || '').trim()),
    alert_enabled: true,
    alert_bot_token: botToken,
    alert_chat_id: reqItem.chat_id,
    display_name: reqItem.full_name
  };

  usersList.push(newUser);
  saveUsers();
  broadcastAccountUpdate('admin');

  // 5. Update Khatabook config & generate 1-Week initial invoice
  try {
    if (!billingStore.user_configs) billingStore.user_configs = {};
    billingStore.user_configs[generatedUsername] = {
      rate_per_bot: finalRate,
      rate_per_day: finalRate,
      max_accounts: initialBots,
      billing_cycle_days: cycleDays,
      payment_model: finalModel,
      notes: `${initialBots} Bots @ ₹${finalRate}/bot/day (1-Week ${finalModel === 'postpaid' ? 'Postpaid' : 'Advance'})`
    };

    if (finalModel === 'advance') {
      const advancePlanCost = initialBots * finalRate * cycleDays;
      addBillingInvoice({
        username: generatedUsername,
        date: getTodayDateString(),
        type: 'weekly_plan',
        description: `1-Week Advance Plan (${initialBots} Bot(s) @ ₹${finalRate}/bot/day x ${cycleDays} Days = ₹${advancePlanCost})`,
        bots_count: initialBots,
        days_count: cycleDays,
        amount: advancePlanCost,
        status: 'due'
      });
    } else {
      // 7-Day Postpaid Plan: Dues accrue day-by-day based strictly on LIVE connected bots (not idle slots)
      accrueDailyUsageForUser(generatedUsername, getTodayDateString());
    }
    saveBillingLocal();
  } catch (e) {
    console.error('[BILLING HOOK ERROR]', e);
  }

  reqItem.status = 'approved';
  reqItem.resolved_at = Date.now();
  reqItem.resolved_by = 'Master Telegram Bot';
  reqItem.created_username = generatedUsername;
  reqItem.created_password = generatedPassword;
  reqItem.rate_per_bot = finalRate;
  reqItem.payment_model = finalModel;
  saveAccessRequests();

  // 6. Update Admin Message in Telegram
  const adminConfirmMsg = `✅ <b>USER ACCESS APPROVED & CREATED!</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `👤 <b>Created User ID:</b> <code>${generatedUsername}</code>\n` +
    `🔑 <b>Temporary Password:</b> <code>${generatedPassword}</code>\n` +
    `📱 <b>Customer:</b> ${reqItem.full_name} (<code>${reqItem.phone}</code>)\n` +
    `🤖 <b>Allowed Bots:</b> <b>${initialBots} Accounts</b>\n` +
    `💵 <b>Approved Rate:</b> <b>₹${finalRate} / bot</b>\n` +
    `💰 <b>Weekly Plan Bill:</b> <b>₹${planCost}</b> (${initialBots} IDs x ₹${finalRate})\n` +
    `📅 <b>Billing Type:</b> <b>${finalModel === 'postpaid' ? '7-Day Postpaid' : '7-Day Advance'} (1 Week)</b>\n` +
    `⏳ <b>Valid Till:</b> <b>${formatDisplayDate(expDateStr)}</b> (7 Days / 1 Week)\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `🚀 <i>Credentials and 1-week subscription details have been dispatched to customer's Telegram!</i>`;

  await sendTelegramMessage(botToken, adminChatId, adminConfirmMsg, null, msgId);

  // 7. Dispatch Credentials to Customer in Easy English
  const webLoginUrl = getWebLoginUrl();
  const customerMsg = `🎉 <b>Congratulations! Your TeleBot Account is Approved!</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `Your TeleBot Dashboard access has been activated by Administrator.\n\n` +
    `🔑 <b>Your Login Credentials:</b>\n` +
    `• <b>Username:</b> <code>${generatedUsername}</code>\n` +
    `• <b>Password:</b> <code>${generatedPassword}</code>\n` +
    `• <b>Allowed Bots:</b> <b>${initialBots} Bot(s)</b>\n\n` +
    `📋 <b>Subscription Terms (1-Week Cycle):</b>\n` +
    `• <b>Rate per Bot:</b> ₹${finalRate} / bot\n` +
    `• <b>Weekly Bill:</b> ₹${planCost} (${initialBots} Bots x ₹${finalRate})\n` +
    `• <b>Billing Plan:</b> ${finalModel === 'postpaid' ? '7-Day Postpaid (Payment due at end of weekly cycle)' : '7-Day Advance (Prepaid)'}\n` +
    `• <b>Valid Until:</b> <b>${formatDisplayDate(expDateStr)}</b> (7 Days / 1 Week)\n\n` +
    `🌐 <b>Login Website:</b>\n${webLoginUrl}\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `💳 <i>Send <code>/bill</code> anytime to view your live balance, invoices, and payment status.</i>\n` +
    `🔒 <i>For security, please login and change your password in account settings.</i>`;

  const customerKeyboard = [
    [{ text: '🌐 Open Website & Login', url: webLoginUrl }],
    [{ text: '💳 View My Bill (/bill)', callback_data: `cust_view_bill:${generatedUsername}` }]
  ];

  await sendTelegramMessage(botToken, reqItem.chat_id, customerMsg, customerKeyboard);
}

// Handler: Admin approves Validity Extension via Telegram Button
async function handleAdminValidityExtensionApproval(botToken: string, adminChatId: string, reqId: string, msgId: any, adminUser: any) {
  const reqItem = accessRequests.find((r) => r.id === reqId);
  if (!reqItem) {
    await sendTelegramMessage(botToken, adminChatId, '⚠️ Request not found or already deleted.', null, msgId);
    return;
  }
  if (reqItem.status !== 'pending') {
    await sendTelegramMessage(botToken, adminChatId, `ℹ️ Request is already <b>${reqItem.status.toUpperCase()}</b>!`, null, msgId);
    return;
  }
  const u = getUser(reqItem.target_username || '');
  if (!u) {
    await sendTelegramMessage(botToken, adminChatId, `❌ User "${reqItem.target_username}" not found in system!`, null, msgId);
    return;
  }

  const days = Number(reqItem.validity_days || 30);
  let curExpMs = Date.now() + 5.5 * 3600 * 1000;
  if (u.expiry_date) {
    const parsed = new Date(u.expiry_date + 'T23:59:59Z').getTime();
    if (!isNaN(parsed) && parsed > curExpMs) curExpMs = parsed;
  }
  const newExpMs = curExpMs + (days * 86400 * 1000);
  const newExpDateStr = new Date(newExpMs).toISOString().split('T')[0];

  u.expiry_date = newExpDateStr;
  u.active = true;
  saveUsers();

  // Auto-Billing Hook: Telegram Bot Validity Extension Approval
  try {
    const userRate = getUserEffectiveRate(u.username);
    const userBots = Number(u.max_accounts || 1);
    const extCost = days * userRate * userBots;
    addBillingInvoice({
      username: u.username,
      date: getTodayDateString(),
      type: 'extend_validity',
      description: `Validity Renewal (+${days} Days for ${userBots} IDs @ ₹${userRate}/day)`,
      bots_count: userBots,
      days_count: days,
      amount: extCost,
      status: 'due'
    });
  } catch (e) {
    console.error('[BILLING HOOK ERROR]', e);
  }

  reqItem.status = 'approved';
  reqItem.resolved_at = Date.now();
  reqItem.resolved_by = 'Master Telegram Bot';
  saveAccessRequests();

  const adminMsg = `✅ <b>VALIDITY EXTENSION APPROVED!</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `👤 <b>User:</b> <code>${u.username}</code> (${u.display_name || ''})\n` +
    `⏳ <b>Extended By:</b> <b>+${days} Days</b>\n` +
    `📅 <b>New Expiry Date:</b> <b>${formatDisplayDate(newExpDateStr)}</b>\n\n` +
    `🚀 <i>Customer has been notified in Telegram with the updated expiry date!</i>`;

  await sendTelegramMessage(botToken, adminChatId, adminMsg, null, msgId);

  // Notify customer
  if (reqItem.chat_id) {
    const webLoginUrl = getWebLoginUrl();
    const custMsg = `🎉 <b>Your Validity Extension Has Been Approved!</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `Your account validity has been extended by Administrator.\n\n` +
      `👤 <b>Username:</b> <code>${u.username}</code>\n` +
      `⏳ <b>Added Validity:</b> <b>+${days} Days</b>\n` +
      `📅 <b>New Expiry Date:</b> <b>${formatDisplayDate(newExpDateStr)}</b>\n\n` +
      `🌐 <b>Dashboard:</b> ${webLoginUrl}`;

    await sendTelegramMessage(botToken, reqItem.chat_id, custMsg, [
      [{ text: '🌐 Open Dashboard', url: webLoginUrl }],
      [{ text: '💳 View My Bill (/bill)', callback_data: `cust_view_bill:${u.username}` }]
    ]);
  }
}

// Handler: Admin approves Extra Bot Slots via Telegram Button
async function handleAdminExtraBotsApproval(botToken: string, adminChatId: string, reqId: string, msgId: any, adminUser: any) {
  const reqItem = accessRequests.find((r) => r.id === reqId);
  if (!reqItem) {
    await sendTelegramMessage(botToken, adminChatId, '⚠️ Request not found or already deleted.', null, msgId);
    return;
  }
  if (reqItem.status !== 'pending') {
    await sendTelegramMessage(botToken, adminChatId, `ℹ️ Request is already <b>${reqItem.status.toUpperCase()}</b>!`, null, msgId);
    return;
  }
  const u = getUser(reqItem.target_username || '');
  if (!u) {
    await sendTelegramMessage(botToken, adminChatId, `❌ User "${reqItem.target_username}" not found in system!`, null, msgId);
    return;
  }

  const added = Number(reqItem.bots_count || 1);
  u.max_accounts = Number(u.max_accounts || 1) + added;
  saveUsers();

  // Auto-Billing Hook: Telegram Bot Extra Slots Approval
  try {
    const userRate = getUserEffectiveRate(u.username);
    let remDays = 30;
    if (u.expiry_date) {
      const expMs = new Date(u.expiry_date + 'T23:59:59Z').getTime();
      const nowMs = Date.now();
      if (expMs > nowMs) {
        remDays = Math.max(1, Math.ceil((expMs - nowMs) / (86400 * 1000)));
      }
    }
    const slotCost = added * userRate * remDays;
    addBillingInvoice({
      username: u.username,
      date: getTodayDateString(),
      type: 'add_bots',
      description: `Added +${added} Bot Slots (${remDays} days remaining in cycle @ ₹${userRate}/day)`,
      bots_count: added,
      days_count: remDays,
      amount: slotCost,
      status: 'due'
    });
  } catch (e) {
    console.error('[BILLING HOOK ERROR]', e);
  }

  reqItem.status = 'approved';
  reqItem.resolved_at = Date.now();
  reqItem.resolved_by = 'Master Telegram Bot';
  saveAccessRequests();

  const adminMsg = `✅ <b>EXTRA BOTS QUOTA APPROVED!</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `👤 <b>User:</b> <code>${u.username}</code> (${u.display_name || ''})\n` +
    `➕ <b>Added Slots:</b> <b>+${added} Bots</b>\n` +
    `🤖 <b>New Total Quota:</b> <b>${u.max_accounts} Bots</b>\n\n` +
    `🚀 <i>Customer has been notified in Telegram that they can now add more accounts!</i>`;

  await sendTelegramMessage(botToken, adminChatId, adminMsg, null, msgId);

  // Notify customer
  if (reqItem.chat_id) {
    const webLoginUrl = getWebLoginUrl();
    const custMsg = `🎉 <b>Your Extra Bot Slots Have Been Approved!</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `Your bot slot quota has been successfully increased by Administrator.\n\n` +
      `👤 <b>Username:</b> <code>${u.username}</code>\n` +
      `➕ <b>Added Bots:</b> <b>+${added} Accounts</b>\n` +
      `🤖 <b>New Total Quota:</b> <b>${u.max_accounts} Bots</b>\n\n` +
      `You can now log in to your dashboard and connect your new accounts!\n` +
      `🌐 <b>Dashboard:</b> ${webLoginUrl}`;

    await sendTelegramMessage(botToken, reqItem.chat_id, custMsg, [
      [{ text: '🌐 Open Dashboard', url: webLoginUrl }],
      [{ text: '💳 View My Bill (/bill)', callback_data: `cust_view_bill:${u.username}` }]
    ]);
  }
}

async function handleAdminUserRequestRejection(botToken: string, adminChatId: string, reqId: string, msgId: any) {
  const reqItem = accessRequests.find((r) => r.id === reqId);
  if (!reqItem) {
    await sendTelegramMessage(botToken, adminChatId, '⚠️ Request not found or already processed.', null, msgId);
    return;
  }
  if (reqItem.status !== 'pending') {
    await sendTelegramMessage(botToken, adminChatId, `ℹ️ Request is already <b>${reqItem.status.toUpperCase()}</b>!`, null, msgId);
    return;
  }

  reqItem.status = 'rejected';
  reqItem.resolved_at = Date.now();
  reqItem.resolved_by = 'Master Telegram Bot';
  saveAccessRequests();

  const rejectAdminMsg = `❌ <b>Request Rejected</b>\n` +
    `Access request for <b>${reqItem.full_name}</b> was rejected.`;

  await sendTelegramMessage(botToken, adminChatId, rejectAdminMsg, null, msgId);

  const custRejectMsg = reqItem.type === 'extend_validity'
    ? `⚠️ <b>Validity Extension Request Update</b>\nYour request to extend validity was not approved at this time.\nPlease contact the Administrator for details.`
    : reqItem.type === 'add_bots'
    ? `⚠️ <b>Extra Bots Request Update</b>\nYour request for additional bot slots was not approved at this time.\nPlease contact the Administrator for details.`
    : `⚠️ <b>Access Request Update: Declined</b>\nYour request for new TeleBot access was not approved at this time.\nPlease contact the Administrator directly for plan discussion or assistance.`;

  await sendTelegramMessage(botToken, reqItem.chat_id, custRejectMsg);
}

async function handleTelegramUpdate(botToken: string, update: any) {
  try {
    const globalAdminUser = usersList.find((u) => u.role === 'admin');
    const adminUser = usersList.find((u) => (u.alert_bot_token || '').trim() === botToken && u.role === 'admin');
    const matchedUser = usersList.find((u) => 
      u.role !== 'admin' && (
        (u.alert_bot_token || '').trim() === botToken ||
        (u.master_config?.filter_bot_token || '').trim() === botToken ||
        ((u as any).filter_bot_token || '').trim() === botToken
      )
    );

    // ---------------- BOT PROMOTED AS ADMIN IN CHANNEL ----------------
    if (update.my_chat_member) {
      const mcm = update.my_chat_member;
      const chat = mcm.chat;
      const newStatus = mcm.new_chat_member?.status;
      if (chat && (chat.type === 'channel' || chat.type === 'supergroup')) {
        const cid = String(chat.id);
        const title = chat.title || `Channel ${cid}`;
        let cached = filterBotAdminChannelsCache.get(botToken);
        if (!cached) {
          cached = { timestamp: Date.now(), channels: new Map() };
          filterBotAdminChannelsCache.set(botToken, cached);
        }
        if (newStatus === 'administrator' || newStatus === 'creator') {
          cached.channels.set(cid, title);
          if (chat.username) cached.channels.set('@' + chat.username.toLowerCase(), title);
          console.log(`[FILTER BOT ADMIN LINKED]: Bot is now Admin in "${title}" (${cid})`);
          const targetOwner = matchedUser ? matchedUser.username : (adminUser ? 'admin' : '');
          if (targetOwner) {
            getOrCreateUserTrackedInviteLink(targetOwner).catch(() => null);
          }
        } else if (newStatus === 'left' || newStatus === 'kicked') {
          cached.channels.delete(cid);
          if (chat.username) cached.channels.delete('@' + chat.username.toLowerCase());
        }
      }
      return;
    }

    if (update.channel_post) {
      const chat = update.channel_post.chat;
      if (chat && (chat.type === 'channel' || chat.type === 'supergroup')) {
        const cid = String(chat.id);
        const title = chat.title || `Channel ${cid}`;
        let cached = filterBotAdminChannelsCache.get(botToken);
        if (!cached) {
          cached = { timestamp: Date.now(), channels: new Map() };
          filterBotAdminChannelsCache.set(botToken, cached);
        }
        cached.channels.set(cid, title);
        if (chat.username) cached.channels.set('@' + chat.username.toLowerCase(), title);
      }
    }

    // ---------------- JOIN REQUEST EVENT HANDLING ----------------
    if (update.chat_join_request) {
      const cjr = update.chat_join_request;
      const invLink = cjr.invite_link;
      const invLinkUrl = (invLink?.invite_link || '').trim();
      const invLinkName = (invLink?.name || '').trim();
      const fromUser = cjr.from || {};
      const chatTitle = cjr.chat?.title || 'Target Channel';
      const channelChatId = String(cjr.chat?.id || '').trim();
      const channelUsername = (cjr.chat?.username || '').toLowerCase().trim();

      // 1. Match to owner by link name (Track_<owner>) or tracked links URL
      let matchedOwner = '';
      if (invLinkName && invLinkName.toLowerCase().startsWith('track_')) {
        matchedOwner = invLinkName.slice(6).trim();
      } else if (invLinkUrl) {
        for (const [uname, rec] of Object.entries(userTrackedLinks)) {
          if (rec.invite_link && rec.invite_link.trim() === invLinkUrl) {
            matchedOwner = uname;
            break;
          }
        }
      }

      // 2. Match by botToken owner (User's filter bot in master_config, alert bot, user root property, or account config)
      if (!matchedOwner) {
        const cleanTok = botToken.trim();
        const matchingUser = usersList.find(u => 
          (u.master_config?.filter_bot_token && u.master_config.filter_bot_token.trim() === cleanTok) ||
          ((u as any).filter_bot_token && (u as any).filter_bot_token.trim() === cleanTok) ||
          (u.alert_bot_token && u.alert_bot_token.trim() === cleanTok)
        );
        if (matchingUser) {
          matchedOwner = matchingUser.username;
        } else {
          // Check accounts configs
          for (const a of accounts.values()) {
            if (a.config?.filter_bot_token?.trim() === cleanTok || a.config?.alert_bot_token?.trim() === cleanTok) {
              matchedOwner = a.owner || 'admin';
              break;
            }
          }
          if (!matchedOwner) {
            const vaultBot = botsVault.find(b => b.token && b.token.trim() === cleanTok);
            if (vaultBot && vaultBot.owner) {
              matchedOwner = vaultBot.owner;
            }
          }
        }
      }

      // 3. Match by channel link in user master_config or account configs
      if (!matchedOwner && (channelChatId || channelUsername || invLinkUrl)) {
        for (const u of usersList) {
          const chLink = (u.master_config?.channel_link || (u as any).channel_link || '').toLowerCase().trim();
          const tgList = Array.isArray(u.master_config?.targets) ? u.master_config.targets.map((t: string) => t.toLowerCase().trim()) : [];
          if (chLink && (
            (channelUsername && chLink.includes(channelUsername)) ||
            (channelChatId && chLink.includes(channelChatId)) ||
            (invLinkUrl && chLink.includes(invLinkUrl.toLowerCase()))
          )) {
            matchedOwner = u.username;
            break;
          }
          if (channelUsername && tgList.some((t: string) => t.includes(channelUsername))) {
            matchedOwner = u.username;
            break;
          }
        }
      }

      // 4. Fallback: match to active user sending DMs if only one non-admin is active
      if (!matchedOwner || matchedOwner.toLowerCase() === 'admin') {
        const activeUsers = usersList.filter(u => {
          if (u.role === 'admin') return false;
          const uAccs = Array.from(accounts.values()).filter(a => (a.owner || '').toLowerCase() === u.username.toLowerCase());
          return uAccs.some(a => a.running || ((a as any).daily_sent_count || 0) > 0);
        });
        if (activeUsers.length === 1) {
          matchedOwner = activeUsers[0].username;
        }
      }

      if (!matchedOwner) {
        const nonAdmin = usersList.filter(u => u.role !== 'admin');
        if (nonAdmin.length === 1) {
          matchedOwner = nonAdmin[0].username;
        } else {
          matchedOwner = 'admin';
        }
      }

      recordJoinRequest(matchedOwner, {
        id: fromUser.id,
        name: [fromUser.first_name, fromUser.last_name].filter(Boolean).join(' ') || fromUser.username || 'User',
        username: fromUser.username
      });
      console.log(`[JOIN REQUEST LOGGED] +1 Join request for ${matchedOwner} from ${fromUser.first_name || fromUser.username} (${fromUser.id}) via ${invLinkUrl || chatTitle}`);
      broadcastAccountUpdate(matchedOwner);
      broadcastAccountUpdate('admin');

      // User channels join requests must NOT notify admin bot (only the target customer gets alerted)
      const todayDms = getOwnerDailyDmStats(matchedOwner, 1)[0]?.count || 0;
      const historyKey = Object.keys(dailyJoinHistory).find(k => k.toLowerCase() === matchedOwner.toLowerCase()) || matchedOwner;
      const todayJoins = dailyJoinHistory[historyKey]?.[getTodayDateString()]?.count || 1;
      const convRoi = todayDms > 0 ? ((todayJoins / todayDms) * 100).toFixed(1) + '%' : '100%';

      // Join request notification on user bot is turned OFF per customer requirement!
      // Instead, user receives an automatic 12:00 AM midnight daily summary of Total Sent DMs & Total Joins.
      // Data remains fully logged for daily analytics, stats, and dashboard live updates.
      return;
    }

    // 1. Handle incoming messages/commands
    if (update.message) {
      const msg = update.message;
      const chatId = String(msg.chat.id);
      let rawText = (msg.text || '').trim();
      // Remove @botusername from command (e.g. /control@MyBot -> /control)
      const commandParts = rawText.split(' ');
      const cleanCommand = commandParts[0].split('@')[0].toLowerCase();
      const argsText = commandParts.slice(1).join(' ').trim();
      const fullText = (cleanCommand + (argsText ? ' ' + argsText : '')).trim();

      // If this token belongs to Admin
      if (adminUser) {
        const adminChatId = String(adminUser.alert_chat_id || '').trim();
        const isAdminChat = (adminChatId && chatId === adminChatId);

        // If the message is NOT from the Admin's registered personal Chat ID, it's a Customer!
        if (!isAdminChat) {
          await handleCustomerOnboardingMessage(botToken, chatId, msg, adminUser);
          return;
        }

        // Check if admin is currently replying to a prompt (typing custom bots quota or days)
        if (adminCustomPrompt.has(chatId) && !rawText.startsWith('/')) {
          const promptData = adminCustomPrompt.get(chatId)!;
          const targetReq = accessRequests.find(r => r.id === promptData.reqId);
          if (!targetReq || targetReq.status !== 'pending') {
            adminCustomPrompt.delete(chatId);
            await sendTelegramMessage(botToken, chatId, '⚠️ Request is no longer pending or was not found.');
            return;
          }

          if (promptData.field === 'rate') {
            const val = parseInt(rawText, 10);
            if (isNaN(val) || val < 1 || val > 10000) {
              await sendTelegramMessage(botToken, chatId, '⚠️ Please type a valid rate in ₹ per bot (e.g. <code>10</code>, <code>15</code>, <code>20</code>):');
              return;
            }
            targetReq.rate_per_bot = val;
            (targetReq as any).customized_by_admin = true;
            saveAccessRequests();
            adminCustomPrompt.delete(chatId);
            const { text: updatedText, keyboard: updatedKeyboard } = formatAdminRequestAlert(targetReq);
            await sendTelegramMessage(botToken, chatId, `✅ <b>Rate per Bot Updated to ₹${val}/bot!</b>\n\n` + updatedText, updatedKeyboard);
            return;
          }

          if (promptData.field === 'bots') {
            const val = parseInt(rawText, 10);
            if (isNaN(val) || val < 1 || val > 1000) {
              await sendTelegramMessage(botToken, chatId, '⚠️ Please type a valid number of bots (e.g. <code>2</code>, <code>5</code>, <code>10</code>):');
              return;
            }
            targetReq.bots_count = val;
            (targetReq as any).customized_by_admin = true;
            saveAccessRequests();
            adminCustomPrompt.delete(chatId);
            const { text: updatedText, keyboard: updatedKeyboard } = formatAdminRequestAlert(targetReq);
            await sendTelegramMessage(botToken, chatId, `✅ <b>Bots Quota Updated to ${val} Bot(s)!</b>\n\n` + updatedText, updatedKeyboard);
            return;
          }

          if (promptData.field === 'days') {
            const val = parseInt(rawText, 10);
            if (isNaN(val) || val < 1 || val > 3650) {
              await sendTelegramMessage(botToken, chatId, '⚠️ Please type a valid number of days (e.g. <code>7</code>, <code>15</code>, <code>30</code>):');
              return;
            }
            targetReq.validity_days = val;
            (targetReq as any).customized_by_admin = true;
            saveAccessRequests();
            adminCustomPrompt.delete(chatId);
            const { text: updatedText, keyboard: updatedKeyboard } = formatAdminRequestAlert(targetReq);
            await sendTelegramMessage(botToken, chatId, `✅ <b>Validity Duration Updated to ${val} Day(s)!</b>\n\n` + updatedText, updatedKeyboard);
            return;
          }
        }

        if (cleanCommand === '/setdomain' || cleanCommand === '/domain') {
          if (argsText) {
            let newDomain = argsText.trim();
            if (!newDomain.startsWith('http://') && !newDomain.startsWith('https://')) {
              newDomain = 'https://' + newDomain;
            }
            newDomain = newDomain.replace(/\/$/, '');
            adminUser.custom_web_url = newDomain;
            setSystemConfiguredDomain(newDomain);
            if (billingStore.settings) {
              billingStore.settings.domain = newDomain;
              saveBillingLocal();
            }
            saveUsers();
            const finalUrl = getWebLoginUrl();
            await sendTelegramMessage(botToken, chatId, `✅ <b>Live Website URL Updated!</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\n🌐 <b>Active Login URL:</b>\n<code>${finalUrl}</code>\n\nLive login links will be automatically dispatched to new customers upon approval and in billing reminders.`);
            return;
          } else {
            const cur = getWebLoginUrl();
            await sendTelegramMessage(botToken, chatId, `🌐 <b>Current Live Website Login URL:</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\n<code>${cur}</code>\n\nTo configure a custom VPS domain or link, send:\n<code>/setdomain https://your-vps-domain.com</code>`);
            return;
          }
        }

        // --- 1. /dm COMMAND (Strictly User-Wise Today, 5-Day & Per-Day DM Statistics & Joins) ---
        if (cleanCommand === '/dm' || cleanCommand === '/dmcount' || cleanCommand === '/dms') {
          const nonAdminUsers = usersList.filter((u: any) => u.role !== 'admin');
          if (nonAdminUsers.length === 0) {
            await sendTelegramMessage(botToken, chatId, '⚠️ <b>No regular users found in the system.</b>');
            return;
          }

          // Case A: Admin requested a specific user's breakdown (e.g. /dm rabiul or /dm @rabiul)
          if (argsText) {
            const cleanTarget = argsText.replace('@', '').trim().toLowerCase();
            const targetUser = nonAdminUsers.find((u: any) =>
              u.username.toLowerCase() === cleanTarget ||
              (u.display_name && u.display_name.toLowerCase().includes(cleanTarget))
            );

            if (!targetUser) {
              const available = nonAdminUsers.map(u => `• <code>${u.username}</code>`).join('\n');
              await sendTelegramMessage(botToken, chatId,
                `❌ <b>User "${argsText}" not found.</b>\n\n` +
                `<b>Available Users:</b>\n${available}\n\n` +
                `<i>Example:</i> <code>/dm ${nonAdminUsers[0]?.username || 'username'}</code>`
              );
              return;
            }

            const ov = getOwnerDmOverview(targetUser.username);
            let uReport = `📊 <b>Direct Messaging Performance: @${targetUser.username}</b>\n` +
              `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
              `👤 <b>Account:</b> <code>${targetUser.username}</code> ${targetUser.display_name ? `(🏷️ ${targetUser.display_name})` : ''}\n` +
              `🤖 <b>Live Bots:</b> 🟢 <b>${ov.liveAccounts} Live</b> / ${ov.totalAccounts} Connected\n` +
              `🚀 <b>Today's Sent DMs:</b> <b>${ov.todayDms} DMs</b>\n` +
              `🎯 <b>Today's Channel Joins:</b> <b>${ov.todayJoins} Joins</b> <i>(${ov.convRate} ROI)</i>\n` +
              `📈 <b>Last 5-Days Total:</b> <b>${ov.sum5DaysDms} DMs</b> ➔ 🎯 <b>${ov.sum5DaysJoins} Joins</b>\n` +
              `⚡ <b>Daily Average:</b> <b>${ov.avgPerDayDms} DMs/day</b>\n` +
              `👑 <b>Lifetime Total Sent:</b> <b>${ov.lifetimeDms} DMs</b> ➔ 🎯 <b>${ov.lifetimeJoins} Joins</b>\n\n` +
              `📅 <b>Last 5 Days Per-Day Activity Breakdown:</b>\n`;

            ov.stats5Days.forEach((d: any, idx: number) => {
              const j = ov.joins5Days[idx]?.join_count || 0;
              const dayRoi = d.count > 0 ? ((j / d.count) * 100).toFixed(1) + '%' : (j > 0 ? '100%' : '0%');
              uReport += `  • <code>${formatDisplayDate(d.date)}</code>: <b>${d.count} DMs</b> ➔ 🎯 <b>${j} Joins</b> <i>(${dayRoi})</i>\n`;
            });

            if (ov.uAccs.length > 0) {
              uReport += `\n📱 <b>Bot Accounts:</b>\n`;
              ov.uAccs.forEach((a: any, idx: number) => {
                const st = a.running ? '🟢' : '🔴';
                const dms = Math.max((a as any).daily_sent_count || 0, (a as any).daily_extracted_count || 0);
                uReport += `  ${st} <b>#${idx + 1}</b> <code>${a.phone}</code>: <b>${dms} DMs today</b> (Total: ${a.sent_count || 0})\n`;
              });
            }

            await sendTelegramMessage(botToken, chatId, uReport);
            return;
          }

          // Case B: Full overview report for ALL active users
          let report = `📊 <b>User-wise DM & Join Performance</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\n`;
          let totalTodayAll = 0;
          let totalTodayJoinsAll = 0;
          let total5DaysAll = 0;
          let total5DaysJoinsAll = 0;
          let totalLifetimeAll = 0;
          let totalLifetimeJoinsAll = 0;

          nonAdminUsers.forEach((u: any) => {
            const ov = getOwnerDmOverview(u.username);
            totalTodayAll += ov.todayDms;
            totalTodayJoinsAll += ov.todayJoins;
            total5DaysAll += ov.sum5DaysDms;
            total5DaysJoinsAll += ov.sum5DaysJoins;
            totalLifetimeAll += ov.lifetimeDms;
            totalLifetimeJoinsAll += ov.lifetimeJoins;

            report += `👤 <b>${u.username}</b> (🟢 ${ov.liveAccounts}/${ov.totalAccounts} IDs Live)\n`;
            report += `  • 🚀 <b>Today:</b> <code>${ov.todayDms} DMs</code> ➔ 🎯 <b>${ov.todayJoins} Joins</b> <i>(${ov.convRate})</i>\n`;
            report += `  • 📈 <b>5-Days:</b> <code>${ov.sum5DaysDms} DMs</code> (⚡ <code>${ov.avgPerDayDms} DMs/day</code>) ➔ 🎯 <b>${ov.sum5DaysJoins} Joins</b>\n`;
            report += `  • 👑 <b>Lifetime:</b> <code>${ov.lifetimeDms} DMs</code> ➔ 🎯 <code>${ov.lifetimeJoins} Joins</code>\n`;

            const breakdown = ov.stats5Days.map((d: any, idx: number) => {
              const j = ov.joins5Days[idx]?.join_count || 0;
              return `${formatDisplayDate(d.date).slice(0, 5)}: ${d.count} [🎯${j}]`;
            }).join(' | ');
            report += `  • <i>Per Day: ${breakdown}</i>\n`;
            report += `────────────────────────\n`;
          });

          report += `\n🔥 <b>Total Today:</b> <code>${totalTodayAll} DMs</code> ➔ 🎯 <code>${totalTodayJoinsAll} Joins</code>\n`;
          report += `📈 <b>Total 5-Days:</b> <code>${total5DaysAll} DMs</code> ➔ 🎯 <code>${total5DaysJoinsAll} Joins</code>\n`;
          report += `👑 <b>Total Lifetime:</b> <code>${totalLifetimeAll} DMs</code> ➔ 🎯 <code>${totalLifetimeJoinsAll} Joins</code>\n\n`;
          report += `👉 <i>Tip: Send <code>/dm username</code> to view an in-depth breakdown for that user.</i>`;

          await sendTelegramMessage(botToken, chatId, report);
          return;
        }

        // --- 2. /user or /users COMMAND (Strictly Total Users & Validity List) ---
        if (cleanCommand === '/user' || cleanCommand === '/users' || cleanCommand === '/userlist') {
          const nonAdminUsers = usersList.filter((u: any) => u.role !== 'admin');
          let report = `👥 <b>Total Registered Users (${nonAdminUsers.length})</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\n`;
          
          nonAdminUsers.forEach((u: any, idx: number) => {
            const uAccs = Array.from(accounts.values()).filter((a: any) => (a.owner || 'admin').toLowerCase() === u.username.toLowerCase());
            const liveAccs = uAccs.filter((a: any) => a.running).length;
            const range = getUserCycleDateRange(u);
            const expDate = u.expiry_date ? formatDisplayDate(u.expiry_date) : 'Lifetime';
            const statusIcon = u.active ? (u.payment_paused ? '⏸️ (Paused)' : '🟢 (Active)') : '🔴 (Disabled)';

            report += `<b>${idx + 1}.</b> <b>${u.username}</b> ${statusIcon}\n`;
            report += `   • 📱 <b>Accounts:</b> ${uAccs.length} IDs (Live: ${liveAccs})\n`;
            report += `   • 📅 <b>Plan Validity:</b> <code>${range.formattedRange}</code>\n`;
            report += `   • ⏳ <b>Plan Expiry:</b> <code>${expDate}</code>\n`;
            if (u.display_name) report += `   • 🏷️ Name: ${u.display_name}\n`;
            report += `────────────────────────\n`;
          });

          await sendTelegramMessage(botToken, chatId, report);
          return;
        }

        // --- 3. /khatabook or /due (Pending Dues & Balances) ---
        if (cleanCommand === '/khatabook' || cleanCommand === '/due' || cleanCommand === '/dues' || cleanCommand === '/billings') {
          const nonAdminUsers = usersList.filter((u: any) => u.role !== 'admin');
          const curr = (billingStore.currency || 'INR') === 'INR' ? '₹' : '$';
          let totalDueSum = 0;
          let report = `💳 <b>Khatabook - Outstanding Dues & Balances</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\n`;

          let dueCount = 0;
          nonAdminUsers.forEach((u: any) => {
            const uLedger = (billingStore.user_ledgers || {})[u.username] || {};
            const bal = Number(uLedger.balance_due || 0);
            const isAdvance = bal < 0;
            const isDue = bal > 0;
            if (isDue) {
              totalDueSum += bal;
              dueCount++;
            }

            const balStr = isDue 
              ? `🔴 <b>${curr}${bal.toLocaleString()} Due</b>` 
              : (isAdvance ? `⭐ <b>-${curr}${Math.abs(bal).toLocaleString()} (Adv)</b>` : `🟢 <b>${curr}0 (All Paid)</b>`);

            report += `• <b>${u.username}</b>: ${balStr} | ⏳ <code>${formatDisplayDate(u.expiry_date)}</code>\n`;
          });

          report += `━━━━━━━━━━━━━━━━━━━━━━━━\n`;
          report += `💰 <b>Total Outstanding Due to Collect:</b> <code>${curr}${totalDueSum.toLocaleString()}</code> (${dueCount} Users)\n\n`;
          report += `👉 <i>Tip: To record payment:</i>\n<code>/pay username 105</code>\n`;
          report += `👉 <i>To send billing reminder:</i>\n<code>/remind username</code>`;

          await sendTelegramMessage(botToken, chatId, report);
          return;
        }

        // --- 4. /pay <username> <amount> (Record Payment & Auto Extend Validity) ---
        if (cleanCommand === '/pay' || cleanCommand === '/jama') {
          const parts = argsText.split(' ').filter(Boolean);
          if (parts.length < 2) {
            await sendTelegramMessage(botToken, chatId, `⚠️ <b>Command Usage:</b>\n<code>/pay username amount [note]</code>\n\n<b>Example:</b>\n<code>/pay rabiul 105</code>`);
            return;
          }
          const targetUser = parts[0].replace('@', '').trim();
          const amt = parseFloat(parts[1]);
          const note = parts.slice(2).join(' ') || 'Payment recorded via Telegram Admin Bot';

          if (isNaN(amt) || amt <= 0) {
            await sendTelegramMessage(botToken, chatId, `❌ Invalid amount: "${parts[1]}". Enter positive number.`);
            return;
          }

          const u = usersList.find((x: any) => x.username.toLowerCase() === targetUser.toLowerCase());
          if (!u) {
            await sendTelegramMessage(botToken, chatId, `❌ User "${targetUser}" not found in system.`);
            return;
          }

          // Record payment and auto-extend 7 days ONLY if all dues are cleared!
          const payResult = applyPaymentAndCheckAutoExtend(u.username, amt, 'UPI', note, 'Telegram Admin Bot');
          const curr = (billingStore.currency || 'INR') === 'INR' ? '₹' : '$';
          const newBal = payResult.summary?.balance_due || 0;
          const dueMsg = newBal > 0 ? `${curr}${newBal.toLocaleString()} Due` : (newBal < 0 ? `-${curr}${Math.abs(newBal).toLocaleString()} (Adv)` : '₹0 (All Paid)');
          const range = getUserCycleDateRange(u);
          const extMsg = payResult.extended 
            ? `\n🎉 <b>All Dues Cleared!</b> Validity automatically extended by +7 Days until <code>${formatDisplayDate(payResult.newExpiry)}</code>!` 
            : (newBal > 0 ? `\nℹ️ <i>Remaining Due: ₹${newBal.toLocaleString()}. Plan expiry NOT extended until full settlement.</i>` : '');

          await sendTelegramMessage(botToken, chatId, `✅ <b>Payment Recorded Successfully!</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\n👤 <b>User:</b> <code>${u.username}</code>\n💵 <b>Amount Received:</b> <b>${curr}${amt.toLocaleString()}</b>\n💳 <b>Current Balance:</b> <b>${dueMsg}</b>\n📅 <b>Plan Validity:</b> <code>${range.formattedRange}</code>\n⏳ <b>Plan Valid Until:</b> <code>${formatDisplayDate(u.expiry_date)}</code>${extMsg}\n\n⚡ User ledger updated and bots active!`);
          return;
        }

        // --- 5. /remind <username> (Send Direct Billing Reminder) ---
        if (cleanCommand === '/remind') {
          const targetUser = argsText.replace('@', '').trim();
          if (!targetUser) {
            await sendTelegramMessage(botToken, chatId, `⚠️ <b>Command Usage:</b>\n<code>/remind username</code>\n\n<b>Example:</b>\n<code>/remind rabiul</code>`);
            return;
          }
          const u = usersList.find((x: any) => x.username.toLowerCase() === targetUser.toLowerCase());
          if (!u) {
            await sendTelegramMessage(botToken, chatId, `❌ User "${targetUser}" not found in system.`);
            return;
          }
          const res = await sendUserBillingReminder(u.username);
          await sendTelegramMessage(botToken, chatId, res.msg);
          return;
        }

        // --- 6. /remindall (Send Reminder to All Due Users) ---
        if (cleanCommand === '/remindall') {
          const nonAdminUsers = usersList.filter((u: any) => u.role !== 'admin');
          let sentCount = 0;
          let failedCount = 0;

          for (const u of nonAdminUsers) {
            const uLedger = (billingStore.user_ledgers || {})[u.username] || {};
            const bal = Number(uLedger.balance_due || 0);
            if (bal > 0) {
              const res = await sendUserBillingReminder(u.username);
              if (res.ok) sentCount++;
              else failedCount++;
            }
          }

          await sendTelegramMessage(botToken, chatId, `📢 <b>Mass Payment Reminders Sent!</b>\n\n✅ <b>Delivered:</b> ${sentCount} users\n⚠️ <b>No Telegram Linked:</b> ${failedCount} users`);
          return;
        }

        // --- 7. /pause <username> and /unpause <username> ---
        if (cleanCommand === '/pause') {
          const targetUser = argsText.replace('@', '').trim();
          const u = usersList.find((x: any) => x.username.toLowerCase() === targetUser.toLowerCase());
          if (!u) {
            await sendTelegramMessage(botToken, chatId, `❌ User "${targetUser}" not found.`);
            return;
          }
          u.payment_paused = true;
          for (const a of accounts.values()) {
            if ((a.owner || 'admin') === u.username && a.running) {
              a.running = false;
              if (a.abortController) a.abortController.abort();
              a.status = 'Paused (Payment Overdue)';
            }
          }
          saveUsers();
          await sendTelegramMessage(botToken, chatId, `⏸️ <b>Bots Paused for ${u.username}</b>\nAll running bots stopped due to payment overdue.`);
          return;
        }

        if (cleanCommand === '/unpause') {
          const targetUser = argsText.replace('@', '').trim();
          const u = usersList.find((x: any) => x.username.toLowerCase() === targetUser.toLowerCase());
          if (!u) {
            await sendTelegramMessage(botToken, chatId, `❌ User "${targetUser}" not found.`);
            return;
          }
          u.payment_paused = false;
          saveUsers();
          await sendTelegramMessage(botToken, chatId, `▶️ <b>Bots Unpaused for ${u.username}</b>\nUser can now resume and run bots smoothly.`);
          return;
        }

        if (cleanCommand === '/start' || cleanCommand === '/admin' || cleanCommand === '/status' || cleanCommand === '/menu') {
          if (argsText) {
            // Check if user ran "/start AccountName"
            const name = argsText;
            const acc = Array.from(accounts.values()).find(a => (a.name || '').toLowerCase() === name.toLowerCase());
            if (acc) { 
              (acc as any).running = true; 
              await sendTelegramMessage(botToken, chatId, `✅ Account <b>${acc.name}</b> started!`); 
            } else {
              await sendTelegramMessage(botToken, chatId, `❌ Account with name '${name}' not found!`); 
            }
            return;
          }
          const { text: t, keyboard: k } = formatAdminMenu();
          await sendTelegramMessage(botToken, chatId, t, k);
          return;
        } else if (cleanCommand === '/requests' || cleanCommand === '/req' || cleanCommand === '/onboard') {
          const pending = accessRequests.filter(r => r.status === 'pending');
          if (pending.length === 0) {
            await sendTelegramMessage(botToken, chatId, '✅ <b>No pending user access requests at the moment!</b>');
            return;
          }
          for (const r of pending.slice(0, 5)) {
            const { text: alertMsg, keyboard: k } = formatAdminRequestAlert(r);
            await sendTelegramMessage(botToken, chatId, alertMsg, k);
          }
          return;
        } else if (cleanCommand === '/control') {
          const keyboard = usersList.filter((u: any) => u.role !== 'admin').map((u: any) => [{ text: `👤 ${u.username}`, callback_data: `adm_ctrl_u:${u.username}` }]);
          keyboard.push([{ text: '🔄 Refresh', callback_data: 'adm_ctrl_refresh' }]);
          await sendTelegramMessage(botToken, chatId, '🎛️ <b>Admin Bot Remote Control Panel</b>\n\n👇 Select a user to manage their Telegram accounts:', keyboard);
          return;
        } else if (cleanCommand === '/stop') {
          const name = argsText;
          const acc = Array.from(accounts.values()).find(a => (a.name || '').toLowerCase() === name.toLowerCase());
          if (acc) { 
            (acc as any).running = false; 
            await sendTelegramMessage(botToken, chatId, `🛑 Account <b>${acc.name}</b> stopped!`); 
          } else {
            await sendTelegramMessage(botToken, chatId, `❌ Account with name '${name}' not found!`); 
          }
          return;
        } else if (cleanCommand === '/dmstatus') {
          const keyboard = usersList.filter((u: any) => u.role !== 'admin').map((u: any) => [{ text: u.username, callback_data: `admin_dm_user:${u.username}` }]);
          await sendTelegramMessage(botToken, chatId, 'Select a user to check DM status:', keyboard);
          return;
        } else if (cleanCommand === '/gemini' || cleanCommand === '/ai' || cleanCommand === '/report') {
          const { text: t, keyboard: k } = formatGeminiReport(5);
          await sendTelegramMessage(botToken, chatId, t, k);
          return;
        } else if (cleanCommand === '/expiry' || cleanCommand === '/exp') {
          const { text: t, keyboard: k } = formatAdminExpiryList();
          await sendTelegramMessage(botToken, chatId, t, k);
          return;
        } else if (cleanCommand === '/vps' || cleanCommand === '/health' || cleanCommand === '/server' || cleanCommand === '/specs') {
          const { text: t, keyboard: k } = await formatVpsStatusMessage();
          await sendTelegramMessage(botToken, chatId, t, k);
          return;
        } else {
          // If unrecognized command sent to admin, do NOT execute menu repeatedly
          return;
        }
      }

      // If this token belongs to a User (NOT admin)
      if (matchedUser) {
        const uAccs = Array.from(accounts.values()).filter((a) => (a.owner || 'admin').toLowerCase() === matchedUser.username.toLowerCase());
        // --- USER SPECIFIC COMMANDS ---
        if (cleanCommand === '/mydm' || cleanCommand === '/dm' || cleanCommand === '/mystats') {
          const ov = getOwnerDmOverview(matchedUser.username);
          let msg = `📊 <b>My Direct Messaging Performance</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\n` +
                    `👤 <b>Account:</b> <code>${matchedUser.username}</code>\n` +
                    `🤖 <b>Live Bots:</b> 🟢 <b>${ov.liveAccounts} Live</b> / ${ov.totalAccounts} Connected\n` +
                    `🔥 <b>Today's Sent DMs:</b> <b>${ov.todayDms} DMs</b>\n` +
                    `🎯 <b>Today's Channel Joins:</b> <b>${ov.todayJoins} Joins</b> <i>(${ov.convRate} ROI)</i>\n` +
                    `👑 <b>Lifetime Joins:</b> <b>${ov.lifetimeJoins} Joins</b>\n` +
                    `📈 <b>Last 5-Days Total:</b> <b>${ov.sum5DaysDms} DMs</b> ➔ 🎯 <b>${ov.sum5DaysJoins} Joins</b>\n` +
                    `⚡ <b>Daily Average:</b> <b>${ov.avgPerDayDms} DMs/day</b>\n` +
                    `👑 <b>Lifetime Total Sent:</b> <b>${ov.lifetimeDms} DMs</b>\n\n`;
          if (ov.stats5Days.length > 0) {
            msg += `📅 <b>Last 5 Days Activity Breakdown:</b>\n`;
            ov.stats5Days.slice(0, 5).forEach((d: any, idx: number) => {
              const jCount = ov.joins5Days[idx]?.join_count || 0;
              msg += `  • <code>${formatDisplayDate(d.date)}</code>: <b>${d.count} DMs</b> ➔ 🎯 <b>${jCount} Joins</b>\n`;
            });
          }
          await sendTelegramMessage(botToken, chatId, msg);
          return;
        }

        if (cleanCommand === '/mybots' || cleanCommand === '/bots') {
          let msg = `📱 <b>My Connected Telegram Bots (${uAccs.length})</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\n`;
          if (uAccs.length === 0) {
            msg += `<i>No phone numbers linked yet. Add accounts from dashboard.</i>`;
          } else {
            uAccs.forEach((a: any, idx: number) => {
              const status = a.running ? '🟢 Running' : '🔴 Stopped';
              const dms = (a as any).daily_sent_count || 0;
              msg += `<b>${idx + 1}.</b> <code>${a.phone}</code> | ${status} | Today: <b>${dms} DMs</b>\n`;
            });
          }
          await sendTelegramMessage(botToken, chatId, msg);
          return;
        }

        if (cleanCommand === '/bill' || cleanCommand === '/mybill' || cleanCommand === '/khatabook' || cleanCommand === '/dues' || cleanCommand === '/due') {
          await handleCustomerBillCommand(botToken, chatId, msg, adminUser, null, matchedUser);
          return;
        }

        if (cleanCommand === '/payinfo' || cleanCommand === '/pay') {
          const uLedger = (billingStore.user_ledgers || {})[matchedUser.username] || {};
          const bal = Number(uLedger.balance_due || 0);
          const curr = (billingStore.currency || 'INR') === 'INR' ? '₹' : '$';
          const dueStr = bal > 0 ? `🔴 ${curr}${bal.toLocaleString()} Due (Pending)` : `🟢 ${curr}0 (All Paid)`;
          const range = getUserCycleDateRange(matchedUser);

          let msg = `💳 <b>Payment & Renewal Information</b>\n━━━━━━━━━━━━━━━━━━━━━━━━\n` +
                    `👤 <b>Account:</b> <code>${matchedUser.username}</code>\n` +
                    `💳 <b>Current Balance Due:</b> <b>${dueStr}</b>\n` +
                    `📅 <b>Plan Validity:</b> <code>${range.formattedRange}</code>\n` +
                    `⏳ <b>Validity Expiry:</b> <code>${formatDisplayDate(matchedUser.expiry_date)}</code>\n\n` +
                    `To renew your plan or clear pending balance, please transfer via UPI to Administrator and send payment screenshot here.\n\n` +
                    `⚡ Need help? Send <code>/bill</code> to view your full statement or contact Administrator!`;
          await sendTelegramMessage(botToken, chatId, msg);
          return;
        }

        // --- /start, /link, or deep-link /start link_<username> ---
        if (cleanCommand === '/start' || cleanCommand === '/link' || rawText.startsWith('/start link_') || rawText.startsWith('/link ')) {
          let targetUser = matchedUser;
          let targetUname = '';
          if (rawText.startsWith('/start link_')) {
            targetUname = rawText.replace('/start link_', '').trim().replace('@', '').toLowerCase();
          } else if (rawText.startsWith('/link ')) {
            targetUname = rawText.replace('/link ', '').trim().replace('@', '').toLowerCase();
          }
          if (targetUname) {
            const found = usersList.find((u: any) => u.username.toLowerCase() === targetUname);
            if (found) targetUser = found;
          }

          // Link Chat ID to the user account
          targetUser.alert_chat_id = chatId;
          targetUser.telegram_id = chatId;
          targetUser.alert_enabled = true;
          if (msg.from?.username) targetUser.telegram_username = msg.from.username;
          if (msg.from?.first_name) targetUser.telegram_name = `${msg.from.first_name || ''} ${msg.from.last_name || ''}`.trim();
          saveUsers();
          broadcastAccountUpdate(targetUser.username);
          console.log(`[USER BOT LINK SUCCESS]: Linked ${targetUser.username} with Telegram Chat ID: ${chatId} (${msg.from?.username || ''})`);

          let linkSuccessNotice = `✅ <b>Telegram Bot Connected Successfully!</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `👤 <b>User Account:</b> <code>${targetUser.username}</code>\n` +
            `🆔 <b>Linked Chat ID:</b> <code>${chatId}</code>\n` +
            `⏳ <b>Plan Expiry:</b> <code>${formatDisplayDate(targetUser.expiry_date)}</code>\n\n` +
            `⚡ <i>Your Telegram Bot is now connected to your dashboard! Live alerts, DM reports, and validity notices are active.</i>\n\n`;

          const { text: t, keyboard: k } = formatUserMenu(targetUser, uAccs);
          await sendTelegramMessage(botToken, chatId, linkSuccessNotice + t, k);
          return;
        }

        if (cleanCommand === '/status' || cleanCommand === '/menu') {
          const { text: t, keyboard: k } = formatUserMenu(matchedUser, uAccs);
          await sendTelegramMessage(botToken, chatId, t, k);
          return;
        } else if (cleanCommand === '/all' || cleanCommand === '/stats') {
          let report = `📊 <b>Accounts Summary for ${matchedUser.username}</b>\n\n`;
          uAccs.forEach((a, idx) => {
            const isLive = a.running ? '🟢 Live' : '🔴 Stopped';
            const count = (a as any).daily_extracted_count || 0;
            report += `<b>${idx + 1}.</b> <code>${a.phone}</code> | ${isLive} | <b>${count} Extracted</b>\n`;
          });
          const ownerQ = getOwnerQueueLength(matchedUser.username);
          report += `\n👥 <b>Shared Common Queue:</b> ${ownerQ} leads`;
          await sendTelegramMessage(botToken, chatId, report, [
            [{ text: '📱 Interactive Accounts Menu', callback_data: `umenu:${matchedUser.username}` }]
          ]);
          return;
        }
        return;
      }
    }

    if (update.callback_query) {
      const cb = update.callback_query;
      const callbackId = cb.id;
      const chatId = String(cb.message?.chat?.id || '');
      const msgId = cb.message?.message_id;
      const data = String(cb.data || '');

      await answerTelegramCallback(botToken, callbackId);

      // --- CUSTOMER ONBOARDING ACTIONS ---
      if (data.startsWith('cust_')) {
        await handleCustomerOnboardingCallback(botToken, chatId, cb, adminUser);
        return;
      }

      // --- ADMIN APPROVE/REJECT CUSTOMER ACCESS REQUESTS ---
      if (data.startsWith('usr_appr_plan:') || data.startsWith('usr_appr:')) {
        let reqId = '';
        let planModel = 'postpaid';
        let approvedRate = 10;
        if (data.startsWith('usr_appr_plan:')) {
          const parts = data.split(':');
          reqId = parts[1];
          planModel = parts[2] || 'postpaid';
          approvedRate = Number(parts[3]) || 10;
        } else {
          reqId = data.replace('usr_appr:', '');
        }
        await handleAdminUserRequestApproval(botToken, chatId, reqId, msgId, adminUser, planModel, approvedRate);
        return;
      }

      if (data.startsWith('adm_sub_nrate:')) {
        const reqId = data.split(':')[1];
        const r = accessRequests.find((x) => x.id === reqId);
        if (!r || r.status !== 'pending') {
          await sendTelegramMessage(botToken, chatId, '⚠️ Request is no longer pending or was not found.', null, msgId);
          return;
        }
        const { text, keyboard } = formatAdminRequestAlert(r, 'edit_rate');
        await sendTelegramMessage(botToken, chatId, text, keyboard, msgId);
        return;
      }

      if (data.startsWith('adm_set_nrate:')) {
        const parts = data.split(':');
        const reqId = parts[1];
        const rate = parseInt(parts[2], 10) || 10;
        const r = accessRequests.find((x) => x.id === reqId);
        if (!r || r.status !== 'pending') {
          await sendTelegramMessage(botToken, chatId, '⚠️ Request is no longer pending.', null, msgId);
          return;
        }
        r.rate_per_bot = rate;
        (r as any).customized_by_admin = true;
        saveAccessRequests();
        const { text, keyboard } = formatAdminRequestAlert(r);
        await sendTelegramMessage(botToken, chatId, text, keyboard, msgId);
        return;
      }

      if (data.startsWith('adm_type_nrate:')) {
        const reqId = data.split(':')[1];
        adminCustomPrompt.set(chatId, { reqId, field: 'rate' });
        await sendTelegramMessage(botToken, chatId, `💬 <b>Type Custom Rate per Bot:</b>\n\nEnter the rate in ₹ per bot per week (e.g. <code>10</code>, <code>15</code>, <code>20</code>):`);
        return;
      }

      if (data.startsWith('usr_appr_ext:')) {
        const reqId = data.replace('usr_appr_ext:', '');
        await handleAdminValidityExtensionApproval(botToken, chatId, reqId, msgId, adminUser);
        return;
      }

      if (data.startsWith('usr_appr_bots:')) {
        const reqId = data.replace('usr_appr_bots:', '');
        await handleAdminExtraBotsApproval(botToken, chatId, reqId, msgId, adminUser);
        return;
      }

      if (data.startsWith('usr_rej:')) {
        const reqId = data.replace('usr_rej:', '');
        await handleAdminUserRequestRejection(botToken, chatId, reqId, msgId);
        return;
      }

      // --- ADMIN REQUEST CUSTOMIZATION CALLBACKS ---
      if (data.startsWith('adm_sub_nbots:') || data.startsWith('adm_sub_slots:')) {
        const reqId = data.split(':')[1];
        const r = accessRequests.find((x) => x.id === reqId);
        if (!r || r.status !== 'pending') {
          await sendTelegramMessage(botToken, chatId, '⚠️ Request is no longer pending or was not found.', null, msgId);
          return;
        }
        const { text, keyboard } = formatAdminRequestAlert(r, 'edit_bots');
        await sendTelegramMessage(botToken, chatId, text, keyboard, msgId);
        return;
      }

      if (data.startsWith('adm_sub_ndays:') || data.startsWith('adm_sub_ext:')) {
        const reqId = data.split(':')[1];
        const r = accessRequests.find((x) => x.id === reqId);
        if (!r || r.status !== 'pending') {
          await sendTelegramMessage(botToken, chatId, '⚠️ Request is no longer pending or was not found.', null, msgId);
          return;
        }
        const { text, keyboard } = formatAdminRequestAlert(r, 'edit_days');
        await sendTelegramMessage(botToken, chatId, text, keyboard, msgId);
        return;
      }

      if (data.startsWith('adm_set_nbots:') || data.startsWith('adm_set_slots:')) {
        const parts = data.split(':');
        const reqId = parts[1];
        const count = parseInt(parts[2], 10) || 1;
        const r = accessRequests.find((x) => x.id === reqId);
        if (!r || r.status !== 'pending') {
          await sendTelegramMessage(botToken, chatId, '⚠️ Request is no longer pending.', null, msgId);
          return;
        }
        r.bots_count = count;
        (r as any).customized_by_admin = true;
        saveAccessRequests();
        const { text, keyboard } = formatAdminRequestAlert(r);
        await sendTelegramMessage(botToken, chatId, text, keyboard, msgId);
        return;
      }

      if (data.startsWith('adm_set_ndays:') || data.startsWith('adm_set_ext:')) {
        const parts = data.split(':');
        const reqId = parts[1];
        const days = parseInt(parts[2], 10) || 30;
        const r = accessRequests.find((x) => x.id === reqId);
        if (!r || r.status !== 'pending') {
          await sendTelegramMessage(botToken, chatId, '⚠️ Request is no longer pending.', null, msgId);
          return;
        }
        r.validity_days = days;
        (r as any).customized_by_admin = true;
        saveAccessRequests();
        const { text, keyboard } = formatAdminRequestAlert(r);
        await sendTelegramMessage(botToken, chatId, text, keyboard, msgId);
        return;
      }

      if (data.startsWith('adm_type_nbots:') || data.startsWith('adm_type_slots:')) {
        const reqId = data.split(':')[1];
        adminCustomPrompt.set(chatId, { reqId, field: 'bots' });
        await sendTelegramMessage(botToken, chatId, `💬 <b>Type Custom Bots Quota:</b>\n\nPlease type the number of bots in chat (e.g. <code>2</code>, <code>5</code>, <code>10</code>, <code>25</code>):`);
        return;
      }

      if (data.startsWith('adm_type_ndays:') || data.startsWith('adm_type_ext:')) {
        const reqId = data.split(':')[1];
        adminCustomPrompt.set(chatId, { reqId, field: 'days' });
        await sendTelegramMessage(botToken, chatId, `💬 <b>Type Custom Validity Days:</b>\n\nPlease type the number of days in chat (e.g. <code>15</code>, <code>45</code>, <code>90</code>, <code>180</code>):`);
        return;
      }

      if (data.startsWith('adm_view_req:')) {
        const reqId = data.split(':')[1];
        adminCustomPrompt.delete(chatId);
        const r = accessRequests.find((x) => x.id === reqId);
        if (!r) {
          await sendTelegramMessage(botToken, chatId, '⚠️ Request not found.', null, msgId);
          return;
        }
        const { text, keyboard } = formatAdminRequestAlert(r);
        await sendTelegramMessage(botToken, chatId, text, keyboard, msgId);
        return;
      }

      // --- ADMIN ACTIONS ---
      if (data === 'adm_ctrl_refresh') {
        const keyboard = usersList.filter((u: any) => u.role !== 'admin').map((u: any) => [{ text: `👤 ${u.username}`, callback_data: `adm_ctrl_u:${u.username}` }]);
        keyboard.push([{ text: '🔄 Refresh', callback_data: 'adm_ctrl_refresh' }]);
        await sendTelegramMessage(botToken, chatId, '🎛️ <b>Admin Bot Remote Control Panel</b>\n\n👇 Select a user to manage their Telegram accounts:', keyboard, msgId);
        return;
      }

      if (data.startsWith('adm_ctrl_u:')) {
        const uname = data.split(':')[1];
        const uAccs = Array.from(accounts.values()).filter((a) => (a.owner || 'admin') === uname);
        if (uAccs.length === 0) {
          const keyboard = [[{ text: '🔙 Back to Users', callback_data: 'adm_ctrl_refresh' }]];
          await sendTelegramMessage(botToken, chatId, `⚠️ User <b>@${uname}</b> has no connected accounts.`, keyboard, msgId);
          return;
        }
        const keyboard = uAccs.map((a: any) => {
          const isLive = a.running ? '🟢' : '🔴';
          const title = `${isLive} ${a.name || a.phone}`;
          return [{ text: title, callback_data: `adm_ctrl_id:${uname}:${a.phone}` }];
        });
        keyboard.push([{ text: '🔙 Back to Users', callback_data: 'adm_ctrl_refresh' }]);
        await sendTelegramMessage(botToken, chatId, `🎛️ <b>User: @${uname}</b>\n\n👇 Select an ID to manage its Bot, DM & Live Monitoring:`, keyboard, msgId);
        return;
      }

      if (data.startsWith('adm_ctrl_id:')) {
        const parts = data.split(':');
        const uname = parts[1];
        const phone = parts[2];
        const acc = accounts.get(phone);
        if (!acc) {
          await sendTelegramMessage(botToken, chatId, `❌ Account ${phone} not found!`, [[{ text: '🔙 Back', callback_data: `adm_ctrl_u:${uname}` }]], msgId);
          return;
        }

        const isBotOn = Boolean(acc.running);
        const isDmOn = acc.dm_on !== false;
        const isLiveOn = acc.live_on !== false;

        const info = `🎛️ <b>Account Control: ${acc.name || acc.phone}</b>\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `👤 <b>Owner:</b> @${uname}\n` +
          `📱 <b>Phone:</b> <code>${acc.phone}</code>\n` +
          `🤖 <b>Bot Status:</b> ${isBotOn ? '🟢 Running' : '🔴 Stopped'}\n` +
          `💬 <b>DM Sending:</b> ${isDmOn ? '🟢 ACTIVE' : '🔴 OFF'}\n` +
          `📡 <b>Live Monitoring:</b> ${isLiveOn ? '🟢 ACTIVE' : '🔴 OFF'}\n` +
          `🎯 <b>Sent Today:</b> <b>${(acc as any).daily_extracted_count || 0} (Unlimited)</b>\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `<i>Toggle or start/stop any module below:</i>`;

        const keyboard = [
          [
            { text: isBotOn ? '⏹️ STOP Entire Bot' : '▶️ START Entire Bot', callback_data: `adm_ctrl_act:${uname}:${phone}:toggle_bot` }
          ],
          [
            { text: isDmOn ? '⏸️ Stop DM' : '▶️ Start DM', callback_data: `adm_ctrl_act:${uname}:${phone}:toggle_dm` },
            { text: isLiveOn ? '⏸️ Stop Live' : '▶️ Start Live', callback_data: `adm_ctrl_act:${uname}:${phone}:toggle_live` }
          ],
          [
            { text: '🔄 Refresh', callback_data: `adm_ctrl_id:${uname}:${phone}` },
            { text: '🔙 Back to IDs', callback_data: `adm_ctrl_u:${uname}` }
          ]
        ];

        await sendTelegramMessage(botToken, chatId, info, keyboard, msgId);
        return;
      }

      if (data.startsWith('adm_ctrl_act:')) {
        const parts = data.split(':');
        const uname = parts[1];
        const phone = parts[2];
        const action = parts[3];
        const acc = accounts.get(phone);

        if (!acc) {
          await sendTelegramMessage(botToken, chatId, `❌ Account ${phone} not found!`, null, msgId);
          return;
        }

        if (action === 'toggle_bot') {
          if (acc.running) {
            // STOP BOT
            acc.running = false;
            if (acc.abortController) {
              acc.abortController.abort();
            }
            acc.status = 'Stopped by Admin Bot';
            broadcastAccountUpdate(acc.owner || uname);
          } else {
            // START BOT
            acc.running = true;
            if (acc.live_on === undefined) acc.live_on = true;
            if (acc.dm_on === undefined) acc.dm_on = true;
            acc.status = 'Starting via Admin Bot...';
            broadcastAccountUpdate(acc.owner || uname);

            const abortController = new AbortController();
            acc.abortController = abortController;
            launchBotWorker(phone, abortController);
          }
        } else if (action === 'toggle_dm') {
          acc.dm_on = !(acc.dm_on !== false);
          broadcastAccountUpdate(acc.owner || uname);
        } else if (action === 'toggle_live') {
          acc.live_on = !(acc.live_on !== false);
          broadcastAccountUpdate(acc.owner || uname);
        }

        // Re-render the account control screen
        const isBotOn = Boolean(acc.running);
        const isDmOn = acc.dm_on !== false;
        const isLiveOn = acc.live_on !== false;

        const info = `🎛️ <b>Account Control: ${acc.name || acc.phone}</b>\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `👤 <b>Owner:</b> @${uname}\n` +
          `📱 <b>Phone:</b> <code>${acc.phone}</code>\n` +
          `🤖 <b>Bot Status:</b> ${isBotOn ? '🟢 Running' : '🔴 Stopped'}\n` +
          `💬 <b>DM Sending:</b> ${isDmOn ? '🟢 ACTIVE' : '🔴 OFF'}\n` +
          `📡 <b>Live Monitoring:</b> ${isLiveOn ? '🟢 ACTIVE' : '🔴 OFF'}\n` +
          `🎯 <b>Sent Today:</b> <b>${(acc as any).daily_extracted_count || 0} (Unlimited)</b>\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `✅ <i>Action updated successfully!</i>`;

        const keyboard = [
          [
            { text: isBotOn ? '⏹️ STOP Entire Bot' : '▶️ START Entire Bot', callback_data: `adm_ctrl_act:${uname}:${phone}:toggle_bot` }
          ],
          [
            { text: isDmOn ? '⏸️ Stop DM' : '▶️ Start DM', callback_data: `adm_ctrl_act:${uname}:${phone}:toggle_dm` },
            { text: isLiveOn ? '⏸️ Stop Live' : '▶️ Start Live', callback_data: `adm_ctrl_act:${uname}:${phone}:toggle_live` }
          ],
          [
            { text: '🔄 Refresh', callback_data: `adm_ctrl_id:${uname}:${phone}` },
            { text: '🔙 Back to IDs', callback_data: `adm_ctrl_u:${uname}` }
          ]
        ];

        await sendTelegramMessage(botToken, chatId, info, keyboard, msgId);
        return;
      }

      if (data.startsWith('admin_dm_user:')) {
        const uname = data.split(':')[1];
        const uAccs = Array.from(accounts.values()).filter((a) => (a.owner || 'admin') === uname);
        const keyboard = uAccs.map((a: any) => [{ text: a.name || a.phone, callback_data: `admin_dm_id:${a.name}` }]);
        await sendTelegramMessage(botToken, chatId, `Select an ID for ${uname}:`, keyboard, msgId);
        return;
      }
      if (data.startsWith('admin_dm_id:')) {
        const name = data.split(':')[1];
        const acc = Array.from(accounts.values()).find(a => (a.name || '') === name);
        if (acc) {
          const sent = (acc as any).daily_extracted_count || 0;
          await sendTelegramMessage(botToken, chatId, `📊 ID Name: <b>${name}</b>\n✅ Total DM Sent: <b>${sent}</b>`, [], msgId);
        } else {
          await sendTelegramMessage(botToken, chatId, `❌ Account ${name} not found!`, [], msgId);
        }
        return;
      }

      // --- USER ACTIONS ---
      if (data.startsWith('umenu:')) {
        const uname = data.split(':')[1];
        const u = getUser(uname);
        if (u) {
          const uAccs = Array.from(accounts.values()).filter((a) => (a.owner || 'admin') === u.username);
          const { text: t, keyboard: k } = formatUserMenu(u, uAccs);
          await sendTelegramMessage(botToken, chatId, t, k, msgId);
        }
        return;
      }

      if (data.startsWith('uacc:')) {
        const parts = data.split(':');
        const uname = parts[1];
        const phone = parts[2];
        const u = getUser(uname);
        const acc = accounts.get(phone);
        if (u && acc) {
          const { text: t, keyboard: k } = formatAccountDetail(u, acc, `umenu:${uname}`);
          await sendTelegramMessage(botToken, chatId, t, k, msgId);
        }
        return;
      }

      if (data.startsWith('uall:')) {
        const uname = data.split(':')[1];
        const u = getUser(uname);
        if (u) {
          const uAccs = Array.from(accounts.values()).filter((a) => (a.owner || 'admin') === u.username);
          let report = `📊 <b>Accounts Summary for ${u.username}</b>\n\n`;
          uAccs.forEach((a, idx) => {
            const isLive = a.running ? '🟢 Live' : '🔴 Stopped';
            const count = (a as any).daily_extracted_count || 0;
            report += `<b>${idx + 1}.</b> <code>${a.phone}</code> | ${isLive} | <b>${count} Extracted</b>\n`;
          });
          const ownerQ = getOwnerQueueLength(u.username);
          report += `\n👥 <b>Shared Common Queue:</b> ${ownerQ} leads`;
          await sendTelegramMessage(botToken, chatId, report, [
            [{ text: '🔙 Back to Accounts List', callback_data: `umenu:${u.username}` }]
          ], msgId);
        }
        return;
      }

      // --- ADMIN ACTIONS ---
      
      if (data.startsWith('gemini_rep:')) {
        const days = parseInt(data.split(':')[1], 10);
        const { text: t, keyboard: k } = formatGeminiReport(days);
        await sendTelegramMessage(botToken, chatId, t, k, msgId);
        return;
      }

      if (data === 'adm_main') {
        const { text: t, keyboard: k } = formatAdminMenu();
        await sendTelegramMessage(botToken, chatId, t, k, msgId);
        return;
      }

      if (data === 'adm_exp:all') {
        const { text: t, keyboard: k } = formatAdminExpiryList();
        await sendTelegramMessage(botToken, chatId, t, k, msgId);
        return;
      }

      if (data === 'adm_vps_health') {
        const { text: t, keyboard: k } = await formatVpsStatusMessage();
        await sendTelegramMessage(botToken, chatId, t, k, msgId);
        return;
      }

      if (data.startsWith('adm_u:')) {
        const uname = data.split(':')[1];
        const u = getUser(uname);
        if (u) {
          const { text: t, keyboard: k } = formatAdminUserView(u);
          await sendTelegramMessage(botToken, chatId, t, k, msgId);
        }
        return;
      }

      if (data.startsWith('adm_acc:')) {
        const parts = data.split(':');
        const uname = parts[1];
        const phone = parts[2];
        const u = getUser(uname);
        const acc = accounts.get(phone);
        if (u && acc) {
          const { text: t, keyboard: k } = formatAccountDetail(u, acc, `adm_u:${uname}`);
          await sendTelegramMessage(botToken, chatId, t, k, msgId);
        }
        return;
      }

      if (data.startsWith('slot_appr:')) {
        const reqId = data.replace('slot_appr:', '');
        const reqItem = slotRequests.find((r) => r.id === reqId);
        if (!reqItem) {
          await sendTelegramMessage(botToken, chatId, '⚠️ Request not found or already processed.', null, msgId);
          return;
        }
        if (reqItem.status !== 'pending') {
          await sendTelegramMessage(botToken, chatId, `ℹ️ Request for <code>${reqItem.phone}</code> is already <b>${reqItem.status.toUpperCase()}</b>.`, null, msgId);
          return;
        }
        reqItem.status = 'approved';
        reqItem.resolved_at = Date.now();
        reqItem.resolved_by = 'Master Telegram Bot';
        saveSlotRequests();

        const u = getUser(reqItem.username);
        if (u) {
          u.max_accounts = Math.max((u.max_accounts || 5) + 1, (u.registered_phones?.length || 0) + 1);
          if (!Array.isArray(u.registered_phones)) u.registered_phones = [];
          if (!u.registered_phones.includes(reqItem.phone)) {
            u.registered_phones.push(reqItem.phone);
          }
          saveUsers();
          broadcastAccountUpdate(u.username);
          if (u.alert_enabled) {
            sendTelegramAlert(u.username, `🎉 <b>Admin Approved Your Account Slot Request!</b>\nSuper Admin approved your request for <code>${reqItem.phone}</code>.\nYou can now connect this Telegram ID in your dashboard!`);
          }
        }

        const approvedMsg = `✅ <b>Account Slot APPROVED!</b>\n\n` +
          `👤 <b>User:</b> <code>${reqItem.username}</code>\n` +
          `📱 <b>Phone:</b> <code>${reqItem.phone}</code>\n` +
          `📊 <b>Updated Limit:</b> ${u?.max_accounts || 0} Slots\n` +
          `🕒 <i>Approved via Telegram Master Bot at ${new Date().toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata' })} (IST)</i>`;

        await sendTelegramMessage(botToken, chatId, approvedMsg, null, msgId);
        broadcastAccountUpdate('admin');
        return;
      }

      if (data.startsWith('slot_rej:')) {
        const reqId = data.replace('slot_rej:', '');
        const reqItem = slotRequests.find((r) => r.id === reqId);
        if (!reqItem) {
          await sendTelegramMessage(botToken, chatId, '⚠️ Request not found or already processed.', null, msgId);
          return;
        }
        if (reqItem.status !== 'pending') {
          await sendTelegramMessage(botToken, chatId, `ℹ️ Request for <code>${reqItem.phone}</code> is already <b>${reqItem.status.toUpperCase()}</b>.`, null, msgId);
          return;
        }
        reqItem.status = 'rejected';
        reqItem.resolved_at = Date.now();
        reqItem.resolved_by = 'Master Telegram Bot';
        saveSlotRequests();

        const u = getUser(reqItem.username);
        if (u && u.alert_enabled) {
          sendTelegramAlert(u.username, `❌ <b>Slot Request Rejected</b>\nAdmin has rejected your request to add <code>${reqItem.phone}</code>.`);
        }

        const rejectedMsg = `❌ <b>Account Slot REJECTED</b>\n\n` +
          `👤 <b>User:</b> <code>${reqItem.username}</code>\n` +
          `📱 <b>Phone:</b> <code>${reqItem.phone}</code>\n` +
          `🕒 <i>Rejected at ${new Date().toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata' })} (IST)</i>`;

        await sendTelegramMessage(botToken, chatId, rejectedMsg, null, msgId);
        broadcastAccountUpdate('admin');
        return;
      }
    }
  } catch (err) {
    console.error('[TELEGRAM UPDATE HANDLER ERROR]:', err);
  }
}

// Global Poller that polls all configured Telegram Bot Tokens seamlessly in the background
let telegramPollerActive = false;
const verifiedPollerBotWebhooks = new Set<string>();

async function startTelegramPollerLoop() {
  if (telegramPollerActive) return;
  telegramPollerActive = true;

  while (true) {
    try {
      // Gather all unique active bot tokens from usersList (alerts & filter bots), master config, accounts, and bots vault
      const tokens = new Set<string>();
      for (const u of usersList) {
        const tok = (u.alert_bot_token || '').trim();
        if (tok) tokens.add(tok);
        const filterTok = (u.master_config?.filter_bot_token || (u as any).filter_bot_token || '').trim();
        if (filterTok) tokens.add(filterTok);
        const masterAlert = (u.master_config?.alert_bot_token || '').trim();
        if (masterAlert) tokens.add(masterAlert);
      }

      // Check all accounts configs
      for (const a of accounts.values()) {
        const aFilter = (a.config?.filter_bot_token || '').trim();
        if (aFilter) tokens.add(aFilter);
        const aAlert = (a.config?.alert_bot_token || '').trim();
        if (aAlert) tokens.add(aAlert);
      }

      // Check admin master config filter bot token
      const adminMasterFilter = (getUser('admin')?.master_config?.filter_bot_token || '').trim();
      if (adminMasterFilter) tokens.add(adminMasterFilter);

      // Check bots vault tokens
      for (const b of botsVault) {
        if (b.token && b.token.trim()) {
          tokens.add(b.token.trim());
        }
      }

      for (const token of tokens) {
        // Clear conflicting webhooks once with await so getUpdates never encounters 409 Conflict
        if (!verifiedPollerBotWebhooks.has(token)) {
          try {
            await fetch(`https://api.telegram.org/bot${token}/deleteWebhook?drop_pending_updates=false`, {
              signal: AbortSignal.timeout(3000)
            }).catch(() => null);
            verifiedPollerBotWebhooks.add(token);
          } catch (e) {}
        }

        registerTelegramBotCommands(token).catch(() => null);
        try {
          const currentOffset = botPollOffsets.get(token) || 0;
          const url = `https://api.telegram.org/bot${token}/getUpdates?offset=${currentOffset}&timeout=2&limit=25&allowed_updates=${encodeURIComponent('["message","callback_query","chat_join_request","chat_member","my_chat_member"]')}`;
          const res = await fetch(url, { method: 'GET', signal: AbortSignal.timeout(3500) }).catch(() => null);
          if (!res) continue;
          const json = await res.json().catch(() => null);

          if (json?.error_code === 409) {
            // Webhook conflict detected dynamically! Delete webhook and retry next cycle
            await fetch(`https://api.telegram.org/bot${token}/deleteWebhook?drop_pending_updates=false`, {
              signal: AbortSignal.timeout(3000)
            }).catch(() => null);
          }

          if (json?.ok && Array.isArray(json.result)) {
            for (const upd of json.result) {
              const updId = upd.update_id;
              botPollOffsets.set(token, updId + 1);
              await handleTelegramUpdate(token, upd);
            }
          }
        } catch (e) {
          // Ignore individual network blips
        }
      }
    } catch (err) {
      console.error('[GLOBAL TELEGRAM POLLER ERROR]:', err);
    }
    await new Promise((r) => setTimeout(r, 2000));
  }
}

// ---------------- START SERVER ----------------
// Load local primary cache instantly
loadUsersLocal();
ensureAdminUser();
loadAccountsLocal();
loadSlotRequestsLocal();
loadAccessRequestsLocal();
loadApiPoolLocal();
loadBotsVaultLocal();
loadChannelReactionsLocal();

// Bind and listen immediately on port
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server listening on port ${PORT}`);
  console.log(`Dashboard: http://0.0.0.0:${PORT}`);
  console.log(`Admin Panel: http://0.0.0.0:${PORT}/admin`);
});

(async () => {
  try {
    await loadUsers();
    await loadAccounts();
    syncUserRegisteredPhones();
    await loadSlotRequests();
    await loadAccessRequests();
    await loadApiPool();
    autoSyncAllUsersIntoBilling();
    console.log('[STARTUP KHATABOOK]: Auto-synced all existing users and bot owners into Khatabook ledger.');
  } catch (err) {
    console.error('[STARTUP BACKGROUND SYNC]:', err);
  }

  // Start background bot listener & midnight/expiry automations
  startTelegramPollerLoop();
  startMidnightAndExpirySchedulerLoop();
  startChannelReactionMonitorLoop();
  startGrowthBotPoller();

  // 🛡️ UNINTERRUPTED AUTO-RESUME: Automatically restart all bots that were running before server/PM2 restart!
  autoResumeRunningBotsOnStartup().catch((err) => {
    console.error('[AUTO-RESUME ERROR]:', err);
  });
})();


//# sourceURL=file:///app/applet/server.ts