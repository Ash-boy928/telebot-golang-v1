import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
// Root directory of the applet
export const ROOT_DIR = path.resolve(__dirname, '../../');

export const PORT = Number(process.env.PORT) || 3000;

const ADMIN_INIT_FILE = path.join(ROOT_DIR, '.admin_secret');
function getInitialAdminPassword(): string {
  if (process.env.ADMIN_PASSWORD && process.env.ADMIN_PASSWORD.trim()) {
    return process.env.ADMIN_PASSWORD.trim();
  }
  try {
    if (fs.existsSync(ADMIN_INIT_FILE)) {
      const stored = fs.readFileSync(ADMIN_INIT_FILE, 'utf8').trim();
      if (stored) return stored;
    }
    const gen = crypto.randomBytes(12).toString('base64url');
    fs.writeFileSync(ADMIN_INIT_FILE, gen, { mode: 0o600 });
    return gen;
  } catch {
    return crypto.randomBytes(12).toString('base64url');
  }
}

export const ADMIN_PASSWORD = getInitialAdminPassword();

export const USERS_FILE = path.join(ROOT_DIR, 'users.json');
export const ACCOUNTS_FILE = path.join(ROOT_DIR, 'accounts.json');
export const SECRET_KEY_FILE = path.join(ROOT_DIR, 'secret.key');
export const MASTER_PROXY_FILE = path.join(ROOT_DIR, 'proxy_config.json');
export const THEME_CONFIG_FILE = path.join(ROOT_DIR, 'theme_config.json');
export const SQLITE_DB_FILE = path.join(ROOT_DIR, 'telebot.db');
export const BILLING_FILE = path.join(ROOT_DIR, 'billing.json');
export const ACCESS_REQUESTS_FILE = path.join(ROOT_DIR, 'access_requests.json');
export const GLOBAL_AI_CONFIG_FILE = path.join(ROOT_DIR, 'global_ai_config.json');

/**
 * Universal timeout wrapper to prevent hanging promises or deadlocks
 */
export function withTimeout<T>(promise: Promise<T>, timeoutMs: number = 20000, errorMsg: string = 'Operation timed out'): Promise<T> {
  let timer: any;
  const timeoutPromise = new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(new Error(errorMsg)), timeoutMs);
  });
  return Promise.race([promise, timeoutPromise]).finally(() => {
    if (timer) clearTimeout(timer);
  });
}
