# 📱 Product Requirement Document (PRD)
# 🚀 Decentralized Mobile Architecture: Leo TeleBot (Customer Mobile Node + Central Admin Licensing VPS)

---

## 1. Executive Summary & Vision

### 1.1. Problem Statement (Current VPS Centralized Model Bottleneck)
In the current architecture, all 23+ Telegram user accounts run inside a single Node.js process (`server.ts` via GramJS MTProto) on an Ubuntu VPS.
* **RAM & CPU Exhaustion**: 23 active accounts currently consume **3.5 GB – 5.5 GB RAM**. At 50–100 customers (each with 5–10 accounts), the VPS requires hundreds of gigabytes of RAM and massive multi-core CPUs, making server hosting economically unviable.
* **IP & Proxy Bans**: Telegram aggressively rate-limits or bans datacenter IPs. The VPS requires costly sticky residential mobile proxies.
* **Single Point of Failure**: If the VPS restarts, drops connection, or hits OOM killer, all customers' bots stop simultaneously.

### 1.2. The Solution: Decentralized Mobile-First Architecture
Transform the system into a **Decentralized Mobile Node Architecture**:
* **Customer Mobile Device (The Worker Node)**:
  - Runs as an Android App (Flutter with native background foreground service / embedded MTProto engine).
  - Uses the **Customer's own Mobile RAM, CPU, and Storage (SQLite/Hive)**.
  - Uses the **Customer's own 4G/5G residential mobile IP**, completely eliminating the need for expensive rotating proxies and preventing Telegram IP bans.
* **Admin VPS (The Central Licensing, Policy & Telemetry Hub)**:
  - VPS **DOES NOT** run any customer Telegram clients.
  - VPS memory consumption drops from 5.5 GB to **< 200 MB**.
  - Responsibilities: **Customer Licensing (7-day billing cycle)**, **Remote Configuration (OTA Config Push)**, **In-App Auto Updates**, **Master Admin Control**, and **Real-Time Telemetry/Heartbeat**.
  - **Dynamic Remote Config**: When Admin updates message templates, channel links, spam filters, or delay settings on the VPS dashboard, every customer's mobile app automatically syncs and applies changes in real-time without app reinstallation.

---

## 2. High-Level Architecture Diagram

```
┌────────────────────────────────────────────────────────────────────────┐
│                   ADMIN CLOUD VPS (LIGHTWEIGHT ENGINE)                 │
│                 (RAM: <200 MB | Runs Admin Console Only)               │
│                                                                        │
│   • Admin Dashboard & User Management (`admin.html`)                   │
│   • 7-Day Billing, Ledger & Auto-Reminder Engine                       │
│   • Dynamic Remote Config & Blacklist Rule Server                      │
│   • Mobile App Versioning & OTA Auto-Update Server                     │
│   • License Verification & Kill-Switch Controller                      │
│   • Aggregated Telemetry Database (SQLite / KV Store)                  │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
                  HTTPS REST API + WSS / Heartbeat (Auth Bearer Token)
                                    │
         ┌──────────────────────────┴──────────────────────────┐
         ▼                                                     ▼
┌───────────────────────────────────┐ ┌───────────────────────────────────┐
│     CUSTOMER A MOBILE DEVICE      │ │     CUSTOMER B MOBILE DEVICE      │
│     (Android / Flutter App)       │ │     (Android / Flutter App)       │
│                                   │ │                                   │
│  ┌─────────────────────────────┐  │ │  ┌─────────────────────────────┐  │
│  │   FOREGROUND SERVICE WORKER │  │ │  │   FOREGROUND SERVICE WORKER │  │
│  │   (Keeps running 24/7)      │  │ │  │   (Keeps running 24/7)      │  │
│  │ • MTProto Telegram Engine   │  │ │  │ • MTProto Telegram Engine   │  │
│  │ • Voice Stream Audio Scanner│  │ │  │ • Voice Stream Audio Scanner│  │
│  │ • Raw -> Verified Filter    │  │ │  │ • Raw -> Verified Filter    │  │
│  │ • Anti-Ban DM Dispatcher    │  │ │  │ • Anti-Ban DM Dispatcher    │  │
│  │ • Cloud Contacts Locker     │  │ │  │ • Cloud Contacts Locker     │  │
│  │ • Local SQLite / Hive Store │  │ │  │ • Local SQLite / Hive Store │  │
│  └──────────────┬──────────────┘  │ │  └──────────────┬──────────────┘  │
│                 │                 │ │                 │                 │
│                 ▼                 │ │                 ▼                 │
│      Customer Mobile 4G/5G IP     │ │      Customer Mobile 4G/5G IP     │
│   (Direct to Telegram DC Servers) │ │   (Direct to Telegram DC Servers) │
└───────────────────────────────────┘ └───────────────────────────────────┘
```

---

## 3. Component Breakdown & Specifications

### 3.1. Customer Mobile App (The Client Worker Node)

* **Platform**: Android (APK) using Flutter (cross-platform with native Android Foreground Service).
* **Storage**: Encrypted local storage using `flutter_secure_storage` + SQLite (`sqflite`) / Hive for queues, sent records, and peer cache.
* **Network & Battery Optimization**:
  - Uses `flutter_background_service` with a persistent Android Notification ("LeoBot Active: Monitoring & DM Delivery running").
  - `WakeLock` and `Battery Optimization Whitelist` prompt upon first install to prevent Android OS Doze Mode from killing the background worker.
* **Core Mobile Modules (Ported from `server.ts`)**:
  1. **Account Session Manager**:
     - Stores encrypted Telegram `StringSession` locally on device.
     - Native OTP Code and 2FA Password input dialogs.
     - Multi-account switcher (Run 5 to 20 accounts concurrently on the phone).
  2. **Live Voice Chat & Audio Stream Listener**:
     - Connects directly to Telegram DC from the phone's mobile connection.
     - Scans channel voice chats for genuine active listeners.
  3. **Node Filter & Qualification**:
     - Runs bio regex filters, admin detection, bot detection locally.
     - Executes `lockContactPermanently` directly from the device to capture permanent access hashes.
  4. **DM Queue & Safe Dispatcher**:
     - Sends DMs using local phone network with spintax rotation and randomized jitter intervals (45s–90s).
     - Tracks daily sent quota per account with automatic 00:00 midnight reset.
  5. **Auto-Config Sync Client**:
     - Background polling (every 60 seconds) or persistent WebSocket to VPS.
     - If Admin changes Message 1, Message 2, Channel Link, or blacklist on VPS, Mobile app immediately hot-updates without restarting.

---

### 3.2. Admin Cloud VPS (Licensing & Remote Control Hub)

* **Runtime**: Node.js 22 LTS / Express / SQLite (`telebot.db`).
* **Resource Consumption**: < 200 MB RAM, < 5% CPU (No Telegram MTProto clients run here).
* **Core Responsibilities**:
  1. **Authentication & Mobile Device Binding**:
     - Issues JWT Access Token upon mobile login.
     - Binds Customer account to device hardware ID (Android ID) to prevent account sharing.
  2. **7-Day Billing Cycle & License Enforcement**:
     - Manages user subscription cycle (Day 1 to Day 7).
     - Day 6: Sends gentle reminder notification (no amount mentioned).
     - Day 7: Calculates exact `balance_due` and delivers urgent bill reminder.
     - Day 8 (If unpaid): Remote **Kill Switch** fires. When mobile app queries `/api/v1/license/verify`, server returns `{ active: false, reason: "Subscription expired" }`. The mobile app immediately pauses all background dispatch loops.
  3. **Remote Configuration Engine (OTA Strategy Push)**:
     - Endpoints provide campaign templates, target channels, spintax variations, blacklist keywords.
     - Admin updates config on Web Dashboard -> VPS pushes payload to all connected mobile clients.
  4. **In-App Code Auto-Update (OTA APK Updater)**:
     - Admin uploads new APK or code patch to VPS.
     - VPS exposes `/api/v1/app/check-update`.
     - Mobile app checks on boot; if `remote_version > current_version`, displays in-app update progress and installs automatically.
  5. **Telemetry Aggregator**:
     - Mobile devices send lightweight heartbeat ping every 2 minutes:
       `{ phone_count: 5, active_bots: 4, today_sent_dms: 120, today_joins: 35, battery_level: 82% }`.
     - Admin sees complete live fleet analytics across all customers in `admin.html`.

---

## 4. REST API Specification (Mobile App <-> VPS)

### 4.1. Authentication & Licensing
* **`POST /api/v1/mobile/login`**
  - **Request**: `{ username: "client1", password: "securepassword", device_id: "android_uuid_123" }`
  - **Response**: `{ token: "jwt_token", expires_at: 1728349200, license: { active: true, expiry_date: "2026-10-14", days_left: 7 } }`

* **`GET /api/v1/mobile/license/heartbeat`**
  - **Header**: `Authorization: Bearer <jwt_token>`
  - **Request**: `{ device_id: "android_uuid_123", stats: { sent_today: 45, joins_today: 12, running_accounts: 3 } }`
  - **Response**: `{ active: true, kill_switch: false, remote_config_hash: "v2.1" }`
  - *(If subscription expired: `{ active: false, kill_switch: true, error_msg: "7-Day Billing cycle expired. Please clear dues." }`)*

### 4.2. Dynamic Remote Configuration (Zero-App-Update Config Sync)
* **`GET /api/v1/mobile/config/sync`**
  - **Response**:
    ```json
    {
      "config_version": "2026.10.07.1",
      "target_channels": ["@crypto_live_stream", "@stock_market_audio"],
      "channel_link": "https://t.me/+AbCdEfGh123",
      "message_templates": [
        "Hey {NAME}, join our live trading call here: {CHANNEL_LINK}",
        "Namaste {NAME}! Special VIP audio stream active: {CHANNEL_LINK}",
        "Hello {NAME}, live market analysis is ongoing: {CHANNEL_LINK}"
      ],
      "delays": { "min_seconds": 45, "max_seconds": 90 },
      "blacklist_keywords": ["gambling", "teenpatti", "color prediction", "scam"],
      "safe_daily_limit_per_account": 35
    }
    ```

### 4.3. In-App Auto-Update (OTA APK)
* **`GET /api/v1/mobile/app/version`**
  - **Response**:
    ```json
    {
      "latest_version_code": 105,
      "latest_version_name": "1.0.5",
      "mandatory_update": false,
      "apk_download_url": "https://your-vps-domain.com/downloads/telebot-1.0.5.apk",
      "release_notes": "Added improved voice stream participant detection and 30% battery saver mode."
    }
    ```

---

## 5. Codebase Migration Matrix (What Stays on VPS vs What Moves to Mobile)

| Existing Feature in `server.ts` | Old Location (VPS) | New Location | Reason |
| :--- | :--- | :--- | :--- |
| **GramJS TelegramClient Connections** | VPS (Heavy RAM) | **Mobile App** (Local Phone RAM) | Eliminates VPS RAM bottleneck; utilizes mobile 4G IP. |
| **Live Stream Voice Chat Scraper** | VPS | **Mobile App** | Directly scrapes via phone socket; zero VPS network usage. |
| **DM Queue & Sending Loops** | VPS | **Mobile App** | Prevents IP ban; runs on customer's own device network. |
| **Session String & Auth Storage** | VPS (`accounts.json`) | **Mobile App** (`SecureStorage`) | Protects customer account privacy; prevents VPS DB leak. |
| **7-Day Billing & Ledger Engine** | VPS | **VPS (Admin Server)** | Centralized billing authority; enforces subscriptions. |
| **Auto 6th/7th Day Reminders** | VPS | **VPS (Admin Server)** | Delivers reminders via Telegram Master Bot to customer chat. |
| **Remote Strategy & Config Engine** | VPS | **VPS (Master) -> Mobile (Sync)** | Allows Admin to push templates & channel links dynamically. |
| **Admin Control Dashboard (`admin.html`)**| VPS | **VPS (Web)** | Accessible via any browser on mobile/desktop by Super Admin. |

---

## 6. Security, Anti-Tamper & Battery Management

1. **Android Battery Optimization Whitelist**:
   - The app uses `Android Intent: ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` during onboarding so Samsung, Xiaomi, and OnePlus battery killers do not kill background DM dispatching.
2. **Foreground Notification Service**:
   - Android requires a persistent status bar notification for background sockets. The notification displays live stats: `LeoBot Active: 124 DMs Sent Today | 4 Accounts Online`.
3. **Hardware Device Binding**:
   - Every user account is tied to their Android device ID. A customer cannot share credentials with other people without Admin's approval.
4. **Offline Grace Period**:
   - If customer loses internet briefly, the app caches DMs and continues gracefully. However, if offline for > 24 hours without license verification ping to VPS, the app pauses dispatch until re-verified.

---

## 7. Implementation Roadmap

### Phase 1: VPS Lightweight Transformation (Days 1–3)
* Extract Remote Config Sync & Mobile Heartbeat endpoints into VPS backend.
* Decouple customer GramJS bot initialization from VPS startup.
* Retain Admin Web Dashboard (`admin.html`), Billing Engine, and License Controller.

### Phase 2: Flutter Mobile App Core & Background Service (Days 4–8)
* Build Flutter UI (Accounts Fleet, Live Logs, Status Cards).
* Implement Android Foreground Service (`flutter_background_service`) with wake lock.
* Port GramJS MTProto client engine to run locally on mobile (via Dart MTProto / embedded JS engine / Native Java-Kotlin wrapper).

### Phase 3: Dynamic Sync & Remote Kill-Switch (Days 9–12)
* Implement Auto-Config Sync (WebSocket / 60s Polling) for live message templates and target channels.
* Implement License Heartbeat and 7-day expiration kill switch.
* Implement In-App OTA APK Auto-Update download and install flow.

### Phase 4: Production Field Testing (Days 13–15)
* 48-hour continuous battery drain and background stability test on Android 12, 13, and 14.
* Verify 20+ accounts running simultaneously on a single Android phone without OS termination.
* Deployment of lightweight Admin VPS.
