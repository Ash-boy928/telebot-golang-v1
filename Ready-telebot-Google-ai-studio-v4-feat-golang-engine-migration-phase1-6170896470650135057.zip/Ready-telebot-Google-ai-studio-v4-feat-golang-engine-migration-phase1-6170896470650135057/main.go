package main

import (
	"log"

	"go-telebot/pkg/api"
	"go-telebot/pkg/config"
	"go-telebot/pkg/db"
	"go-telebot/pkg/security"
	"go-telebot/pkg/services/growth"
)

func main() {
	log.Println("Starting Telebot High-Performance Golang Engine...")

	// 1. Enforce Linux file permissions (chmod 600)
	security.EnforceSecureFilePermissions()

	// 2. Initialize Pure-Go SQLite WAL Database Engine
	if err := db.InitDB(); err != nil {
		log.Fatalf("Database initialization failed: %v", err)
	}
	defer db.CloseDB()

	// 3. Start Growth Engine Poller
	growth.StartGrowthEnginePoller()

	// 4. Setup Gin HTTP Router and Start HTTP Server
	router := api.SetupRouter()
	port := config.GetPort()

	log.Printf("Golang Engine running on http://0.0.0.0:%s", port)
	if err := router.Run(":" + port); err != nil {
		log.Fatalf("Server failed to start: %v", err)
	}
}
